import { Outlet } from "react-router";
import '../../styles/layouts.css';

export function RootProviders() {
  return (
    <div className="ds-root-layout">
      <Outlet />
    </div>
  );
}
