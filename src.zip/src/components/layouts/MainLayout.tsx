import { type ReactNode } from 'react';
import '../../styles/layouts.css';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="ds-main-layout">
      {/* Top Header Bar */}
      <div className="ds-main-layout__header">
        <div className="ds-main-layout__logo">
          <div className="ds-main-layout__logo-inner">
            <span className="ds-main-layout__logo-text">SONAR</span>
          </div>
        </div>
        <div className="ds-main-layout__actions" />
      </div>

      {/* Main Content Area */}
      <div className="ds-main-layout__content">
        <main className="ds-main-layout__main">
          {children}
        </main>
      </div>
    </div>
  );
}