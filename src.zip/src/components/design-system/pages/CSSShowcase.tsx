/**
 * CSS Showcase
 * =============
 * A living catalog of all CSS design tokens, utility classes, and component classes.
 * Route: /css-showcase
 */
import React, { useState } from 'react';
import Box from '@mui/material/Box';
import MuiDivider from '@mui/material/Divider';

/* ─── Section wrapper ─── */
function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <Box id={id} sx={{ mb: 6, scrollMarginTop: '80px' }}>
      <Box sx={{ fontSize: 20, fontWeight: 600, color: '#111827', mb: 2 }}>{title}</Box>
      <MuiDivider sx={{ mb: 3 }} />
      {children}
    </Box>
  );
}

/* ─── Color swatch ─── */
function Swatch({ name, value, textColor = '#fff' }: { name: string; value: string; textColor?: string }) {
  return (
    <Box sx={{ textAlign: 'center', minWidth: 80 }}>
      <Box
        sx={{
          width: 64,
          height: 64,
          borderRadius: '8px',
          backgroundColor: value,
          border: '1px solid #e5e7eb',
          mx: 'auto',
          mb: 0.5,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 9,
          color: textColor,
          fontFamily: 'monospace',
        }}
      >
        {value}
      </Box>
      <Box sx={{ fontSize: 10, color: '#6b7280', fontFamily: 'monospace' }}>{name}</Box>
    </Box>
  );
}

/* ─── Token row ─── */
function TokenRow({ token, value, preview }: { token: string; value: string; preview?: React.ReactNode }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 0.75, borderBottom: '1px solid #f3f4f6', fontSize: 12 }}>
      <Box sx={{ width: 240, fontFamily: 'monospace', color: '#0052FF', fontWeight: 500, flexShrink: 0 }}>{token}</Box>
      <Box sx={{ width: 200, fontFamily: 'monospace', color: '#6b7280', flexShrink: 0 }}>{value}</Box>
      {preview && <Box sx={{ flex: 1 }}>{preview}</Box>}
    </Box>
  );
}

/* ─── Class demo ─── */
function ClassDemo({ className, label, children }: { className: string; label: string; children?: React.ReactNode }) {
  return (
    <Box sx={{ mb: 2 }}>
      <Box sx={{ fontSize: 11, fontFamily: 'monospace', color: '#0052FF', mb: 0.5 }}>.{label}</Box>
      <Box className={className}>{children || <Box sx={{ p: 1.5 }}>Example content</Box>}</Box>
    </Box>
  );
}

/* ═══════════════════════════════════════════════════════
   DATA
   ═══════════════════════════════════════════════════════ */

const brandColors = [
  { name: '--ds-brand-primary', value: '#0052FF' },
  { name: '--ds-brand-primary-hover', value: '#003ACC' },
  { name: '--ds-brand-primary-light', value: '#005587' },
  { name: '--ds-brand-primary-dark', value: '#003057' },
  { name: '--ds-brand-navy', value: '#0A1C3F' },
];

const grayScale = [
  { name: '50', value: '#f9fafb', textColor: '#111' },
  { name: '100', value: '#f3f4f6', textColor: '#111' },
  { name: '200', value: '#e5e7eb', textColor: '#111' },
  { name: '300', value: '#d1d5db', textColor: '#111' },
  { name: '400', value: '#9ca3af', textColor: '#fff' },
  { name: '500', value: '#6b7280', textColor: '#fff' },
  { name: '600', value: '#4b5563', textColor: '#fff' },
  { name: '700', value: '#374151', textColor: '#fff' },
  { name: '800', value: '#1f2937', textColor: '#fff' },
  { name: '900', value: '#111827', textColor: '#fff' },
];

const semanticColors = [
  { name: 'Success', value: '#10b981' },
  { name: 'Warning', value: '#f59e0b' },
  { name: 'Error', value: '#ef4444' },
  { name: 'Info', value: '#3b82f6' },
];

const blueScale = [
  { name: '50', value: '#eff6ff', textColor: '#111' },
  { name: '100', value: '#dbeafe', textColor: '#111' },
  { name: '200', value: '#bfdbfe', textColor: '#111' },
  { name: '300', value: '#93c5fd', textColor: '#111' },
  { name: '400', value: '#60a5fa', textColor: '#fff' },
  { name: '500', value: '#3b82f6', textColor: '#fff' },
  { name: '600', value: '#2563eb', textColor: '#fff' },
  { name: '700', value: '#1d4ed8', textColor: '#fff' },
  { name: '800', value: '#1e40af', textColor: '#fff' },
  { name: '900', value: '#1e3a5f', textColor: '#fff' },
];

const redScale = [
  { name: '50', value: '#fef2f2', textColor: '#111' },
  { name: '100', value: '#fee2e2', textColor: '#111' },
  { name: '200', value: '#fecaca', textColor: '#111' },
  { name: '500', value: '#ef4444', textColor: '#fff' },
  { name: '600', value: '#dc2626', textColor: '#fff' },
  { name: '700', value: '#b91c1c', textColor: '#fff' },
];

const greenScale = [
  { name: '50', value: '#f0fdf4', textColor: '#111' },
  { name: '100', value: '#dcfce7', textColor: '#111' },
  { name: '500', value: '#22c55e', textColor: '#fff' },
  { name: '600', value: '#16a34a', textColor: '#fff' },
  { name: '700', value: '#15803d', textColor: '#fff' },
];

const emeraldScale = [
  { name: '50', value: '#ecfdf5', textColor: '#111' },
  { name: '100', value: '#d1fae5', textColor: '#111' },
  { name: '500', value: '#10b981', textColor: '#fff' },
  { name: '600', value: '#059669', textColor: '#fff' },
  { name: '700', value: '#047857', textColor: '#fff' },
];

const amberScale = [
  { name: '50', value: '#fffbeb', textColor: '#111' },
  { name: '100', value: '#fef3c7', textColor: '#111' },
  { name: '500', value: '#f59e0b', textColor: '#fff' },
  { name: '600', value: '#d97706', textColor: '#fff' },
  { name: '700', value: '#b45309', textColor: '#fff' },
];

const spacingTokens = [
  { token: '--ds-space-0', value: '0px' },
  { token: '--ds-space-0.5', value: '2px' },
  { token: '--ds-space-1', value: '4px' },
  { token: '--ds-space-1.5', value: '6px' },
  { token: '--ds-space-2', value: '8px' },
  { token: '--ds-space-3', value: '12px' },
  { token: '--ds-space-4', value: '16px' },
  { token: '--ds-space-5', value: '20px' },
  { token: '--ds-space-6', value: '24px' },
  { token: '--ds-space-8', value: '32px' },
  { token: '--ds-space-10', value: '40px' },
  { token: '--ds-space-12', value: '48px' },
  { token: '--ds-space-16', value: '64px' },
  { token: '--ds-space-20', value: '80px' },
  { token: '--ds-space-24', value: '96px' },
];

const typographyTokens = [
  { token: '--ds-font-size-2xs', value: '10px' },
  { token: '--ds-font-size-xs', value: '11px' },
  { token: '--ds-font-size-sm', value: '12px' },
  { token: '--ds-font-size-base', value: '13px' },
  { token: '--ds-font-size-md', value: '14px' },
  { token: '--ds-font-size-lg', value: '16px' },
  { token: '--ds-font-size-xl', value: '20px' },
  { token: '--ds-font-size-2xl', value: '24px' },
  { token: '--ds-font-size-3xl', value: '28px' },
];

const radiusTokens = [
  { token: '--ds-radius-none', value: '0px' },
  { token: '--ds-radius-sm', value: '4px' },
  { token: '--ds-radius-md', value: '6px' },
  { token: '--ds-radius-lg', value: '8px' },
  { token: '--ds-radius-xl', value: '12px' },
  { token: '--ds-radius-2xl', value: '16px' },
  { token: '--ds-radius-full', value: '9999px' },
];

const shadowTokens = [
  { token: '--ds-shadow-xs', value: '0 1px 2px …' },
  { token: '--ds-shadow-sm', value: '0 1px 3px …' },
  { token: '--ds-shadow-md', value: '0 4px 6px …' },
  { token: '--ds-shadow-lg', value: '0 10px 15px …' },
  { token: '--ds-shadow-xl', value: '0 20px 25px …' },
];

const zIndexTokens = [
  { token: '--ds-z-base', value: '0' },
  { token: '--ds-z-dropdown', value: '100' },
  { token: '--ds-z-sticky', value: '200' },
  { token: '--ds-z-overlay', value: '300' },
  { token: '--ds-z-modal', value: '400' },
  { token: '--ds-z-popover', value: '500' },
  { token: '--ds-z-toast', value: '600' },
  { token: '--ds-z-tooltip', value: '700' },
];

const transitionTokens = [
  { token: '--ds-transition-fast', value: '150ms ease' },
  { token: '--ds-transition-normal', value: '250ms ease' },
  { token: '--ds-transition-slow', value: '350ms ease' },
];

const sections = [
  { id: 'brand', label: 'Brand Colors' },
  { id: 'semantic', label: 'Semantic Colors' },
  { id: 'gray', label: 'Gray Scale' },
  { id: 'color-scales', label: 'Color Scales' },
  { id: 'typography', label: 'Typography Tokens' },
  { id: 'spacing', label: 'Spacing' },
  { id: 'radius', label: 'Border Radius' },
  { id: 'shadows', label: 'Shadows' },
  { id: 'z-index', label: 'Z-Index' },
  { id: 'transitions', label: 'Transitions' },
  { id: 'utility-layout', label: 'Layout Utilities' },
  { id: 'utility-text', label: 'Text Utilities' },
  { id: 'utility-bg', label: 'Background Utilities' },
  { id: 'utility-border', label: 'Border Utilities' },
  { id: 'component-btn', label: 'Button Components' },
  { id: 'component-card', label: 'Card Components' },
  { id: 'component-badge', label: 'Badge Components' },
  { id: 'component-input', label: 'Input Components' },
  { id: 'component-table', label: 'Table Components' },
  { id: 'component-alert', label: 'Alert Components' },
  { id: 'component-misc', label: 'Misc Components' },
  { id: 'animations', label: 'Animations' },
];

/* ═══════════════════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════════════════ */
export function CSSShowcase() {
  const [activeSection, setActiveSection] = useState('brand');

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f9fafb' }}>
      {/* ── Sidebar Nav ── */}
      <Box
        sx={{
          width: 240,
          flexShrink: 0,
          position: 'sticky',
          top: 0,
          height: '100vh',
          overflowY: 'auto',
          bgcolor: '#fff',
          borderRight: '1px solid #e5e7eb',
          py: 3,
          px: 2,
        }}
      >
        <Box sx={{ fontSize: 16, fontWeight: 700, color: '#0052FF', mb: 2, px: 1 }}>
          CSS Showcase
        </Box>
        {sections.map((s) => (
          <Box
            key={s.id}
            component="a"
            href={`#${s.id}`}
            onClick={() => setActiveSection(s.id)}
            sx={{
              display: 'block',
              fontSize: 12,
              py: 0.6,
              px: 1.5,
              borderRadius: '6px',
              color: activeSection === s.id ? '#0052FF' : '#6b7280',
              bgcolor: activeSection === s.id ? 'rgba(0,82,255,0.06)' : 'transparent',
              fontWeight: activeSection === s.id ? 600 : 400,
              textDecoration: 'none',
              transition: 'all 150ms',
              '&:hover': { bgcolor: '#f3f4f6', color: '#374151' },
            }}
          >
            {s.label}
          </Box>
        ))}
      </Box>

      {/* ── Content ── */}
      <Box sx={{ flex: 1, p: 5, maxWidth: 1100 }}>
        <Box sx={{ fontSize: 28, fontWeight: 700, color: '#111827', mb: 0.5 }}>
          SONAR CSS Design Tokens & Utilities
        </Box>
        <Box sx={{ fontSize: 13, color: '#6b7280', mb: 5 }}>
          Pure CSS — all styles reference <code>--ds-*</code> tokens from <code>variables.css</code>. No Tailwind runtime required.
        </Box>

        {/* ═══ BRAND COLORS ═══ */}
        <Section id="brand" title="Brand Colors">
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            {brandColors.map((c) => (
              <Swatch key={c.name} name={c.name} value={c.value} />
            ))}
          </Box>
        </Section>

        {/* ═══ SEMANTIC COLORS ═══ */}
        <Section id="semantic" title="Semantic Colors">
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            {semanticColors.map((c) => (
              <Swatch key={c.name} name={c.name} value={c.value} />
            ))}
          </Box>
        </Section>

        {/* ═══ GRAY SCALE ═══ */}
        <Section id="gray" title="Gray Scale (--ds-gray-*)">
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {grayScale.map((c) => (
              <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />
            ))}
          </Box>
        </Section>

        {/* ═══ COLOR SCALES ═══ */}
        <Section id="color-scales" title="Extended Color Scales">
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: '#374151' }}>Blue (--ds-blue-*)</Box>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {blueScale.map((c) => <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />)}
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: '#374151' }}>Red (--ds-red-*)</Box>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {redScale.map((c) => <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />)}
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: '#374151' }}>Green (--ds-green-*)</Box>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {greenScale.map((c) => <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />)}
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: '#374151' }}>Emerald (--ds-emerald-*)</Box>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {emeraldScale.map((c) => <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />)}
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1, color: '#374151' }}>Amber (--ds-amber-*)</Box>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {amberScale.map((c) => <Swatch key={c.name} name={c.name} value={c.value} textColor={c.textColor} />)}
            </Box>
          </Box>
        </Section>

        {/* ═══ TYPOGRAPHY ═══ */}
        <Section id="typography" title="Typography Tokens">
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Font Sizes</Box>
            {typographyTokens.map((t) => (
              <TokenRow
                key={t.token}
                token={t.token}
                value={t.value}
                preview={<Box sx={{ fontSize: t.value, lineHeight: 1.5 }}>The quick brown fox</Box>}
              />
            ))}
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Font Weights</Box>
            <TokenRow token="--ds-font-weight-regular" value="400" preview={<Box sx={{ fontWeight: 400 }}>Regular weight</Box>} />
            <TokenRow token="--ds-font-weight-medium" value="500" preview={<Box sx={{ fontWeight: 500 }}>Medium weight</Box>} />
            <TokenRow token="--ds-font-weight-semibold" value="600" preview={<Box sx={{ fontWeight: 600 }}>Semibold weight</Box>} />
            <TokenRow token="--ds-font-weight-bold" value="700" preview={<Box sx={{ fontWeight: 700 }}>Bold weight</Box>} />
          </Box>
          <Box>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Line Heights</Box>
            <TokenRow token="--ds-line-height-none" value="1" />
            <TokenRow token="--ds-line-height-tight" value="1.3" />
            <TokenRow token="--ds-line-height-snug" value="1.4" />
            <TokenRow token="--ds-line-height-normal" value="1.5" />
            <TokenRow token="--ds-line-height-relaxed" value="1.6" />
            <TokenRow token="--ds-line-height-loose" value="1.75" />
          </Box>
        </Section>

        {/* ═══ SPACING ═══ */}
        <Section id="spacing" title="Spacing Tokens (4px base)">
          {spacingTokens.map((t) => (
            <TokenRow
              key={t.token}
              token={t.token}
              value={t.value}
              preview={
                <Box
                  sx={{
                    width: t.value,
                    height: 12,
                    bgcolor: '#0052FF',
                    borderRadius: '2px',
                    opacity: 0.7,
                  }}
                />
              }
            />
          ))}
        </Section>

        {/* ═══ BORDER RADIUS ═══ */}
        <Section id="radius" title="Border Radius Tokens">
          <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
            {radiusTokens.map((t) => (
              <Box key={t.token} sx={{ textAlign: 'center' }}>
                <Box
                  sx={{
                    width: 56,
                    height: 56,
                    bgcolor: '#0052FF',
                    borderRadius: t.value,
                    mx: 'auto',
                    mb: 0.5,
                    opacity: 0.8,
                  }}
                />
                <Box sx={{ fontSize: 10, fontFamily: 'monospace', color: '#6b7280' }}>{t.token.replace('--ds-', '')}</Box>
                <Box sx={{ fontSize: 10, fontFamily: 'monospace', color: '#9ca3af' }}>{t.value}</Box>
              </Box>
            ))}
          </Box>
        </Section>

        {/* ═══ SHADOWS ═══ */}
        <Section id="shadows" title="Shadow Tokens">
          <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
            {shadowTokens.map((t) => (
              <Box key={t.token} sx={{ textAlign: 'center' }}>
                <Box className={`ds-shadow-${t.token.replace('--ds-shadow-', '')}`} sx={{ width: 80, height: 80, bgcolor: '#fff', borderRadius: '8px', mx: 'auto', mb: 0.5 }} />
                <Box sx={{ fontSize: 10, fontFamily: 'monospace', color: '#6b7280' }}>{t.token.replace('--ds-', '')}</Box>
              </Box>
            ))}
          </Box>
        </Section>

        {/* ═══ Z-INDEX ═══ */}
        <Section id="z-index" title="Z-Index Tokens">
          {zIndexTokens.map((t) => (
            <TokenRow key={t.token} token={t.token} value={t.value} />
          ))}
        </Section>

        {/* ═══ TRANSITIONS ═══ */}
        <Section id="transitions" title="Transition Tokens">
          {transitionTokens.map((t) => (
            <TokenRow key={t.token} token={t.token} value={t.value} />
          ))}
        </Section>

        {/* ═══ LAYOUT UTILITIES ═══ */}
        <Section id="utility-layout" title="Layout Utility Classes">
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2, fontSize: 11 }}>
            {[
              { cls: 'ds-flex', desc: 'display: flex' },
              { cls: 'ds-inline-flex', desc: 'display: inline-flex' },
              { cls: 'ds-grid', desc: 'display: grid' },
              { cls: 'ds-block', desc: 'display: block' },
              { cls: 'ds-hidden', desc: 'display: none' },
              { cls: 'ds-flex-col', desc: 'flex-direction: column' },
              { cls: 'ds-flex-row', desc: 'flex-direction: row' },
              { cls: 'ds-flex-wrap', desc: 'flex-wrap: wrap' },
              { cls: 'ds-flex-1', desc: 'flex: 1 1 0%' },
              { cls: 'ds-items-center', desc: 'align-items: center' },
              { cls: 'ds-items-start', desc: 'align-items: flex-start' },
              { cls: 'ds-items-end', desc: 'align-items: flex-end' },
              { cls: 'ds-justify-between', desc: 'justify-content: space-between' },
              { cls: 'ds-justify-center', desc: 'justify-content: center' },
              { cls: 'ds-justify-end', desc: 'justify-content: flex-end' },
              { cls: 'ds-gap-1', desc: 'gap: 4px' },
              { cls: 'ds-gap-2', desc: 'gap: 8px' },
              { cls: 'ds-gap-4', desc: 'gap: 16px' },
              { cls: 'ds-gap-6', desc: 'gap: 24px' },
              { cls: 'ds-relative', desc: 'position: relative' },
              { cls: 'ds-absolute', desc: 'position: absolute' },
            ].map(({ cls, desc }) => (
              <Box key={cls} sx={{ p: 1.5, border: '1px solid #e5e7eb', borderRadius: '6px', bgcolor: '#fff' }}>
                <Box sx={{ fontFamily: 'monospace', color: '#0052FF', fontWeight: 500 }}>.{cls}</Box>
                <Box sx={{ color: '#9ca3af', mt: 0.3 }}>{desc}</Box>
              </Box>
            ))}
          </Box>
        </Section>

        {/* ═══ TEXT UTILITIES ═══ */}
        <Section id="utility-text" title="Text Utility Classes">
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Font Size Classes</Box>
            {[
              { cls: 'ds-text-2xs', size: '10px' },
              { cls: 'ds-text-xs', size: '11px' },
              { cls: 'ds-text-sm', size: '12px' },
              { cls: 'ds-text-base', size: '13px' },
              { cls: 'ds-text-md', size: '14px' },
              { cls: 'ds-text-lg', size: '16px' },
              { cls: 'ds-text-xl', size: '20px' },
              { cls: 'ds-text-2xl', size: '24px' },
              { cls: 'ds-text-3xl', size: '28px' },
            ].map(({ cls, size }) => (
              <Box key={cls} sx={{ display: 'flex', alignItems: 'baseline', gap: 2, py: 0.5 }}>
                <Box sx={{ width: 120, fontFamily: 'monospace', color: '#0052FF', fontSize: 11 }}>.{cls}</Box>
                <Box className={cls}>The quick brown fox ({size})</Box>
              </Box>
            ))}
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Font Weight Classes</Box>
            <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
              {['ds-font-normal', 'ds-font-medium', 'ds-font-semibold', 'ds-font-bold'].map((cls) => (
                <Box key={cls}>
                  <Box sx={{ fontFamily: 'monospace', color: '#0052FF', fontSize: 11, mb: 0.3 }}>.{cls}</Box>
                  <Box className={cls} sx={{ fontSize: 14 }}>Sample text</Box>
                </Box>
              ))}
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Text Color Classes</Box>
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              {[
                'ds-text-gray-400', 'ds-text-gray-500', 'ds-text-gray-600',
                'ds-text-gray-700', 'ds-text-gray-900', 'ds-text-brand',
                'ds-text-success', 'ds-text-warning', 'ds-text-error', 'ds-text-info',
              ].map((cls) => (
                <Box key={cls} className={cls} sx={{ fontSize: 12, fontFamily: 'monospace' }}>.{cls}</Box>
              ))}
            </Box>
          </Box>
        </Section>

        {/* ═══ BACKGROUND UTILITIES ═══ */}
        <Section id="utility-bg" title="Background Utility Classes">
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
            {[
              'ds-bg-white', 'ds-bg-gray-50', 'ds-bg-gray-100', 'ds-bg-gray-200',
              'ds-bg-gray-800', 'ds-bg-gray-900', 'ds-bg-blue-50', 'ds-bg-blue-100',
              'ds-bg-blue-500', 'ds-bg-red-50', 'ds-bg-red-100', 'ds-bg-red-500',
              'ds-bg-green-50', 'ds-bg-green-100', 'ds-bg-emerald-50', 'ds-bg-emerald-100',
              'ds-bg-amber-50', 'ds-bg-amber-100', 'ds-bg-brand', 'ds-bg-brand-navy',
            ].map((cls) => (
              <Box key={cls} sx={{ textAlign: 'center' }}>
                <Box
                  className={cls}
                  sx={{ width: 56, height: 40, borderRadius: '6px', border: '1px solid #e5e7eb', mb: 0.3 }}
                />
                <Box sx={{ fontSize: 9, fontFamily: 'monospace', color: '#9ca3af', maxWidth: 70 }}>.{cls}</Box>
              </Box>
            ))}
          </Box>
        </Section>

        {/* ═══ BORDER UTILITIES ═══ */}
        <Section id="utility-border" title="Border & Radius Utility Classes">
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mb: 3 }}>
            {['ds-rounded-none', 'ds-rounded-sm', 'ds-rounded-md', 'ds-rounded-lg', 'ds-rounded-xl', 'ds-rounded-2xl', 'ds-rounded-full'].map((cls) => (
              <Box key={cls} sx={{ textAlign: 'center' }}>
                <Box
                  className={cls}
                  sx={{ width: 48, height: 48, bgcolor: '#0052FF', opacity: 0.7, mx: 'auto', mb: 0.3 }}
                />
                <Box sx={{ fontSize: 9, fontFamily: 'monospace', color: '#9ca3af' }}>.{cls}</Box>
              </Box>
            ))}
          </Box>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            {['ds-border', 'ds-border-t', 'ds-border-b', 'ds-border-l', 'ds-border-r', 'ds-border-dashed'].map((cls) => (
              <Box key={cls} sx={{ textAlign: 'center' }}>
                <Box
                  className={cls}
                  sx={{ width: 56, height: 40, bgcolor: '#f9fafb', borderRadius: '4px', mx: 'auto', mb: 0.3 }}
                />
                <Box sx={{ fontSize: 9, fontFamily: 'monospace', color: '#9ca3af' }}>.{cls}</Box>
              </Box>
            ))}
          </Box>
        </Section>

        {/* ═══ BUTTON COMPONENTS ═══ */}
        <Section id="component-btn" title="Button Component Classes (ds-c-btn)">
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mb: 3, alignItems: 'center' }}>
            <button className="ds-c-btn ds-c-btn--primary">Primary</button>
            <button className="ds-c-btn ds-c-btn--secondary">Secondary</button>
            <button className="ds-c-btn ds-c-btn--ghost">Ghost</button>
            <button className="ds-c-btn ds-c-btn--danger">Danger</button>
            <button className="ds-c-btn ds-c-btn--primary" disabled>Disabled</button>
          </Box>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
            <button className="ds-c-btn ds-c-btn--primary ds-c-btn--sm">Small</button>
            <button className="ds-c-btn ds-c-btn--primary ds-c-btn--md">Medium</button>
            <button className="ds-c-btn ds-c-btn--primary ds-c-btn--lg">Large</button>
          </Box>
        </Section>

        {/* ═══ CARD COMPONENTS ═══ */}
        <Section id="component-card" title="Card Component Classes (ds-c-card)">
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 3 }}>
            <div className="ds-c-card">
              <div className="ds-c-card__header">
                <span style={{ fontSize: 13, fontWeight: 500 }}>Card Header</span>
              </div>
              <div className="ds-c-card__body">
                <p style={{ fontSize: 12, color: '#6b7280' }}>Card body content using <code>.ds-c-card</code> classes.</p>
              </div>
              <div className="ds-c-card__footer">
                <span style={{ fontSize: 11, color: '#9ca3af' }}>Card footer</span>
              </div>
            </div>
            <div className="ds-c-card ds-c-card--hoverable">
              <div className="ds-c-card__body">
                <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>Hoverable Card</p>
                <p style={{ fontSize: 12, color: '#6b7280' }}>This card has <code>.ds-c-card--hoverable</code> — shadow on hover.</p>
              </div>
            </div>
          </Box>
        </Section>

        {/* ═══ BADGE COMPONENTS ═══ */}
        <Section id="component-badge" title="Badge Component Classes (ds-c-badge)">
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', mb: 2 }}>
            <span className="ds-c-badge ds-c-badge--success">Success</span>
            <span className="ds-c-badge ds-c-badge--warning">Warning</span>
            <span className="ds-c-badge ds-c-badge--error">Error</span>
            <span className="ds-c-badge ds-c-badge--info">Info</span>
            <span className="ds-c-badge ds-c-badge--neutral">Neutral</span>
            <span className="ds-c-badge ds-c-badge--primary">Primary</span>
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
            <span className="ds-c-badge ds-c-badge--success ds-c-badge--dot">With dot</span>
            <span className="ds-c-badge ds-c-badge--error ds-c-badge--dot">With dot</span>
            <span className="ds-c-count-badge">3</span>
            <span className="ds-c-count-badge">99+</span>
          </Box>
        </Section>

        {/* ═══ INPUT COMPONENTS ═══ */}
        <Section id="component-input" title="Input Component Classes (ds-c-input)">
          <Box sx={{ maxWidth: 400, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <div>
              <label className="ds-c-label">Default Input</label>
              <input className="ds-c-input" placeholder="Placeholder text..." />
            </div>
            <div>
              <label className="ds-c-label ds-c-label--required">Required Input</label>
              <input className="ds-c-input" placeholder="Required field" />
            </div>
            <div>
              <label className="ds-c-label">Error State</label>
              <input className="ds-c-input ds-c-input--error" defaultValue="Invalid value" />
              <p className="ds-c-helper ds-c-helper--error">This field has an error</p>
            </div>
            <div>
              <label className="ds-c-label">Disabled</label>
              <input className="ds-c-input ds-c-input--disabled" disabled placeholder="Disabled" />
            </div>
            <div>
              <label className="ds-c-label">Textarea</label>
              <textarea className="ds-c-textarea" placeholder="Multi-line input..." />
            </div>
          </Box>
        </Section>

        {/* ═══ TABLE COMPONENTS ═══ */}
        <Section id="component-table" title="Table Component Classes (ds-c-table)">
          <table className="ds-c-table" style={{ maxWidth: 600 }}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Hurricane Alpha</td>
                <td><span className="ds-c-badge ds-c-badge--success">Active</span></td>
                <td>$1,250,000</td>
              </tr>
              <tr>
                <td>Earthquake Beta</td>
                <td><span className="ds-c-badge ds-c-badge--warning">Pending</span></td>
                <td>$3,400,000</td>
              </tr>
              <tr>
                <td>Flood Gamma</td>
                <td><span className="ds-c-badge ds-c-badge--error">Closed</span></td>
                <td>$890,000</td>
              </tr>
            </tbody>
          </table>
        </Section>

        {/* ═══ ALERT COMPONENTS ═══ */}
        <Section id="component-alert" title="Alert Component Classes (ds-c-alert)">
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, maxWidth: 500 }}>
            <div className="ds-c-alert ds-c-alert--info">ℹ️ This is an informational alert.</div>
            <div className="ds-c-alert ds-c-alert--success">✅ Operation completed successfully.</div>
            <div className="ds-c-alert ds-c-alert--warning">⚠️ Please review before continuing.</div>
            <div className="ds-c-alert ds-c-alert--error">❌ An error occurred during processing.</div>
          </Box>
        </Section>

        {/* ═══ MISC COMPONENTS ═══ */}
        <Section id="component-misc" title="Miscellaneous Components">
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Avatar (ds-c-avatar)</Box>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              <span className="ds-c-avatar ds-c-avatar--sm">SM</span>
              <span className="ds-c-avatar ds-c-avatar--md">MD</span>
              <span className="ds-c-avatar ds-c-avatar--lg">LG</span>
            </Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Tooltip (ds-c-tooltip)</Box>
            <Box className="ds-c-tooltip" sx={{ display: 'inline-block' }}>Tooltip content</Box>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Tab Bar (ds-c-tab-bar)</Box>
            <div className="ds-c-tab-bar">
              <button className="ds-c-tab ds-c-tab--active">Active Tab</button>
              <button className="ds-c-tab">Other Tab</button>
              <button className="ds-c-tab">Another Tab</button>
            </div>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Empty State (ds-c-empty-state)</Box>
            <div className="ds-c-empty-state" style={{ border: '1px dashed #e5e7eb', borderRadius: 8, maxWidth: 400 }}>
              <div className="ds-c-empty-state__title">No Data Found</div>
              <div className="ds-c-empty-state__text">Try adjusting your filters or create a new item.</div>
            </div>
          </Box>
          <Box sx={{ mb: 3 }}>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Add Row (ds-c-add-row)</Box>
            <button className="ds-c-add-row" style={{ maxWidth: 400 }}>+ Add New Item</button>
          </Box>
          <Box>
            <Box sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>Step Dots (ds-c-step-dot)</Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <span className="ds-c-step-dot ds-c-step-dot--completed" />
              <span className="ds-c-step-dot ds-c-step-dot--active" />
              <span className="ds-c-step-dot ds-c-step-dot--pending" />
            </Box>
          </Box>
        </Section>

        {/* ═══ ANIMATIONS ═══ */}
        <Section id="animations" title="Animation Classes">
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, fontSize: 11 }}>
            {[
              { cls: 'ds-animate-slide-in', desc: 'Slide up + fade in (0.3s)' },
              { cls: 'ds-animate-fade-slide-in', desc: 'Slide down + fade in (0.25s)' },
              { cls: 'ds-animate-spin', desc: 'Continuous rotation' },
              { cls: 'ds-animate-pulse', desc: 'Pulse opacity' },
            ].map(({ cls, desc }) => (
              <Box key={cls} sx={{ p: 2, border: '1px solid #e5e7eb', borderRadius: '6px', bgcolor: '#fff' }}>
                <Box sx={{ fontFamily: 'monospace', color: '#0052FF', fontWeight: 500 }}>.{cls}</Box>
                <Box sx={{ color: '#9ca3af', mt: 0.3 }}>{desc}</Box>
                <Box
                  className={cls}
                  sx={{
                    mt: 1,
                    width: 24,
                    height: 24,
                    bgcolor: '#0052FF',
                    borderRadius: cls.includes('spin') ? '50%' : '4px',
                    opacity: 0.7,
                  }}
                />
              </Box>
            ))}
          </Box>
        </Section>

      </Box>
    </Box>
  );
}

export default CSSShowcase;
