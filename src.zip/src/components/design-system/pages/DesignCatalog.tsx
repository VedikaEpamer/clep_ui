/**
 * Design Catalog
 * ================
 * Unified catalog page that combines all three showcases:
 *   1. Components — Atoms, Molecules, Organisms, Templates
 *   2. CSS Tokens — Design tokens, utility classes, component classes
 *   3. Assets — Images and SVG icons
 *
 * Route: /design-system
 */
import React, { useState, lazy, Suspense } from 'react';
import Box from '@mui/material/Box';
import MuiTabs from '@mui/material/Tabs';
import MuiTab from '@mui/material/Tab';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';
import { Skeleton } from '../atoms/Skeleton';

/* ─── Lazy-loaded tab panels ─────────────── */
const ComponentsPanel = lazy(() => import('../DesignSystemShowcase'));
const CSSPanel = lazy(() => import('./CSSShowcase'));
const AssetsPanel = lazy(() => import('./AssetsCatalog'));

/* ─── Tab definitions ────────────────────── */
const catalogTabs = [
  { value: 'components', label: 'Components', icon: 'layers' as const },
  { value: 'css', label: 'CSS Tokens', icon: 'edit' as const },
  { value: 'assets', label: 'Assets', icon: 'folder-open' as const },
];

/* ─── Loading fallback ───────────────────── */
function TabLoading() {
  return (
    <Box className="ds-catalog__loading">
      <Skeleton variant="rectangular" width="100%" height={40} />
      <Skeleton variant="rectangular" width="80%" height={24} />
      <Skeleton variant="rectangular" width="100%" height={200} />
      <Skeleton variant="rectangular" width="60%" height={24} />
      <Skeleton variant="rectangular" width="100%" height={200} />
    </Box>
  );
}

/* ─── Main Component ─────────────────────── */
function DesignCatalog() {
  const [activeTab, setActiveTab] = useState('components');

  return (
    <Box className="ds-catalog">
      {/* ── Header ─────────────────────────── */}
      <Box className="ds-catalog__header">
        <Typography variant="h1" className="ds-catalog__title">
          SONAR Design System
        </Typography>
        <Typography variant="body1" muted className="ds-catalog__subtitle">
          Living catalog — Components · CSS Tokens · Assets
        </Typography>
      </Box>

      {/* ── Tab bar ────────────────────────── */}
      <Box className="ds-catalog__tabs">
        <MuiTabs
          value={activeTab}
          onChange={(_e, v) => setActiveTab(v)}
          variant="standard"
          className="ds-catalog__tab-bar"
        >
          {catalogTabs.map((tab) => (
            <MuiTab
              key={tab.value}
              value={tab.value}
              icon={<Icon name={tab.icon} size={18} />}
              iconPosition="start"
              label={tab.label}
              className="ds-catalog__tab-item"
            />
          ))}
        </MuiTabs>
      </Box>

      {/* ── Tab panels ─────────────────────── */}
      <Box className="ds-catalog__panel">
        <Suspense fallback={<TabLoading />}>
          {activeTab === 'components' && <ComponentsPanel />}
          {activeTab === 'css' && <CSSPanel />}
          {activeTab === 'assets' && <AssetsPanel />}
        </Suspense>
      </Box>

      {/* ── Footer ─────────────────────────── */}
      <Box className="ds-catalog__footer">
        <Typography variant="caption">
          SONAR Design System · Built with MUI + AG Grid · Atomic Design Pattern
        </Typography>
      </Box>
    </Box>
  );
}

export { DesignCatalog };
export default DesignCatalog;
