/**
 * Assets Catalog
 * ================
 * A living catalog of all images and SVG icons in the asset library.
 * Route: /assets-catalog
 */
import React, { useState, useMemo } from 'react';
import Box from '@mui/material/Box';
import MuiDivider from '@mui/material/Divider';
import * as assets from '../../../assets/images';

/* ─── Asset metadata (name → { src, description, size, category }) ─── */
interface AssetMeta {
  exportName: string;
  src: string;
  description: string;
  size: string;
  category: 'image' | 'custom-icon' | 'standard-icon';
}

const assetList: AssetMeta[] = [
  // Images
  { exportName: 'everestLogo', src: assets.everestLogo, description: 'Everest company logo', size: 'png', category: 'image' },

  // Custom Icons (extracted from Figma / inline SVGs)
  { exportName: 'iconAlertCircle', src: assets.iconAlertCircle, description: 'Warning/alert circle', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconArrowLeft', src: assets.iconArrowLeft, description: 'Left arrow for back nav', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconBarChart', src: assets.iconBarChart, description: 'Bar chart with axis', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconBell', src: assets.iconBell, description: 'Notification bell', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconBrandLogo', src: assets.iconBrandLogo, description: 'Brand logomark', size: '28×28', category: 'custom-icon' },
  { exportName: 'iconChartBar', src: assets.iconChartBar, description: 'Chart bar columns, small', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconCheckmark', src: assets.iconCheckmark, description: 'Checkmark, selection', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconChevronDown', src: assets.iconChevronDown, description: 'Chevron down, small', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconChevronDownLg', src: assets.iconChevronDownLg, description: 'Chevron down, dropdown', size: '24×24', category: 'custom-icon' },
  { exportName: 'iconChevronLeft', src: assets.iconChevronLeft, description: 'Chevron left, sidebar collapse', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconClockHistory', src: assets.iconClockHistory, description: 'Clock with history arrow', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconClose', src: assets.iconClose, description: 'X/close button', size: '24×24', category: 'custom-icon' },
  { exportName: 'iconCurrency', src: assets.iconCurrency, description: 'Dollar sign S-curve', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconDocumentText', src: assets.iconDocumentText, description: 'Document with text lines', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconDownload', src: assets.iconDownload, description: 'Download arrow with tray', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconEye', src: assets.iconEye, description: 'Eye/view', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconFilter', src: assets.iconFilter, description: 'Funnel/filter', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconFolder', src: assets.iconFolder, description: 'Folder with document', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconFullscreen', src: assets.iconFullscreen, description: 'Expand fullscreen corners', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconImagePlaceholder', src: assets.iconImagePlaceholder, description: 'Broken image placeholder', size: '88×88', category: 'custom-icon' },
  { exportName: 'iconInfoCircle', src: assets.iconInfoCircle, description: 'Info circle filled', size: '20×20', category: 'custom-icon' },
  { exportName: 'iconSave', src: assets.iconSave, description: 'Floppy disk save', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconSearch', src: assets.iconSearch, description: 'Magnifying glass, small', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconSearchLg', src: assets.iconSearchLg, description: 'Magnifying glass, large', size: '24×24', category: 'custom-icon' },
  { exportName: 'iconSend', src: assets.iconSend, description: 'Paper plane/send', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconSettingsGear', src: assets.iconSettingsGear, description: 'Settings gear/cog', size: '16×16', category: 'custom-icon' },
  { exportName: 'iconShieldCheck', src: assets.iconShieldCheck, description: 'Shield with checkmark', size: '24×24', category: 'custom-icon' },
  { exportName: 'iconSortArrowDown', src: assets.iconSortArrowDown, description: 'Sort triangle down', size: '10×5', category: 'custom-icon' },
  { exportName: 'iconSortArrowUp', src: assets.iconSortArrowUp, description: 'Sort triangle up', size: '10×5', category: 'custom-icon' },
  { exportName: 'iconUpload', src: assets.iconUpload, description: 'Upload arrow with tray', size: '16×16', category: 'custom-icon' },

  // Standard Icons (Lucide library, 24×24)
  { exportName: 'iconActivity', src: assets.iconActivity, description: 'Activity/trend line', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconActivityLine', src: assets.iconActivityLine, description: 'Activity pulse line', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconAlertTriangle', src: assets.iconAlertTriangle, description: 'Warning triangle', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconArchive', src: assets.iconArchive, description: 'Archive box', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconArrowDown', src: assets.iconArrowDown, description: 'Arrow down', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconArrowRight', src: assets.iconArrowRight, description: 'Arrow right', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconArrowUp', src: assets.iconArrowUp, description: 'Arrow up', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconArrowUpDown', src: assets.iconArrowUpDown, description: 'Sort arrows up/down', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconBarChart2', src: assets.iconBarChart2, description: 'Bar chart variant 2', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconBarChart3', src: assets.iconBarChart3, description: 'Bar chart variant 3', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconBuilding2', src: assets.iconBuilding2, description: 'Building/company', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCalendar', src: assets.iconCalendar, description: 'Calendar', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCheck', src: assets.iconCheck, description: 'Checkmark', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCheckCircle', src: assets.iconCheckCircle, description: 'Check in circle', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCheckCircle2', src: assets.iconCheckCircle2, description: 'Check in circle variant', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCheckSquare', src: assets.iconCheckSquare, description: 'Check in square', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconChevronLeftNav', src: assets.iconChevronLeftNav, description: 'Chevron left navigation', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconChevronRight', src: assets.iconChevronRight, description: 'Chevron right', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconChevronUp', src: assets.iconChevronUp, description: 'Chevron up', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconChevronsDownUp', src: assets.iconChevronsDownUp, description: 'Double chevrons collapse', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconChevronsUpDown', src: assets.iconChevronsUpDown, description: 'Double chevrons expand', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCircle', src: assets.iconCircle, description: 'Circle outline', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconClipboardList', src: assets.iconClipboardList, description: 'Clipboard with list', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconClock', src: assets.iconClock, description: 'Clock', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCpu', src: assets.iconCpu, description: 'CPU/processor', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconCrosshair', src: assets.iconCrosshair, description: 'Crosshair/target', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconDollarSign', src: assets.iconDollarSign, description: 'Dollar sign', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconEdit', src: assets.iconEdit, description: 'Edit/pencil basic', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconEdit2', src: assets.iconEdit2, description: 'Edit/pencil with line', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconExternalLink', src: assets.iconExternalLink, description: 'External link arrow', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconEyeOff', src: assets.iconEyeOff, description: 'Eye hidden/off', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconFile', src: assets.iconFile, description: 'File/document', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconFileText', src: assets.iconFileText, description: 'File with text', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconFolderOpen', src: assets.iconFolderOpen, description: 'Open folder', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconGlobe', src: assets.iconGlobe, description: 'Globe', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconGlobeFull', src: assets.iconGlobeFull, description: 'Globe with meridians', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconHistory', src: assets.iconHistory, description: 'History/undo', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconInbox', src: assets.iconInbox, description: 'Inbox', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconInfo', src: assets.iconInfo, description: 'Info circle', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconKeyRound', src: assets.iconKeyRound, description: 'Key/access', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconLayers', src: assets.iconLayers, description: 'Layers stacked', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconLoader2', src: assets.iconLoader2, description: 'Loading spinner', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconLock', src: assets.iconLock, description: 'Lock/locked', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMail', src: assets.iconMail, description: 'Mail/email', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMapPin', src: assets.iconMapPin, description: 'Map pin/location', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMaximize2', src: assets.iconMaximize2, description: 'Maximize/expand', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMessageSquare', src: assets.iconMessageSquare, description: 'Chat message', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMessageSquarePlus', src: assets.iconMessageSquarePlus, description: 'New message', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconMinimize2', src: assets.iconMinimize2, description: 'Minimize/collapse', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconPaperclip', src: assets.iconPaperclip, description: 'Paperclip/attachment', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconPencil', src: assets.iconPencil, description: 'Pencil/edit', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconPercent', src: assets.iconPercent, description: 'Percentage', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconPlus', src: assets.iconPlus, description: 'Plus/add', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconPrinter', src: assets.iconPrinter, description: 'Printer', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconReceipt', src: assets.iconReceipt, description: 'Receipt', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconRefreshCw', src: assets.iconRefreshCw, description: 'Refresh/sync', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconRotateCcw', src: assets.iconRotateCcw, description: 'Rotate counter-clockwise', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconSettings', src: assets.iconSettings, description: 'Settings sliders', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconShield', src: assets.iconShield, description: 'Shield', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconSquare', src: assets.iconSquare, description: 'Square', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconTag', src: assets.iconTag, description: 'Tag/label', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconTarget', src: assets.iconTarget, description: 'Target/bullseye', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconTrash2', src: assets.iconTrash2, description: 'Trash/delete', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconTrendingDown', src: assets.iconTrendingDown, description: 'Trending down', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconTrendingUp', src: assets.iconTrendingUp, description: 'Trending up', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconUnlock', src: assets.iconUnlock, description: 'Unlock/unlocked', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconUser', src: assets.iconUser, description: 'User/person', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconUserCheck', src: assets.iconUserCheck, description: 'User verified', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconUserPlus', src: assets.iconUserPlus, description: 'Add user', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconUsers', src: assets.iconUsers, description: 'Multiple users', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconX', src: assets.iconX, description: 'X/close', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconXCircle', src: assets.iconXCircle, description: 'X in circle', size: '24×24', category: 'standard-icon' },
  { exportName: 'iconXSquare', src: assets.iconXSquare, description: 'X in square', size: '24×24', category: 'standard-icon' },
];

const categories = [
  { id: 'all', label: 'All Assets', count: assetList.length },
  { id: 'image', label: 'Images', count: assetList.filter((a) => a.category === 'image').length },
  { id: 'custom-icon', label: 'Custom Icons', count: assetList.filter((a) => a.category === 'custom-icon').length },
  { id: 'standard-icon', label: 'Standard Icons (Lucide)', count: assetList.filter((a) => a.category === 'standard-icon').length },
];

/* ─── Icon card ─── */
function AssetCard({ asset }: { asset: AssetMeta }) {
  const [copied, setCopied] = useState(false);
  const isImage = asset.category === 'image';

  const handleCopy = () => {
    navigator.clipboard.writeText(`import { ${asset.exportName} } from '@/assets/images';`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <Box
      onClick={handleCopy}
      sx={{
        bgcolor: '#fff',
        border: '1px solid #e5e7eb',
        borderRadius: '8px',
        p: 2,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 1,
        cursor: 'pointer',
        transition: 'all 150ms',
        position: 'relative',
        '&:hover': {
          borderColor: '#0052FF',
          boxShadow: '0 2px 8px rgba(0,82,255,0.10)',
          transform: 'translateY(-1px)',
        },
      }}
    >
      {copied && (
        <Box
          sx={{
            position: 'absolute',
            top: 4,
            right: 6,
            fontSize: 9,
            bgcolor: '#10b981',
            color: '#fff',
            borderRadius: '4px',
            px: 0.8,
            py: 0.2,
            fontWeight: 600,
          }}
        >
          Copied!
        </Box>
      )}
      <Box
        sx={{
          width: isImage ? 120 : 40,
          height: isImage ? 60 : 40,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          bgcolor: '#f9fafb',
          borderRadius: '6px',
          p: isImage ? 1 : 0.5,
        }}
      >
        <img
          src={asset.src}
          alt={asset.description}
          style={{
            maxWidth: '100%',
            maxHeight: '100%',
            objectFit: 'contain',
          }}
        />
      </Box>
      <Box sx={{ textAlign: 'center', width: '100%' }}>
        <Box
          sx={{
            fontSize: 10,
            fontFamily: 'monospace',
            color: '#374151',
            fontWeight: 500,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
          title={asset.exportName}
        >
          {asset.exportName}
        </Box>
        <Box sx={{ fontSize: 10, color: '#9ca3af', mt: 0.2 }}>{asset.description}</Box>
        <Box sx={{ fontSize: 9, color: '#d1d5db', mt: 0.2, fontFamily: 'monospace' }}>{asset.size}</Box>
      </Box>
    </Box>
  );
}

/* ═══════════════════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════════════════ */
export function AssetsCatalog() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = useMemo(() => {
    let items = assetList;
    if (activeCategory !== 'all') {
      items = items.filter((a) => a.category === activeCategory);
    }
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      items = items.filter(
        (a) => a.exportName.toLowerCase().includes(q) || a.description.toLowerCase().includes(q)
      );
    }
    return items;
  }, [activeCategory, searchTerm]);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f9fafb' }}>
      {/* ── Sidebar ── */}
      <Box
        sx={{
          width: 240,
          flexShrink: 0,
          position: 'sticky',
          top: 0,
          height: '100vh',
          overflowY: 'auto',
          bgcolor: '#fff',
          borderRight: '1px solid #e5e7eb',
          py: 3,
          px: 2,
        }}
      >
        <Box sx={{ fontSize: 16, fontWeight: 700, color: '#0052FF', mb: 2, px: 1 }}>
          Assets Catalog
        </Box>
        {categories.map((cat) => (
          <Box
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              fontSize: 12,
              py: 0.7,
              px: 1.5,
              borderRadius: '6px',
              color: activeCategory === cat.id ? '#0052FF' : '#6b7280',
              bgcolor: activeCategory === cat.id ? 'rgba(0,82,255,0.06)' : 'transparent',
              fontWeight: activeCategory === cat.id ? 600 : 400,
              cursor: 'pointer',
              transition: 'all 150ms',
              '&:hover': { bgcolor: '#f3f4f6', color: '#374151' },
            }}
          >
            <span>{cat.label}</span>
            <Box
              component="span"
              sx={{
                fontSize: 10,
                bgcolor: activeCategory === cat.id ? 'rgba(0,82,255,0.12)' : '#f3f4f6',
                color: activeCategory === cat.id ? '#0052FF' : '#9ca3af',
                borderRadius: '4px',
                px: 0.8,
                py: 0.1,
                fontWeight: 600,
                minWidth: 20,
                textAlign: 'center',
              }}
            >
              {cat.count}
            </Box>
          </Box>
        ))}

        <MuiDivider sx={{ my: 2 }} />

        <Box sx={{ px: 1, fontSize: 11, color: '#9ca3af', lineHeight: 1.5 }}>
          Click any card to copy its import statement to clipboard.
        </Box>

        <Box sx={{ px: 1, mt: 2, fontSize: 11, color: '#9ca3af', lineHeight: 1.5 }}>
          <strong style={{ color: '#374151' }}>Usage:</strong>
          <Box
            component="pre"
            sx={{
              mt: 0.5,
              p: 1,
              bgcolor: '#f3f4f6',
              borderRadius: '4px',
              fontSize: 9,
              fontFamily: 'monospace',
              whiteSpace: 'pre-wrap',
              color: '#374151',
            }}
          >
{`import { iconEdit } from
  '@/assets/images';

<img src={iconEdit}
     alt="Edit" />`}
          </Box>
        </Box>
      </Box>

      {/* ── Content ── */}
      <Box sx={{ flex: 1, p: 5 }}>
        <Box sx={{ fontSize: 28, fontWeight: 700, color: '#111827', mb: 0.5 }}>
          SONAR Asset Library
        </Box>
        <Box sx={{ fontSize: 13, color: '#6b7280', mb: 3 }}>
          {assetList.length} assets — 1 image, {assetList.filter((a) => a.category === 'custom-icon').length} custom icons, {assetList.filter((a) => a.category === 'standard-icon').length} standard icons
        </Box>

        {/* Search */}
        <Box sx={{ mb: 4, maxWidth: 400 }}>
          <input
            className="ds-c-input"
            placeholder="Search icons by name or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ fontSize: 13 }}
          />
        </Box>

        {/* Results count */}
        <Box sx={{ fontSize: 12, color: '#9ca3af', mb: 2 }}>
          Showing {filtered.length} of {assetList.length} assets
          {searchTerm && <> matching "<strong>{searchTerm}</strong>"</>}
        </Box>

        {/* Grid */}
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
            gap: 2,
          }}
        >
          {filtered.map((asset) => (
            <AssetCard key={asset.exportName} asset={asset} />
          ))}
        </Box>

        {filtered.length === 0 && (
          <Box sx={{ textAlign: 'center', py: 8, color: '#9ca3af' }}>
            <Box sx={{ fontSize: 40, mb: 1 }}>🔍</Box>
            <Box sx={{ fontSize: 14, fontWeight: 500 }}>No assets found</Box>
            <Box sx={{ fontSize: 12, mt: 0.5 }}>Try a different search term or category</Box>
          </Box>
        )}
      </Box>
    </Box>
  );
}

export default AssetsCatalog;
