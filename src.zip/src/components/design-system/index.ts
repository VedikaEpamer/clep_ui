/**
 * SONAR Design System
 * ====================
 *
 * Atomic Design Pattern:
 *   atoms/      → Smallest UI building blocks (Typography, Button, Input, Dropdown, etc.)
 *   molecules/  → Composed atoms (SearchInput, FormField, StatCard, etc.)
 *   organisms/  → Complex multi-molecule components (DataGrid, PageHeader, AppHeader, etc.)
 *   templates/  → Page layouts (PageLayout)
 *   theme/      → MUI theme configuration + palette constants
 *
 * Usage:
 *   import { Typography, Button, Input, Dropdown, DataGrid } from '@/components/design-system';
 *   import { theme } from '@/components/design-system';
 */

// Atoms
export {
  Typography, type TypographyProps, type TypographyVariant,
  Button, type ButtonProps,
  IconButton, type IconButtonProps,
  Input, type InputProps,
  Dropdown, type DropdownProps, type DropdownOption,
  DateTimePicker, type DateTimePickerProps, type DateTimeMode,
  Checkbox, type CheckboxProps,
  Switch, type SwitchProps,
  RadioGroup, type RadioGroupProps, type RadioOption,
  Badge, type BadgeProps,
  Chip, type ChipProps, type ChipStatus,
  Tooltip, type TooltipProps,
  Avatar, type AvatarProps,
  Tabs, type TabsProps, type TabItem,
  Skeleton, type SkeletonProps,
  Divider, type DividerProps,
  Card, type CardProps,
  Icon, type IconProps, type IconName, iconMap,
  Modal, type ModalSize, type ModalProps,
  Textarea, type TextareaProps,
  Accordion, type AccordionProps,
  Popover, type PopoverPlacement, type PopoverProps,
  ProgressBar, type ProgressColor, type ProgressBarProps,
  Spinner, type SpinnerSize, type SpinnerProps,
  FileUpload, type UploadedFile, type FileUploadProps,
} from './atoms';

// Molecules
export {
  SearchInput, type SearchInputProps,
  FormField, type FormFieldProps,
  ConfirmDialog, type ConfirmDialogProps,
  StatCard, type StatCardProps,
  EmptyState, type EmptyStateProps,
  Stepper, type StepStatus, type StepItem, type StepperProps,
  CommentCard, type CommentAttachment, type CommentCardProps,
  Timeline, type TimelineColor, type TimelineEntry, type TimelineProps,
  NotificationItem, type NotificationItemProps,
  TaskItem, type TaskStatus, type TaskPriority, type TaskItemProps,
  TreeView, TreeNodeItem, type TreeNodeData, type TreeViewProps,
  RepeaterField, type RepeaterItem, type RepeaterFieldProps,
  ChipGroup, type ChipOption, type ChipGroupProps,
  ErrorBoundary, DefaultFallback, type ErrorFallbackProps, type ErrorBoundaryProps,
} from './molecules';

// Organisms
export {
  DataGrid, type DataGridProps,
  PageHeader, type PageHeaderProps, type BreadcrumbItem,
  AppHeader, type AppHeaderProps, type NavItem,
  AppFooter, type AppFooterProps, type FooterLink,
  FilterBar, type FilterBarProps, type FilterDef,
  NotificationPanel, type NotificationData, type TaskData, type NotificationPanelProps,
  Drawer, type DrawerProps,
} from './organisms';

// Templates
export {
  PageLayout, type PageLayoutProps,
  SidebarLayout, type SidebarLayoutProps,
  MasterDetail, type MasterDetailProps,
  StepWizard, type WizardStep, type StepWizardProps,
} from './templates';

// Theme
export { theme, muiTheme, palette } from './theme';
