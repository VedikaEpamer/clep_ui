/**
 * SONAR Design System — MUI Theme
 * =================================
 * Centralised Material UI theme that reads from CSS variables where possible
 * and defines the Everest brand palette + typography for all MUI components.
 */
import { createTheme, type ThemeOptions } from '@mui/material/styles';

/* ─── Palette constants (so TypeScript can consume them) ─── */
export const palette = {
  brand: {
    primary: '#0052FF',
    primaryHover: '#003ACC',
    primaryLight: '#005587',
    primaryDark: '#003057',
    navy: '#0A1C3F',
  },
  gray: {
    50: '#f9fafb',
    100: '#f3f4f6',
    200: '#e5e7eb',
    300: '#d1d5db',
    400: '#9ca3af',
    500: '#6b7280',
    600: '#4b5563',
    700: '#374151',
    800: '#1f2937',
    900: '#111827',
  },
  semantic: {
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',
    info: '#3b82f6',
  },
} as const;

const fontFamily = "'Segoe UI', Segoe, Tahoma, 'Helvetica Neue', Helvetica, Arial, sans-serif";

const themeOptions: ThemeOptions = {
  palette: {
    primary: {
      main: palette.brand.primary,
      dark: palette.brand.primaryDark,
      light: palette.brand.primaryLight,
      contrastText: '#ffffff',
    },
    secondary: {
      main: palette.gray[600],
      light: palette.gray[400],
      dark: palette.gray[800],
    },
    error: { main: palette.semantic.error },
    warning: { main: palette.semantic.warning },
    success: { main: palette.semantic.success },
    info: { main: palette.semantic.info },
    background: {
      default: '#ffffff',
      paper: '#ffffff',
    },
    text: {
      primary: palette.gray[900],
      secondary: palette.gray[600],
      disabled: palette.gray[400],
    },
    divider: palette.gray[200],
  },

  typography: {
    fontFamily,
    fontSize: 13,
    fontWeightRegular: 400,
    fontWeightMedium: 500,
    fontWeightBold: 600,
    h1: { fontSize: 28, fontWeight: 500, lineHeight: 1.3, letterSpacing: '-0.02em' },
    h2: { fontSize: 20, fontWeight: 500, lineHeight: 1.4, letterSpacing: '-0.01em' },
    h3: { fontSize: 16, fontWeight: 500, lineHeight: 1.4 },
    h4: { fontSize: 14, fontWeight: 500, lineHeight: 1.5 },
    h5: { fontSize: 13, fontWeight: 500, lineHeight: 1.5 },
    h6: { fontSize: 12, fontWeight: 500, lineHeight: 1.5 },
    subtitle1: { fontSize: 14, fontWeight: 500, lineHeight: 1.5 },
    subtitle2: { fontSize: 12, fontWeight: 500, lineHeight: 1.5 },
    body1: { fontSize: 13, fontWeight: 400, lineHeight: 1.5 },
    body2: { fontSize: 12, fontWeight: 400, lineHeight: 1.5 },
    caption: { fontSize: 11, fontWeight: 400, lineHeight: 1.5, color: palette.gray[500] },
    overline: { fontSize: 10, fontWeight: 500, lineHeight: 1.5, letterSpacing: '0.06em', textTransform: 'uppercase' },
    button: { fontSize: 13, fontWeight: 500, lineHeight: 1.5, textTransform: 'none' },
  },

  shape: { borderRadius: 6 },
  spacing: 4, // 4px base unit → theme.spacing(2) = 8px

  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: { fontFamily, fontSize: 13, fontWeight: 400 },
      },
    },

    /* ── Button ─────────────────────────────── */
    MuiButton: {
      defaultProps: { disableElevation: true, size: 'small' },
      styleOverrides: {
        root: {
          borderRadius: 6,
          textTransform: 'none',
          fontWeight: 500,
          fontSize: 13,
          minHeight: 36,
          padding: '6px 16px',
        },
        sizeSmall: { minHeight: 30, padding: '4px 12px', fontSize: 12 },
        sizeLarge: { minHeight: 42, padding: '8px 24px', fontSize: 14 },
        containedPrimary: {
          '&:hover': { backgroundColor: palette.brand.primaryHover },
        },
        outlinedPrimary: {
          borderColor: palette.gray[300],
          color: palette.gray[700],
          '&:hover': {
            borderColor: palette.brand.primary,
            color: palette.brand.primary,
            backgroundColor: 'rgba(0, 82, 255, 0.04)',
          },
        },
      },
    },
    MuiIconButton: {
      defaultProps: { size: 'small' },
      styleOverrides: {
        root: { borderRadius: 6 },
      },
    },

    /* ── Input / TextField ──────────────────── */
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          fontSize: 13,
          borderRadius: 6,
          backgroundColor: '#ffffff',
          transition: 'all 150ms ease',
          '& .MuiOutlinedInput-notchedOutline': {
            borderColor: palette.gray[200],
            borderWidth: 1,
          },
          '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: palette.gray[300],
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: '#3b82f6',
            borderWidth: 2,
            boxShadow: '0 0 0 2px rgba(59,130,246,0.15)',
          },
          '&.Mui-disabled': {
            backgroundColor: palette.gray[50],
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: palette.gray[200],
            },
          },
        },
        input: {
          padding: '8px 12px',
          '&::placeholder': {
            color: palette.gray[400],
            opacity: 1,
          },
          '&.Mui-disabled': {
            color: palette.gray[500],
            WebkitTextFillColor: palette.gray[500],
            cursor: 'not-allowed',
          },
        },
        inputSizeSmall: { padding: '6px 10px' },
      },
    },
    MuiInputLabel: {
      defaultProps: { shrink: true },
      styleOverrides: {
        root: {
          fontSize: 13,
          fontWeight: 500,
          color: palette.gray[700],
          '&.Mui-focused': { color: palette.gray[700] },
        },
        sizeSmall: { fontSize: 12 },
      },
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          fontSize: 11,
          marginLeft: 0,
          marginTop: 4,
        },
      },
    },

    /* ── Select ─────────────────────────────── */
    MuiSelect: {
      defaultProps: { size: 'small' },
      styleOverrides: {
        select: { fontSize: 13 },
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          fontSize: 13,
          minHeight: 36,
          '&.Mui-selected': {
            backgroundColor: 'rgba(0, 82, 255, 0.08)',
            '&:hover': { backgroundColor: 'rgba(0, 82, 255, 0.12)' },
          },
        },
      },
    },

    /* ── Checkbox / Radio / Switch ──────────── */
    MuiCheckbox: {
      defaultProps: { size: 'small' },
      styleOverrides: { root: { padding: 6 } },
    },
    MuiRadio: {
      defaultProps: { size: 'small' },
      styleOverrides: { root: { padding: 6 } },
    },
    MuiSwitch: {
      defaultProps: { size: 'small' },
    },

    /* ── Chip / Badge ───────────────────────── */
    MuiChip: {
      defaultProps: { size: 'small' },
      styleOverrides: {
        root: { fontSize: 12, fontWeight: 500, borderRadius: 6, height: 24 },
      },
    },
    MuiBadge: {
      styleOverrides: {
        badge: { fontSize: 10, fontWeight: 600, minWidth: 18, height: 18 },
      },
    },

    /* ── Table ──────────────────────────────── */
    MuiTableHead: {
      styleOverrides: {
        root: { backgroundColor: palette.gray[50] },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          fontSize: 13,
          padding: '8px 12px',
          borderColor: palette.gray[200],
        },
        head: {
          fontWeight: 500,
          fontSize: 12,
          color: palette.gray[700],
          textTransform: 'uppercase',
          letterSpacing: '0.03em',
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: { '&:hover': { backgroundColor: palette.gray[50] } },
      },
    },

    /* ── Dialog / Modal ─────────────────────── */
    MuiDialog: {
      styleOverrides: {
        paper: {
          borderRadius: 12,
          boxShadow: '0 20px 25px rgba(0,0,0,0.08), 0 8px 10px rgba(0,0,0,0.04)',
        },
      },
    },
    MuiDialogTitle: {
      styleOverrides: {
        root: { fontSize: 16, fontWeight: 500, padding: '16px 24px' },
      },
    },

    /* ── Tooltip ─────────────────────────────── */
    MuiTooltip: {
      defaultProps: { arrow: true },
      styleOverrides: {
        tooltip: { fontSize: 12, borderRadius: 4 },
      },
    },

    /* ── Tabs ────────────────────────────────── */
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 500,
          fontSize: 13,
          minHeight: 40,
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: { height: 2 },
      },
    },

    /* ── Card ────────────────────────────────── */
    MuiCard: {
      defaultProps: { variant: 'outlined' },
      styleOverrides: {
        root: { borderRadius: 8, borderColor: palette.gray[200] },
      },
    },

    /* ── Paper ───────────────────────────────── */
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none' },
        outlined: { borderColor: palette.gray[200] },
      },
    },

    /* ── Autocomplete ────────────────────────── */
    MuiAutocomplete: {
      styleOverrides: {
        tag: { fontSize: 12, height: 24, borderRadius: 4 },
        option: { fontSize: 13, minHeight: 36 },
        listbox: { padding: 4 },
      },
    },
  },
};

export const theme = createTheme(themeOptions);
export default theme;
