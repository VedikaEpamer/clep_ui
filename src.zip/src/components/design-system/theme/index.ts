/**
 * Theme — barrel export
 */
export { theme, default as muiTheme, palette } from './theme';
