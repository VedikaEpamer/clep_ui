/**
 * Organism: PageHeader
 * =====================
 * Standard page-level header with breadcrumb, title, description, and actions.
 *
 * Usage:
 *   <PageHeader
 *     title="Events"
 *     description="Manage large loss events"
 *     breadcrumbs={[{ label: 'Home', href: '/' }, { label: 'Events' }]}
 *     actions={<Button variant="contained">New Event</Button>}
 *   />
 */
import React from 'react';
import Box from '@mui/material/Box';
import MuiBreadcrumbs from '@mui/material/Breadcrumbs';
import MuiLink from '@mui/material/Link';
import { Typography } from '../atoms/Typography';
import { Icon } from '../atoms/Icon';

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

export interface PageHeaderProps {
  /** Page title */
  title: string;
  /** Page description */
  description?: string;
  /** Breadcrumb trail */
  breadcrumbs?: BreadcrumbItem[];
  /** Action buttons (right-aligned) */
  actions?: React.ReactNode;
  /** Optional icon */
  icon?: React.ReactNode;
}

function PageHeader({
  title,
  description,
  breadcrumbs,
  actions,
  icon,
}: PageHeaderProps) {
  return (
    <Box className="ds-c-page-header">
      {breadcrumbs && breadcrumbs.length > 0 && (
        <MuiBreadcrumbs
          separator={<Icon name="chevron-right" size={14} color="var(--ds-text-tertiary)" />}
          className="ds-c-page-header__breadcrumbs"
        >
          {breadcrumbs.map((crumb, i) =>
            crumb.href && i < breadcrumbs.length - 1 ? (
              <MuiLink
                key={i}
                href={crumb.href}
                underline="hover"
                className="ds-c-page-header__crumb-link"
              >
                {crumb.label}
              </MuiLink>
            ) : (
              <Typography key={i} variant="caption" className="ds-c-page-header__crumb-current">
                {crumb.label}
              </Typography>
            ),
          )}
        </MuiBreadcrumbs>
      )}

      <Box className="ds-c-page-header__row">
        <Box className="ds-c-page-header__left">
          {icon && (
            <Box className="ds-c-page-header__icon">
              {icon}
            </Box>
          )}
          <Box>
            <Typography variant="h2">{title}</Typography>
            {description && (
              <Typography variant="body2" muted className="ds-c-page-header__desc">
                {description}
              </Typography>
            )}
          </Box>
        </Box>

        {actions && <Box className="ds-c-page-header__actions">{actions}</Box>}
      </Box>
    </Box>
  );
}
export { PageHeader };
export default PageHeader;
