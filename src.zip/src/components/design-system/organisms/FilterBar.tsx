/**
 * Organism: FilterBar
 * ====================
 * Horizontal bar with multiple filter controls + search + reset.
 *
 * Usage:
 *   <FilterBar
 *     filters={[
 *       { type: 'dropdown', name: 'region', label: 'Region', options: regions, value: r, onChange: setR },
 *       { type: 'dropdown', name: 'status', label: 'Status', options: statuses, value: s, onChange: setS, multiple: true },
 *       { type: 'date', name: 'from', label: 'From', value: from, onChange: setFrom },
 *       { type: 'date', name: 'to', label: 'To', value: to, onChange: setTo },
 *     ]}
 *     searchValue={search}
 *     onSearchChange={setSearch}
 *     onReset={handleReset}
 *   />
 */
import React from 'react';
import Box from '@mui/material/Box';
import { Button } from '../atoms/Button';
import { Dropdown, type DropdownOption } from '../atoms/Dropdown';
import { DateTimePicker, type DateTimeMode } from '../atoms/DateTimePicker';
import { SearchInput } from '../molecules/SearchInput';
import { Icon } from '../atoms/Icon';
import type { Dayjs } from 'dayjs';

/* ─── Filter definitions ─────────────────────── */
interface DropdownFilter {
  type: 'dropdown';
  name: string;
  label: string;
  options: (string | DropdownOption)[];
  value: any;
  onChange: (value: any) => void;
  multiple?: boolean;
  placeholder?: string;
}

interface DateFilter {
  type: 'date';
  name: string;
  label: string;
  value: Dayjs | null;
  onChange: (value: Dayjs | null) => void;
  mode?: DateTimeMode;
}

export type FilterDef = DropdownFilter | DateFilter;

export interface FilterBarProps {
  /** Filter definitions */
  filters: FilterDef[];
  /** Search input value */
  searchValue?: string;
  /** Search change handler */
  onSearchChange?: (value: string) => void;
  /** Reset all filters */
  onReset?: () => void;
  /** Search placeholder */
  searchPlaceholder?: string;
}

function FilterBar({
  filters,
  searchValue,
  onSearchChange,
  onReset,
  searchPlaceholder = 'Search…',
}: FilterBarProps) {
  return (
    <Box className="ds-c-filter-bar">
      {onSearchChange != null && (
        <Box className="ds-c-filter-bar__search">
          <SearchInput
            value={searchValue ?? ''}
            onChange={onSearchChange}
            placeholder={searchPlaceholder}
          />
        </Box>
      )}

      {filters.map((f) => {
        if (f.type === 'dropdown') {
          return (
            <Box key={f.name} className="ds-c-filter-bar__dropdown">
              <Dropdown
                label={f.label}
                options={f.options}
                value={f.value}
                onChange={f.onChange}
                multiple={f.multiple ?? false}
                placeholder={f.placeholder}
                size="small"
              />
            </Box>
          );
        }
        if (f.type === 'date') {
          return (
            <Box key={f.name} className="ds-c-filter-bar__date">
              <DateTimePicker
                label={f.label}
                value={f.value}
                onChange={f.onChange}
                mode={f.mode ?? 'date'}
                size="small"
              />
            </Box>
          );
        }
        return null;
      })}

      {onReset && (
        <Button
          variant="text"
          size="small"
          startIcon={<Icon name="rotate-ccw" size={14} />}
          onClick={onReset}
          className="ds-c-filter-bar__reset"
        >
          Reset
        </Button>
      )}
    </Box>
  );
}
export { FilterBar };
export default FilterBar;
