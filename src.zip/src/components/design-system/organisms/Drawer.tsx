/**
 * Organism: Drawer
 * =================
 * Side-sliding panel for editing forms, detail views, etc.
 *
 * Usage:
 *   <Drawer open={isOpen} onClose={handleClose} title="Edit Rule" anchor="right">
 *     <form>...</form>
 *   </Drawer>
 */
import { type ReactNode } from 'react';
import MuiDrawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import { Typography } from '../atoms/Typography';
import { IconButton } from '../atoms/IconButton';
import { Icon } from '../atoms/Icon';
import { Divider } from '../atoms/Divider';

export interface DrawerProps {
  /** Whether the drawer is open */
  open: boolean;
  /** Called when the drawer requests to close */
  onClose: () => void;
  /** Title text in the header */
  title?: string;
  /** Drawer anchor (default "right") */
  anchor?: 'left' | 'right';
  /** Drawer width (px or CSS string) */
  width?: number | string;
  /** Body content */
  children: ReactNode;
  /** Footer content (action buttons) */
  footer?: ReactNode;
  /** Extra className on the paper */
  className?: string;
}

function Drawer({
  open,
  onClose,
  title,
  anchor = 'right',
  width = 480,
  children,
  footer,
  className,
}: DrawerProps) {
  return (
    <MuiDrawer
      open={open}
      onClose={onClose}
      anchor={anchor}
      className={`ds-c-drawer ${className ?? ''}`}
      slotProps={{
        paper: {
          className: 'ds-c-drawer__paper',
          style: { width: typeof width === 'number' ? `${width}px` : width },
        },
      }}
    >
      {/* Header */}
      {title && (
        <>
          <Box className="ds-c-drawer__header">
            <Typography variant="h3">{title}</Typography>
            <IconButton size="small" onClick={onClose} tooltip="Close"><Icon name="x" size={16} /></IconButton>
          </Box>
          <Divider />
        </>
      )}

      {/* Body */}
      <Box className="ds-c-drawer__body">
        {children}
      </Box>

      {/* Footer */}
      {footer && (
        <>
          <Divider />
          <Box className="ds-c-drawer__footer">
            {footer}
          </Box>
        </>
      )}
    </MuiDrawer>
  );
}

export { Drawer };
export default Drawer;
