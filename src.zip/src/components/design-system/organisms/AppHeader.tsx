/**
 * Organism: AppHeader
 * ====================
 * Top navigation bar with logo, nav links, actions, and user menu.
 * Supports dark (navy) and light variants to match the SONAR app header.
 *
 * Usage:
 *   <AppHeader variant="dark" logo={<img src={logo} />} navItems={[...]} />
 *   <AppHeader variant="light" logo={...} navItems={[...]} />
 */
import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Box from '@mui/material/Box';
import MuiButton from '@mui/material/Button';

export interface NavItem {
  label: string;
  href: string;
  active?: boolean;
  icon?: React.ReactNode;
}

export interface AppHeaderProps {
  /** Logo element */
  logo?: React.ReactNode;
  /** Navigation items */
  navItems?: NavItem[];
  /** Right-side actions (notifications, user menu, etc.) */
  actions?: React.ReactNode;
  /** Navigation click handler */
  onNavigate?: (href: string) => void;
  /** Visual variant: dark matches the SONAR navy header, light is white */
  variant?: 'dark' | 'light';
}

function AppHeader({ logo, navItems = [], actions, onNavigate, variant = 'dark' }: AppHeaderProps) {

  return (
    <AppBar
      position="sticky"
      elevation={0}
      className="ds-c-app-header"
      data-variant={variant}
      style={{ height: 'var(--ds-header-height)', zIndex: 'var(--ds-z-sticky)' } as React.CSSProperties}
    >
      <Toolbar className="ds-c-app-header__toolbar">
        {/* Logo */}
        {logo && <Box className="ds-c-app-header__logo">{logo}</Box>}

        {/* Nav links */}
        <Box className="ds-c-app-header__nav">
          {navItems.map((item) => (
            <MuiButton
              key={item.href}
              size="small"
              startIcon={item.icon}
              onClick={() => onNavigate?.(item.href)}
              className={`ds-c-app-header__nav-btn ${item.active ? 'ds-c-app-header__nav-btn--active' : ''}`}
            >
              {item.label}
            </MuiButton>
          ))}
        </Box>

        {/* Actions */}
        {actions && (
          <Box className="ds-c-app-header__actions">
            {actions}
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
}
export { AppHeader };
export default AppHeader;
