/**
 * Organism: NotificationPanel
 * ============================
 * Dropdown notification/task center with tabbed view and item list.
 * Combines Popover, Tabs, NotificationItem, and TaskItem.
 *
 * Usage:
 *   <NotificationPanel
 *     notifications={notifications}
 *     tasks={tasks}
 *     onNotificationClick={(n) => navigate(n.link)}
 *     onTaskClick={(t) => navigate(t.link)}
 *   />
 */
import { useState } from 'react';
import Box from '@mui/material/Box';
import MuiBadge from '@mui/material/Badge';
import { Popover } from '../atoms/Popover';
import { IconButton } from '../atoms/IconButton';
import { Tabs } from '../atoms/Tabs';
import { Typography } from '../atoms/Typography';
import { Icon } from '../atoms/Icon';
import { NotificationItem, type NotificationItemProps } from '../molecules/NotificationItem';
import { TaskItem, type TaskItemProps } from '../molecules/TaskItem';

export interface NotificationData extends Omit<NotificationItemProps, 'onClick'> {
  id: string;
  link?: string;
}

export interface TaskData extends Omit<TaskItemProps, 'onClick'> {
  id: string;
  link?: string;
}

export interface NotificationPanelProps {
  /** Notification items */
  notifications?: NotificationData[];
  /** Task items */
  tasks?: TaskData[];
  /** Called when a notification is clicked */
  onNotificationClick?: (notification: NotificationData) => void;
  /** Called when a task is clicked */
  onTaskClick?: (task: TaskData) => void;
  /** Whether to show tabs (notifications + tasks) or just notifications */
  showTabs?: boolean;
  /** Extra className */
  className?: string;
}

function NotificationPanel({
  notifications = [],
  tasks = [],
  onNotificationClick,
  onTaskClick,
  showTabs = true,
  className,
}: NotificationPanelProps) {
  const [activeTab, setActiveTab] = useState('notifications');
  const unreadCount = notifications.filter((n) => n.unread).length;
  const pendingTasks = tasks.filter((t) => t.status !== 'completed').length;
  const totalBadge = unreadCount + pendingTasks;

  const trigger = (
    <MuiBadge
      badgeContent={totalBadge}
      color="error"
      max={99}
      className="ds-c-notification-panel__trigger"
    >
      <IconButton tooltip="Notifications"><Icon name="bell" size={18} /></IconButton>
    </MuiBadge>
  );

  const tabs = [
    { value: 'notifications', label: `Notifications${unreadCount ? ` (${unreadCount})` : ''}` },
    { value: 'tasks', label: `Tasks${pendingTasks ? ` (${pendingTasks})` : ''}` },
  ];

  return (
    <Popover
      trigger={trigger}
      title={showTabs ? undefined : 'Notifications'}
      width={400}
      maxHeight={520}
      placement="bottom-end"
      className={`ds-c-notification-panel ${className ?? ''}`}
    >
      {showTabs && (
        <Box className="ds-c-notification-panel__tabs">
          <Tabs
            tabs={tabs}
            value={activeTab}
            onChange={setActiveTab}
            size="small"
          />
        </Box>
      )}

      <Box className="ds-c-notification-panel__list">
        {activeTab === 'notifications' && (
          <>
            {notifications.length === 0 ? (
              <Box className="ds-c-notification-panel__empty">
                <Icon name="bell" size={32} />
                <Typography variant="body2" muted>No notifications</Typography>
              </Box>
            ) : (
              notifications.map((n) => (
                <NotificationItem
                  key={n.id}
                  title={n.title}
                  message={n.message}
                  timestamp={n.timestamp}
                  unread={n.unread}
                  onClick={() => onNotificationClick?.(n)}
                />
              ))
            )}
          </>
        )}

        {activeTab === 'tasks' && (
          <>
            {tasks.length === 0 ? (
              <Box className="ds-c-notification-panel__empty">
                <Icon name="inbox" size={32} />
                <Typography variant="body2" muted>No tasks</Typography>
              </Box>
            ) : (
              tasks.map((t) => (
                <TaskItem
                  key={t.id}
                  title={t.title}
                  description={t.description}
                  status={t.status}
                  priority={t.priority}
                  dueDate={t.dueDate}
                  assignee={t.assignee}
                  onClick={() => onTaskClick?.(t)}
                />
              ))
            )}
          </>
        )}
      </Box>
    </Popover>
  );
}

export { NotificationPanel };
export default NotificationPanel;
