/**
 * Organism: AppFooter
 * ====================
 * Application footer with copyright, version, and optional links.
 *
 * Usage:
 *   <AppFooter version="1.0.0" />
 *   <AppFooter
 *     links={[{ label: 'Privacy', href: '/privacy' }, { label: 'Terms', href: '/terms' }]}
 *   />
 */
import React from 'react';
import Box from '@mui/material/Box';
import MuiLink from '@mui/material/Link';
import { Typography } from '../atoms/Typography';

export interface FooterLink {
  label: string;
  href: string;
}

export interface AppFooterProps {
  /** Application version */
  version?: string;
  /** Footer links */
  links?: FooterLink[];
  /** Copyright text override */
  copyright?: string;
}

function AppFooter({
  version,
  links = [],
  copyright,
}: AppFooterProps) {
  const year = new Date().getFullYear();
  const copyrightText = copyright ?? `© ${year} Everest Re Group. All rights reserved.`;

  return (
    <Box component="footer" className="ds-c-app-footer">
      <Typography variant="caption">
        {copyrightText}
        {version && (
          <Box component="span" className="ds-c-app-footer__version">
            v{version}
          </Box>
        )}
      </Typography>

      {links.length > 0 && (
        <Box className="ds-c-app-footer__links">
          {links.map((link) => (
            <MuiLink
              key={link.href}
              href={link.href}
              underline="hover"
              className="ds-c-app-footer__link"
            >
              {link.label}
            </MuiLink>
          ))}
        </Box>
      )}
    </Box>
  );
}
export { AppFooter };
export default AppFooter;
