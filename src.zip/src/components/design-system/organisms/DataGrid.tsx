/**
 * Organism: DataGrid
 * ===================
 * Full-featured AG Grid wrapper with pre-configured defaults.
 * Supports all AG Grid community filters, column types, and features.
 *
 * Usage — Basic:
 *   <DataGrid
 *     rowData={rows}
 *     columnDefs={[
 *       { field: 'name', headerName: 'Name', filter: 'agTextColumnFilter' },
 *       { field: 'amount', headerName: 'Amount', filter: 'agNumberColumnFilter' },
 *       { field: 'date', headerName: 'Date', filter: 'agDateColumnFilter' },
 *       { field: 'status', headerName: 'Status', filter: 'agSetColumnFilter' },
 *     ]}
 *   />
 *
 * Usage — With all features:
 *   <DataGrid
 *     rowData={rows}
 *     columnDefs={columns}
 *     height={500}
 *     pagination
 *     pageSize={25}
 *     rowSelection="multiple"
 *     onRowClick={(row) => navigate(`/events/${row.id}`)}
 *     onSelectionChanged={(rows) => setSelected(rows)}
 *     quickFilterText={search}
 *     loading={isLoading}
 *     emptyMessage="No records found"
 *   />
 */
import React, { useMemo, useCallback, useRef } from 'react';
import { AgGridReact, type AgGridReactProps } from 'ag-grid-react';
import type {
  ColDef,
  GridReadyEvent,
  RowClickedEvent,
  SelectionChangedEvent,
  GridApi,
} from 'ag-grid-community';

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
interface AnyRow {  [key: string]: any; }
import {
  AllCommunityModule,
  ModuleRegistry,
  themeQuartz,
} from 'ag-grid-community';
import Box from '@mui/material/Box';

// Register all AG Grid community modules once
ModuleRegistry.registerModules([AllCommunityModule]);

/* ─── Styled AG Grid theme to match SONAR design tokens ─── */
const sonarGridTheme = themeQuartz.withParams({
  accentColor: '#0052FF',
  backgroundColor: '#FFFFFF',
  borderColor: '#e5e7eb',
  borderRadius: 6,
  browserColorScheme: 'light',
  cellTextColor: '#111827',
  chromeBackgroundColor: '#f9fafb',
  fontFamily: "'Segoe UI', Segoe, Tahoma, 'Helvetica Neue', Helvetica, Arial, sans-serif",
  fontSize: 13,
  foregroundColor: '#111827',
  headerBackgroundColor: '#f9fafb',
  headerFontSize: 12,
  headerFontWeight: 500,
  headerTextColor: '#374151',
  oddRowBackgroundColor: '#FFFFFF',
  rowBorder: { color: '#f3f4f6', style: 'solid', width: 1 },
  rowVerticalPaddingScale: 0.8,
  spacing: 6,
  wrapperBorder: false,
  wrapperBorderRadius: 8,
});

/* ─── Types ──────────────────────────────────── */
export interface DataGridProps<TData = any> {
  /** Row data array */
  rowData: TData[] | null;
  /** Column definitions */
  columnDefs: ColDef<TData>[];
  /** Grid height in px or CSS string (default 400) */
  height?: number | string;
  /** Enable pagination */
  pagination?: boolean;
  /** Rows per page (default 25) */
  pageSize?: number;
  /** Row selection mode */
  rowSelection?: 'single' | 'multiple';
  /** Quick filter text for instant global search */
  quickFilterText?: string;
  /** Row click handler */
  onRowClick?: (data: TData) => void;
  /** Selection changed handler */
  onSelectionChanged?: (selectedRows: TData[]) => void;
  /** Loading state */
  loading?: boolean;
  /** Custom empty message */
  emptyMessage?: string;
  /** Whether columns auto-size to fit (default true) */
  autoSizeColumns?: boolean;
  /** Ref to AG Grid API */
  gridRef?: React.RefObject<GridApi<TData> | null>;
  /** Default col def overrides */
  defaultColDef?: ColDef<TData>;
  /** Additional AG Grid props */
  gridProps?: Partial<AgGridReactProps<TData>>;
}

/* ─── Default column definitions ─────────────── */
const baseDefaultColDef: ColDef = {
  sortable: true,
  resizable: true,
  filter: true,
  floatingFilter: true,
  minWidth: 80,
  flex: 1,
  filterParams: {
    buttons: ['reset', 'apply'],
    closeOnApply: true,
  },
};

/* ─── Component ──────────────────────────────── */
function DataGrid<TData = any>({
  rowData,
  columnDefs,
  height = 400,
  pagination = true,
  pageSize = 25,
  rowSelection,
  quickFilterText,
  onRowClick,
  onSelectionChanged,
  loading = false,
  emptyMessage = 'No rows to display',
  autoSizeColumns = true,
  gridRef,
  defaultColDef: userDefaultColDef,
  gridProps = {},
}: DataGridProps<TData>) {
  const internalRef = useRef<AgGridReact<TData>>(null);

  const mergedDefaultColDef = useMemo(
    () => ({ ...baseDefaultColDef, ...userDefaultColDef }),
    [userDefaultColDef],
  );

  const onGridReady = useCallback(
    (params: GridReadyEvent<TData>) => {
      if (gridRef) {
        (gridRef as React.MutableRefObject<GridApi<TData> | null>).current = params.api;
      }
      if (autoSizeColumns) {
        params.api.sizeColumnsToFit();
      }
      gridProps?.onGridReady?.(params);
    },
    [autoSizeColumns, gridRef, gridProps],
  );

  const handleRowClicked = useCallback(
    (event: RowClickedEvent<TData>) => {
      if (event.data && onRowClick) onRowClick(event.data);
    },
    [onRowClick],
  );

  const handleSelectionChanged = useCallback(
    (event: SelectionChangedEvent<TData>) => {
      if (onSelectionChanged) {
        const selected = event.api.getSelectedRows();
        onSelectionChanged(selected);
      }
    },
    [onSelectionChanged],
  );

  const paginationConfig = pagination
    ? { pagination: true, paginationPageSize: pageSize, paginationPageSizeSelector: [10, 25, 50, 100] }
    : { pagination: false as const };

  const selectionConfig = rowSelection
    ? { rowSelection: { mode: rowSelection as 'singleRow' | 'multiRow' } }
    : {};

  return (
    <Box
      className="ds-c-data-grid"
      style={{ height: typeof height === 'number' ? `${height}px` : height }}
    >
      <AgGridReact<TData>
        ref={internalRef}
        theme={sonarGridTheme}
        rowData={rowData}
        columnDefs={columnDefs as any}
        defaultColDef={mergedDefaultColDef as any}
        quickFilterText={quickFilterText}
        loading={loading}
        overlayNoRowsTemplate={`<span style="font-size:13px;color:#6b7280">${emptyMessage}</span>`}
        animateRows
        enableCellTextSelection
        suppressCellFocus
        onGridReady={onGridReady}
        onRowClicked={handleRowClicked}
        {...paginationConfig}
        {...selectionConfig}
        {...gridProps}
      />
    </Box>
  );
}

export { DataGrid };
export default DataGrid;
