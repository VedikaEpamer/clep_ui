/**
 * Templates — barrel export
 */
export { PageLayout, type PageLayoutProps } from './PageLayout';
export { SidebarLayout, type SidebarLayoutProps } from './SidebarLayout';
export { MasterDetail, type MasterDetailProps } from './MasterDetail';
export { StepWizard, type WizardStep, type StepWizardProps } from './StepWizard';
