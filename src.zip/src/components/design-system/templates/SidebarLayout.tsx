/**
 * Template: SidebarLayout
 * ========================
 * Fixed header + collapsible sidebar + main content area.
 * Used for event detail layouts, admin pages with nav sidebars.
 *
 * Usage:
 *   <SidebarLayout
 *     header={<AppHeader />}
 *     sidebar={<NavSidebar />}
 *     sidebarWidth={240}
 *   >
 *     <Outlet />
 *   </SidebarLayout>
 */
import { useState, type ReactNode } from 'react';
import Box from '@mui/material/Box';
import { IconButton } from '../atoms/IconButton';
import { Icon } from '../atoms/Icon';

export interface SidebarLayoutProps {
  /** Header content (typically AppHeader) */
  header?: ReactNode;
  /** Sidebar content (nav items, tree view, etc.) */
  sidebar?: ReactNode;
  /** Sidebar width in px (default 240) */
  sidebarWidth?: number;
  /** Sidebar position */
  sidebarPosition?: 'left' | 'right';
  /** Whether sidebar is collapsible (default true) */
  collapsible?: boolean;
  /** Default collapsed state */
  defaultCollapsed?: boolean;
  /** Main content */
  children: ReactNode;
  /** Footer content */
  footer?: ReactNode;
  /** Extra className */
  className?: string;
}

function SidebarLayout({
  header,
  sidebar,
  sidebarWidth = 240,
  sidebarPosition = 'left',
  collapsible = true,
  defaultCollapsed = false,
  children,
  footer,
  className,
}: SidebarLayoutProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);
  const effectiveWidth = collapsed ? 0 : sidebarWidth;

  return (
    <Box className={`ds-t-sidebar-layout ${className ?? ''}`}>
      {/* Header */}
      {header && <Box className="ds-t-sidebar-layout__header">{header}</Box>}

      {/* Body: sidebar + main */}
      <Box className="ds-t-sidebar-layout__body">
        {/* Sidebar */}
        {sidebar && (
          <Box
            className={`ds-t-sidebar-layout__sidebar ds-t-sidebar-layout__sidebar--${sidebarPosition} ${collapsed ? 'ds-t-sidebar-layout__sidebar--collapsed' : ''}`}
            style={{ width: effectiveWidth }}
          >
            <Box className="ds-t-sidebar-layout__sidebar-content">
              {sidebar}
            </Box>
            {collapsible && (
              <Box className="ds-t-sidebar-layout__collapse-btn">
                <IconButton
                  size="small"
                  onClick={() => setCollapsed((prev) => !prev)}
                  tooltip={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                >
                  <Icon name={collapsed ? 'chevron-right' : 'chevron-left'} size={16} />
                </IconButton>
              </Box>
            )}
          </Box>
        )}

        {/* Main */}
        <Box className="ds-t-sidebar-layout__main">
          {children}
        </Box>
      </Box>

      {/* Footer */}
      {footer && <Box className="ds-t-sidebar-layout__footer">{footer}</Box>}
    </Box>
  );
}

export { SidebarLayout };
export default SidebarLayout;
