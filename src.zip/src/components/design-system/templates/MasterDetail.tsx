/**
 * Template: MasterDetail
 * =======================
 * Two-panel layout: left list/nav panel + right detail panel.
 * Used for roles & permissions, settings pages, etc.
 *
 * Usage:
 *   <MasterDetail
 *     master={<RoleList ... />}
 *     detail={<RoleDetail ... />}
 *     masterWidth={280}
 *   />
 */
import { type ReactNode } from 'react';
import Box from '@mui/material/Box';

export interface MasterDetailProps {
  /** Left (master) panel content */
  master: ReactNode;
  /** Right (detail) panel content */
  detail: ReactNode;
  /** Master panel width in px (default 280) */
  masterWidth?: number;
  /** Title for the master panel */
  masterTitle?: string;
  /** Extra className */
  className?: string;
}

function MasterDetail({
  master,
  detail,
  masterWidth = 280,
  className,
}: MasterDetailProps) {
  return (
    <Box className={`ds-t-master-detail ${className ?? ''}`}>
      <Box className="ds-t-master-detail__master" style={{ width: masterWidth, minWidth: masterWidth }}>
        {master}
      </Box>
      <Box className="ds-t-master-detail__detail">
        {detail}
      </Box>
    </Box>
  );
}

export { MasterDetail };
export default MasterDetail;
