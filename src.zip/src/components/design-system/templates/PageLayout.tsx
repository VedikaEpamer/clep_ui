/**
 * Template: PageLayout
 * =====================
 * Standard page wrapper with header, content area, and optional footer.
 *
 * Usage:
 *   <PageLayout
 *     header={<AppHeader ... />}
 *     footer={<AppFooter ... />}
 *   >
 *     <PageHeader title="Events" />
 *     <DataGrid ... />
 *   </PageLayout>
 */
import React from 'react';
import Box from '@mui/material/Box';

export interface PageLayoutProps {
  /** App header (sticky top) */
  header?: React.ReactNode;
  /** App footer (sticky bottom) */
  footer?: React.ReactNode;
  /** Main content */
  children: React.ReactNode;
  /** Max width for content area (default "100%") */
  maxWidth?: number | string;
  /** Background color */
  bg?: string;
}

function PageLayout({
  header,
  footer,
  children,
  maxWidth = '100%',
  bg = 'var(--ds-bg-secondary)',
}: PageLayoutProps) {
  return (
    <Box
      className="ds-c-page-layout"
      style={{ backgroundColor: bg }}
    >
      {header}
      <Box
        component="main"
        className="ds-c-page-layout__main"
        style={{ maxWidth }}
      >
        {children}
      </Box>
      {footer}
    </Box>
  );
}
export { PageLayout };
export default PageLayout;
