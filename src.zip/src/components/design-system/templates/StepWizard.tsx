/**
 * Template: StepWizard
 * =====================
 * Multi-step form wizard with step tracker, navigation, and action buttons.
 *
 * Usage:
 *   <StepWizard
 *     steps={[
 *       { label: 'Event Identity', content: <EventIdentityForm /> },
 *       { label: 'Impact & Perils', content: <ImpactForm /> },
 *       { label: 'Review', content: <ReviewStep /> },
 *     ]}
 *     onComplete={handlePublish}
 *     onSaveDraft={handleSaveDraft}
 *   />
 */
import { useState, type ReactNode } from 'react';
import Box from '@mui/material/Box';
import MuiStepper from '@mui/material/Stepper';
import MuiStep from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import { Button } from '../atoms/Button';
import { Typography } from '../atoms/Typography';
import { Divider } from '../atoms/Divider';

export interface WizardStep {
  /** Step label */
  label: string;
  /** Optional description */
  description?: string;
  /** Step content */
  content: ReactNode;
  /** Whether this step is optional */
  optional?: boolean;
  /** Custom validation — return true if valid */
  validate?: () => boolean;
}

export interface StepWizardProps {
  /** Array of wizard steps */
  steps: WizardStep[];
  /** Called when the final step completes */
  onComplete?: () => void;
  /** Called when save draft is clicked */
  onSaveDraft?: () => void;
  /** Called when cancel is clicked */
  onCancel?: () => void;
  /** Label for the final action button (default "Submit") */
  completeLabel?: string;
  /** Whether to show save draft button */
  showDraft?: boolean;
  /** Title displayed above the stepper */
  title?: string;
  /** Extra className */
  className?: string;
}

function StepWizard({
  steps,
  onComplete,
  onSaveDraft,
  onCancel,
  completeLabel = 'Submit',
  showDraft = true,
  title,
  className,
}: StepWizardProps) {
  const [activeStep, setActiveStep] = useState(0);
  const isLast = activeStep === steps.length - 1;
  const currentStep = steps[activeStep];

  function handleNext() {
    if (currentStep.validate && !currentStep.validate()) return;
    if (isLast) {
      onComplete?.();
    } else {
      setActiveStep((prev) => prev + 1);
    }
  }

  function handleBack() {
    setActiveStep((prev) => Math.max(0, prev - 1));
  }

  return (
    <Box className={`ds-t-step-wizard ${className ?? ''}`}>
      {/* Header */}
      {title && (
        <Box className="ds-t-step-wizard__header">
          <Typography variant="h2">{title}</Typography>
        </Box>
      )}

      {/* Stepper */}
      <Box className="ds-t-step-wizard__stepper">
        <MuiStepper activeStep={activeStep} alternativeLabel>
          {steps.map((step, index) => (
            <MuiStep key={step.label} completed={index < activeStep}>
              <StepLabel
                optional={step.optional ? <Typography variant="caption">Optional</Typography> : undefined}
              >
                {step.label}
              </StepLabel>
            </MuiStep>
          ))}
        </MuiStepper>
      </Box>

      <Divider />

      {/* Step content */}
      <Box className="ds-t-step-wizard__content">
        {currentStep.content}
      </Box>

      {/* Actions */}
      <Divider />
      <Box className="ds-t-step-wizard__actions">
        <Box className="ds-t-step-wizard__actions-left">
          {onCancel && (
            <Button variant="text" onClick={onCancel}>
              Cancel
            </Button>
          )}
          {showDraft && onSaveDraft && (
            <Button variant="outlined" startIcon="save" onClick={onSaveDraft}>
              Save Draft
            </Button>
          )}
        </Box>
        <Box className="ds-t-step-wizard__actions-right">
          <Button variant="outlined" onClick={handleBack} disabled={activeStep === 0}>
            Back
          </Button>
          <Button variant="contained" onClick={handleNext} startIcon={isLast ? 'send' : undefined}>
            {isLast ? completeLabel : 'Next'}
          </Button>
        </Box>
      </Box>
    </Box>
  );
}

export { StepWizard };
export default StepWizard;
