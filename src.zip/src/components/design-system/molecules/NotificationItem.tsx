/**
 * Molecule: NotificationItem
 * ===========================
 * A single notification row with unread dot, title, message, and relative time.
 *
 * Usage:
 *   <NotificationItem
 *     title="New assignment"
 *     message="You've been assigned to Hurricane Maria"
 *     timestamp="2026-03-28T10:30:00Z"
 *     unread
 *     onClick={() => navigate('/events/1')}
 *   />
 */
import Box from '@mui/material/Box';
import { Typography } from '../atoms/Typography';

export interface NotificationItemProps {
  /** Notification title */
  title: string;
  /** Description or body */
  message?: string;
  /** ISO timestamp */
  timestamp: string;
  /** Whether unread */
  unread?: boolean;
  /** Click handler */
  onClick?: () => void;
  /** Extra className */
  className?: string;
}

function formatRelativeTime(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(ts).toLocaleDateString();
}

function NotificationItem({
  title,
  message,
  timestamp,
  unread = false,
  onClick,
  className,
}: NotificationItemProps) {
  return (
    <Box
      component="button"
      type="button"
      onClick={onClick}
      className={`ds-c-notification-item ${unread ? 'ds-c-notification-item--unread' : ''} ${className ?? ''}`}
    >
      {unread && <Box className="ds-c-notification-item__dot" />}
      <Box className="ds-c-notification-item__content">
        <Typography variant="subtitle2" className="ds-c-notification-item__title">{title}</Typography>
        {message && <Typography variant="caption" muted>{message}</Typography>}
      </Box>
      <Typography variant="caption" muted className="ds-c-notification-item__time">
        {formatRelativeTime(timestamp)}
      </Typography>
    </Box>
  );
}

export { NotificationItem };
export default NotificationItem;
