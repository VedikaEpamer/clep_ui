/**
 * Molecule: SearchInput
 * =====================
 * Search field with icon, clear button, and optional debounce.
 *
 * Usage:
 *   <SearchInput value={q} onChange={setQ} placeholder="Search events..." />
 *   <SearchInput value={q} onChange={setQ} debounceMs={300} />
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import TextField from '@mui/material/TextField';
import MuiIconButton from '@mui/material/IconButton';
import Box from '@mui/material/Box';
import { Icon } from '../atoms/Icon';
import { fieldSx } from '../atoms/Input';

export interface SearchInputProps {
  /** Controlled value */
  value: string;
  /** Called with new search text */
  onChange: (value: string) => void;
  /** Placeholder text */
  placeholder?: string;
  /** Debounce delay in ms (0 = immediate) */
  debounceMs?: number;
  /** Size */
  size?: 'small' | 'medium';
  /** Full width */
  fullWidth?: boolean;
  /** Extra className */
  className?: string;
}

function SearchInput({
  value,
  onChange,
  placeholder = 'Search…',
  debounceMs = 0,
  size = 'small',
  fullWidth = true,
  className,
}: SearchInputProps) {
  const [local, setLocal] = useState(value);
  const timerRef = useRef<ReturnType<typeof setTimeout>>(undefined);

  // Sync external → local
  useEffect(() => {
    setLocal(value);
  }, [value]);

  const emit = useCallback(
    (v: string) => {
      if (debounceMs > 0) {
        clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => onChange(v), debounceMs);
      } else {
        onChange(v);
      }
    },
    [onChange, debounceMs],
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocal(e.target.value);
    emit(e.target.value);
  };

  const handleClear = () => {
    setLocal('');
    onChange('');
  };

  return (
    <Box className={`ds-c-search-input ${fullWidth ? 'ds-c-search-input--full' : 'ds-c-search-input--inline'}`}>
      <Box className="ds-c-search-input__icon">
        <Icon name="search" size={16} color="var(--ds-text-tertiary)" />
      </Box>
      <TextField
        value={local}
        onChange={handleChange}
        placeholder={placeholder}
        size={size}
        fullWidth={fullWidth}
        className={`ds-c-field ${className ?? ''}`}
        style={{ paddingLeft: 32, paddingRight: local ? 36 : undefined } as React.CSSProperties}
        variant="outlined"
      />
      {local && (
        <Box className="ds-c-search-input__clear">
          <MuiIconButton size="small" onClick={handleClear}>
            <Icon name="x" size={14} />
          </MuiIconButton>
        </Box>
      )}
    </Box>
  );
}


export { SearchInput };
export default SearchInput;
