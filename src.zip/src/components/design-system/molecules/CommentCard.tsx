/**
 * Molecule: CommentCard
 * ======================
 * Single comment display with avatar, metadata, text, and file attachments.
 *
 * Usage:
 *   <CommentCard
 *     author="John Doe"
 *     authorRole="Claims Analyst"
 *     team="Claims"
 *     timestamp="2026-03-28T10:30:00Z"
 *     text="This is a comment..."
 *     isInternal
 *   />
 */
import Box from '@mui/material/Box';
import { Avatar } from '../atoms/Avatar';
import { Badge } from '../atoms/Badge';
import { Chip } from '../atoms/Chip';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export interface CommentAttachment {
  id: string;
  name: string;
}

export interface CommentCardProps {
  /** Comment author name */
  author: string;
  /** Author role / position */
  authorRole?: string;
  /** Team name (color-coded badge) */
  team?: string;
  /** ISO timestamp or display string */
  timestamp: string;
  /** Comment text */
  text: string;
  /** Whether this is an internal/private comment */
  isInternal?: boolean;
  /** File attachments */
  attachments?: CommentAttachment[];
  /** Extra className */
  className?: string;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function formatRelativeTime(timestamp: string): string {
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diff = now - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(timestamp).toLocaleDateString();
}

function CommentCard({
  author,
  authorRole,
  team,
  timestamp,
  text,
  isInternal = false,
  attachments,
  className,
}: CommentCardProps) {
  return (
    <Box className={`ds-c-comment ${isInternal ? 'ds-c-comment--internal' : ''} ${className ?? ''}`}>
      {/* Header */}
      <Box className="ds-c-comment__header">
        <Avatar initials={getInitials(author)} size="small" />
        <Box className="ds-c-comment__meta">
          <Box className="ds-c-comment__author-row">
            <Typography variant="subtitle2">{author}</Typography>
            {isInternal && (
              <Chip label="Internal" status="warning" size="small" icon={<Icon name="lock" size={12} />} />
            )}
          </Box>
          <Box className="ds-c-comment__info-row">
            {authorRole && <Typography variant="caption" muted>{authorRole}</Typography>}
            {team && <Chip label={team} size="small" />}
            <Typography variant="caption" muted>{formatRelativeTime(timestamp)}</Typography>
          </Box>
        </Box>
      </Box>

      {/* Body */}
      <Box className="ds-c-comment__body">
        <Typography variant="body2" style={{ whiteSpace: 'pre-wrap' }}>{text}</Typography>
      </Box>

      {/* Attachments */}
      {attachments && attachments.length > 0 && (
        <Box className="ds-c-comment__attachments">
          {attachments.map((file) => (
            <Box key={file.id} className="ds-c-comment__file">
              <Icon name="paperclip" size={12} />
              <Typography variant="caption">{file.name}</Typography>
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
}

export { CommentCard };
export default CommentCard;
