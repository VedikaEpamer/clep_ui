/**
 * Molecule: EmptyState
 * =====================
 * Placeholder shown when a list/table has no data.
 *
 * Usage:
 *   <EmptyState icon={<Inbox />} title="No events found" description="Try adjusting your filters." />
 *   <EmptyState title="No data" action={<Button>Create</Button>} />
 */
import React from 'react';
import Box from '@mui/material/Box';
import { Typography } from '../atoms/Typography';

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <Box className="ds-c-empty-state">
      {icon && (
        <Box className="ds-c-empty-state__icon">
          {icon}
        </Box>
      )}
      <Typography variant="h4" className="ds-c-empty-state__title">
        {title}
      </Typography>
      {description && (
        <Typography variant="body2" muted className="ds-c-empty-state__desc">
          {description}
        </Typography>
      )}
      {action && <Box className="ds-c-empty-state__action">{action}</Box>}
    </Box>
  );
}
export { EmptyState };
export default EmptyState;
