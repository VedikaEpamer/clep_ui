/**
 * Molecule: RepeaterField
 * ========================
 * Dynamic add/remove form row set for repeating data (IDs, sources, items).
 *
 * Usage:
 *   <RepeaterField
 *     label="External IDs"
 *     items={items}
 *     onAdd={handleAdd}
 *     onRemove={handleRemove}
 *     onChange={handleChange}
 *     renderItem={(item, index) => (
 *       <Input value={item.value} onChange={...} />
 *     )}
 *   />
 */
import { type ReactNode } from 'react';
import Box from '@mui/material/Box';
import { Button } from '../atoms/Button';
import { IconButton } from '../atoms/IconButton';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export interface RepeaterItem {
  /** Unique identifier for this row */
  id: string;
  [key: string]: any;
}

export interface RepeaterFieldProps<T extends RepeaterItem = RepeaterItem> {
  /** Section label */
  label?: string;
  /** Current items */
  items: T[];
  /** Render a single row — receives item and index */
  renderItem: (item: T, index: number) => ReactNode;
  /** Called to add a new empty row */
  onAdd: () => void;
  /** Called to remove a row by id */
  onRemove: (id: string) => void;
  /** Label for the add button (default "Add Row") */
  addLabel?: string;
  /** Maximum number of rows */
  maxItems?: number;
  /** Minimum rows (cannot remove below this) */
  minItems?: number;
  /** Empty state message */
  emptyMessage?: string;
  /** Extra className */
  className?: string;
}

function RepeaterField<T extends RepeaterItem = RepeaterItem>({
  label,
  items,
  renderItem,
  onAdd,
  onRemove,
  addLabel = 'Add Row',
  maxItems,
  minItems = 0,
  emptyMessage = 'No items added yet.',
  className,
}: RepeaterFieldProps<T>) {
  const canAdd = !maxItems || items.length < maxItems;
  const canRemove = items.length > minItems;

  return (
    <Box className={`ds-c-repeater ${className ?? ''}`}>
      {label && (
        <Typography variant="subtitle2" className="ds-c-repeater__label">{label}</Typography>
      )}

      {items.length === 0 ? (
        <Box className="ds-c-repeater__empty">
          <Icon name="inbox" size={24} />
          <Typography variant="caption" muted>{emptyMessage}</Typography>
        </Box>
      ) : (
        <Box className="ds-c-repeater__list">
          {items.map((item, index) => (
            <Box key={item.id} className="ds-c-repeater__row">
              <Box className="ds-c-repeater__row-content">
                {renderItem(item, index)}
              </Box>
              {canRemove && (
                <IconButton
                  size="small"
                  color="error"
                  onClick={() => onRemove(item.id)}
                  tooltip="Remove"
                >
                  <Icon name="trash-2" size={14} />
                </IconButton>
              )}
            </Box>
          ))}
        </Box>
      )}

      {canAdd && (
        <Button
          variant="outlined"
          startIcon="plus"
          onClick={onAdd}
          className="ds-c-repeater__add-btn"
        >
          {addLabel}
        </Button>
      )}
    </Box>
  );
}

export { RepeaterField };
export default RepeaterField;
