/**
 * Molecule: FormField
 * ====================
 * Labelled form field wrapper with error, helper, and required indicator.
 *
 * Usage:
 *   <FormField label="Event Name" required error="Name is required">
 *     <Input value={name} onChange={...} />
 *   </FormField>
 *
 *   <FormField label="Region" helper="Select all impacted regions">
 *     <Dropdown multiple options={regions} ... />
 *   </FormField>
 */
import React from 'react';
import Box from '@mui/material/Box';
import { Typography } from '../atoms/Typography';

export interface FormFieldProps {
  /** Field label */
  label: string;
  /** Is the field required? */
  required?: boolean;
  /** Error message (if present, shows in error style) */
  error?: string;
  /** Helper text */
  helper?: string;
  /** Orientation */
  direction?: 'vertical' | 'horizontal';
  /** Label width when horizontal (default 140px) */
  labelWidth?: number;
  /** Content */
  children: React.ReactNode;
  /** Extra className */
  className?: string;
}

function FormField({
  label,
  required,
  error,
  helper,
  direction = 'vertical',
  labelWidth = 140,
  children,
  className,
}: FormFieldProps) {
  const isHorizontal = direction === 'horizontal';

  return (
    <Box
      className={`ds-c-form-field ${className ?? ''}`}
      data-direction={direction}
    >
      <Typography
        variant="label"
        className="ds-c-form-field__label"
        style={isHorizontal ? { minWidth: labelWidth } : undefined}
      >
        {label}
        {required && (
          <Box component="span" className="ds-c-form-field__required">
            *
          </Box>
        )}
      </Typography>

      <Box className="ds-c-form-field__body">
        {children}
        {(error || helper) && (
          <Typography
            variant="helper"
            className={`ds-c-form-field__helper ${error ? 'ds-c-form-field__helper--error' : ''}`}
          >
            {error || helper}
          </Typography>
        )}
      </Box>
    </Box>
  );
}
export { FormField };
export default FormField;
