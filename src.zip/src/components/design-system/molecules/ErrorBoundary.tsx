/**
 * Molecule: ErrorBoundary
 * ========================
 * Error fallback with retry and optional error detail display.
 *
 * Usage:
 *   <ErrorBoundary fallback={<ErrorFallback />}>
 *     <SomeComponent />
 *   </ErrorBoundary>
 *
 * Or use the pre-built fallback:
 *   <ErrorBoundary>
 *     <SomeComponent />
 *   </ErrorBoundary>
 */
import { Component, type ReactNode } from 'react';
import Box from '@mui/material/Box';
import { Button } from '../atoms/Button';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export interface ErrorFallbackProps {
  /** The error that was caught */
  error: Error;
  /** Call to retry (re-mount the children) */
  onRetry: () => void;
}

export interface ErrorBoundaryProps {
  /** Child components to wrap */
  children: ReactNode;
  /** Custom fallback UI — receives error and retry function */
  fallback?: (props: ErrorFallbackProps) => ReactNode;
  /** Called when an error is caught */
  onError?: (error: Error, info: React.ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/** Default fallback component */
function DefaultFallback({ error, onRetry }: ErrorFallbackProps) {
  return (
    <Box className="ds-c-error-boundary">
      <Icon name="alert-triangle" size={40} className="ds-c-error-boundary__icon" />
      <Typography variant="h4">Something went wrong</Typography>
      <Typography variant="body2" muted className="ds-c-error-boundary__message">
        {error.message}
      </Typography>
      <Box className="ds-c-error-boundary__actions">
        <Button variant="contained" onClick={onRetry} startIcon="rotate-ccw">
          Try Again
        </Button>
        <Button variant="outlined" onClick={() => window.location.reload()}>
          Reload Page
        </Button>
      </Box>
    </Box>
  );
}

class ErrorBoundary extends Component<ErrorBoundaryProps, State> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    this.props.onError?.(error, info);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError && this.state.error) {
      const { fallback } = this.props;
      if (fallback) {
        return fallback({ error: this.state.error, onRetry: this.handleRetry });
      }
      return <DefaultFallback error={this.state.error} onRetry={this.handleRetry} />;
    }
    return this.props.children;
  }
}

export { ErrorBoundary, DefaultFallback };
export default ErrorBoundary;
