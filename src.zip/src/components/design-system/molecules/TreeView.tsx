/**
 * Molecule: TreeNode (recursive)
 * ===============================
 * A collapsible tree-view row item, used for hierarchical data (portfolios, org charts, etc.).
 *
 * Usage:
 *   <TreeView
 *     nodes={[
 *       { id: '1', label: 'North America', children: [
 *         { id: '1a', label: 'USA' },
 *         { id: '1b', label: 'Canada' },
 *       ]},
 *     ]}
 *     selectedId={selectedId}
 *     onSelect={setSelectedId}
 *   />
 */
import { useState, type ReactNode } from 'react';
import Box from '@mui/material/Box';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export interface TreeNodeData {
  /** Unique node id */
  id: string;
  /** Display label */
  label: string;
  /** Optional icon name */
  icon?: string;
  /** Optional right-side badge or count */
  badge?: ReactNode;
  /** Child nodes */
  children?: TreeNodeData[];
  /** Whether initially expanded */
  defaultExpanded?: boolean;
  /** Disabled state */
  disabled?: boolean;
}

export interface TreeViewProps {
  /** Root nodes */
  nodes: TreeNodeData[];
  /** Currently selected node id */
  selectedId?: string;
  /** Called when a node is selected */
  onSelect?: (id: string) => void;
  /** Extra className */
  className?: string;
}

interface TreeNodeProps {
  node: TreeNodeData;
  depth: number;
  selectedId?: string;
  onSelect?: (id: string) => void;
}

function TreeNodeItem({ node, depth, selectedId, onSelect }: TreeNodeProps) {
  const [expanded, setExpanded] = useState(node.defaultExpanded ?? depth < 1);
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = selectedId === node.id;

  return (
    <Box className="ds-c-tree-node">
      <Box
        component="button"
        type="button"
        className={`ds-c-tree-node__row ${isSelected ? 'ds-c-tree-node__row--selected' : ''}`}
        style={{ paddingLeft: depth * 16 + 8 }}
        onClick={() => {
          if (hasChildren) setExpanded((prev) => !prev);
          onSelect?.(node.id);
        }}
        disabled={node.disabled}
      >
        {hasChildren ? (
          <Icon name={expanded ? 'chevron-down' : 'chevron-right'} size={14} className="ds-c-tree-node__toggle" />
        ) : (
          <Box className="ds-c-tree-node__spacer" />
        )}
        {node.icon && <Icon name={node.icon as any} size={14} />}
        <Typography variant="body2" className="ds-c-tree-node__label">{node.label}</Typography>
        {node.badge && <Box className="ds-c-tree-node__badge">{node.badge}</Box>}
      </Box>
      {hasChildren && expanded && (
        <Box className="ds-c-tree-node__children">
          {node.children!.map((child) => (
            <TreeNodeItem key={child.id} node={child} depth={depth + 1} selectedId={selectedId} onSelect={onSelect} />
          ))}
        </Box>
      )}
    </Box>
  );
}

function TreeView({ nodes, selectedId, onSelect, className }: TreeViewProps) {
  return (
    <Box className={`ds-c-tree-view ${className ?? ''}`}>
      {nodes.map((node) => (
        <TreeNodeItem key={node.id} node={node} depth={0} selectedId={selectedId} onSelect={onSelect} />
      ))}
    </Box>
  );
}

export { TreeView, TreeNodeItem };
export default TreeView;
