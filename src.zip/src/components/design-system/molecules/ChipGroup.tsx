/**
 * Molecule: ChipGroup
 * ====================
 * Multi-select chip toggle group for selecting from a set of options.
 *
 * Usage:
 *   <ChipGroup
 *     label="Teams"
 *     options={[
 *       { value: 'claims', label: 'Claims' },
 *       { value: 'finance', label: 'Finance' },
 *     ]}
 *     selected={selectedSet}
 *     onChange={setSelectedSet}
 *   />
 */
import Box from '@mui/material/Box';
import MuiChip from '@mui/material/Chip';
import { Icon } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export interface ChipOption {
  /** Unique value */
  value: string;
  /** Display label */
  label: string;
  /** Optional icon */
  icon?: string;
  /** Disabled */
  disabled?: boolean;
}

export interface ChipGroupProps {
  /** Group label */
  label?: string;
  /** Available options */
  options: ChipOption[];
  /** Currently selected values */
  selected: Set<string>;
  /** Called with updated selection set */
  onChange: (selected: Set<string>) => void;
  /** Color variant for selected chips */
  color?: 'primary' | 'success' | 'warning' | 'error' | 'info';
  /** Single-select mode (radio-like) */
  singleSelect?: boolean;
  /** Extra className */
  className?: string;
}

function ChipGroup({
  label,
  options,
  selected,
  onChange,
  color = 'primary',
  singleSelect = false,
  className,
}: ChipGroupProps) {
  function handleToggle(value: string) {
    if (singleSelect) {
      onChange(new Set([value]));
      return;
    }
    const next = new Set(selected);
    if (next.has(value)) {
      next.delete(value);
    } else {
      next.add(value);
    }
    onChange(next);
  }

  return (
    <Box className={`ds-c-chip-group ${className ?? ''}`}>
      {label && (
        <Typography variant="label" className="ds-c-chip-group__label">{label}</Typography>
      )}
      <Box className="ds-c-chip-group__chips">
        {options.map((opt) => {
          const isSelected = selected.has(opt.value);
          return (
            <MuiChip
              key={opt.value}
              label={opt.label}
              icon={opt.icon ? <Icon name={opt.icon as any} size={14} /> : undefined}
              onClick={() => handleToggle(opt.value)}
              variant={isSelected ? 'filled' : 'outlined'}
              color={isSelected ? color : 'default'}
              disabled={opt.disabled}
              className={`ds-c-chip-group__chip ${isSelected ? 'ds-c-chip-group__chip--selected' : ''}`}
            />
          );
        })}
      </Box>
    </Box>
  );
}

export { ChipGroup };
export default ChipGroup;
