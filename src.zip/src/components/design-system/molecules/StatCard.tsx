/**
 * Molecule: StatCard
 * ===================
 * Statistic display card (icon + value + label + optional trend).
 *
 * Usage:
 *   <StatCard icon={<DollarSign />} label="Total Loss" value="$1.2B" />
 *   <StatCard icon={<TrendingUp />} label="Growth" value="+12%" trend="up" />
 */
import React from 'react';
import Box from '@mui/material/Box';
import { Typography } from '../atoms/Typography';
import { Icon } from '../atoms/Icon';
import { iconTrendingUp, iconTrendingDown } from '../../../assets/images';

export interface StatCardProps {
  /** Icon element */
  icon?: React.ReactNode;
  /** Stat label */
  label: string;
  /** Stat value */
  value: React.ReactNode;
  /** Show trend indicator */
  trend?: 'up' | 'down' | 'neutral';
  /** Trend description (e.g. "+5% vs last quarter") */
  trendLabel?: string;
  /** Custom className */
  className?: string;
}

const trendConfig = {
  up: { color: 'var(--ds-color-success)', iconSrc: iconTrendingUp },
  down: { color: 'var(--ds-color-error)', iconSrc: iconTrendingDown },
  neutral: { color: 'var(--ds-text-secondary)', iconSrc: null },
};

function StatCard({ icon, label, value, trend, trendLabel, className }: StatCardProps) {
  const trendInfo = trend ? trendConfig[trend] : null;

  return (
    <Box className={`ds-c-stat-card ${className ?? ''}`}>
      <Box className="ds-c-stat-card__label-row">
        {icon && (
          <Box className="ds-c-stat-card__icon">
            {icon}
          </Box>
        )}
        <Typography variant="label">{label}</Typography>
      </Box>

      <Typography variant="h2" className="ds-c-stat-card__value">
        {value}
      </Typography>

      {trendInfo && trendLabel && (
        <Box className="ds-c-stat-card__trend">
          {trendInfo.iconSrc && <Icon src={trendInfo.iconSrc} size={14} color={trendInfo.color} />}
          <Typography variant="caption" style={{ color: trendInfo.color }}>
            {trendLabel}
          </Typography>
        </Box>
      )}
    </Box>
  );
}


export { StatCard };
export default StatCard;
