/**
 * Molecule: Stepper
 * ==================
 * Workflow phase stepper — vertical or horizontal, with status colors.
 *
 * Usage:
 *   <Stepper
 *     steps={[
 *       { label: 'Event Creation', status: 'completed' },
 *       { label: 'Monitoring', status: 'in-progress' },
 *       { label: 'Estimation', status: 'not-started' },
 *     ]}
 *   />
 */
import Box from '@mui/material/Box';
import { Icon, type IconName } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';
import { Chip } from '../atoms/Chip';

export type StepStatus = 'completed' | 'in-progress' | 'blocked' | 'not-started';

export interface StepItem {
  /** Step label */
  label: string;
  /** Current status */
  status: StepStatus;
  /** Optional description or assignee */
  description?: string;
  /** Optional icon override */
  icon?: IconName;
  /** Optional date string */
  date?: string;
}

export interface StepperProps {
  /** Array of steps */
  steps: StepItem[];
  /** Orientation — vertical (default) or horizontal */
  orientation?: 'vertical' | 'horizontal';
  /** Compact mode — smaller, icon-only (for sidebars) */
  compact?: boolean;
  /** Extra className */
  className?: string;
}

const statusConfig: Record<StepStatus, { icon: IconName; cssModifier: string; chipColor: string }> = {
  completed: { icon: 'check-circle-2', cssModifier: 'completed', chipColor: 'success' },
  'in-progress': { icon: 'clock', cssModifier: 'in-progress', chipColor: 'warning' },
  blocked: { icon: 'alert-circle', cssModifier: 'blocked', chipColor: 'error' },
  'not-started': { icon: 'circle', cssModifier: 'not-started', chipColor: 'default' },
};

function Stepper({
  steps,
  orientation = 'vertical',
  compact = false,
  className,
}: StepperProps) {
  return (
    <Box className={`ds-c-stepper ds-c-stepper--${orientation} ${compact ? 'ds-c-stepper--compact' : ''} ${className ?? ''}`}>
      {steps.map((step, index) => {
        const config = statusConfig[step.status];
        const isLast = index === steps.length - 1;
        const iconName = step.icon ?? config.icon;

        return (
          <Box key={step.label} className="ds-c-stepper__step">
            {/* Node (icon circle) + connector */}
            <Box className="ds-c-stepper__track">
              <Box className={`ds-c-stepper__node ds-c-stepper__node--${config.cssModifier}`}>
                <Icon name={iconName} size={compact ? 14 : 18} />
              </Box>
              {!isLast && (
                <Box className={`ds-c-stepper__connector ds-c-stepper__connector--${config.cssModifier}`} />
              )}
            </Box>

            {/* Content */}
            {!compact && (
              <Box className="ds-c-stepper__content">
                <Box className="ds-c-stepper__label-row">
                  <Typography variant="subtitle2">{step.label}</Typography>
                  <Chip
                    label={step.status.replace('-', ' ')}
                    status={config.chipColor as any}
                    size="small"
                  />
                </Box>
                {step.description && (
                  <Typography variant="caption" muted>{step.description}</Typography>
                )}
                {step.date && (
                  <Typography variant="caption" muted>
                    <Icon name="calendar" size={12} /> {step.date}
                  </Typography>
                )}
              </Box>
            )}
          </Box>
        );
      })}
    </Box>
  );
}

export { Stepper };
export default Stepper;
