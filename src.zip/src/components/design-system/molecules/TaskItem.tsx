/**
 * Molecule: TaskItem
 * ===================
 * Task row with status icon, priority badge, title, and due date.
 *
 * Usage:
 *   <TaskItem
 *     title="Review estimation"
 *     status="pending"
 *     priority="high"
 *     dueDate="2026-04-01"
 *     onClick={() => navigate('/tasks/1')}
 *   />
 */
import Box from '@mui/material/Box';
import { Icon, type IconName } from '../atoms/Icon';
import { Chip } from '../atoms/Chip';
import { Typography } from '../atoms/Typography';

export type TaskStatus = 'pending' | 'in-progress' | 'completed' | 'overdue';
export type TaskPriority = 'low' | 'medium' | 'high' | 'critical';

export interface TaskItemProps {
  /** Task title */
  title: string;
  /** Description */
  description?: string;
  /** Current status */
  status?: TaskStatus;
  /** Priority level */
  priority?: TaskPriority;
  /** Due date (display string or ISO) */
  dueDate?: string;
  /** Assignee name */
  assignee?: string;
  /** Click handler */
  onClick?: () => void;
  /** Extra className */
  className?: string;
}

const statusConfig: Record<TaskStatus, { icon: IconName; color: string }> = {
  pending: { icon: 'clock', color: 'warning' },
  'in-progress': { icon: 'loader-2', color: 'info' },
  completed: { icon: 'check-circle-2', color: 'success' },
  overdue: { icon: 'alert-circle', color: 'error' },
};

const priorityConfig: Record<TaskPriority, string> = {
  low: 'default',
  medium: 'info',
  high: 'warning',
  critical: 'error',
};

function TaskItem({
  title,
  description,
  status = 'pending',
  priority,
  dueDate,
  assignee,
  onClick,
  className,
}: TaskItemProps) {
  const sConfig = statusConfig[status];

  return (
    <Box
      component="button"
      type="button"
      onClick={onClick}
      className={`ds-c-task-item ds-c-task-item--${status} ${className ?? ''}`}
    >
      <Icon name={sConfig.icon} size={16} className={`ds-c-task-item__icon ds-c-task-item__icon--${sConfig.color}`} />
      <Box className="ds-c-task-item__content">
        <Box className="ds-c-task-item__title-row">
          <Typography variant="body2">{title}</Typography>
          {priority && (
            <Chip label={priority} status={priorityConfig[priority] as any} size="small" />
          )}
        </Box>
        {description && <Typography variant="caption" muted>{description}</Typography>}
        <Box className="ds-c-task-item__footer">
          {assignee && (
            <Box className="ds-c-task-item__assignee">
              <Icon name="user" size={12} />
              <Typography variant="caption">{assignee}</Typography>
            </Box>
          )}
          {dueDate && (
            <Box className="ds-c-task-item__due">
              <Icon name="calendar" size={12} />
              <Typography variant="caption" muted>{dueDate}</Typography>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
}

export { TaskItem };
export default TaskItem;
