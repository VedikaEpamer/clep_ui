/**
 * Molecule: Timeline
 * ===================
 * Chronological timeline with icon-per-entry-type, useful for audit logs.
 *
 * Usage:
 *   <Timeline
 *     entries={[
 *       { id: '1', icon: 'upload', color: 'info', title: 'File uploaded', description: 'report.pdf', user: 'John', timestamp: '...' },
 *       { id: '2', icon: 'check-circle-2', color: 'success', title: 'Approved', user: 'Jane', timestamp: '...' },
 *     ]}
 *   />
 */
import Box from '@mui/material/Box';
import { Icon, type IconName } from '../atoms/Icon';
import { Typography } from '../atoms/Typography';

export type TimelineColor = 'primary' | 'success' | 'warning' | 'error' | 'info' | 'neutral';

export interface TimelineEntry {
  /** Unique id */
  id: string;
  /** Icon name */
  icon?: IconName;
  /** Entry color theme */
  color?: TimelineColor;
  /** Primary title */
  title: string;
  /** Secondary description */
  description?: string;
  /** Who performed the action */
  user?: string;
  /** User role */
  userRole?: string;
  /** ISO timestamp or display string */
  timestamp: string;
  /** Expandable detail (key-value pairs) */
  details?: Record<string, string>;
}

export interface TimelineProps {
  /** Array of timeline entries (newest first) */
  entries: TimelineEntry[];
  /** Group entries by date */
  groupByDate?: boolean;
  /** Extra className */
  className?: string;
}

function formatDate(timestamp: string): string {
  return new Date(timestamp).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function formatTime(timestamp: string): string {
  return new Date(timestamp).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function Timeline({
  entries,
  groupByDate = true,
  className,
}: TimelineProps) {
  const grouped = groupByDate
    ? entries.reduce<Record<string, TimelineEntry[]>>((acc, entry) => {
        const date = formatDate(entry.timestamp);
        (acc[date] ??= []).push(entry);
        return acc;
      }, {})
    : { all: entries };

  return (
    <Box className={`ds-c-timeline ${className ?? ''}`}>
      {Object.entries(grouped).map(([dateLabel, items]) => (
        <Box key={dateLabel} className="ds-c-timeline__group">
          {groupByDate && (
            <Box className="ds-c-timeline__date-header">
              <Icon name="calendar" size={14} />
              <Typography variant="caption">{dateLabel}</Typography>
            </Box>
          )}
          {items.map((entry, idx) => {
            const isLast = idx === items.length - 1;
            const colorClass = `ds-c-timeline__node--${entry.color ?? 'neutral'}`;

            return (
              <Box key={entry.id} className="ds-c-timeline__entry">
                {/* Track: node + connector */}
                <Box className="ds-c-timeline__track">
                  <Box className={`ds-c-timeline__node ${colorClass}`}>
                    <Icon name={entry.icon ?? 'circle'} size={14} />
                  </Box>
                  {!isLast && <Box className="ds-c-timeline__connector" />}
                </Box>

                {/* Content */}
                <Box className="ds-c-timeline__content">
                  <Box className="ds-c-timeline__content-header">
                    <Typography variant="body2">{entry.title}</Typography>
                    <Typography variant="caption" muted>{formatTime(entry.timestamp)}</Typography>
                  </Box>
                  {entry.description && (
                    <Typography variant="caption" muted>{entry.description}</Typography>
                  )}
                  {entry.user && (
                    <Box className="ds-c-timeline__user">
                      <Icon name="user" size={12} />
                      <Typography variant="caption">{entry.user}</Typography>
                      {entry.userRole && (
                        <Typography variant="caption" muted> · {entry.userRole}</Typography>
                      )}
                    </Box>
                  )}
                  {entry.details && Object.keys(entry.details).length > 0 && (
                    <Box className="ds-c-timeline__details">
                      {Object.entries(entry.details).map(([key, val]) => (
                        <Box key={key} className="ds-c-timeline__detail-row">
                          <Typography variant="caption" muted>{key}:</Typography>
                          <Typography variant="caption">{val}</Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </Box>
              </Box>
            );
          })}
        </Box>
      ))}
    </Box>
  );
}

export { Timeline };
export default Timeline;
