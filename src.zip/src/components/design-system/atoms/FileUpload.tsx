/**
 * Atom: FileUpload
 * =================
 * File input with drag-and-drop zone and file list display.
 *
 * Usage:
 *   <FileUpload
 *     files={files}
 *     onAdd={handleAdd}
 *     onRemove={handleRemove}
 *     accept=".pdf,.xlsx,.csv"
 *     maxFiles={5}
 *   />
 */
import { type DragEvent, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import { Icon } from './Icon';
import { Typography } from './Typography';
import { IconButton } from './IconButton';

export interface UploadedFile {
  /** Unique id */
  id: string;
  /** File name */
  name: string;
  /** File size in bytes */
  size: number;
  /** MIME type */
  type?: string;
  /** The native File object (when available) */
  file?: File;
}

export interface FileUploadProps {
  /** Current file list */
  files?: UploadedFile[];
  /** Called with newly added files */
  onAdd?: (files: UploadedFile[]) => void;
  /** Called when a file is removed by id */
  onRemove?: (id: string) => void;
  /** Accepted file types (e.g. ".pdf,.xlsx") */
  accept?: string;
  /** Maximum number of files (default unlimited) */
  maxFiles?: number;
  /** Maximum file size in bytes */
  maxSize?: number;
  /** Disabled state */
  disabled?: boolean;
  /** Custom label for the drop zone */
  label?: string;
  /** Compact mode (no drop zone, just a button) */
  compact?: boolean;
  /** Extra className */
  className?: string;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileToUpload(file: File): UploadedFile {
  return {
    id: `${file.name}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: file.name,
    size: file.size,
    type: file.type,
    file,
  };
}

function FileUpload({
  files = [],
  onAdd,
  onRemove,
  accept,
  maxFiles,
  maxSize,
  disabled = false,
  label = 'Drag & drop files here, or click to browse',
  compact = false,
  className,
}: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  function handleFiles(fileList: FileList | null) {
    if (!fileList || disabled) return;
    const arr = Array.from(fileList);
    const filtered = arr
      .filter((f) => !maxSize || f.size <= maxSize)
      .slice(0, maxFiles ? maxFiles - files.length : undefined);
    if (filtered.length > 0) {
      onAdd?.(filtered.map(fileToUpload));
    }
  }

  function handleDrop(e: DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }

  function handleDragOver(e: DragEvent) {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  }

  function handleDragLeave() {
    setIsDragging(false);
  }

  function handleClick() {
    if (!disabled) inputRef.current?.click();
  }

  const canAdd = !maxFiles || files.length < maxFiles;

  if (compact) {
    return (
      <Box className={`ds-c-file-upload--compact ${className ?? ''}`}>
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={!maxFiles || maxFiles > 1}
          onChange={(e) => handleFiles(e.target.files)}
          hidden
        />
        <button
          type="button"
          className="ds-c-file-upload__btn"
          onClick={handleClick}
          disabled={disabled || !canAdd}
        >
          <Icon name="upload" size={16} />
          <span>Upload</span>
        </button>
        {files.length > 0 && (
          <Box className="ds-c-file-upload__list">
            {files.map((f) => (
              <Box key={f.id} className="ds-c-file-upload__item">
                <Icon name="file-text" size={14} />
                <Typography variant="caption">{f.name}</Typography>
                <Typography variant="caption" muted>{formatFileSize(f.size)}</Typography>
                {onRemove && (
                  <IconButton size="small" onClick={() => onRemove(f.id)} tooltip="Remove"><Icon name="x" size={14} /></IconButton>
                )}
              </Box>
            ))}
          </Box>
        )}
      </Box>
    );
  }

  return (
    <Box className={`ds-c-file-upload ${className ?? ''}`}>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={!maxFiles || maxFiles > 1}
        onChange={(e) => handleFiles(e.target.files)}
        hidden
      />
      {canAdd && (
        <Box
          className={`ds-c-file-upload__zone ${isDragging ? 'ds-c-file-upload__zone--active' : ''}`}
          onClick={handleClick}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          role="button"
          tabIndex={0}
        >
          <Icon name="upload" size={32} className="ds-c-file-upload__zone-icon" />
          <Typography variant="body2">{label}</Typography>
          {accept && (
            <Typography variant="caption" muted>
              Accepted: {accept}
            </Typography>
          )}
        </Box>
      )}
      {files.length > 0 && (
        <Box className="ds-c-file-upload__list">
          {files.map((f) => (
            <Box key={f.id} className="ds-c-file-upload__item">
              <Icon name="file-text" size={16} />
              <Typography variant="body2" className="ds-c-file-upload__name">{f.name}</Typography>
              <Typography variant="caption" muted>{formatFileSize(f.size)}</Typography>
              {onRemove && (
                <IconButton size="small" onClick={() => onRemove(f.id)} tooltip="Remove"><Icon name="x" size={14} /></IconButton>
              )}
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
}

export { FileUpload };
export default FileUpload;
