/**
 * Atom: ProgressBar
 * ==================
 * Linear progress indicator with optional label and value display.
 *
 * Usage:
 *   <ProgressBar value={75} />
 *   <ProgressBar value={45} label="Exposure" showValue color="success" />
 */
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import { Typography } from './Typography';

export type ProgressColor = 'primary' | 'success' | 'warning' | 'error' | 'info';

export interface ProgressBarProps {
  /** Current value (0–100) */
  value: number;
  /** Label text above the bar */
  label?: string;
  /** Show percentage value text */
  showValue?: boolean;
  /** Color variant */
  color?: ProgressColor;
  /** Bar height in px (default 6) */
  height?: number;
  /** Extra className */
  className?: string;
}

function ProgressBar({
  value,
  label,
  showValue = false,
  color = 'primary',
  height = 6,
  className,
}: ProgressBarProps) {
  const clampedValue = Math.min(100, Math.max(0, value));

  return (
    <Box className={`ds-c-progress ${className ?? ''}`}>
      {(label || showValue) && (
        <Box className="ds-c-progress__header">
          {label && <Typography variant="caption">{label}</Typography>}
          {showValue && (
            <Typography variant="caption" className="ds-c-progress__value">
              {Math.round(clampedValue)}%
            </Typography>
          )}
        </Box>
      )}
      <LinearProgress
        variant="determinate"
        value={clampedValue}
        color={color}
        className="ds-c-progress__bar"
        style={{ height, borderRadius: height / 2 }}
      />
    </Box>
  );
}

export { ProgressBar };
export default ProgressBar;
