/**
 * Atom: Badge
 * ============
 * Numeric or dot badge overlay.
 *
 * Usage:
 *   <Badge count={5}><Bell /></Badge>
 *   <Badge dot><Mail /></Badge>
 */
import React from 'react';
import MuiBadge, { type BadgeProps as MuiBadgeProps } from '@mui/material/Badge';

export interface BadgeProps extends Omit<MuiBadgeProps, 'badgeContent'> {
  /** Show a numeric count */
  count?: number;
  /** Show as dot only */
  dot?: boolean;
  /** Max number to display (default 99) */
  max?: number;
}

function Badge({ count, dot, max = 99, children, ...rest }: BadgeProps) {
  return (
    <MuiBadge
      badgeContent={dot ? undefined : count}
      variant={dot ? 'dot' : 'standard'}
      max={max}
      color="error"
      {...rest}
    >
      {children}
    </MuiBadge>
  );
}

export { Badge };
export default Badge;
