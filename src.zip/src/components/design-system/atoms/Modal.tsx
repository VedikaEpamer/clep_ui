/**
 * Atom: Modal
 * ============
 * Full-screen overlay dialog with header, scrollable body, and sticky footer.
 *
 * Usage:
 *   <Modal open={isOpen} onClose={handleClose} title="Add Comment">
 *     <p>Modal body content</p>
 *   </Modal>
 *
 *   <Modal open={isOpen} onClose={handleClose} title="Confirm" footer={<Button>Save</Button>}>
 *     <p>Body</p>
 *   </Modal>
 */
import { type ReactNode } from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Box from '@mui/material/Box';
import { Icon } from './Icon';
import { Typography } from './Typography';
import { IconButton } from './IconButton';

export type ModalSize = 'sm' | 'md' | 'lg' | 'xl' | 'fullWidth';

export interface ModalProps {
  /** Whether the modal is visible */
  open: boolean;
  /** Called when the modal requests to close */
  onClose: () => void;
  /** Title text displayed in the header */
  title?: string;
  /** Optional icon name rendered beside the title */
  icon?: string;
  /** Header content override (replaces default title row) */
  header?: ReactNode;
  /** Modal body */
  children: ReactNode;
  /** Footer (action buttons) — rendered in a sticky bottom bar */
  footer?: ReactNode;
  /** Preset width */
  size?: ModalSize;
  /** Disable closing on backdrop click */
  disableBackdropClose?: boolean;
  /** Extra className on the paper element */
  className?: string;
}

const sizeMap: Record<ModalSize, 'xs' | 'sm' | 'md' | 'lg' | 'xl'> = {
  sm: 'xs',
  md: 'sm',
  lg: 'md',
  xl: 'lg',
  fullWidth: 'xl',
};

function Modal({
  open,
  onClose,
  title,
  icon,
  header,
  children,
  footer,
  size = 'md',
  disableBackdropClose = false,
  className,
}: ModalProps) {
  function handleClose(_event: object, reason: string) {
    if (disableBackdropClose && reason === 'backdropClick') return;
    onClose();
  }

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth={sizeMap[size]}
      fullWidth
      className={`ds-c-modal ${className ?? ''}`}
    >
      {/* Header */}
      {header ?? (
        <DialogTitle className="ds-c-modal__header">
          <Box className="ds-c-modal__title-row">
            {icon && <Icon name={icon as any} size={20} className="ds-c-modal__icon" />}
            <Typography variant="h3">{title}</Typography>
          </Box>
          <IconButton size="small" onClick={onClose} tooltip="Close"><Icon name="x" size={16} /></IconButton>
        </DialogTitle>
      )}

      {/* Body */}
      <DialogContent className="ds-c-modal__body" dividers>
        {children}
      </DialogContent>

      {/* Footer */}
      {footer && (
        <DialogActions className="ds-c-modal__footer">
          {footer}
        </DialogActions>
      )}
    </Dialog>
  );
}

export { Modal };
export default Modal;
