/**
 * Atom: Tabs
 * ===========
 * Tabbed navigation wrapping MUI Tabs.
 *
 * Usage:
 *   <Tabs
 *     tabs={[
 *       { label: 'Overview', value: 'overview' },
 *       { label: 'Details', value: 'details', count: 5 },
 *       { label: 'Disabled', value: 'x', disabled: true },
 *     ]}
 *     value={activeTab}
 *     onChange={setActiveTab}
 *   />
 */
import React from 'react';
import MuiTabs from '@mui/material/Tabs';
import MuiTab from '@mui/material/Tab';
import MuiBadge from '@mui/material/Badge';

export interface TabItem {
  label: string;
  value: string;
  icon?: React.ReactElement;
  count?: number;
  disabled?: boolean;
}

export interface TabsProps {
  tabs: TabItem[];
  value: string;
  onChange: (value: string) => void;
  variant?: 'standard' | 'scrollable' | 'fullWidth';
  size?: 'small' | 'medium';
}

function Tabs({
  tabs,
  value,
  onChange,
  variant = 'standard',
  size = 'small',
}: TabsProps) {
  return (
    <MuiTabs
      value={value}
      onChange={(_e, v) => onChange(v)}
      variant={variant}
      scrollButtons="auto"
      className={size === 'small' ? 'ds-c-tabs--small' : 'ds-c-tabs--default'}
    >
      {tabs.map((tab) => (
        <MuiTab
          key={tab.value}
          value={tab.value}
          disabled={tab.disabled}
          icon={tab.icon}
          iconPosition="start"
          label={
            tab.count != null ? (
              <MuiBadge badgeContent={tab.count} color="primary" className="ds-c-tab-badge">
                {tab.label}
              </MuiBadge>
            ) : (
              tab.label
            )
          }
        />
      ))}
    </MuiTabs>
  );
}

export { Tabs };
export default Tabs;
