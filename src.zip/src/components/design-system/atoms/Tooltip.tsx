/**
 * Atom: Tooltip
 * ==============
 * Wraps MUI Tooltip for consistent styling.
 *
 * Usage:
 *   <Tooltip title="Edit this item"><IconButton><Edit /></IconButton></Tooltip>
 */
import React from 'react';
import MuiTooltip, { type TooltipProps as MuiTooltipProps } from '@mui/material/Tooltip';

export interface TooltipProps extends MuiTooltipProps {}

function Tooltip({ children, ...rest }: TooltipProps) {
  return (
    <MuiTooltip arrow {...rest}>
      {children}
    </MuiTooltip>
  );
}

export { Tooltip };
export default Tooltip;
