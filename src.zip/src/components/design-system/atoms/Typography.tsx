/**
 * Atom: Typography
 * ================
 * Wraps MUI Typography with project-specific variants.
 *
 * Usage:
 *   <Typography variant="h1">Page Title</Typography>
 *   <Typography variant="body2" color="secondary">Muted helper text</Typography>
 *   <Typography variant="label">Field Label</Typography>
 *   <Typography variant="caption" muted>Small note</Typography>
 */
import React from 'react';
import MuiTypography, { type TypographyProps as MuiTypographyProps } from '@mui/material/Typography';

export type TypographyVariant =
  | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'
  | 'subtitle1' | 'subtitle2'
  | 'body1' | 'body2'
  | 'caption' | 'overline'
  | 'label' | 'helper';

export interface TypographyProps extends Omit<MuiTypographyProps, 'variant'> {
  /** Visual variant. "label" and "helper" are custom additions. */
  variant?: TypographyVariant;
  /** Shorthand: apply secondary (muted) color */
  muted?: boolean;
  /** Truncate text with ellipsis after N lines (0 = off) */
  truncate?: number;
}

/* Map custom variants to underlying MUI variant + CSS class */
const customVariantMap: Record<string, { muiVariant: MuiTypographyProps['variant']; className: string }> = {
  label: { muiVariant: 'body2', className: 'ds-c-typo--label' },
  helper: { muiVariant: 'caption', className: 'ds-c-typo--helper' },
};

function Typography({ variant = 'body1', muted, truncate, sx, ref, ...rest }: TypographyProps & { ref?: React.Ref<HTMLElement> }) {
    const custom = customVariantMap[variant];
    const muiVariant = custom?.muiVariant ?? (variant as MuiTypographyProps['variant']);

    const truncateStyle: React.CSSProperties = truncate && truncate > 0
      ? {
          display: '-webkit-box',
          WebkitLineClamp: truncate,
          WebkitBoxOrient: 'vertical' as const,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }
      : {};

    const classes = [
      custom?.className,
      muted ? 'ds-c-typo--muted' : undefined,
      rest.className,
    ].filter(Boolean).join(' ');

    return (
      <MuiTypography
        ref={ref}
        variant={muiVariant}
        className={classes || undefined}
        style={{ ...truncateStyle, ...(sx as React.CSSProperties ?? {}) }}
        {...((() => { const { className: _c, ...r } = rest; return r; })())}
      />
    );
  }

export { Typography };
export default Typography;
