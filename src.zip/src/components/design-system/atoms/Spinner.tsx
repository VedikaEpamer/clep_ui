/**
 * Atom: Spinner
 * ==============
 * Loading indicator — circular spinner with optional label.
 *
 * Usage:
 *   <Spinner />
 *   <Spinner size={32} label="Loading..." />
 *   <Spinner overlay />
 */
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import { Typography } from './Typography';

export type SpinnerSize = 'small' | 'medium' | 'large';

export interface SpinnerProps {
  /** Preset size */
  size?: SpinnerSize;
  /** Custom size in px (overrides preset) */
  sizePx?: number;
  /** Label below the spinner */
  label?: string;
  /** Render as a full-area overlay */
  overlay?: boolean;
  /** Color */
  color?: 'primary' | 'secondary' | 'inherit';
  /** Extra className */
  className?: string;
}

const sizeMap: Record<SpinnerSize, number> = {
  small: 20,
  medium: 32,
  large: 48,
};

function Spinner({
  size = 'medium',
  sizePx,
  label,
  overlay = false,
  color = 'primary',
  className,
}: SpinnerProps) {
  const resolvedSize = sizePx ?? sizeMap[size];

  const spinner = (
    <Box className={`ds-c-spinner ${overlay ? 'ds-c-spinner--overlay' : ''} ${className ?? ''}`}>
      <CircularProgress size={resolvedSize} color={color} />
      {label && (
        <Typography variant="caption" muted className="ds-c-spinner__label">
          {label}
        </Typography>
      )}
    </Box>
  );

  return spinner;
}

export { Spinner };
export default Spinner;
