/**
 * Atom: Switch
 * =============
 * Toggle switch with optional label.
 *
 * Usage:
 *   <Switch label="Enable notifications" checked={on} onChange={setOn} />
 */
import React from 'react';
import MuiSwitch, { type SwitchProps as MuiSwitchProps } from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';

export interface SwitchProps extends Omit<MuiSwitchProps, 'onChange'> {
  label?: React.ReactNode;
  onChange?: (checked: boolean) => void;
}

function Switch({ label, onChange, ...rest }: SwitchProps) {
  const handleChange = (_e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
    onChange?.(checked);
  };

  const ctrl = <MuiSwitch size="small" onChange={handleChange} {...rest} />;

  if (label) {
    return (
      <FormControlLabel
        control={ctrl}
        label={label}
        className="ds-c-form-control-sm"
      />
    );
  }
  return ctrl;
}

export { Switch };
export default Switch;
