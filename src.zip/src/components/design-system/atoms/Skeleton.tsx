/**
 * Atom: Skeleton
 * ===============
 * Loading placeholder built on MUI Skeleton.
 *
 * Usage:
 *   <Skeleton variant="text" width={200} />
 *   <Skeleton variant="rectangular" height={120} />
 *   <Skeleton variant="circular" width={40} height={40} />
 */
import React from 'react';
import MuiSkeleton, { type SkeletonProps as MuiSkeletonProps } from '@mui/material/Skeleton';

export interface SkeletonProps extends MuiSkeletonProps {}

function Skeleton(props: SkeletonProps) {
  return <MuiSkeleton animation="wave" {...props} />;
}

export { Skeleton };
export default Skeleton;
