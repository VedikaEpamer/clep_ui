/**
 * Atom: Icon
 * ===========
 * Renders SVG icons from src/assets/images as inline SVGs.
 * The SVG content is fetched once and cached so `currentColor` in the SVG
 * naturally inherits the parent element's CSS `color` property.
 *
 * Usage:
 *   <Icon name="search" size={16} />
 *   <Icon name="bell" size={20} color="var(--ds-brand-primary)" />
 *   <Icon src={iconBell} size={20} />
 */
import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';

/* ─── Icon map for convenience (name → asset import) ─── */
import {
  iconActivity,
  iconActivityLine,
  iconAlertCircle,
  iconAlertTriangle,
  iconArchive,
  iconArrowDown,
  iconArrowLeft,
  iconArrowRight,
  iconArrowUp,
  iconArrowUpDown,
  iconBarChart,
  iconBarChart2,
  iconBarChart3,
  iconBell,
  iconBrandLogo,
  iconBuilding2,
  iconCalendar,
  iconChartBar,
  iconCheck,
  iconCheckCircle,
  iconCheckCircle2,
  iconCheckSquare,
  iconCheckmark,
  iconChevronDown,
  iconChevronDownLg,
  iconChevronLeft,
  iconChevronLeftNav,
  iconChevronRight,
  iconChevronUp,
  iconChevronsDownUp,
  iconChevronsUpDown,
  iconCircle,
  iconClipboardList,
  iconClock,
  iconClockHistory,
  iconClose,
  iconCpu,
  iconCrosshair,
  iconCurrency,
  iconDocumentText,
  iconDollarSign,
  iconDownload,
  iconEdit,
  iconEdit2,
  iconExternalLink,
  iconEye,
  iconEyeOff,
  iconFile,
  iconFileText,
  iconFilter,
  iconFolder,
  iconFolderOpen,
  iconFullscreen,
  iconGlobe,
  iconGlobeFull,
  iconHistory,
  iconImagePlaceholder,
  iconInbox,
  iconInfo,
  iconInfoCircle,
  iconKeyRound,
  iconLayers,
  iconLoader2,
  iconLock,
  iconMail,
  iconMapPin,
  iconMaximize2,
  iconMessageSquare,
  iconMessageSquarePlus,
  iconMinimize2,
  iconPaperclip,
  iconPencil,
  iconPercent,
  iconPlus,
  iconPrinter,
  iconReceipt,
  iconRefreshCw,
  iconRotateCcw,
  iconSave,
  iconSearch,
  iconSearchLg,
  iconSend,
  iconSettings,
  iconSettingsGear,
  iconShield,
  iconShieldCheck,
  iconSortArrowDown,
  iconSortArrowUp,
  iconSquare,
  iconTag,
  iconTarget,
  iconTrash2,
  iconTrendingDown,
  iconTrendingUp,
  iconUnlock,
  iconUpload,
  iconUser,
  iconUserCheck,
  iconUserPlus,
  iconUsers,
  iconX,
  iconXCircle,
  iconXSquare,
} from '../../../assets/images';

/** All available icon names */
export type IconName =
  | 'activity' | 'activity-line' | 'alert-circle' | 'alert-triangle'
  | 'archive' | 'arrow-down' | 'arrow-left' | 'arrow-right' | 'arrow-up' | 'arrow-up-down'
  | 'bar-chart' | 'bar-chart-2' | 'bar-chart-3' | 'bell' | 'brand-logo' | 'building-2'
  | 'calendar' | 'chart-bar' | 'check' | 'check-circle' | 'check-circle-2' | 'check-square' | 'checkmark'
  | 'chevron-down' | 'chevron-down-lg' | 'chevron-left' | 'chevron-left-nav' | 'chevron-right' | 'chevron-up'
  | 'chevrons-down-up' | 'chevrons-up-down' | 'circle' | 'clipboard-list'
  | 'clock' | 'clock-history' | 'close' | 'cpu' | 'crosshair' | 'currency'
  | 'document-text' | 'dollar-sign' | 'download'
  | 'edit' | 'edit-2' | 'external-link' | 'eye' | 'eye-off'
  | 'file' | 'file-text' | 'filter' | 'folder' | 'folder-open' | 'fullscreen'
  | 'globe' | 'globe-full' | 'history'
  | 'image-placeholder' | 'inbox' | 'info' | 'info-circle'
  | 'key-round' | 'layers' | 'loader-2' | 'lock'
  | 'mail' | 'map-pin' | 'maximize-2' | 'message-square' | 'message-square-plus' | 'minimize-2'
  | 'paperclip' | 'pencil' | 'percent' | 'plus' | 'printer'
  | 'receipt' | 'refresh-cw' | 'rotate-ccw'
  | 'save' | 'search' | 'search-lg' | 'send' | 'settings' | 'settings-gear'
  | 'shield' | 'shield-check' | 'sort-arrow-down' | 'sort-arrow-up' | 'square'
  | 'tag' | 'target' | 'trash-2' | 'trending-down' | 'trending-up'
  | 'unlock' | 'upload' | 'user' | 'user-check' | 'user-plus' | 'users'
  | 'x' | 'x-circle' | 'x-square';

const iconMap: Record<IconName, string> = {
  'activity': iconActivity,
  'activity-line': iconActivityLine,
  'alert-circle': iconAlertCircle,
  'alert-triangle': iconAlertTriangle,
  'archive': iconArchive,
  'arrow-down': iconArrowDown,
  'arrow-left': iconArrowLeft,
  'arrow-right': iconArrowRight,
  'arrow-up': iconArrowUp,
  'arrow-up-down': iconArrowUpDown,
  'bar-chart': iconBarChart,
  'bar-chart-2': iconBarChart2,
  'bar-chart-3': iconBarChart3,
  'bell': iconBell,
  'brand-logo': iconBrandLogo,
  'building-2': iconBuilding2,
  'calendar': iconCalendar,
  'chart-bar': iconChartBar,
  'check': iconCheck,
  'check-circle': iconCheckCircle,
  'check-circle-2': iconCheckCircle2,
  'check-square': iconCheckSquare,
  'checkmark': iconCheckmark,
  'chevron-down': iconChevronDown,
  'chevron-down-lg': iconChevronDownLg,
  'chevron-left': iconChevronLeft,
  'chevron-left-nav': iconChevronLeftNav,
  'chevron-right': iconChevronRight,
  'chevron-up': iconChevronUp,
  'chevrons-down-up': iconChevronsDownUp,
  'chevrons-up-down': iconChevronsUpDown,
  'circle': iconCircle,
  'clipboard-list': iconClipboardList,
  'clock': iconClock,
  'clock-history': iconClockHistory,
  'close': iconClose,
  'cpu': iconCpu,
  'crosshair': iconCrosshair,
  'currency': iconCurrency,
  'document-text': iconDocumentText,
  'dollar-sign': iconDollarSign,
  'download': iconDownload,
  'edit': iconEdit,
  'edit-2': iconEdit2,
  'external-link': iconExternalLink,
  'eye': iconEye,
  'eye-off': iconEyeOff,
  'file': iconFile,
  'file-text': iconFileText,
  'filter': iconFilter,
  'folder': iconFolder,
  'folder-open': iconFolderOpen,
  'fullscreen': iconFullscreen,
  'globe': iconGlobe,
  'globe-full': iconGlobeFull,
  'history': iconHistory,
  'image-placeholder': iconImagePlaceholder,
  'inbox': iconInbox,
  'info': iconInfo,
  'info-circle': iconInfoCircle,
  'key-round': iconKeyRound,
  'layers': iconLayers,
  'loader-2': iconLoader2,
  'lock': iconLock,
  'mail': iconMail,
  'map-pin': iconMapPin,
  'maximize-2': iconMaximize2,
  'message-square': iconMessageSquare,
  'message-square-plus': iconMessageSquarePlus,
  'minimize-2': iconMinimize2,
  'paperclip': iconPaperclip,
  'pencil': iconPencil,
  'percent': iconPercent,
  'plus': iconPlus,
  'printer': iconPrinter,
  'receipt': iconReceipt,
  'refresh-cw': iconRefreshCw,
  'rotate-ccw': iconRotateCcw,
  'save': iconSave,
  'search': iconSearch,
  'search-lg': iconSearchLg,
  'send': iconSend,
  'settings': iconSettings,
  'settings-gear': iconSettingsGear,
  'shield': iconShield,
  'shield-check': iconShieldCheck,
  'sort-arrow-down': iconSortArrowDown,
  'sort-arrow-up': iconSortArrowUp,
  'square': iconSquare,
  'tag': iconTag,
  'target': iconTarget,
  'trash-2': iconTrash2,
  'trending-down': iconTrendingDown,
  'trending-up': iconTrendingUp,
  'unlock': iconUnlock,
  'upload': iconUpload,
  'user': iconUser,
  'user-check': iconUserCheck,
  'user-plus': iconUserPlus,
  'users': iconUsers,
  'x': iconX,
  'x-circle': iconXCircle,
  'x-square': iconXSquare,
};

/** Get the icon map for external access */
export { iconMap };

/* ─── SVG content cache (shared across all Icon instances) ─── */
const svgCache = new Map<string, string>();

/** Strip width/height from root <svg> so CSS controls the size, and set fill/stroke defaults */
function prepareSvg(raw: string, size: number): string {
  return raw
    .replace(/<svg([^>]*)>/, (_match, attrs: string) => {
      // Remove fixed width/height, keep viewBox
      let cleaned = attrs
        .replace(/\s*width="[^"]*"/g, '')
        .replace(/\s*height="[^"]*"/g, '');
      return `<svg${cleaned} width="${size}" height="${size}" style="display:block">`;
    });
}

export interface IconProps {
  /** SVG source URL (from asset import) — takes priority over `name` */
  src?: string;
  /** Convenience: icon name from the built-in map */
  name?: IconName;
  /** Size in pixels (default 20) */
  size?: number;
  /** Color override — sets CSS `color` so SVG `currentColor` inherits it */
  color?: string;
  /** Accessible label */
  alt?: string;
  /** MUI sx overrides */
  sx?: object;
  /** Extra className */
  className?: string;
}

function Icon({
  src,
  name,
  size = 20,
  color,
  alt = '',
  sx,
  className,
}: IconProps) {
  const resolvedSrc = src ?? (name ? iconMap[name] : undefined);
  const [svgHtml, setSvgHtml] = useState<string>(
    resolvedSrc ? svgCache.get(resolvedSrc + size) ?? '' : '',
  );

  useEffect(() => {
    if (!resolvedSrc) return;
    const cacheKey = resolvedSrc + size;
    if (svgCache.has(cacheKey)) {
      setSvgHtml(svgCache.get(cacheKey)!);
      return;
    }
    fetch(resolvedSrc)
      .then((res) => res.text())
      .then((raw) => {
        const prepared = prepareSvg(raw, size);
        svgCache.set(cacheKey, prepared);
        setSvgHtml(prepared);
      })
      .catch(() => {});
  }, [resolvedSrc, size]);

  if (!resolvedSrc || !svgHtml) return null;

  return (
    <Box
      component="span"
      role={alt ? 'img' : 'presentation'}
      aria-label={alt || undefined}
      className={`ds-c-icon ${className ?? ''}`}
      dangerouslySetInnerHTML={{ __html: svgHtml }}
      style={{
        width: size,
        height: size,
        color: color || 'currentColor',
        ...(sx as React.CSSProperties ?? {}),
      }}
    />
  );
}

export { Icon };
export default Icon;
