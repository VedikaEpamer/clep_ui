/**
 * Atom: Popover
 * ==============
 * Anchored floating panel that appears on click.
 * Wraps MUI Popover with design-system styling.
 *
 * Usage:
 *   <Popover trigger={<IconButton icon="bell" />} title="Notifications">
 *     <NotificationList ... />
 *   </Popover>
 */
import { type ReactNode, useState, useRef } from 'react';
import MuiPopover from '@mui/material/Popover';
import Box from '@mui/material/Box';
import { Typography } from './Typography';
import { IconButton } from './IconButton';
import { Icon } from './Icon';

export type PopoverPlacement = 'bottom-start' | 'bottom-end' | 'bottom' | 'top-start' | 'top-end' | 'top';

export interface PopoverProps {
  /** Element that triggers the popover on click */
  trigger: ReactNode;
  /** Optional header title */
  title?: string;
  /** Whether to show a close button in the header */
  showClose?: boolean;
  /** Popover body content */
  children: ReactNode;
  /** Placement relative to anchor */
  placement?: PopoverPlacement;
  /** Panel width (px or CSS string) */
  width?: number | string;
  /** Max height for scrollable content area */
  maxHeight?: number | string;
  /** Extra className */
  className?: string;
  /** Controlled open state */
  open?: boolean;
  /** Controlled close handler */
  onClose?: () => void;
}

const anchorOriginMap: Record<PopoverPlacement, { vertical: 'top' | 'bottom'; horizontal: 'left' | 'right' | 'center' }> = {
  'bottom-start': { vertical: 'bottom', horizontal: 'left' },
  'bottom-end': { vertical: 'bottom', horizontal: 'right' },
  'bottom': { vertical: 'bottom', horizontal: 'center' },
  'top-start': { vertical: 'top', horizontal: 'left' },
  'top-end': { vertical: 'top', horizontal: 'right' },
  'top': { vertical: 'top', horizontal: 'center' },
};

const transformOriginMap: Record<PopoverPlacement, { vertical: 'top' | 'bottom'; horizontal: 'left' | 'right' | 'center' }> = {
  'bottom-start': { vertical: 'top', horizontal: 'left' },
  'bottom-end': { vertical: 'top', horizontal: 'right' },
  'bottom': { vertical: 'top', horizontal: 'center' },
  'top-start': { vertical: 'bottom', horizontal: 'left' },
  'top-end': { vertical: 'bottom', horizontal: 'right' },
  'top': { vertical: 'bottom', horizontal: 'center' },
};

function Popover({
  trigger,
  title,
  showClose = true,
  children,
  placement = 'bottom-end',
  width = 384,
  maxHeight = 500,
  className,
  open: controlledOpen,
  onClose: controlledOnClose,
}: PopoverProps) {
  const anchorRef = useRef<HTMLDivElement>(null);
  const [internalOpen, setInternalOpen] = useState(false);

  const isControlled = controlledOpen !== undefined;
  const isOpen = isControlled ? controlledOpen : internalOpen;

  function handleToggle() {
    if (isControlled) {
      controlledOnClose?.();
    } else {
      setInternalOpen((prev) => !prev);
    }
  }

  function handleClose() {
    if (isControlled) {
      controlledOnClose?.();
    } else {
      setInternalOpen(false);
    }
  }

  return (
    <>
      <Box ref={anchorRef} onClick={handleToggle} className="ds-c-popover__anchor">
        {trigger}
      </Box>
      <MuiPopover
        open={isOpen}
        anchorEl={anchorRef.current}
        onClose={handleClose}
        anchorOrigin={anchorOriginMap[placement]}
        transformOrigin={transformOriginMap[placement]}
        className={`ds-c-popover ${className ?? ''}`}
        slotProps={{
          paper: {
            className: 'ds-c-popover__panel',
            style: { width: typeof width === 'number' ? `${width}px` : width },
          },
        }}
      >
        {title && (
          <Box className="ds-c-popover__header">
            <Typography variant="subtitle1">{title}</Typography>
            {showClose && (
              <IconButton size="small" onClick={handleClose} tooltip="Close"><Icon name="x" size={16} /></IconButton>
            )}
          </Box>
        )}
        <Box className="ds-c-popover__body" style={{ maxHeight }}>
          {children}
        </Box>
      </MuiPopover>
    </>
  );
}

export { Popover };
export default Popover;
