/**
 * Atom: Dropdown
 * ===============
 * Single-select and multi-select dropdown built on MUI Autocomplete.
 *
 * Usage — Single select:
 *   <Dropdown
 *     label="Region"
 *     options={regions}
 *     value={selected}
 *     onChange={(val) => setSelected(val)}
 *   />
 *
 * Usage — Multi select:
 *   <Dropdown
 *     label="Perils"
 *     options={perils}
 *     multiple
 *     value={selectedPerils}
 *     onChange={(vals) => setSelectedPerils(vals)}
 *   />
 *
 * Options can be strings OR objects with { label, value, group? }.
 */
import React from 'react';
import Autocomplete, { type AutocompleteProps } from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Chip from '@mui/material/Chip';
import Checkbox from '@mui/material/Checkbox';
import { Icon } from './Icon';
import { fieldSx } from './Input';

/* ─── Types ──────────────────────────────────── */
export interface DropdownOption {
  label: string;
  value: string | number;
  group?: string;
  disabled?: boolean;
}

type OptionType = string | DropdownOption;

interface BaseDropdownProps {
  /** Input label */
  label?: string;
  /** Placeholder text */
  placeholder?: string;
  /** List of options (strings or { label, value } objects) */
  options: OptionType[];
  /** Controlled disabled state */
  disabled?: boolean;
  /** Error state */
  error?: boolean;
  /** Helper / error text below the field */
  helperText?: string;
  /** MUI size */
  size?: 'small' | 'medium';
  /** Full width (default true) */
  fullWidth?: boolean;
  /** If true, options are grouped by `option.group` */
  grouped?: boolean;
  /** Allow free-text entry */
  freeSolo?: boolean;
  /** Enable virtual scrolling for large lists */
  loading?: boolean;
  /** Extra Autocomplete props */
  autoCompleteProps?: Partial<AutocompleteProps<OptionType, boolean, boolean, boolean>>;
}

interface SingleDropdownProps extends BaseDropdownProps {
  multiple?: false;
  value: OptionType | null;
  onChange: (value: OptionType | null) => void;
}

interface MultiDropdownProps extends BaseDropdownProps {
  multiple: true;
  value: OptionType[];
  onChange: (value: OptionType[]) => void;
}

export type DropdownProps = SingleDropdownProps | MultiDropdownProps;

/* ─── Helpers ────────────────────────────────── */
const getOptionLabel = (opt: OptionType): string =>
  typeof opt === 'string' ? opt : opt.label;

const isOptionEqual = (opt: OptionType, val: OptionType): boolean => {
  if (typeof opt === 'string' && typeof val === 'string') return opt === val;
  if (typeof opt === 'object' && typeof val === 'object') return opt.value === val.value;
  return false;
};

/* ─── Component ──────────────────────────────── */
function Dropdown(props: DropdownProps) {
  const {
    label,
    placeholder,
    options,
    disabled,
    error,
    helperText,
    size = 'small',
    fullWidth = true,
    grouped = false,
    freeSolo = false,
    loading = false,
    autoCompleteProps,
    multiple,
    value,
    onChange,
  } = props;

  return (
    <Autocomplete
      multiple={multiple ?? false}
      options={options}
      value={value as any}
      onChange={(_e, newValue) => (onChange as any)(newValue)}
      getOptionLabel={getOptionLabel}
      isOptionEqualToValue={isOptionEqual}
      disabled={disabled}
      loading={loading}
      freeSolo={freeSolo}
      disableCloseOnSelect={multiple ?? false}
      fullWidth={fullWidth}
      size={size}
      groupBy={grouped ? (opt: OptionType) => (typeof opt === 'object' && opt !== null ? (opt.group ?? '') : '') : undefined}
      getOptionDisabled={(opt: OptionType) => (typeof opt === 'object' && opt !== null ? (opt.disabled ?? false) : false)}
      renderOption={
        multiple
          ? (renderProps, option: OptionType, { selected }) => {
              const key = typeof option === 'object' && option !== null ? String(option.value) : String(option);
              return (
                <li {...renderProps} key={key}>
                  <Checkbox
                    icon={<Icon name="square" size={16} />}
                    checkedIcon={<Icon name="check-square" size={16} />}
                    className="ds-c-dropdown__checkbox"
                    checked={selected}
                    size="small"
                  />
                  {getOptionLabel(option)}
                </li>
              );
            }
          : undefined
      }
      renderTags={
        multiple
          ? (tagValues: OptionType[], getTagProps: any) =>
              tagValues.map((option, index) => {
                const { key, ...rest } = getTagProps({ index });
                return (
                  <Chip
                    key={key}
                    label={getOptionLabel(option)}
                    size="small"
                    variant="outlined"
                    {...rest}
                  />
                );
              })
          : undefined
      }
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          error={error}
          helperText={helperText}
          variant="outlined"
          InputLabelProps={{ ...params.InputLabelProps, shrink: true }}
          sx={fieldSx}
        />
      )}
      {...(autoCompleteProps as any)}
    />
  );
}

export { Dropdown };
export default Dropdown;
