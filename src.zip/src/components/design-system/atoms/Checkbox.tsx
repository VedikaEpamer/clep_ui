/**
 * Atom: Checkbox
 * ===============
 * Wraps MUI Checkbox + FormControlLabel for a complete labelled checkbox.
 *
 * Usage:
 *   <Checkbox label="Accept terms" checked={v} onChange={setV} />
 *   <Checkbox label="Remember me" indeterminate />
 */
import React from 'react';
import MuiCheckbox, { type CheckboxProps as MuiCheckboxProps } from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

export interface CheckboxProps extends Omit<MuiCheckboxProps, 'onChange'> {
  /** Label text (if omitted, renders just the checkbox) */
  label?: React.ReactNode;
  /** Controlled change handler */
  onChange?: (checked: boolean) => void;
}

function Checkbox({ label, onChange, ...rest }: CheckboxProps) {
  const handleChange = (_e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => {
    onChange?.(checked);
  };

  const checkbox = <MuiCheckbox size="small" onChange={handleChange} {...rest} />;

  if (label) {
    return (
      <FormControlLabel
        control={checkbox}
        label={label}
        className="ds-c-form-control-sm"
      />
    );
  }
  return checkbox;
}

export { Checkbox };
export default Checkbox;
