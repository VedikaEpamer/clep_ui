/**
 * Atom: DateTimePicker
 * =====================
 * Date-only and Date+Time picker built on MUI X Date Pickers + Day.js.
 *
 * Usage — Date only:
 *   <DateTimePicker label="Start Date" value={date} onChange={setDate} />
 *
 * Usage — DateTime:
 *   <DateTimePicker label="Deadline" mode="datetime" value={dt} onChange={setDt} />
 *
 * Usage — Time only:
 *   <DateTimePicker label="Time" mode="time" value={t} onChange={setT} />
 */
import React from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import Box from '@mui/material/Box';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { DateTimePicker as MuiDateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { Typography } from './Typography';

export type DateTimeMode = 'date' | 'datetime' | 'time';

export interface DateTimePickerProps {
  /** Field label */
  label?: string;
  /** Controlled value (dayjs instance, ISO string, Date object, or null) */
  value: Dayjs | string | Date | null;
  /** Called when value changes */
  onChange: (value: Dayjs | null) => void;
  /** Picker mode (default: "date") */
  mode?: DateTimeMode;
  /** MUI size */
  size?: 'small' | 'medium';
  /** Full width (default true) */
  fullWidth?: boolean;
  /** Disabled state */
  disabled?: boolean;
  /** Error state */
  error?: boolean;
  /** Helper text */
  helperText?: string;
  /** Minimum selectable date */
  minDate?: Dayjs | string | Date;
  /** Maximum selectable date */
  maxDate?: Dayjs | string | Date;
  /** Date format string (default depends on mode) */
  format?: string;
  /** Disable future dates */
  disableFuture?: boolean;
  /** Disable past dates */
  disablePast?: boolean;
}

const toDayjs = (v: Dayjs | string | Date | null | undefined): Dayjs | null => {
  if (!v) return null;
  if (dayjs.isDayjs(v)) return v;
  return dayjs(v);
};

const defaultFormats: Record<DateTimeMode, string> = {
  date: 'MM/DD/YYYY',
  datetime: 'MM/DD/YYYY hh:mm A',
  time: 'hh:mm A',
};

const slotConfig = {
  textField: { size: 'small' as const, variant: 'outlined' as const },
};

function DateTimePicker({
  label,
  value,
  onChange,
  mode = 'date',
  size = 'small',
  fullWidth = true,
  disabled = false,
  error = false,
  helperText,
  minDate,
  maxDate,
  format,
  disableFuture,
  disablePast,
}: DateTimePickerProps) {
  const dayjsValue = toDayjs(value);
  const displayFormat = format ?? defaultFormats[mode];

  const commonProps = {
    value: dayjsValue,
    onChange,
    format: displayFormat,
    disabled,
    disableFuture,
    disablePast,
    minDate: toDayjs(minDate) ?? undefined,
    maxDate: toDayjs(maxDate) ?? undefined,
    slotProps: {
      textField: {
        ...slotConfig.textField,
        size,
        fullWidth,
        error,
        helperText,
      },
    },
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box style={{ width: fullWidth ? '100%' : 'auto' }}>
        {label && (
          <Typography variant="label" className="ds-c-datepicker__label">
            {label}
          </Typography>
        )}
        {mode === 'date' && <DatePicker {...commonProps} />}
        {mode === 'datetime' && <MuiDateTimePicker {...commonProps} />}
        {mode === 'time' && <TimePicker {...commonProps} />}
      </Box>
    </LocalizationProvider>
  );
}

export { DateTimePicker };
export default DateTimePicker;
