/**
 * Atom: Chip
 * ===========
 * Status / category chip with semantic color helpers.
 *
 * Usage:
 *   <Chip label="Active" status="success" />
 *   <Chip label="Pending" status="warning" />
 *   <Chip label="Category A" onDelete={handleDelete} />
 */
import React from 'react';
import MuiChip, { type ChipProps as MuiChipProps } from '@mui/material/Chip';

export type ChipStatus = 'default' | 'success' | 'warning' | 'error' | 'info' | 'primary';

export interface ChipProps extends Omit<MuiChipProps, 'color'> {
  /** Semantic status color */
  status?: ChipStatus;
}

const statusColorMap: Record<ChipStatus, MuiChipProps['color']> = {
  default: 'default',
  success: 'success',
  warning: 'warning',
  error: 'error',
  info: 'info',
  primary: 'primary',
};

function Chip({ status = 'default', variant = 'outlined', ...rest }: ChipProps) {
  return (
    <MuiChip
      color={statusColorMap[status]}
      variant={variant}
      size="small"
      {...rest}
    />
  );
}

export { Chip };
export default Chip;
