/**
 * Atom: Avatar
 * =============
 * User avatar with initials fallback.
 *
 * Usage:
 *   <Avatar src="/img/user.png" alt="John Doe" />
 *   <Avatar initials="JD" />
 *   <Avatar initials="AB" size="large" />
 */
import React from 'react';
import MuiAvatar, { type AvatarProps as MuiAvatarProps } from '@mui/material/Avatar';

export interface AvatarProps extends MuiAvatarProps {
  /** Two-letter initials fallback */
  initials?: string;
  /** Preset sizes */
  size?: 'small' | 'medium' | 'large';
}

const sizeMap = {
  small: 28,
  medium: 36,
  large: 48,
};

function Avatar({ initials, size = 'medium', sx, children, ...rest }: AvatarProps) {
  return (
    <MuiAvatar
      className={`ds-c-avatar ds-c-avatar--${size}`}
      style={sx as React.CSSProperties}
      {...rest}
    >
      {children ?? initials ?? null}
    </MuiAvatar>
  );
}

export { Avatar };
export default Avatar;
