/**
 * Atom: Button
 * =============
 * Wraps MUI Button with project sizes and variants.
 *
 * Usage:
 *   <Button>Default</Button>
 *   <Button variant="contained" color="primary">Save</Button>
 *   <Button variant="outlined" size="small" startIcon={<Save />}>Save Draft</Button>
 *   <Button variant="text" color="error">Delete</Button>
 */
import React from 'react';
import MuiButton, { type ButtonProps as MuiButtonProps } from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';

export interface ButtonProps extends MuiButtonProps {
  /** Show a spinner and disable the button */
  loading?: boolean;
}

function Button({ loading, disabled, children, startIcon, ref, ...rest }: ButtonProps & { ref?: React.Ref<HTMLButtonElement> }) {
    return (
      <MuiButton
        ref={ref}
        disabled={disabled || loading}
        startIcon={loading ? <CircularProgress size={16} color="inherit" /> : startIcon}
        {...rest}
      >
        {children}
      </MuiButton>
    );
  }

export { Button };
export default Button;
