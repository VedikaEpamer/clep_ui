/**
 * Atom: IconButton
 * =================
 * Thin wrapper over MUI IconButton with consistent sizing.
 *
 * Usage:
 *   <IconButton tooltip="Edit"><Edit /></IconButton>
 */
import React from 'react';
import MuiIconButton, { type IconButtonProps as MuiIconButtonProps } from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';

export interface IconButtonProps extends MuiIconButtonProps {
  /** Optional tooltip text */
  tooltip?: string;
}

function IconButton({ tooltip, children, ref, ...rest }: IconButtonProps & { ref?: React.Ref<HTMLButtonElement> }) {
    const btn = (
      <MuiIconButton ref={ref} {...rest}>
        {children}
      </MuiIconButton>
    );

    if (tooltip) {
      return <Tooltip title={tooltip}>{btn}</Tooltip>;
    }
    return btn;
  }

export { IconButton };
export default IconButton;
