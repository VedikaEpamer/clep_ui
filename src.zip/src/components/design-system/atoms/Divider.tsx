/**
 * Atom: Divider
 * ==============
 * Semantic horizontal / vertical divider.
 *
 * Usage:
 *   <Divider />
 *   <Divider orientation="vertical" spacing={2} />
 *   <Divider label="OR" />
 */
import React from 'react';
import MuiDivider, { type DividerProps as MuiDividerProps } from '@mui/material/Divider';

export interface DividerProps extends MuiDividerProps {
  /** If provided, show this text centred in the divider */
  label?: string;
  /** Vertical spacing factor (theme.spacing units) */
  spacing?: number;
}

function Divider({ label, spacing = 0, sx, ...rest }: DividerProps) {
  return (
    <MuiDivider
      className="ds-c-divider"
      style={{ marginTop: spacing * 8, marginBottom: spacing * 8, ...(sx as React.CSSProperties ?? {}) }}
      {...rest}
    >
      {label ?? undefined}
    </MuiDivider>
  );
}

export { Divider };
export default Divider;
