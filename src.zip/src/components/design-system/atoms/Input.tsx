/**
 * Atom: Input
 * ============
 * Text input matching the SONAR application styling — label sits **above**
 * the field (not floating MUI style), with matching border, focus-ring, and
 * disabled states.
 *
 * Usage:
 *   <Input label="Name" />
 *   <Input label="Amount" type="number" size="small" />
 *   <Input label="Notes" multiline rows={3} />
 *   <Input label="Email" error helperText="Invalid email" />
 *   <Input label="Disabled" disabled value="Cannot edit" />
 */
import React from 'react';
import Box from '@mui/material/Box';
import TextField, { type TextFieldProps } from '@mui/material/TextField';
import { palette } from '../theme/theme';

export type InputProps = Omit<TextFieldProps, 'variant'> & {
  /** When true the label is hidden (field-only mode) */
  hideLabel?: boolean;
};

/**
 * Shared sx overrides that make MUI TextField look like a plain HTML input
 * with `border-gray-200 rounded-md px-3 py-2 text-sm` styling.
 */
const fieldSx = {
  /* Label — sits outside the field thanks to shrink:true but we apply extra
     overrides to make it look like a regular `<label>` element. */
  '& .MuiInputLabel-root': {
    position: 'relative',
    transform: 'none',
    fontSize: 13,
    fontWeight: 500,
    color: palette.gray[700],
    marginBottom: '6px',
    pointerEvents: 'auto',
    '&.Mui-focused': {
      color: palette.gray[700],
    },
    '&.Mui-error': {
      color: palette.semantic.error,
    },
    '&.Mui-disabled': {
      color: palette.gray[500],
    },
  },

  /* Remove the notched-outline legend (the "cutout" for floating label) */
  '& .MuiOutlinedInput-notchedOutline legend': {
    display: 'none',
  },

  /* Field root */
  '& .MuiOutlinedInput-root': {
    fontSize: 13,
    borderRadius: '6px',
    backgroundColor: '#ffffff',
    transition: 'all 150ms ease',

    '& .MuiOutlinedInput-notchedOutline': {
      borderColor: palette.gray[200],
      borderWidth: 1,
      top: 0,
    },
    '&:hover .MuiOutlinedInput-notchedOutline': {
      borderColor: palette.gray[300],
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: '#3b82f6',
      borderWidth: 2,
      boxShadow: '0 0 0 2px rgba(59,130,246,0.15)',
    },
    '&.Mui-error .MuiOutlinedInput-notchedOutline': {
      borderColor: palette.semantic.error,
    },
    '&.Mui-disabled': {
      backgroundColor: palette.gray[50],
      '& .MuiOutlinedInput-notchedOutline': {
        borderColor: palette.gray[200],
      },
    },
  },

  /* Input element */
  '& .MuiOutlinedInput-input': {
    padding: '8px 12px',
    '&::placeholder': {
      color: palette.gray[400],
      opacity: 1,
    },
    '&.Mui-disabled': {
      color: palette.gray[500],
      WebkitTextFillColor: palette.gray[500],
      cursor: 'not-allowed',
    },
  },
  '& .MuiOutlinedInput-inputSizeSmall': {
    padding: '6px 10px',
  },

  /* Multiline textarea */
  '& .MuiOutlinedInput-inputMultiline': {
    padding: 0,
  },
  '& .MuiOutlinedInput-multiline': {
    padding: '8px 12px',
  },

  /* Helper text */
  '& .MuiFormHelperText-root': {
    fontSize: 11,
    marginLeft: 0,
    marginTop: '4px',
  },
} as const;

function Input({ hideLabel, label, slotProps, sx, ref, ...rest }: InputProps & { ref?: React.Ref<HTMLInputElement> }) {
    return (
      <Box style={{ width: rest.fullWidth !== false ? '100%' : 'auto' }}>
        <TextField
          inputRef={ref}
          variant="outlined"
          size="small"
          fullWidth
          label={hideLabel ? undefined : label}
          InputLabelProps={{ shrink: true }}
          slotProps={slotProps}
          className="ds-c-field"
          style={sx as React.CSSProperties}
          {...rest}
        />
      </Box>
    );
  }

export { Input, fieldSx };
export default Input;
