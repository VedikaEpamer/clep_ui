/**
 * Atom: Accordion
 * ================
 * Collapsible content section with header toggle.
 *
 * Usage:
 *   <Accordion title="Section 1" defaultExpanded>
 *     <p>Content</p>
 *   </Accordion>
 *
 *   <Accordion title="Contracts" icon="file-text" badge={12}>
 *     <DataGrid ... />
 *   </Accordion>
 */
import { type ReactNode } from 'react';
import MuiAccordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Box from '@mui/material/Box';
import { Icon } from './Icon';
import { Typography } from './Typography';
import { Badge } from './Badge';

export interface AccordionProps {
  /** Section title */
  title: string;
  /** Optional icon name beside the title */
  icon?: string;
  /** Optional badge count next to the title */
  badge?: number;
  /** Content inside the accordion body */
  children: ReactNode;
  /** Whether expanded by default */
  defaultExpanded?: boolean;
  /** Controlled expanded state */
  expanded?: boolean;
  /** Called when expand/collapse toggles */
  onChange?: (expanded: boolean) => void;
  /** Disable interaction */
  disabled?: boolean;
  /** Variant — 'outlined' (default) or 'elevated' */
  variant?: 'outlined' | 'elevated';
  /** Extra className on root */
  className?: string;
}

function Accordion({
  title,
  icon,
  badge,
  children,
  defaultExpanded = false,
  expanded,
  onChange,
  disabled = false,
  variant = 'outlined',
  className,
}: AccordionProps) {
  const controlledProps = expanded !== undefined
    ? { expanded, onChange: (_e: React.SyntheticEvent, isExpanded: boolean) => onChange?.(isExpanded) }
    : { defaultExpanded };

  return (
    <MuiAccordion
      {...controlledProps}
      disabled={disabled}
      disableGutters
      className={`ds-c-accordion ds-c-accordion--${variant} ${className ?? ''}`}
    >
      <AccordionSummary
        expandIcon={<Icon name="chevron-down" size={18} />}
        className="ds-c-accordion__header"
      >
        <Box className="ds-c-accordion__title-row">
          {icon && <Icon name={icon as any} size={18} className="ds-c-accordion__icon" />}
          <Typography variant="subtitle1">{title}</Typography>
          {badge !== undefined && (
            <Badge count={badge} color="primary" />
          )}
        </Box>
      </AccordionSummary>
      <AccordionDetails className="ds-c-accordion__body">
        {children}
      </AccordionDetails>
    </MuiAccordion>
  );
}

export { Accordion };
export default Accordion;
