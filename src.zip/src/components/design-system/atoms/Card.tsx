/**
 * Atom: Card
 * ===========
 * Content container card with optional header/footer slots.
 *
 * Usage:
 *   <Card>Content</Card>
 *   <Card title="Section Title" subtitle="Description">Content</Card>
 *   <Card title="Events" action={<Button>New</Button>}>Table here</Card>
 *   <Card noPadding>Full-bleed content</Card>
 */
import React from 'react';
import MuiCard from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Box from '@mui/material/Box';
import Typography from './Typography';

export interface CardProps {
  /** Card title */
  title?: React.ReactNode;
  /** Subtitle / description text */
  subtitle?: React.ReactNode;
  /** Action element (rendered to the right of title) */
  action?: React.ReactNode;
  /** Card content */
  children: React.ReactNode;
  /** Remove internal padding */
  noPadding?: boolean;
  /** Custom className */
  className?: string;
  /** Custom sx */
  sx?: object;
}

function Card({ title, subtitle, action, children, noPadding, className, sx }: CardProps) {
  return (
    <MuiCard
      variant="outlined"
      className={`ds-c-card ${className ?? ''}`}
      style={sx as React.CSSProperties}
    >
      {(title || action) && (
        <Box className="ds-c-card__header">
          <Box>
            {typeof title === 'string' ? (
              <Typography variant="h4">{title}</Typography>
            ) : (
              title
            )}
            {subtitle && (
              <Typography variant="helper" className="ds-c-card__subtitle">
                {subtitle}
              </Typography>
            )}
          </Box>
          {action && <Box>{action}</Box>}
        </Box>
      )}
      {noPadding ? children : <CardContent className="ds-c-card__content">{children}</CardContent>}
    </MuiCard>
  );
}

export { Card };
export default Card;
