/**
 * Atom: RadioGroup
 * =================
 * Radio button group with label + options.
 *
 * Usage:
 *   <RadioGroup
 *     label="Status"
 *     options={[{ label: 'Active', value: 'active' }, { label: 'Inactive', value: 'inactive' }]}
 *     value={status}
 *     onChange={setStatus}
 *   />
 *
 *   <RadioGroup row options={options} value={v} onChange={setV} />
 */
import React from 'react';
import MuiRadioGroup from '@mui/material/RadioGroup';
import MuiRadio from '@mui/material/Radio';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';

export interface RadioOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface RadioGroupProps {
  /** Group label */
  label?: string;
  /** List of radio options */
  options: RadioOption[];
  /** Currently selected value */
  value: string;
  /** Called with the selected value string */
  onChange: (value: string) => void;
  /** Render options in a row */
  row?: boolean;
  /** Disabled state for the whole group */
  disabled?: boolean;
  /** Size */
  size?: 'small' | 'medium';
}

function RadioGroup({
  label,
  options,
  value,
  onChange,
  row = false,
  disabled = false,
  size = 'small',
}: RadioGroupProps) {
  return (
    <FormControl disabled={disabled} size={size}>
      {label && (
        <FormLabel className="ds-c-radio-label">
          {label}
        </FormLabel>
      )}
      <MuiRadioGroup
        value={value}
        onChange={(_e, v) => onChange(v)}
        row={row}
      >
        {options.map((opt) => (
          <FormControlLabel
            key={opt.value}
            value={opt.value}
            disabled={opt.disabled}
            control={<MuiRadio size={size} />}
            label={opt.label}
            className="ds-c-form-control-sm"
          />
        ))}
      </MuiRadioGroup>
    </FormControl>
  );
}

export { RadioGroup };
export default RadioGroup;
