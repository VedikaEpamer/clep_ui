/**
 * Atom: Textarea
 * ===============
 * Multi-line text input with label-above pattern matching the Input atom.
 *
 * Usage:
 *   <Textarea label="Notes" value={val} onChange={e => setVal(e.target.value)} />
 *   <Textarea label="Description" rows={6} maxLength={500} />
 */
import { type TextareaHTMLAttributes } from 'react';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';

export interface TextareaProps extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'onChange'> {
  /** Field label (rendered above) */
  label?: string;
  /** Controlled value */
  value?: string;
  /** Change handler */
  onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  /** Number of visible rows (default 4) */
  rows?: number;
  /** Maximum character count */
  maxLength?: number;
  /** Full width (default true) */
  fullWidth?: boolean;
  /** Error state */
  error?: boolean;
  /** Helper / error text */
  helperText?: string;
  /** Disabled state */
  disabled?: boolean;
  /** Placeholder */
  placeholder?: string;
  /** Extra className */
  className?: string;
}

function Textarea({
  label,
  value,
  onChange,
  rows = 4,
  maxLength,
  fullWidth = true,
  error = false,
  helperText,
  disabled = false,
  placeholder,
  className,
  ...rest
}: TextareaProps) {
  const charCount = value?.length ?? 0;
  const displayHelper = maxLength
    ? `${helperText ? helperText + ' · ' : ''}${charCount}/${maxLength}`
    : helperText;

  return (
    <Box style={{ width: fullWidth ? '100%' : 'auto' }} className={className}>
      <TextField
        multiline
        rows={rows}
        variant="outlined"
        size="small"
        fullWidth={fullWidth}
        label={label}
        value={value}
        onChange={onChange as any}
        error={error}
        helperText={displayHelper}
        disabled={disabled}
        placeholder={placeholder}
        className="ds-c-field"
        InputLabelProps={{ shrink: true }}
        inputProps={{ maxLength, ...rest }}
      />
    </Box>
  );
}

export { Textarea };
export default Textarea;
