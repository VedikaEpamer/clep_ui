/**
 * Design System Showcase
 * =======================
 * A living catalog of all atoms, molecules, organisms, and templates.
 * Route: /design-system
 */
import React, { useState, useRef, useCallback } from 'react';
import Box from '@mui/material/Box';
import MuiDivider from '@mui/material/Divider';
import dayjs, { type Dayjs } from 'dayjs';
import {
  // Atoms
  Typography,
  Button,
  IconButton,
  Input,
  Dropdown,
  DateTimePicker,
  Checkbox,
  Switch,
  RadioGroup,
  Badge,
  Chip,
  Tooltip,
  Avatar,
  Tabs,
  Skeleton,
  Divider,
  Card,
  Icon,
  Modal,
  Textarea,
  Accordion,
  Popover,
  ProgressBar,
  Spinner,
  FileUpload,
  // Molecules
  SearchInput,
  FormField,
  ConfirmDialog,
  StatCard,
  EmptyState,
  Stepper,
  CommentCard,
  Timeline,
  NotificationItem,
  TaskItem,
  TreeView,
  RepeaterField,
  ChipGroup,
  ErrorBoundary,
  // Organisms
  DataGrid,
  PageHeader,
  AppHeader,
  AppFooter,
  FilterBar,
  NotificationPanel,
  Drawer,
  // Templates
  PageLayout,
  SidebarLayout,
  MasterDetail,
  StepWizard,
  // Types
  type DropdownOption,
  type FilterDef,
  type UploadedFile,
  type StepItem,
  type TimelineEntry,
  type NotificationData,
  type TaskData,
  type TreeNodeData,
  type ChipOption,
} from '../design-system';
import { everestLogo } from '../../assets/images';

/* ─── Section wrapper ──────────────────────── */
function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
  <Box className="ds-showcase-ds-section">
    <Typography variant="h3" className="ds-showcase-ds-section__title">{title}</Typography>
    {description && <Typography variant="body2" muted className="ds-showcase-mb-2">{description}</Typography>}
    <Box className="ds-showcase-ds-section__body">
      {children}
    </Box>
  </Box>
  );
}

function Row({ children, gap = 2 }: { children: React.ReactNode; gap?: number }) {
  return (
  <Box className="ds-showcase-ds-row" style={gap !== 2 ? { gap: gap * 8 } : undefined}>{children}</Box>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
  <Typography variant="label" className="ds-showcase-ds-label">{children}</Typography>
  );
}

/* ─── Sample data ──────────────────────────── */
const sampleDropdownOptions: DropdownOption[] = [
  { label: 'North America', value: 'na', group: 'Americas' },
  { label: 'South America', value: 'sa', group: 'Americas' },
  { label: 'Europe', value: 'eu', group: 'EMEA' },
  { label: 'Middle East', value: 'me', group: 'EMEA' },
  { label: 'Africa', value: 'af', group: 'EMEA' },
  { label: 'Asia Pacific', value: 'apac', group: 'APAC' },
];

const sampleGridData = [
  { id: 1, event: 'Hurricane Maria', region: 'North America', lossAmount: 45000000, status: 'Active', date: '2025-09-15', peril: 'Wind' },
  { id: 2, event: 'Earthquake Chile', region: 'South America', lossAmount: 120000000, status: 'Closed', date: '2025-03-22', peril: 'Earthquake' },
  { id: 3, event: 'Flood Germany', region: 'Europe', lossAmount: 30000000, status: 'Pending', date: '2025-07-10', peril: 'Flood' },
  { id: 4, event: 'Wildfire California', region: 'North America', lossAmount: 85000000, status: 'Active', date: '2025-10-01', peril: 'Wildfire' },
  { id: 5, event: 'Typhoon Haiyan II', region: 'Asia Pacific', lossAmount: 200000000, status: 'Active', date: '2025-11-08', peril: 'Wind' },
  { id: 6, event: 'Tornado Alley Outbreak', region: 'North America', lossAmount: 15000000, status: 'Closed', date: '2025-05-20', peril: 'Wind' },
  { id: 7, event: 'Volcanic Eruption Iceland', region: 'Europe', lossAmount: 50000000, status: 'Pending', date: '2025-08-14', peril: 'Other' },
  { id: 8, event: 'Cyclone Amphan III', region: 'Asia Pacific', lossAmount: 75000000, status: 'Active', date: '2025-06-30', peril: 'Wind' },
];

const sampleGridColumns = [
  { field: 'id', headerName: 'ID', width: 70, filter: 'agNumberColumnFilter' },
  { field: 'event', headerName: 'Event Name', flex: 2, filter: 'agTextColumnFilter' },
  { field: 'region', headerName: 'Region', flex: 1, filter: 'agSetColumnFilter' },
  { field: 'peril', headerName: 'Peril', flex: 1, filter: 'agSetColumnFilter' },
  {
    field: 'lossAmount', headerName: 'Loss Amount', flex: 1, filter: 'agNumberColumnFilter',
    valueFormatter: (p: any) => p.value ? `$${(p.value / 1e6).toFixed(1)}M` : '',
  },
  {
    field: 'status', headerName: 'Status', width: 120, filter: 'agSetColumnFilter',
    cellStyle: (p: any) => {
      const colors: Record<string, string> = { Active: '#10b981', Closed: '#6b7280', Pending: '#f59e0b' };
      return { color: colors[p.value] ?? '#000', fontWeight: 500 };
    },
  },
  { field: 'date', headerName: 'Date', width: 120, filter: 'agDateColumnFilter' },
];

/* ═══════════════════════════════════════════════ */
/*  SHOWCASE COMPONENT                             */
/* ═══════════════════════════════════════════════ */
function DesignSystemShowcase() {
  // Atoms state
  const [singleDd, setSingleDd] = useState<DropdownOption | null>(null);
  const [multiDd, setMultiDd] = useState<DropdownOption[]>([]);
  const [dateVal, setDateVal] = useState<Dayjs | null>(dayjs());
  const [dateTimeVal, setDateTimeVal] = useState<Dayjs | null>(dayjs());
  const [timeVal, setTimeVal] = useState<Dayjs | null>(dayjs());
  const [checkVal, setCheckVal] = useState(false);
  const [switchVal, setSwitchVal] = useState(true);
  const [radioVal, setRadioVal] = useState('active');
  const [activeTab, setActiveTab] = useState('overview');
  const [inputVal, setInputVal] = useState('');

  // Molecules state
  const [searchVal, setSearchVal] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);

  // New atoms state
  const [modalOpen, setModalOpen] = useState(false);
  const [textareaVal, setTextareaVal] = useState('');
  const [uploadFiles, setUploadFiles] = useState<UploadedFile[]>([]);
  const [chipSelection, setChipSelection] = useState<Set<string>>(new Set(['react']));

  // New molecules state
  const [treeSelected, setTreeSelected] = useState<string | undefined>('events');

  // Drawer state
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Organisms state
  const [gridSearch, setGridSearch] = useState('');
  const [filterRegion, setFilterRegion] = useState<DropdownOption | null>(null);
  const [filterDate, setFilterDate] = useState<Dayjs | null>(null);

  const filters: FilterDef[] = [
    {
      type: 'dropdown', name: 'region', label: 'Region',
      options: sampleDropdownOptions, value: filterRegion, onChange: setFilterRegion,
    },
    { type: 'date', name: 'from', label: 'From Date', value: filterDate, onChange: setFilterDate },
  ];

  return (
    <Box>
      {/* ════════════════════════════════════════ */}
      {/*  ATOMS                                   */}
      {/* ════════════════════════════════════════ */}
      <Typography variant="h2" sx={{ mb: 3, pb: 1, borderBottom: '2px solid var(--ds-brand-primary)' }}>
        Atoms
      </Typography>

      {/* Typography */}
      <Section title="Typography" description="All heading, body, and utility text variants">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Typography variant="h1">H1 — Page Title (28px Medium)</Typography>
          <Typography variant="h2">H2 — Section Title (20px Medium)</Typography>
          <Typography variant="h3">H3 — Subsection Title (16px Medium)</Typography>
          <Typography variant="h4">H4 — Card Title (14px Medium)</Typography>
          <Typography variant="h5">H5 — Small Heading (13px Medium)</Typography>
          <Typography variant="h6">H6 — Micro Heading (12px Medium)</Typography>
          <MuiDivider sx={{ my: 1 }} />
          <Typography variant="subtitle1">Subtitle 1 — Section label (14px Medium)</Typography>
          <Typography variant="subtitle2">Subtitle 2 — Secondary label (12px Medium)</Typography>
          <Typography variant="body1">Body 1 — Default body text (13px Regular). The quick brown fox jumps over the lazy dog.</Typography>
          <Typography variant="body2">Body 2 — Secondary body text (12px Regular). The quick brown fox jumps over the lazy dog.</Typography>
          <Typography variant="caption">Caption — Small annotation text (11px)</Typography>
          <Typography variant="overline">Overline — Uppercase Label</Typography>
          <Typography variant="label">Label — Field label (12px Medium)</Typography>
          <Typography variant="helper">Helper — Helper text (11px Muted)</Typography>
          <MuiDivider sx={{ my: 1 }} />
          <Typography variant="body1" muted>Muted text (using muted prop)</Typography>
          <Typography variant="body1" truncate={2} sx={{ maxWidth: 400 }}>
            Truncated text (2 lines max): Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
          </Typography>
        </Box>
      </Section>

      {/* Buttons */}
      <Section title="Button" description="Primary, outlined, text variants with sizes and loading state">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Row>
            <Label>Contained</Label>
            <Button variant="contained">Primary</Button>
            <Button variant="contained" color="success">Success</Button>
            <Button variant="contained" color="error">Error</Button>
            <Button variant="contained" color="warning">Warning</Button>
            <Button variant="contained" disabled>Disabled</Button>
          </Row>
          <Row>
            <Label>Outlined</Label>
            <Button variant="outlined">Default</Button>
            <Button variant="outlined" color="primary">Primary</Button>
            <Button variant="outlined" color="error">Error</Button>
            <Button variant="outlined" disabled>Disabled</Button>
          </Row>
          <Row>
            <Label>Text</Label>
            <Button variant="text">Default</Button>
            <Button variant="text" color="primary">Primary</Button>
            <Button variant="text" color="error">Delete</Button>
          </Row>
          <Row>
            <Label>With Icons</Label>
            <Button variant="contained" startIcon={<Icon name="save" size={16} />}>Save</Button>
            <Button variant="outlined" startIcon={<Icon name="download" size={16} />}>Export</Button>
            <Button variant="outlined" color="error" startIcon={<Icon name="trash-2" size={16} />}>Delete</Button>
            <Button variant="contained" startIcon={<Icon name="plus" size={16} />}>New Event</Button>
          </Row>
          <Row>
            <Label>Sizes</Label>
            <Button variant="contained" size="small">Small</Button>
            <Button variant="contained" size="medium">Medium</Button>
            <Button variant="contained" size="large">Large</Button>
          </Row>
          <Row>
            <Label>Loading</Label>
            <Button variant="contained" loading>Saving...</Button>
            <Button variant="outlined" loading>Exporting...</Button>
          </Row>
        </Box>
      </Section>

      {/* IconButton */}
      <Section title="IconButton" description="Icon-only buttons with optional tooltip">
        <Row gap={1}>
          <IconButton tooltip="Edit"><Icon name="edit" size={18} /></IconButton>
          <IconButton tooltip="Save"><Icon name="save" size={18} /></IconButton>
          <IconButton tooltip="Delete" color="error"><Icon name="trash-2" size={18} /></IconButton>
          <IconButton tooltip="Filter"><Icon name="filter" size={18} /></IconButton>
          <IconButton tooltip="Settings"><Icon name="settings" size={18} /></IconButton>
          <IconButton tooltip="View"><Icon name="eye" size={18} /></IconButton>
          <IconButton disabled tooltip="Disabled"><Icon name="plus" size={18} /></IconButton>
        </Row>
      </Section>

      {/* Input */}
      <Section title="Input" description="Text input with sizes, states, and validation">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 400 }}>
          <Input label="Default Input" value={inputVal} onChange={(e) => setInputVal(e.target.value)} />
          <Input label="With Placeholder" placeholder="Enter event name..." />
          <Input label="Search" placeholder="Search..." />
          <Input label="Amount" type="number" placeholder="0.00" />
          <Input label="Error State" error helperText="This field is required" />
          <Input label="Disabled" disabled value="Cannot edit" />
          <Input label="Multiline" multiline rows={3} placeholder="Enter description..." />
        </Box>
      </Section>

      {/* Dropdown */}
      <Section title="Dropdown" description="Single-select and multi-select with grouped options">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, maxWidth: 400 }}>
          <Box>
            <Typography variant="label" sx={{ mb: 1 }}>Single Select</Typography>
            <Dropdown
              label="Region"
              options={sampleDropdownOptions}
              value={singleDd}
              onChange={((val: any) => setSingleDd(val)) as any}
              grouped
              placeholder="Select a region..."
            />
          </Box>
          <Box>
            <Typography variant="label" sx={{ mb: 1 }}>Multi Select (with checkboxes & chips)</Typography>
            <Dropdown
              label="Regions"
              options={sampleDropdownOptions}
              multiple
              value={multiDd}
              onChange={((val: any) => setMultiDd(val)) as any}
              grouped
              placeholder="Select regions..."
            />
          </Box>
          <Box>
            <Typography variant="label" sx={{ mb: 1 }}>Free Solo (allow custom entries)</Typography>
            <Dropdown
              label="Custom"
              options={['Option A', 'Option B', 'Option C']}
              value={null}
              onChange={() => {}}
              freeSolo
              placeholder="Type or select..."
            />
          </Box>
        </Box>
      </Section>

      {/* DateTimePicker */}
      <Section title="DateTimePicker" description="Date only, DateTime, and Time-only modes">
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
          <Box sx={{ minWidth: 220 }}>
            <DateTimePicker label="Date Only" mode="date" value={dateVal} onChange={setDateVal} />
          </Box>
          <Box sx={{ minWidth: 260 }}>
            <DateTimePicker label="Date & Time" mode="datetime" value={dateTimeVal} onChange={setDateTimeVal} />
          </Box>
          <Box sx={{ minWidth: 180 }}>
            <DateTimePicker label="Time Only" mode="time" value={timeVal} onChange={setTimeVal} />
          </Box>
          <Box sx={{ minWidth: 220 }}>
            <DateTimePicker label="Disabled" mode="date" value={dayjs()} onChange={() => {}} disabled />
          </Box>
        </Box>
      </Section>

      {/* Checkbox, Switch, RadioGroup */}
      <Section title="Checkbox / Switch / RadioGroup" description="Selection controls with labels">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Row>
            <Label>Checkbox</Label>
            <Checkbox label="Accept terms" checked={checkVal} onChange={setCheckVal} />
            <Checkbox label="Checked" checked />
            <Checkbox label="Indeterminate" indeterminate checked />
            <Checkbox label="Disabled" disabled />
          </Row>
          <Row>
            <Label>Switch</Label>
            <Switch label="Notifications" checked={switchVal} onChange={setSwitchVal} />
            <Switch label="Off" checked={false} />
            <Switch label="Disabled" disabled />
          </Row>
          <Row>
            <Label>Radio</Label>
            <RadioGroup
              options={[
                { label: 'Active', value: 'active' },
                { label: 'Pending', value: 'pending' },
                { label: 'Closed', value: 'closed' },
              ]}
              value={radioVal}
              onChange={setRadioVal}
              row
            />
          </Row>
        </Box>
      </Section>

      {/* Badge & Chip */}
      <Section title="Badge & Chip" description="Notification badges and status chips">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Row gap={3}>
            <Label>Badges</Label>
            <Badge count={5}><Icon name="bell" size={20} /></Badge>
            <Badge count={99}><Icon name="mail" size={20} /></Badge>
            <Badge count={150} max={99}><Icon name="inbox" size={20} /></Badge>
            <Badge dot><Icon name="bell" size={20} /></Badge>
          </Row>
          <Row gap={1}>
            <Label>Status Chips</Label>
            <Chip label="Active" status="success" />
            <Chip label="Pending" status="warning" />
            <Chip label="Error" status="error" />
            <Chip label="Info" status="info" />
            <Chip label="Primary" status="primary" />
            <Chip label="Default" status="default" />
          </Row>
          <Row gap={1}>
            <Label>Deletable</Label>
            <Chip label="North America" onDelete={() => {}} />
            <Chip label="Europe" onDelete={() => {}} status="primary" />
          </Row>
        </Box>
      </Section>

      {/* Tooltip & Avatar */}
      <Section title="Tooltip & Avatar" description="Hover tooltips and user avatars">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Row gap={3}>
            <Label>Tooltips</Label>
            <Tooltip title="I'm a tooltip on the top" placement="top">
              <Button variant="outlined" size="small">Hover me (top)</Button>
            </Tooltip>
            <Tooltip title="Tooltip on the right" placement="right">
              <Button variant="outlined" size="small">Right</Button>
            </Tooltip>
            <Tooltip title="Tooltip on the bottom" placement="bottom">
              <Button variant="outlined" size="small">Bottom</Button>
            </Tooltip>
          </Row>
          <Row gap={1}>
            <Label>Avatars</Label>
            <Avatar initials="JD" size="small" />
            <Avatar initials="AB" size="medium" />
            <Avatar initials="XY" size="large" />
            <Avatar size="medium" sx={{ bgcolor: '#10b981' }}>
              <Icon name="users" size={18} color="#fff" />
            </Avatar>
            <Avatar size="medium" sx={{ bgcolor: '#f59e0b' }}>
              <Icon name="shield" size={18} color="#fff" />
            </Avatar>
          </Row>
        </Box>
      </Section>

      {/* Tabs */}
      <Section title="Tabs" description="Tab navigation with optional count badges">
        <Tabs
          tabs={[
            { label: 'Overview', value: 'overview', icon: <Icon name="activity" size={16} /> },
            { label: 'Details', value: 'details', icon: <Icon name="info" size={16} />, count: 3 },
            { label: 'Finance', value: 'finance', icon: <Icon name="dollar-sign" size={16} /> },
            { label: 'Documents', value: 'documents', icon: <Icon name="globe" size={16} />, count: 12 },
            { label: 'Disabled', value: 'disabled', disabled: true },
          ]}
          value={activeTab}
          onChange={setActiveTab}
        />
        <Box sx={{ mt: 2, p: 2, bgcolor: 'var(--ds-bg-secondary)', borderRadius: 'var(--ds-radius-md)' }}>
          <Typography variant="body2">Active tab: <strong>{activeTab}</strong></Typography>
        </Box>
      </Section>

      {/* Skeleton */}
      <Section title="Skeleton" description="Loading placeholders">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, maxWidth: 400 }}>
          <Skeleton variant="text" width={200} height={24} />
          <Skeleton variant="text" width={300} height={16} />
          <Skeleton variant="rectangular" height={80} />
          <Row gap={1}>
            <Skeleton variant="circular" width={36} height={36} />
            <Box sx={{ flex: 1 }}>
              <Skeleton variant="text" width="60%" height={16} />
              <Skeleton variant="text" width="40%" height={14} />
            </Box>
          </Row>
        </Box>
      </Section>

      {/* Divider & Card */}
      <Section title="Divider & Card" description="Content separators and card containers">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Divider />
          <Divider label="OR" />
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Box sx={{ flex: 1, minWidth: 250 }}>
              <Card title="Basic Card" subtitle="With title and subtitle">
                <Typography variant="body2">Card content goes here.</Typography>
              </Card>
            </Box>
            <Box sx={{ flex: 1, minWidth: 250 }}>
              <Card
                title="Card with Action"
                action={<Button variant="outlined" size="small" startIcon={<Icon name="plus" size={14} />}>Add</Button>}
              >
                <Typography variant="body2">Card with an action button in the header.</Typography>
              </Card>
            </Box>
          </Box>
        </Box>
      </Section>

      {/* Modal */}
      <Section title="Modal" description="Dialog with header (icon + title), scrollable body, and sticky footer">
        <Button variant="outlined" onClick={() => setModalOpen(true)} startIcon={<Icon name="maximize-2" size={14} />}>
          Open Modal
        </Button>
        <Modal
          open={modalOpen}
          onClose={() => setModalOpen(false)}
          title="Create New Event"
          icon="activity"
          size="md"
          footer={
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="text" onClick={() => setModalOpen(false)}>Cancel</Button>
              <Button variant="contained" onClick={() => setModalOpen(false)}>Create</Button>
            </Box>
          }
        >
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Input label="Event Name" placeholder="Enter event name" fullWidth />
            <Textarea label="Description" placeholder="Enter description..." rows={3} fullWidth />
          </Box>
        </Modal>
      </Section>

      {/* Textarea */}
      <Section title="Textarea" description="Multi-line text field with character count">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 400 }}>
          <Textarea label="Notes" value={textareaVal} onChange={(e) => setTextareaVal(e.target.value)} placeholder="Enter notes..." rows={3} maxLength={200} fullWidth />
          <Textarea label="Disabled" value="Cannot edit" onChange={() => {}} disabled fullWidth />
          <Textarea label="With Error" value="" onChange={() => {}} error helperText="This field is required" fullWidth />
        </Box>
      </Section>

      {/* Accordion */}
      <Section title="Accordion" description="Collapsible panels with icon, badge, and variant styles">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, maxWidth: 500 }}>
          <Accordion title="Event Details" icon="activity" defaultExpanded variant="outlined">
            <Typography variant="body2">Hurricane Maria caused $45M in losses across the North America region.</Typography>
          </Accordion>
          <Accordion title="Financial Impact" icon="dollar-sign" badge={3} variant="outlined">
            <Typography variant="body2">Total insured loss: $120M across 3 treaties.</Typography>
          </Accordion>
          <Accordion title="Disabled Section" disabled variant="outlined">
            <Typography variant="body2">This content is hidden.</Typography>
          </Accordion>
        </Box>
      </Section>

      {/* Popover */}
      <Section title="Popover" description="Overlay panel anchored to a trigger element">
        <Row>
          <Popover trigger={<Button variant="outlined" size="small">Click for Popover</Button>} title="Quick Filters" placement="bottom-start" width={280}>
            <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Typography variant="body2">Filter options would go here.</Typography>
              <Button variant="contained" size="small" fullWidth>Apply Filters</Button>
            </Box>
          </Popover>
          <Popover trigger={<IconButton tooltip="Info"><Icon name="info" size={16} /></IconButton>} placement="bottom-end" width={220}>
            <Box sx={{ p: 2 }}>
              <Typography variant="body2">Helpful tooltip-style popover content.</Typography>
            </Box>
          </Popover>
        </Row>
      </Section>

      {/* ProgressBar */}
      <Section title="ProgressBar" description="Linear progress indicator with label and value">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 400 }}>
          <ProgressBar value={75} label="Claims Processed" showValue color="primary" />
          <ProgressBar value={100} label="Completed" showValue color="success" />
          <ProgressBar value={45} label="In Review" showValue color="warning" />
          <ProgressBar value={20} label="Critical Issues" showValue color="error" />
        </Box>
      </Section>

      {/* Spinner */}
      <Section title="Spinner" description="Loading indicator with sizes and optional label">
        <Row gap={4}>
          <Spinner size="small" />
          <Spinner size="medium" label="Loading..." />
          <Spinner size="large" color="secondary" />
          <Box sx={{ position: 'relative', width: 120, height: 80, border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)' }}>
            <Spinner overlay size="small" label="Loading" />
          </Box>
        </Row>
      </Section>

      {/* FileUpload */}
      <Section title="FileUpload" description="Drag-and-drop file upload zone with file list">
        <Box sx={{ maxWidth: 400 }}>
          <FileUpload
            label="Attachments"
            files={uploadFiles}
            onAdd={(newFiles) => setUploadFiles((prev) => [...prev, ...newFiles])}
            onRemove={(id) => setUploadFiles((prev) => prev.filter((f) => f.id !== id))}
            accept=".pdf,.doc,.docx,.xlsx"
            maxFiles={5}
            maxSize={10 * 1024 * 1024}
          />
        </Box>
      </Section>

      {/* ════════════════════════════════════════ */}
      {/*  MOLECULES                               */}
      {/* ════════════════════════════════════════ */}
      <Typography variant="h2" sx={{ mt: 5, mb: 3, pb: 1, borderBottom: '2px solid var(--ds-color-success)' }}>
        Molecules
      </Typography>

      {/* SearchInput */}
      <Section title="SearchInput" description="Search field with icon, clear, and optional debounce">
        <Box sx={{ maxWidth: 400 }}>
          <SearchInput
            value={searchVal}
            onChange={setSearchVal}
            placeholder="Search events, contracts..."
            debounceMs={300}
          />
          <Typography variant="caption" sx={{ mt: 1, display: 'block' }}>
            Current value: "{searchVal}"
          </Typography>
        </Box>
      </Section>

      {/* FormField */}
      <Section title="FormField" description="Labelled form fields with error/helper text">
        <Box sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          <Box sx={{ flex: 1, minWidth: 280 }}>
            <Typography variant="label" sx={{ mb: 1.5, display: 'block' }}>Vertical Layout</Typography>
            <FormField label="Event Name" required>
              <Input placeholder="Enter event name" />
            </FormField>
            <FormField label="Region" helper="Select the primary impacted region">
              <Dropdown options={sampleDropdownOptions} value={null} onChange={() => {}} label="" placeholder="Select..." />
            </FormField>
            <FormField label="Notes" error="This field is required">
              <Input multiline rows={2} error />
            </FormField>
          </Box>
          <Box sx={{ flex: 1, minWidth: 280 }}>
            <Typography variant="label" sx={{ mb: 1.5, display: 'block' }}>Horizontal Layout</Typography>
            <FormField label="Event Name" direction="horizontal" required>
              <Input placeholder="Enter event name" />
            </FormField>
            <FormField label="Amount" direction="horizontal">
              <Input type="number" placeholder="0.00" />
            </FormField>
          </Box>
        </Box>
      </Section>

      {/* ConfirmDialog */}
      <Section title="ConfirmDialog" description="Confirmation modal with loading state">
        <Row>
          <Button variant="outlined" color="error" onClick={() => setConfirmOpen(true)} startIcon={<Icon name="trash-2" size={16} />}>
            Open Confirm Dialog
          </Button>
          <ConfirmDialog
            open={confirmOpen}
            title="Delete Event"
            message="Are you sure you want to delete this event? This action cannot be undone."
            confirmLabel="Delete"
            confirmColor="error"
            onConfirm={() => setConfirmOpen(false)}
            onCancel={() => setConfirmOpen(false)}
          />
        </Row>
      </Section>

      {/* StatCard */}
      <Section title="StatCard" description="Key metric display with trend indicators">
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 2 }}>
          <StatCard
            icon={<Icon name="dollar-sign" size={20} />}
            label="Total Gross Loss"
            value="$1.2B"
            trend="up"
            trendLabel="+12% vs last quarter"
          />
          <StatCard
            icon={<Icon name="activity" size={20} />}
            label="Active Events"
            value="24"
            trend="down"
            trendLabel="-3 from last month"
          />
          <StatCard
            icon={<Icon name="globe" size={20} />}
            label="Impacted Regions"
            value="8"
            trend="neutral"
            trendLabel="No change"
          />
          <StatCard
            icon={<Icon name="clock" size={20} />}
            label="Avg Resolution Time"
            value="14 days"
          />
        </Box>
      </Section>

      {/* EmptyState */}
      <Section title="EmptyState" description="Placeholder when no data is available">
        <EmptyState
          icon={<Icon name="inbox" size={48} />}
          title="No events found"
          description="Try adjusting your search criteria or create a new event to get started."
          action={<Button variant="contained" startIcon={<Icon name="plus" size={16} />}>Create Event</Button>}
        />
      </Section>

      {/* Stepper */}
      <Section title="Stepper" description="Workflow phase stepper with status indicators">
        <Box sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          <Box sx={{ flex: 1, minWidth: 250 }}>
            <Typography variant="label" sx={{ mb: 1, display: 'block' }}>Vertical</Typography>
            <Stepper
              orientation="vertical"
              steps={[
                { label: 'Event Created', status: 'completed', description: 'Initial event logged', icon: 'check-circle', date: 'Jan 15, 2025' },
                { label: 'Under Review', status: 'completed', description: 'Loss assessment in progress', icon: 'eye' },
                { label: 'Financial Analysis', status: 'in-progress', description: 'Calculating treaty impacts', icon: 'dollar-sign' },
                { label: 'Final Approval', status: 'not-started', description: 'Pending management sign-off', icon: 'shield' },
              ] as StepItem[]}
            />
          </Box>
          <Box sx={{ flex: 1, minWidth: 300 }}>
            <Typography variant="label" sx={{ mb: 1, display: 'block' }}>Horizontal (Compact)</Typography>
            <Stepper
              orientation="horizontal"
              compact
              steps={[
                { label: 'Draft', status: 'completed' },
                { label: 'Review', status: 'in-progress' },
                { label: 'Approved', status: 'not-started' },
              ] as StepItem[]}
            />
          </Box>
        </Box>
      </Section>

      {/* CommentCard */}
      <Section title="CommentCard" description="User comment with metadata, team badge, and attachments">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 500 }}>
          <CommentCard
            author="Jane Doe"
            authorRole="Claims Analyst"
            team="North America"
            timestamp="2025-01-15T14:30:00Z"
            text="Updated the loss estimate to reflect the latest FEMA damage assessment report."
            attachments={[
              { id: '1', name: 'FEMA_Report.pdf' },
              { id: '2', name: 'Loss_Summary.xlsx' },
            ]}
          />
          <CommentCard
            author="John Smith"
            authorRole="Underwriter"
            timestamp="2025-01-15T10:00:00Z"
            text="This is an internal note — not visible to external parties."
            isInternal
          />
        </Box>
      </Section>

      {/* Timeline */}
      <Section title="Timeline" description="Chronological activity timeline with colored icons">
        <Box sx={{ maxWidth: 500 }}>
          <Timeline
            groupByDate
            entries={[
              { id: '1', icon: 'plus-circle', color: 'success', title: 'Event Created', description: 'Hurricane Maria logged in SONAR', user: 'Jane Doe', userRole: 'Analyst', timestamp: '2025-01-15T09:00:00Z' },
              { id: '2', icon: 'edit', color: 'primary', title: 'Loss Updated', description: 'Estimate revised to $45M', user: 'John Smith', userRole: 'Underwriter', timestamp: '2025-01-15T14:00:00Z', details: { 'Previous': '$30M', 'Updated': '$45M' } },
              { id: '3', icon: 'alert-triangle', color: 'warning', title: 'Threshold Exceeded', description: 'Loss exceeds $40M notification threshold', timestamp: '2025-01-14T11:00:00Z' },
              { id: '4', icon: 'check-circle', color: 'success', title: 'Approved', description: 'Final loss approved by management', user: 'Director', timestamp: '2025-01-14T08:00:00Z' },
            ] as TimelineEntry[]}
          />
        </Box>
      </Section>

      {/* TreeView */}
      <Section title="TreeView" description="Hierarchical navigation tree with select state">
        <Box sx={{ maxWidth: 300, border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', p: 1 }}>
          <TreeView
            selectedId={treeSelected}
            onSelect={setTreeSelected}
            nodes={[
              { id: 'events', label: 'Events', icon: 'activity', children: [
                { id: 'active', label: 'Active', icon: 'zap', badge: <Badge count={5} /> },
                { id: 'closed', label: 'Closed', icon: 'archive' },
              ]},
              { id: 'admin', label: 'Administration', icon: 'settings', children: [
                { id: 'users', label: 'Users', icon: 'users' },
                { id: 'roles', label: 'Roles', icon: 'shield' },
              ]},
              { id: 'reports', label: 'Reports', icon: 'bar-chart-3' },
            ] as TreeNodeData[]}
          />
        </Box>
      </Section>

      {/* ChipGroup */}
      <Section title="ChipGroup" description="Multi-select chip toggle group">
        <Box sx={{ maxWidth: 400 }}>
          <ChipGroup
            label="Technologies"
            options={[
              { value: 'react', label: 'React', icon: 'code' },
              { value: 'ts', label: 'TypeScript', icon: 'file-text' },
              { value: 'mui', label: 'MUI', icon: 'layers' },
              { value: 'vite', label: 'Vite', icon: 'zap' },
            ] as ChipOption[]}
            selected={chipSelection}
            onChange={setChipSelection}
            color="primary"
          />
        </Box>
      </Section>

      {/* ErrorBoundary */}
      <Section title="ErrorBoundary" description="Graceful error fallback boundary">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden' }}>
          <ErrorBoundary>
            <Box sx={{ p: 3 }}>
              <Typography variant="body2">This content is wrapped in an ErrorBoundary. If it throws, a fallback UI will appear.</Typography>
            </Box>
          </ErrorBoundary>
        </Box>
      </Section>

      {/* ════════════════════════════════════════ */}
      {/*  ORGANISMS                               */}
      {/* ════════════════════════════════════════ */}
      <Typography variant="h2" sx={{ mt: 5, mb: 3, pb: 1, borderBottom: '2px solid var(--ds-color-warning)' }}>
        Organisms
      </Typography>

      {/* PageHeader */}
      <Section title="PageHeader" description="Page-level header with breadcrumbs, title, and actions">
        <PageHeader
          title="Large Loss Events"
          description="Track and manage catastrophe and large loss events across all regions"
          breadcrumbs={[
            { label: 'Home', href: '/' },
            { label: 'Events', href: '/events' },
            { label: 'Hurricane Maria' },
          ]}
          icon={<Icon name="bar-chart-3" size={24} />}
          actions={
            <>
              <Button variant="outlined" startIcon={<Icon name="download" size={16} />}>Export</Button>
              <Button variant="contained" startIcon={<Icon name="plus" size={16} />}>New Event</Button>
            </>
          }
        />
      </Section>

      {/* FilterBar */}
      <Section title="FilterBar" description="Horizontal filter bar with search, dropdowns, dates, and reset">
        <FilterBar
          filters={filters}
          searchValue={gridSearch}
          onSearchChange={setGridSearch}
          searchPlaceholder="Quick filter grid..."
          onReset={() => {
            setGridSearch('');
            setFilterRegion(null);
            setFilterDate(null);
          }}
        />
      </Section>

      {/* DataGrid */}
      <Section title="DataGrid (AG Grid)" description="Full-featured data grid with filters, sorting, pagination, and SONAR theme">
        <DataGrid
          rowData={sampleGridData}
          columnDefs={sampleGridColumns as any}
          height={360}
          pagination
          pageSize={5}
          quickFilterText={gridSearch}
          emptyMessage="No events match your filter criteria"
        />
      </Section>

      {/* AppHeader */}
      <Section title="AppHeader" description="Top navigation bar — dark variant matches the SONAR app header">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden' }}>
          <AppHeader
            variant="dark"
            logo={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <img src={everestLogo} alt="Everest" style={{ height: 28 }} />
                <Typography variant="h4" sx={{ letterSpacing: '0.05em', color: '#fff' }}>SONAR</Typography>
              </Box>
            }
            navItems={[
              { label: 'Events', href: '/events', active: true, icon: <Icon name="activity" size={16} /> },
              { label: 'Administration', href: '/admin', icon: <Icon name="settings" size={16} /> },
              { label: 'Reports', href: '/reports', icon: <Icon name="bar-chart-3" size={16} /> },
            ]}
            actions={
              <>
                <Badge count={3}><IconButton tooltip="Notifications"><Icon name="bell" size={18} /></IconButton></Badge>
                <Avatar initials="JD" size="small" />
              </>
            }
            onNavigate={(href) => console.log('Navigate:', href)}
          />
        </Box>
      </Section>

      {/* AppFooter */}
      <Section title="AppFooter" description="Application footer with copyright and links">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden' }}>
          <AppFooter
            version="1.0.0"
            links={[
              { label: 'Privacy Policy', href: '/privacy' },
              { label: 'Terms of Use', href: '/terms' },
              { label: 'Help', href: '/help' },
            ]}
          />
        </Box>
      </Section>

      {/* NotificationPanel */}
      <Section title="NotificationPanel" description="Bell icon popover with notifications and tasks tabs">
        <Row>
          <NotificationPanel
            notifications={[
              { id: '1', title: 'Event Updated', message: 'Hurricane Maria loss revised to $45M', timestamp: new Date(Date.now() - 300000).toISOString(), unread: true },
              { id: '2', title: 'New Comment', message: 'Jane Doe commented on Earthquake Chile', timestamp: new Date(Date.now() - 3600000).toISOString(), unread: true },
              { id: '3', title: 'Report Published', message: 'Q4 Loss Summary is ready for download', timestamp: new Date(Date.now() - 86400000).toISOString(), unread: false },
            ] as NotificationData[]}
            tasks={[
              { id: '1', title: 'Review loss estimate', status: 'in-progress', priority: 'high', dueDate: '2025-01-20', assignee: 'You' },
              { id: '2', title: 'Approve treaty allocation', status: 'pending', priority: 'medium', dueDate: '2025-01-25' },
              { id: '3', title: 'Archive closed events', status: 'completed', priority: 'low' },
            ] as TaskData[]}
            showTabs
          />
          <Typography variant="body2" muted>← Click the bell icon</Typography>
        </Row>
      </Section>

      {/* Drawer */}
      <Section title="Drawer" description="Side sliding panel for detail views or forms">
        <Button variant="outlined" onClick={() => setDrawerOpen(true)} startIcon={<Icon name="layers" size={14} />}>
          Open Drawer
        </Button>
        <Drawer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          title="Event Details"
          width={400}
          footer={
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="text" onClick={() => setDrawerOpen(false)}>Cancel</Button>
              <Button variant="contained" onClick={() => setDrawerOpen(false)}>Save</Button>
            </Box>
          }
        >
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Input label="Event Name" value="Hurricane Maria" onChange={() => {}} fullWidth />
            <Dropdown label="Region" options={sampleDropdownOptions} value={null} onChange={() => {}} fullWidth />
            <Textarea label="Notes" value="" onChange={() => {}} rows={4} fullWidth />
          </Box>
        </Drawer>
      </Section>

      {/* ════════════════════════════════════════ */}
      {/*  TEMPLATES                               */}
      {/* ════════════════════════════════════════ */}
      <Typography variant="h2" sx={{ mt: 5, mb: 3, pb: 1, borderBottom: '2px solid #7c3aed' }}>
        Templates
      </Typography>

      <Section title="PageLayout" description="Full page shell preview (header + content + footer)">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden', height: 400 }}>
          <PageLayout
            header={
              <AppHeader
                variant="dark"
                logo={<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><img src={everestLogo} alt="Everest" style={{ height: 24 }} /><Typography variant="h5" sx={{ fontWeight: 600, color: '#fff' }}>SONAR</Typography></Box>}
                navItems={[
                  { label: 'Events', href: '/events', active: true },
                  { label: 'Admin', href: '/admin' },
                ]}
                onNavigate={() => {}}
              />
            }
            footer={<AppFooter version="1.0.0" />}
            bg="var(--ds-bg-secondary)"
          >
            <PageHeader title="Events Dashboard" description="Overview of all large loss events" />
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2, mb: 3 }}>
              <StatCard icon={<Icon name="dollar-sign" size={18} />} label="Total Loss" value="$1.2B" />
              <StatCard icon={<Icon name="activity" size={18} />} label="Active" value="24" />
              <StatCard icon={<Icon name="globe" size={18} />} label="Regions" value="8" />
            </Box>
            <Card title="Recent Events" noPadding>
              <Box sx={{ p: 2 }}>
                <Typography variant="body2" muted>Table content would go here...</Typography>
              </Box>
            </Card>
          </PageLayout>
        </Box>
      </Section>

      {/* SidebarLayout */}
      <Section title="SidebarLayout" description="Fixed header + collapsible sidebar + main content area">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden', height: 350 }}>
          <SidebarLayout
            sidebarWidth={200}
            collapsible
            header={
              <Box sx={{ p: 1.5, bgcolor: 'var(--ds-brand-navy)', color: '#fff', display: 'flex', alignItems: 'center', gap: 1 }}>
                <Icon name="layers" size={18} />
                <Typography variant="h5" sx={{ color: '#fff' }}>SONAR</Typography>
              </Box>
            }
            sidebar={
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography variant="label">Navigation</Typography>
                <Button variant="text" size="small" startIcon={<Icon name="activity" size={14} />} sx={{ justifyContent: 'flex-start' }}>Events</Button>
                <Button variant="text" size="small" startIcon={<Icon name="bar-chart-3" size={14} />} sx={{ justifyContent: 'flex-start' }}>Reports</Button>
                <Button variant="text" size="small" startIcon={<Icon name="settings" size={14} />} sx={{ justifyContent: 'flex-start' }}>Settings</Button>
              </Box>
            }
          >
            <Typography variant="h3" sx={{ mb: 2 }}>Main Content Area</Typography>
            <Typography variant="body2" muted>This is the main content region. The sidebar can be collapsed using the toggle button.</Typography>
          </SidebarLayout>
        </Box>
      </Section>

      {/* MasterDetail */}
      <Section title="MasterDetail" description="Two-panel layout with list on left, detail on right">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden', height: 280 }}>
          <MasterDetail
            masterWidth={220}
            master={
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                <Typography variant="label" sx={{ mb: 1 }}>Events</Typography>
                {['Hurricane Maria', 'Earthquake Chile', 'Flood Germany'].map((e) => (
                  <Box key={e} sx={{ p: 1, borderRadius: 'var(--ds-radius-sm)', cursor: 'pointer', '&:hover': { bgcolor: 'var(--ds-gray-50)' } }}>
                    <Typography variant="body2">{e}</Typography>
                  </Box>
                ))}
              </Box>
            }
            detail={
              <Box>
                <Typography variant="h3" sx={{ mb: 1 }}>Hurricane Maria</Typography>
                <Typography variant="body2" muted>Region: North America</Typography>
                <Typography variant="body2" muted>Loss: $45M</Typography>
              </Box>
            }
          />
        </Box>
      </Section>

      {/* StepWizard */}
      <Section title="StepWizard" description="Multi-step form wizard with validation">
        <Box sx={{ border: '1px solid var(--ds-border-light)', borderRadius: 'var(--ds-radius-md)', overflow: 'hidden' }}>
          <StepWizard
            title="Create New Event"
            steps={[
              { label: 'Basic Info', description: 'Event details', content: (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Input label="Event Name" placeholder="Enter event name" fullWidth />
                  <Dropdown label="Peril" options={[{ label: 'Wind', value: 'wind' }, { label: 'Flood', value: 'flood' }, { label: 'Earthquake', value: 'earthquake' }]} value={null} onChange={() => {}} fullWidth />
                </Box>
              )},
              { label: 'Financial', description: 'Loss estimates', content: (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Input label="Estimated Loss" placeholder="$0.00" fullWidth />
                  <Input label="Insured Loss" placeholder="$0.00" fullWidth />
                </Box>
              )},
              { label: 'Review', description: 'Confirm details', content: (
                <Box sx={{ p: 2, bgcolor: 'var(--ds-gray-50)', borderRadius: 'var(--ds-radius-md)' }}>
                  <Typography variant="body2">Review and confirm all details before submission.</Typography>
                </Box>
              )},
            ]}
            onComplete={() => console.log('Wizard completed')}
            showDraft
            onSaveDraft={() => console.log('Draft saved')}
          />
        </Box>
      </Section>

      {/* ════════════════════════════════════════ */}
      {/*  CSS VARIABLES REFERENCE                 */}
      {/* ════════════════════════════════════════ */}
      <Typography variant="h2" sx={{ mt: 5, mb: 3, pb: 1, borderBottom: '2px solid var(--ds-gray-600)' }}>
        Design Tokens
      </Typography>

      <Section title="Color Palette" description="Brand, semantic, and neutral colors from variables.css">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Typography variant="label">Brand</Typography>
          <Row gap={1}>
            {[
              { var: '--ds-brand-primary', label: 'Primary' },
              { var: '--ds-brand-primary-hover', label: 'Hover' },
              { var: '--ds-brand-primary-light', label: 'Light' },
              { var: '--ds-brand-primary-dark', label: 'Dark' },
              { var: '--ds-brand-navy', label: 'Navy' },
            ].map((c) => (
              <Box key={c.var} sx={{ textAlign: 'center' }}>
                <Box sx={{ width: 48, height: 48, borderRadius: 'var(--ds-radius-md)', bgcolor: `var(${c.var})`, border: '1px solid var(--ds-border-light)' }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>{c.label}</Typography>
              </Box>
            ))}
          </Row>

          <Typography variant="label">Semantic</Typography>
          <Row gap={1}>
            {[
              { var: '--ds-color-success', label: 'Success' },
              { var: '--ds-color-warning', label: 'Warning' },
              { var: '--ds-color-error', label: 'Error' },
              { var: '--ds-color-info', label: 'Info' },
            ].map((c) => (
              <Box key={c.var} sx={{ textAlign: 'center' }}>
                <Box sx={{ width: 48, height: 48, borderRadius: 'var(--ds-radius-md)', bgcolor: `var(${c.var})`, border: '1px solid var(--ds-border-light)' }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>{c.label}</Typography>
              </Box>
            ))}
          </Row>

          <Typography variant="label">Gray Scale</Typography>
          <Row gap={0.5}>
            {[50, 100, 200, 300, 400, 500, 600, 700, 800, 900].map((n) => (
              <Box key={n} sx={{ textAlign: 'center' }}>
                <Box sx={{ width: 40, height: 40, borderRadius: 'var(--ds-radius-sm)', bgcolor: `var(--ds-gray-${n})`, border: '1px solid var(--ds-border-light)' }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>{n}</Typography>
              </Box>
            ))}
          </Row>
        </Box>
      </Section>

      <Section title="Spacing & Radius" description="Spacing scale and border radius tokens">
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Typography variant="label">Spacing (4px base)</Typography>
          <Row gap={1}>
            {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((n) => (
              <Box key={n} sx={{ textAlign: 'center' }}>
                <Box sx={{ width: `var(--ds-space-${n})`, height: 32, bgcolor: 'var(--ds-brand-primary)', borderRadius: 'var(--ds-radius-sm)', minWidth: 4 }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>{n}</Typography>
              </Box>
            ))}
          </Row>
          <Typography variant="label">Border Radius</Typography>
          <Row gap={2}>
            {[
              { var: '--ds-radius-sm', label: 'sm (4px)' },
              { var: '--ds-radius-md', label: 'md (6px)' },
              { var: '--ds-radius-lg', label: 'lg (8px)' },
              { var: '--ds-radius-xl', label: 'xl (12px)' },
              { var: '--ds-radius-full', label: 'full' },
            ].map((r) => (
              <Box key={r.var} sx={{ textAlign: 'center' }}>
                <Box sx={{ width: 48, height: 48, bgcolor: 'var(--ds-brand-primary-bg)', border: '2px solid var(--ds-brand-primary)', borderRadius: `var(${r.var})` }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block' }}>{r.label}</Typography>
              </Box>
            ))}
          </Row>
        </Box>
      </Section>

      {/* Shadows */}
      <Section title="Shadows" description="Elevation shadow scale">
        <Row gap={3}>
          {['xs', 'sm', 'md', 'lg', 'xl'].map((s) => (
            <Box key={s} sx={{ textAlign: 'center' }}>
              <Box sx={{
                width: 80, height: 60, bgcolor: 'var(--ds-bg-primary)',
                borderRadius: 'var(--ds-radius-md)', boxShadow: `var(--ds-shadow-${s})`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Typography variant="caption">{s}</Typography>
              </Box>
            </Box>
          ))}
        </Row>
      </Section>
    </Box>
  );
}

export { DesignSystemShowcase };
export default DesignSystemShowcase;
