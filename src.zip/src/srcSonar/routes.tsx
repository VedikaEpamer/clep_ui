import { createBrowserRouter, Navigate } from 'react-router';
import { EventDashboard } from './components/EventDashboard';
import { EventCreation } from './components/EventCreation';
import { EventDetail } from './components/EventDetail';
import { Administration } from './components/Administration';
import { RootProviders } from './components/layouts/RootProviders';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootProviders,
    children: [
      {
        index: true,
        element: <Navigate to="/events" replace />,
      },
      {
        path: 'events',
        Component: EventDashboard,
      },
      {
        path: 'events/new',
        Component: EventCreation,
      },
      {
        path: 'events/:eventId/*',
        Component: EventDetail,
      },
      {
        path: 'administration/*',
        Component: Administration,
      },
      {
        path: '*',
        element: <Navigate to="/events" replace />,
      },
    ],
  },
]);
