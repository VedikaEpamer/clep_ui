import { CheckCircle2, Circle, Clock, AlertCircle, RotateCcw } from 'lucide-react';
import { useWorkflow, WorkflowStep } from '../lib/workflowContext';

interface WorkflowTrackerProps {
  eventId: string;
  compact?: boolean;
}

export function WorkflowTracker({ eventId, compact = false }: WorkflowTrackerProps) {
  const { getWorkflowStatus } = useWorkflow();
  const workflow = getWorkflowStatus(eventId);

  const getStepIcon = (step: WorkflowStep, index: number) => {
    switch (step.status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-emerald-600" />;
      case 'in-progress':
        return <Clock className="w-5 h-5 text-amber-600" />;
      case 'blocked':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Circle className="w-5 h-5 text-slate-300" />;
    }
  };

  const getStepColor = (step: WorkflowStep) => {
    switch (step.status) {
      case 'completed':
        return 'border-emerald-600 bg-emerald-50';
      case 'in-progress':
        return 'border-amber-600 bg-amber-50';
      case 'blocked':
        return 'border-red-600 bg-red-50';
      default:
        return 'border-slate-200 bg-white';
    }
  };

  const getStepTextColor = (step: WorkflowStep) => {
    switch (step.status) {
      case 'completed':
        return 'text-emerald-900';
      case 'in-progress':
        return 'text-amber-900';
      case 'blocked':
        return 'text-red-900';
      default:
        return 'text-slate-400';
    }
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        {workflow.steps.map((step, index) => (
          <div key={step.phase} className="flex items-center">
            <div
              className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${getStepColor(
                step
              )}`}
              title={step.phase}
            >
              {step.status === 'completed' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              ) : step.status === 'in-progress' ? (
                <Clock className="w-4 h-4 text-amber-600" />
              ) : (
                <div className="w-2 h-2 rounded-full bg-slate-300" />
              )}
            </div>
            {index < workflow.steps.length - 1 && (
              <div
                className={`w-6 h-0.5 ${
                  step.status === 'completed' ? 'bg-emerald-600' : 'bg-slate-200'
                }`}
              />
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="mb-6">
        <h3 className="text-sm font-semibold text-slate-900 mb-1">Workflow Progress</h3>
        <p className="text-xs text-slate-600">
          Current Phase: <span className={`font-medium ${workflow.isReopened ? 'text-red-600' : 'text-everest-blue'}`}>{workflow.currentPhase}{workflow.isReopened ? ' (Reopened)' : ''}</span>
        </p>
      </div>

      {/* Reopened Banner */}
      {workflow.isReopened && (
        <div className="mb-4 px-3 py-2 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <RotateCcw className="w-4 h-4 text-red-600" />
          <span className="text-xs text-red-700 font-medium">This event has been reopened — lifecycle restarted at Monitoring (Phases 2-4 reset).</span>
        </div>
      )}

      <div className="space-y-4">
        {workflow.steps.map((step, index) => (
          <div key={step.phase} className="flex items-start gap-4">
            {/* Icon & Connector */}
            <div className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${getStepColor(
                  step
                )}`}
              >
                {getStepIcon(step, index)}
              </div>
              {index < workflow.steps.length - 1 && (
                <div
                  className={`w-0.5 h-12 ${
                    step.status === 'completed' ? 'bg-emerald-600' : 'bg-slate-200'
                  }`}
                />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 pt-1">
              <div className={`font-medium text-sm mb-1 ${getStepTextColor(step)}`}>
                {step.phase}
              </div>
              
              <div className="text-xs text-slate-500 space-y-0.5">
                {step.assignedTo && (
                  <div>Assigned to: {step.assignedTo}</div>
                )}
                {step.completedBy && (
                  <div className="text-emerald-600">
                    ✓ Completed by {step.completedBy}
                  </div>
                )}
                {step.completedAt && (
                  <div className="text-slate-400">
                    {new Date(step.completedAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                )}
                {step.dueDate && step.status !== 'completed' && (
                  <div className={step.status === 'in-progress' ? 'text-amber-600' : ''}>
                    Due: {new Date(step.dueDate).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                )}
              </div>

              {/* Status Badge */}
              <div className="mt-2">
                {step.status === 'completed' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-700">
                    <CheckCircle2 className="w-3 h-3" />
                    Complete
                  </span>
                )}
                {step.status === 'in-progress' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">
                    <Clock className="w-3 h-3" />
                    In Progress
                  </span>
                )}
                {step.status === 'blocked' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-700">
                    <AlertCircle className="w-3 h-3" />
                    Blocked
                  </span>
                )}
                {step.status === 'not-started' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-600">
                    Pending
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}