import { useState } from 'react';
import { CheckCircle2, Eye, Pencil, RotateCcw, ShieldCheck } from 'lucide-react';

// Same data as UsersDirectory
const executiveAreas = [
  'Administration',
  'Cat Modeling',
  'Claims',
  'Finance',
  'Group Underwriting',
  'Facultative',
  'International Treaty',
  'North America Treaty',
  'Product',
  'Financial Lines',
  'Risk Management',
];

const businessUnitsByArea: Record<string, string[]> = {
  'Administration': ['Administration'],
  'Cat Modeling': ['Cat Modeling'],
  'Claims': ['Claims'],
  'Finance': ['Finance'],
  'Group Underwriting': ['Group Underwriting'],
  'Facultative': ['Facultative', 'International Facultative', 'North America Facultative'],
  'International Treaty': ['International Treaty', 'Zurich/Dublin', 'Latam', 'London', 'Middle East', 'Singapore'],
  'North America Treaty': ['North America Treaty', 'Bermuda', 'Canada', 'Treaty Casualty', 'Treaty Property'],
  'Product': ['Product', 'Aviation', 'Cyber', 'Engineering', 'Marine', 'Parametric', 'Energy'],
  'Financial Lines': ['Financial Lines', 'Financial', 'Mortgage'],
  'Risk Management': ['Risk Management'],
};

const teams = ['Admin', 'CAT', 'Claim', 'Finance', 'Management', 'Underwriting'];

const roles = [
  'Administrator',
  'Business Unit Lead',
  'CAT Contributor',
  'Event Coordinator',
  'Executive Area Lead',
  'Finance Contributor',
  'Reader',
  'UW Contributor',
];

const accessLevels = ['Admin', 'Contributor', 'Reader'];

// Mapping: Executive Area → default Team, Role, Access
const defaultsByArea: Record<string, { team: string; role: string; access: string }> = {
  'Administration':     { team: 'Admin',         role: 'Administrator',       access: 'Admin' },
  'Cat Modeling':        { team: 'CAT',          role: 'CAT Contributor',     access: 'Contributor' },
  'Claims':             { team: 'Claims Cordinator',         role: 'Event Coordinator',   access: 'Contributor' },
  'Finance':            { team: 'Finance',       role: 'Finance Contributor', access: 'Contributor' },
  'Group Underwriting': { team: 'Management',    role: 'Reader',              access: 'Reader' },
  'Facultative':        { team: 'Underwriting',  role: 'UW Contributor',      access: 'Contributor' },
  'International Treaty':{ team: 'Underwriting', role: 'UW Contributor',      access: 'Contributor' },
  'North America Treaty':{ team: 'Underwriting', role: 'UW Contributor',      access: 'Contributor' },
  'Product':          { team: 'Underwriting',  role: 'UW Contributor',      access: 'Contributor' },
  'Financial Lines':    { team: 'Underwriting',  role: 'UW Contributor',      access: 'Contributor' },
  'Risk Management':    { team: 'Management',   role: 'UW Contributor',      access: 'Contributor' },
};

// Mapping: Role → Access level (deterministic)
const roleToAccess: Record<string, string> = {
  'Administrator': 'Admin',
  'Event Coordinator': 'Contributor',
  'Finance Contributor': 'Contributor',
  'CAT Contributor': 'Contributor',
  'UW Contributor': 'Contributor',
  'Business Unit Lead': 'Contributor',
  'Executive Area Lead': 'Contributor',
  'Reader': 'Reader',
};

// Detailed permission matrix per role
interface RolePermissionDetail {
  description: string;
  readAccess: string[];
  editPermissions: string[];
  lifecycle: string[];
  approval: string[];
}

const rolePermissions: Record<string, RolePermissionDetail> = {
  'Administrator': {
    description: 'Full system access. Read/edit all modules and units. Global admin override, emergency unlock/lock.',
    readAccess: ['All Priorities', 'All Units', 'All Modules'],
    editPermissions: ['Finance Module', 'CAT Module', 'UW Module', 'Overview'],
    lifecycle: ['Lock Estimates', 'Unlock Estimates', 'Reopen Estimates'],
    approval: ['Approve Estimates', 'Admin Override', 'Emergency Controls'],
  },
  'Event Coordinator': {
    description: 'Creates/publishes events. Sets monitoring or tracking mode. Assigns participants, enters Operational Summary, closes events.',
    readAccess: ['All Priorities', 'All Units', 'Claims/Event Modules'],
    editPermissions: ['Finance Module', 'CAT Module', 'UW Module'],
    lifecycle: ['Lock Estimates', 'Reopen Estimates'],
    approval: [],
  },
  'Finance Contributor': {
    description: 'All units (read). Edits Finance & UW modules. Locks/reopens estimates. Completes reserving extract.',
    readAccess: ['All Priorities', 'All Units', 'Overview/Finance Modules'],
    editPermissions: ['Finance Module', 'UW Module'],
    lifecycle: ['Lock Estimates', 'Reopen Estimates'],
    approval: [],
  },
  'CAT Contributor': {
    description: 'All units (read). Edits CAT and Finance modules. Performs event footprint/severity assessment. Locks/unlocks CAT data.',
    readAccess: ['All Priorities', 'All Units', 'All Modules (read-only)'],
    editPermissions: ['CAT Module', 'Finance Module'],
    lifecycle: ['Lock CAT'],
    approval: [],
  },
  'Business Unit Lead': {
    description: 'Scoped to own Business Unit only. Read-only view of own BU data across all modules. Assigns tasks, approves estimates within own BU scope.',
    readAccess: ['Own Business Unit', 'All Modules (own BU)'],
    editPermissions: ['UW Module (own BU)'],
    lifecycle: ['Reopen Estimates (own BU)'],
    approval: ['Approve Estimates (own BU)'],
  },
  'Executive Area Lead': {
    description: 'Reads across all Business Units and all modules within own Executive Area. Assigns tasks, approves estimates scoped to own Executive Area domain. Largest role group (24 users).',
    readAccess: ['All BUs within Executive Area', 'All Modules'],
    editPermissions: ['UW Module (own Executive Area)'],
    lifecycle: ['Reopen Estimates (own Executive Area)'],
    approval: ['Approve Estimates (own Executive Area)'],
  },
  'UW Contributor': {
    description: 'Scoped to Business Unit & Profit Center. Reads own units. Uploads UW data and enters exposure estimates. Cannot lock, reopen, or approve.',
    readAccess: ['Own Unit(s)', 'UW Module'],
    editPermissions: ['UW Module'],
    lifecycle: [],
    approval: [],
  },
  'Reader': {
    description: 'View-only access across all modules and business units. No edit, task, lock, or approval capability. Senior management oversight.',
    readAccess: ['All Priorities', 'All Units', 'All Modules'],
    editPermissions: [],
    lifecycle: [],
    approval: [],
  },
};

// Mapping: (Team, Role) → possible Executive Areas
const teamRoleToExecAreas: Record<string, Record<string, string[]>> = {
  'Admin': {
    'Administrator': ['Administration'],
  },
  'CAT': {
    'CAT Contributor': ['Cat Modeling'],
  },
  'Claim': {
    'Event Coordinator': ['Claims'],
  },
  'Finance': {
    'Finance Contributor': ['Finance'],
  },
  'Management': {
    'Reader': ['Group Underwriting'],
    'Executive Area Lead': ['Group Underwriting', 'Risk Management'],
    'UW Contributor': ['Risk Management'],
  },
  'Underwriting': {
    'Business Unit Lead': ['Facultative', 'International Treaty', 'North America Treaty', 'Product', 'Financial Lines'],
    'Executive Area Lead': ['Facultative', 'International Treaty', 'North America Treaty', 'Product', 'Financial Lines'],
    'UW Contributor': ['Facultative', 'International Treaty', 'North America Treaty', 'Product', 'Financial Lines'],
  },
};

const teamRoleMap: Record<string, string[]> = {
  'Admin': ['Administrator'],
  'CAT': ['CAT Contributor'],
  'Claim': ['Event Coordinator'],
  'Finance': ['Finance Contributor'],
  'Management': ['Reader', 'Executive Area Lead', 'UW Contributor'],
  'Underwriting': ['Executive Area Lead', 'Business Unit Lead', 'UW Contributor'],
};

interface SailPointAccessFormProps {
  onSubmitSuccess?: () => void;
}

// Mock AD directory — all users in the single SONAR_Platform_Users AD group
const adUsers = [
  { name: 'David Chen', email: 'david.chen@everestre.com', department: 'Administration' },
  { name: 'Neil Schwarzenberger', email: 'neil.schwarzenberger@everestre.com', department: 'Cat Modeling' },
  { name: 'Huy Hong', email: 'huy.hong@everestre.com', department: 'Cat Modeling' },
  { name: 'Andrew McBride', email: 'andrew.mcbride@everestre.com', department: 'Claims' },
  { name: 'Lope Garcia', email: 'lope.garcia@everestre.com', department: 'Claims' },
  { name: 'Tim Carter', email: 'tim.carter@everestre.com', department: 'Claims' },
  { name: 'James Parker', email: 'james.parker@everestre.com', department: 'Claims' },
  { name: 'Barbara Toro', email: 'barbara.toro@everestre.com', department: 'Claims' },
  { name: 'Patricia McMahon', email: 'patricia.mcmahon@everestre.com', department: 'Claims' },
  { name: 'Clem Demetz', email: 'clem.demetz@everestre.com', department: 'Finance' },
  { name: 'Nigel Smith', email: 'nigel.smith@everestre.com', department: 'Finance' },
  { name: 'Tim Ritter', email: 'tim.ritter@everestre.com', department: 'Finance' },
  { name: 'Reena Boltax', email: 'reena.boltax@everestre.com', department: 'Group Underwriting' },
  { name: 'Chris Downey', email: 'chris.downey@everestre.com', department: 'Group Underwriting' },
  { name: 'Jill Beggs', email: 'jill.beggs@everestre.com', department: 'Group Underwriting' },
  { name: 'Mike Cellura', email: 'mike.cellura@everestre.com', department: 'Facultative' },
  { name: 'Juan Delgado', email: 'juan.delgado@everestre.com', department: 'Facultative' },
  { name: 'Leo Fernandez', email: 'leo.fernandez@everestre.com', department: 'Facultative' },
  { name: 'Nicholas Pozzebon', email: 'nicholas.pozzebon@everestre.com', department: 'Facultative' },
  { name: 'Derek Hollis', email: 'derek.hollis@everestre.com', department: 'Facultative' },
  { name: 'Artur Klinger', email: 'artur.klinger@everestre.com', department: 'International Treaty' },
  { name: 'Harad Jacobsen', email: 'harad.jacobsen@everestre.com', department: 'International Treaty' },
  { name: 'Rui Marliere', email: 'rui.marliere@everestre.com', department: 'International Treaty' },
  { name: 'Mark Wallace', email: 'mark.wallace@everestre.com', department: 'International Treaty' },
  { name: 'Melissa Ford', email: 'melissa.ford@everestre.com', department: 'International Treaty' },
  { name: 'Kevin Bogardus', email: 'kevin.bogardus@everestre.com', department: 'International Treaty' },
  { name: 'Thomas Brennan', email: 'thomas.brennan@everestre.com', department: 'International Treaty' },
  { name: 'Jiten Voralia', email: 'jiten.voralia@everestre.com', department: 'North America Treaty' },
  { name: 'Peter Bell', email: 'peter.bell@everestre.com', department: 'North America Treaty' },
  { name: 'Scott Paddington', email: 'scott.paddington@everestre.com', department: 'North America Treaty' },
  { name: 'Mayur Doshi', email: 'mayur.doshi@everestre.com', department: 'North America Treaty' },
  { name: 'Chuck Volker', email: 'chuck.volker@everestre.com', department: 'North America Treaty' },
  { name: 'Sarah Lindqvist', email: 'sarah.lindqvist@everestre.com', department: 'North America Treaty' },
  { name: 'Emily Davis', email: 'emily.davis@everestre.com', department: 'Product' },
  { name: 'Tim Hewer', email: 'tim.hewer@everestre.com', department: 'Product' },
  { name: 'Wesley Zeliff', email: 'wesley.zeliff@everestre.com', department: 'Product' },
  { name: 'Erick Davidson', email: 'erick.davidson@everestre.com', department: 'Product' },
  { name: 'Daniel Okoro', email: 'daniel.okoro@everestre.com', department: 'Product' },
  { name: 'Karen Whitfield', email: 'karen.whitfield@everestre.com', department: 'Product' },
  { name: 'Levi Mayer', email: 'levi.mayer@everestre.com', department: 'Financial Lines' },
  { name: 'Greg Patel', email: 'greg.patel@everestre.com', department: 'Financial Lines' },
  { name: 'Atilla Kerenyi', email: 'atilla.kerenyi@everestre.com', department: 'Risk Management' },
  { name: 'Nick Dimuzio', email: 'nick.dimuzio@everestre.com', department: 'Risk Management' },
  { name: 'Kathy Garrigan', email: 'kathy.garrigan@everestre.com', department: 'Risk Management' },
  { name: 'Monica Ivanova', email: 'monica.ivanova@everestre.com', department: 'Risk Management' },
  // New users not yet onboarded
  { name: 'Robert Tanaka', email: 'robert.tanaka@everestre.com', department: 'Underwriting' },
  { name: 'Lisa Chang', email: 'lisa.chang@everestre.com', department: 'Finance' },
  { name: 'Marcus Williams', email: 'marcus.williams@everestre.com', department: 'Claims' },
  { name: 'Sofia Rodriguez', email: 'sofia.rodriguez@everestre.com', department: 'Product' },
  { name: 'Ahmed Hassan', email: 'ahmed.hassan@everestre.com', department: 'International Treaty' },
];

export function SailPointAccessForm({ onSubmitSuccess }: SailPointAccessFormProps) {
  const [userName, setUserName] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [selectedExecAreas, setSelectedExecAreas] = useState<string[]>([]);
  const [selectedBUs, setSelectedBUs] = useState<string[]>([]);
  const [team, setTeam] = useState('');
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [access, setAccess] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [rolesDropdownOpen, setRolesDropdownOpen] = useState(false);
  const [execAreaDropdownOpen, setExecAreaDropdownOpen] = useState(false);
  const [buDropdownOpen, setBuDropdownOpen] = useState(false);

  // Determine if the highest-privilege selected role has cross-BU access
  const hasExecAreaScope = selectedRoles.includes('Executive Area Lead');
  const isSingleBURole = selectedRoles.length > 0 && !hasExecAreaScope && 
    (selectedRoles.includes('Business Unit Lead') || selectedRoles.includes('UW Contributor'));

  // Collect all BUs across all selected exec areas
  const availableBUs = (() => {
    const bus = new Set<string>();
    for (const ea of selectedExecAreas) {
      const areaBUs = businessUnitsByArea[ea] || [];
      if (hasExecAreaScope) {
        // Executive Area Lead sees ALL BUs within the exec area
        areaBUs.forEach(bu => bus.add(bu));
      } else {
        // BU Lead & UW Contributor only see individual BUs (not the parent area name)
        areaBUs.forEach(bu => {
          if (bu !== ea) bus.add(bu); // exclude the parent exec area entry
        });
        // If no sub-BUs exist (e.g., Facultative), show the area itself
        if (areaBUs.length === 1 && areaBUs[0] === ea) bus.add(ea);
      }
    }
    return Array.from(bus);
  })();

  // Compute available exec areas based on team + role selections (for UI filtering)
  const availableExecAreas = (() => {
    if (!team || selectedRoles.length === 0) return [] as string[];
    const areas = new Set<string>();
    for (const role of selectedRoles) {
      const possibleAreas = teamRoleToExecAreas[team]?.[role];
      if (possibleAreas) possibleAreas.forEach(a => areas.add(a));
    }
    return Array.from(areas);
  })();

  // Helper: given a team and roles, compute downstream defaults
  const computeDownstream = (teamVal: string, newRoles: string[]) => {
    // Access: highest-privilege role
    let accessVal = '';
    if (newRoles.length > 0) {
      const accessPriority = ['Admin', 'Contributor', 'Reader'];
      let bestAccess = 'Reader';
      for (const r of newRoles) {
        const a = roleToAccess[r] || 'Reader';
        if (accessPriority.indexOf(a) < accessPriority.indexOf(bestAccess)) {
          bestAccess = a;
        }
      }
      accessVal = bestAccess;
    }

    // Exec area: collect all possible areas for team + roles
    const areas = new Set<string>();
    for (const r of newRoles) {
      const possibleAreas = teamRoleToExecAreas[teamVal]?.[r];
      if (possibleAreas) possibleAreas.forEach(a => areas.add(a));
    }
    const areaList = Array.from(areas);

    // Default: if only 1 exec area, auto-select it; otherwise select all
    let execAreaVals: string[] = [];
    let buVals: string[] = [];
    if (areaList.length === 1) {
      execAreaVals = [areaList[0]];
      const areaBUs = businessUnitsByArea[areaList[0]] || [];
      buVals = areaBUs.length > 0 ? [areaBUs[0]] : [];
    } else if (areaList.length === 0) {
      execAreaVals = [];
      buVals = [];
    }
    // For multiple areas, leave empty so user picks

    return { accessVal, execAreaVals, buVals };
  };

  const toggleRole = (role: string) => {
    let newRoles: string[];
    if (selectedRoles.includes(role)) {
      newRoles = selectedRoles.filter(r => r !== role);
    } else {
      newRoles = [...selectedRoles, role];
    }
    setSelectedRoles(newRoles);

    const { accessVal, execAreaVals, buVals } = computeDownstream(team, newRoles);
    setAccess(accessVal);
    setSelectedExecAreas(execAreaVals);
    setSelectedBUs(buVals);
  };

  const handleTeamChange = (val: string) => {
    setTeam(val);
    if (!val) {
      setSelectedRoles([]);
      setSelectedExecAreas([]);
      setSelectedBUs([]);
      setAccess('');
      return;
    }

    // Get available roles for this team and default to the first one
    const availRoles = teamRoleMap[val] || [];
    const defaultRole = availRoles[0] || '';
    const defaultRoles = defaultRole ? [defaultRole] : [];
    setSelectedRoles(defaultRoles);

    const { accessVal, execAreaVals, buVals } = computeDownstream(val, defaultRoles);
    setAccess(accessVal);
    setSelectedExecAreas(execAreaVals);
    setSelectedBUs(buVals);
  };

  const toggleExecArea = (ea: string) => {
    let newAreas: string[];
    if (isSingleBURole) {
      // BU Lead & UW Contributor: single exec area selection
      newAreas = selectedExecAreas.includes(ea) ? [] : [ea];
    } else if (selectedExecAreas.includes(ea)) {
      newAreas = selectedExecAreas.filter(a => a !== ea);
    } else {
      newAreas = [...selectedExecAreas, ea];
    }
    setSelectedExecAreas(newAreas);

    // Auto-default BUs based on role scope
    if (hasExecAreaScope) {
      // Executive Area Lead: auto-select ALL BUs within each selected area
      const newBUs = new Set<string>();
      for (const area of newAreas) {
        const areaBUs = businessUnitsByArea[area] || [];
        areaBUs.forEach(bu => newBUs.add(bu));
      }
      setSelectedBUs(Array.from(newBUs));
    } else {
      // BU Lead & UW Contributor: clear BUs so user picks one
      setSelectedBUs([]);
    }
  };

  const toggleBU = (bu: string) => {
    if (isSingleBURole) {
      // BU Lead & UW Contributor: single BU selection (radio behavior)
      setSelectedBUs(selectedBUs.includes(bu) ? [] : [bu]);
    } else if (selectedBUs.includes(bu)) {
      setSelectedBUs(selectedBUs.filter(b => b !== bu));
    } else {
      setSelectedBUs([...selectedBUs, bu]);
    }
  };

  const handleSubmit = () => {
    setSubmitted(true);
    if (onSubmitSuccess) {
      // Brief delay so user sees the submission, then navigate to Users
      setTimeout(() => {
        onSubmitSuccess();
        handleReset();
      }, 1200);
    }
  };

  const handleReset = () => {
    setUserName('');
    setUserSearch('');
    setSelectedExecAreas([]);
    setSelectedBUs([]);
    setTeam('');
    setSelectedRoles([]);
    setAccess('');
    setIsAdmin(false);
    setSubmitted(false);
  };

  const canSubmit = userName && team && selectedRoles.length > 0;

  // Merge permissions from all selected roles
  const mergedPermissions = (() => {
    const merged: RolePermissionDetail = {
      description: '',
      readAccess: [],
      editPermissions: [],
      lifecycle: [],
      approval: [],
    };
    const readSet = new Set<string>();
    const editSet = new Set<string>();
    const lifeSet = new Set<string>();
    const approveSet = new Set<string>();
    for (const r of selectedRoles) {
      const p = rolePermissions[r];
      if (p) {
        p.readAccess.forEach(x => readSet.add(x));
        p.editPermissions.forEach(x => editSet.add(x));
        p.lifecycle.forEach(x => lifeSet.add(x));
        p.approval.forEach(x => approveSet.add(x));
      }
    }
    merged.readAccess = Array.from(readSet);
    merged.editPermissions = Array.from(editSet);
    merged.lifecycle = Array.from(lifeSet);
    merged.approval = Array.from(approveSet);
    return merged;
  })();

  if (submitted) {
    return (
      <div className="flex flex-col h-full">
        <div className="px-8 py-6 border-b border-slate-200 bg-white">
          <h1 className="text-2xl font-semibold text-slate-900">User On-Boarding</h1>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Access Request Submitted</h3>
            <p className="text-sm text-slate-500 mb-1">User: <span className="font-medium text-slate-700">{userName}</span></p>
            <p className="text-sm text-slate-500 mb-1">Team: <span className="font-medium text-slate-700">{team}</span></p>
            <p className="text-sm text-slate-500 mb-4">
              Roles: <span className="font-medium text-slate-700">{selectedRoles.join(', ')}</span>
            </p>
            <button
              onClick={handleReset}
              className="px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              Submit Another Request
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-8 py-6 border-b border-slate-200 bg-white">
        <h1 className="text-2xl font-semibold text-slate-900">User On-Boarding</h1>
      </div>

      {/* Form */}
      <div className="flex-1 overflow-auto bg-white px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="border border-slate-300 rounded-lg overflow-visible">
            {/* Title bar */}
            <div className="bg-slate-100 border-b border-slate-300 px-6 py-3">
              <span className="text-sm font-semibold text-slate-800">User On-Boarding</span>
              <p className="text-xs text-slate-500 mt-0.5">Assign team &amp; role for a new SONAR user from the AD group</p>
            </div>

            {/* Form rows */}
            <div className="divide-y divide-slate-200">

              {/* Step 1: AD Group — single group, locked */}
              <div className="px-6 py-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center flex-shrink-0">1</span>
                  <span className="text-sm font-semibold text-slate-800">AD Group</span>
                </div>
                <div className="ml-8">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 max-w-sm px-3 py-2 bg-slate-50 border border-slate-200 rounded text-sm text-slate-700 flex items-center gap-2">
                      <svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                      <span>SONAR_Platform_Users</span>
                    </div>
                    <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Single AD Group
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1.5">All SONAR users belong to this AD group. Team &amp; role are assigned within SONAR.</p>
                </div>
              </div>

              {/* Step 2: User */}
              <div className="px-6 py-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`w-6 h-6 rounded-full text-xs flex items-center justify-center flex-shrink-0 ${userName ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>2</span>
                  <span className="text-sm font-semibold text-slate-800">User</span>
                  {userName && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      {userName}
                    </span>
                  )}
                </div>
                <div className="ml-8 relative">
                  {/* Selected user display */}
                  {userName && !userDropdownOpen ? (
                    <div className="flex items-center gap-2 max-w-sm">
                      <div className="flex-1 px-3 py-2 bg-blue-50 border border-blue-200 rounded text-sm text-blue-800 flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center flex-shrink-0">
                          {userName.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="block truncate">{userName}</span>
                          <span className="text-[10px] text-blue-500">{adUsers.find(u => u.name === userName)?.email || ''}</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => { setUserName(''); setUserSearch(''); setUserDropdownOpen(true); }}
                        className="text-xs text-slate-500 hover:text-red-500 px-2 py-1 border border-slate-200 rounded hover:border-red-200 transition-colors"
                      >
                        Change
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="relative max-w-sm">
                        <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        <input
                          type="text"
                          value={userSearch}
                          onChange={e => { setUserSearch(e.target.value); setUserDropdownOpen(true); }}
                          onFocus={() => setUserDropdownOpen(true)}
                          placeholder="Search AD users by name…"
                          className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      {/* Dropdown list */}
                      {userDropdownOpen && (
                        <>
                          <div className="fixed inset-0 z-10" onClick={() => setUserDropdownOpen(false)} />
                          <div className="absolute z-20 mt-1 w-full max-w-sm bg-white border border-slate-300 rounded-lg shadow-lg max-h-64 overflow-y-auto">
                            {(() => {
                              const query = userSearch.toLowerCase().trim();
                              const filtered = query
                                ? adUsers.filter(u => u.name.toLowerCase().includes(query) || u.email.toLowerCase().includes(query) || u.department.toLowerCase().includes(query))
                                : adUsers;

                              if (filtered.length === 0) {
                                return (
                                  <div className="px-3 py-4 text-center text-sm text-slate-400">
                                    No users found matching "{userSearch}"
                                  </div>
                                );
                              }

                              return filtered.map(user => (
                                <button
                                  key={user.email}
                                  type="button"
                                  onClick={() => {
                                    setUserName(user.name);
                                    setUserSearch(user.name);
                                    setUserDropdownOpen(false);
                                  }}
                                  className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-blue-50 text-left transition-colors"
                                >
                                  <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-600 text-[10px] flex items-center justify-center flex-shrink-0">
                                    {user.name.split(' ').map(n => n[0]).join('')}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <span className="text-sm text-slate-800 block truncate">{user.name}</span>
                                    <span className="text-[10px] text-slate-400 block truncate">{user.email}</span>
                                  </div>
                                </button>
                              ));
                            })()}
                          </div>
                        </>
                      )}
                    </>
                  )}
                  <p className="text-[11px] text-slate-400 mt-1.5">
                    {adUsers.length} users in SONAR_Platform_Users AD group
                  </p>
                </div>
              </div>

              {/* Step 3: Assign Team */}
              <div className="px-6 py-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`w-6 h-6 rounded-full text-xs flex items-center justify-center flex-shrink-0 ${team ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>3</span>
                  <span className="text-sm font-semibold text-slate-800">Assign Team</span>
                </div>
                <div className="ml-8">
                  <div className="grid grid-cols-3 gap-2 max-w-md">
                    {teams.map(t => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => handleTeamChange(t === team ? '' : t)}
                        className={`px-3 py-2 rounded-lg border text-sm transition-all ${
                          team === t
                            ? 'bg-blue-50 border-blue-400 text-blue-700 ring-2 ring-blue-200'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {t === 'Claim' ? 'Claims Coordinator' : t}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-2">Select one team. This determines available roles.</p>
                </div>
              </div>

              {/* Step 4: Assign Role */}
              <div className="px-6 py-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`w-6 h-6 rounded-full text-xs flex items-center justify-center flex-shrink-0 ${selectedRoles.length > 0 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>4</span>
                  <span className="text-sm font-semibold text-slate-800">Assign Role</span>
                  {selectedRoles.length > 0 && (
                    <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full">{selectedRoles.length} selected</span>
                  )}
                </div>
                <div className="ml-8">
                  {!team ? (
                    <p className="text-sm text-slate-400 italic">Select a team first</p>
                  ) : (
                    <div className="space-y-2 max-w-2xl">
                      {(teamRoleMap[team] || []).filter(role => team !== 'Management' || (role !== 'Executive Area Lead' && role !== 'UW Contributor')).map(role => {
                        const perms = rolePermissions[role];
                        const isSelected = selectedRoles.includes(role);
                        return (
                          <label
                            key={role}
                            className={`block px-4 py-3 rounded-lg border cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-200'
                                : 'bg-white border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => toggleRole(role)}
                                className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 mt-0.5"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-sm text-slate-800">{role}</span>
                                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                                    roleToAccess[role] === 'Admin' ? 'bg-red-100 text-red-600' :
                                    roleToAccess[role] === 'Contributor' ? 'bg-blue-100 text-blue-600' :
                                    'bg-slate-100 text-slate-500'
                                  }`}>
                                    {roleToAccess[role] || 'Reader'}
                                  </span>
                                </div>
                                {perms && (() => {
                                  // Management/Reader inherits Finance Contributor + Event Coordinator permissions
                                  const displayPerms = (team === 'Management' && role === 'Reader')
                                    ? {
                                        readAccess: ['All Priorities', 'All Units', 'All Modules'],
                                        editPermissions: ['Finance Module'],
                                        lifecycle: ['Lock Estimates', 'Reopen Estimates'],
                                        approval: [],
                                      }
                                    : perms;
                                  return (
                                  <div className={`grid grid-cols-4 gap-2 rounded-lg border p-2.5 ${isSelected ? 'bg-white border-blue-200' : 'bg-slate-50 border-slate-200'}`}>
                                    {/* Read Access */}
                                    <div>
                                      <div className="flex items-center gap-1 mb-1.5">
                                        <Eye className="w-3 h-3 text-emerald-500" />
                                        <span className="text-[10px] font-semibold text-slate-600 uppercase tracking-wider">Read</span>
                                      </div>
                                      {displayPerms.readAccess.length > 0 ? displayPerms.readAccess.map(p => (
                                        <span key={p} className="block text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-1.5 py-0.5 mb-0.5">{p}</span>
                                      )) : (
                                        <span className="text-[10px] text-slate-300 italic">None</span>
                                      )}
                                    </div>
                                    {/* Edit Permissions */}
                                    <div>
                                      <div className="flex items-center gap-1 mb-1.5">
                                        <Pencil className="w-3 h-3 text-blue-500" />
                                        <span className="text-[10px] font-semibold text-slate-600 uppercase tracking-wider">Edit</span>
                                      </div>
                                      {displayPerms.editPermissions.length > 0 ? displayPerms.editPermissions.map(p => (
                                        <span key={p} className="block text-[10px] text-blue-700 bg-blue-50 border border-blue-200 rounded px-1.5 py-0.5 mb-0.5">{p}</span>
                                      )) : (
                                        <span className="text-[10px] text-slate-300 italic">None</span>
                                      )}
                                    </div>
                                    {/* Lifecycle */}
                                    <div>
                                      <div className="flex items-center gap-1 mb-1.5">
                                        <RotateCcw className="w-3 h-3 text-amber-500" />
                                        <span className="text-[10px] font-semibold text-slate-600 uppercase tracking-wider">Lifecycle</span>
                                      </div>
                                      {displayPerms.lifecycle.length > 0 ? displayPerms.lifecycle.map(p => (
                                        <span key={p} className="block text-[10px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5 mb-0.5">{p}</span>
                                      )) : (
                                        <span className="text-[10px] text-slate-300 italic">None</span>
                                      )}
                                    </div>
                                    {/* Approval */}
                                    <div>
                                      <div className="flex items-center gap-1 mb-1.5">
                                        <ShieldCheck className="w-3 h-3 text-purple-500" />
                                        <span className="text-[10px] font-semibold text-slate-600 uppercase tracking-wider">Approval</span>
                                      </div>
                                      {displayPerms.approval.length > 0 ? displayPerms.approval.map(p => (
                                        <span key={p} className="block text-[10px] text-purple-700 bg-purple-50 border border-purple-200 rounded px-1.5 py-0.5 mb-0.5">{p}</span>
                                      )) : (
                                        <span className="text-[10px] text-slate-300 italic">None</span>
                                      )}
                                    </div>
                                  </div>
                                  );
                                })()}
                              </div>
                            </div>
                          </label>
                        );
                      })}
                      <p className="text-[11px] text-slate-400 mt-1">One or multiple roles can be assigned.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Auto-Derived Summary with merged permission view */}
              {team && selectedRoles.length > 0 && (
                <div className="px-6 py-4 bg-slate-50">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-white text-xs flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-sm font-semibold text-slate-800">Scope &amp; Overrides</span>
                  </div>
                  <div className="ml-8 space-y-3">
                    {/* Executive Area */}
                    <div className="flex items-start gap-3">
                      <span className="text-sm text-slate-500 w-32 flex-shrink-0 pt-0.5">Executive Area</span>
                      <div>
                        <div className="flex flex-wrap gap-1.5">
                          {availableExecAreas.length > 0 ? availableExecAreas.map(ea => (
                            <label
                              key={ea}
                              className={`flex items-center gap-1.5 px-2 py-1 rounded border text-xs cursor-pointer transition-all ${
                                selectedExecAreas.includes(ea)
                                  ? 'bg-blue-50 border-blue-300 text-blue-700'
                                  : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                              }`}
                            >
                              <input
                                type={isSingleBURole ? 'radio' : 'checkbox'}
                                name={isSingleBURole ? 'execArea' : undefined}
                                checked={selectedExecAreas.includes(ea)}
                                onChange={() => toggleExecArea(ea)}
                                className="w-3 h-3 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                              />
                              {ea === 'Claim' ? 'Claims' : ea}
                            </label>
                          )) : (
                            <span className="text-xs text-slate-400 italic">Auto-populated from Team &amp; Role</span>
                          )}
                        </div>
                        {isSingleBURole && (
                          <p className="text-[10px] text-amber-600 mt-1">Single area — {selectedRoles.includes('Business Unit Lead') ? 'Business Unit Lead' : 'UW Contributor'} is scoped to one Executive Area</p>
                        )}
                        {hasExecAreaScope && (
                          <p className="text-[10px] text-blue-600 mt-1">Cross-BU read — Executive Area Lead can select multiple areas</p>
                        )}
                      </div>
                    </div>

                    {/* Business Units */}
                    {selectedExecAreas.length > 0 && (
                      <div className="flex items-start gap-3">
                        <span className="text-sm text-slate-500 w-32 flex-shrink-0 pt-0.5">Business Unit{isSingleBURole ? '' : 's'}</span>
                        <div>
                          <div className="flex flex-wrap gap-1.5">
                            {availableBUs.length > 0 ? availableBUs.map(bu => (
                              selectedExecAreas.includes(bu) ? null : (
                               <label
                                 key={bu}
                                 className={`flex items-center gap-1.5 px-2 py-1 rounded border text-xs cursor-pointer transition-all ${
                                   selectedBUs.includes(bu)
                                     ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                                     : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                                 }`}
                               >
                                 <input
                                   type={isSingleBURole ? 'radio' : 'checkbox'}
                                   name={isSingleBURole ? 'businessUnit' : undefined}
                                   checked={selectedBUs.includes(bu)}
                                   onChange={() => toggleBU(bu)}
                                   className="w-3 h-3 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                                 />
                                 {bu}
                               </label>
                              )
                            )) : (
                              <span className="text-xs text-slate-400 italic">Select executive area first</span>
                            )}
                          </div>
                          {isSingleBURole && availableBUs.length > 0 && (
                            <p className="text-[10px] text-amber-600 mt-1">Assign to one Business Unit only</p>
                          )}
                          {hasExecAreaScope && availableBUs.length > 0 && (
                            <p className="text-[10px] text-blue-600 mt-1">All BUs within area are accessible — multi-select enabled</p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Admin flag */}
                    <div className="flex items-center gap-3 pt-1 border-t border-slate-200">
                      <span className="text-sm text-slate-500 w-32 flex-shrink-0">Admin Override</span>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isAdmin}
                          onChange={e => setIsAdmin(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-xs text-slate-500">Grant admin privileges</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Submit */}
          <div className="mt-6 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              {canSubmit ? (
                <span className="text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Ready to submit
                </span>
              ) : (
                <span>Complete steps 2–4 to submit</span>
              )}
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleReset}
                className="px-5 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Reset
              </button>
              <button
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                On-Board User
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}