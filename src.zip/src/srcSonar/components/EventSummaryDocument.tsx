interface EventSummaryDocumentProps {
  eventData: any;
}

export function EventSummaryDocument({ eventData }: EventSummaryDocumentProps) {
  const formatDate = (date: string) => {
    if (!date) return 'Not specified';
    return new Date(date).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    });
  };

  const formatDateTime = (date: string) => {
    if (!date) return 'TBD';
    return new Date(date).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Map team names to leaders
  const getTeamLeader = (teamName: string) => {
    const leaders: { [key: string]: { name: string; email: string } } = {
      'Underwriting': { name: 'Group Underwriting Team', email: 'underwriting@everestre.com' },
      'Cat Modeling': { name: 'Cat Modeling Team', email: 'catmodeling@everestre.com' },
      'Portfolio Management': { name: 'Portfolio Management Team', email: 'portfoliomgmt@everestre.com' },
      'Claims': { name: 'Claims Team', email: 'claims@everestre.com' },
      'Finance': { name: 'Finance Team', email: 'finance@everestre.com' },
      'Actuarial': { name: 'Actuarial Team', email: 'actuarial@everestre.com' },
      'Risk Management': { name: 'Risk Management Team', email: 'riskmgmt@everestre.com' }
    };
    return leaders[teamName] || { name: 'TBD', email: 'tbd@everestre.com' };
  };

  return (
    <div id="event-summary-document" style={{ 
      backgroundColor: '#FFFFFF',
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      color: '#1F2937',
      width: '1200px',
      margin: '0 auto'
    }}>
      
      {/* Header Section */}
      <div style={{ 
        backgroundColor: '#0052FF',
        padding: '40px 48px',
        borderBottom: '1px solid #E5E7EB'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <div style={{ marginBottom: '16px' }}>
              <h1 style={{ 
                fontSize: '32px', 
                fontWeight: '600',
                color: '#FFFFFF',
                margin: '0 0 12px 0',
                lineHeight: '1.2'
              }}>
                {eventData.eventName || 'Large Loss Event'}
              </h1>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <span style={{ 
                  backgroundColor: '#FFFFFF',
                  color: '#0052FF',
                  padding: '4px 12px',
                  fontSize: '13px',
                  fontWeight: '600',
                  border: '1px solid #D1D5DB'
                }}>
                  {eventData.eventId || 'EVT-XXXX-XXX'}
                </span>
                <span style={{ 
                  backgroundColor: eventData.eventType === 'CAT' ? '#7F1D1D' : '#1E3A8A',
                  color: '#FFFFFF',
                  padding: '4px 12px',
                  fontSize: '13px',
                  fontWeight: '600'
                }}>
                  {eventData.eventType || 'CAT'}
                </span>
              </div>
            </div>
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: 'repeat(3, auto)',
              gap: '32px',
              fontSize: '14px',
              color: '#E5E7EB'
            }}>
              <div>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px', opacity: 0.8 }}>
                  Event Date
                </div>
                <div style={{ fontWeight: '500', color: '#FFFFFF' }}>
                  {formatDate(eventData.lossDate)}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px', opacity: 0.8 }}>
                  Region
                </div>
                <div style={{ fontWeight: '500', color: '#FFFFFF' }}>
                  {eventData.region || 'Not specified'}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px', opacity: 0.8 }}>
                  Primary Peril
                </div>
                <div style={{ fontWeight: '500', color: '#FFFFFF' }}>
                  {eventData.peril || 'Not specified'}
                </div>
              </div>
            </div>
          </div>
          
          {/* Market Loss Box */}
          <div style={{ 
            backgroundColor: '#FFFFFF',
            padding: '20px 24px',
            minWidth: '280px',
            border: '1px solid #D1D5DB'
          }}>
            <div style={{ 
              fontSize: '11px', 
              textTransform: 'uppercase', 
              letterSpacing: '0.5px', 
              color: '#6B7280',
              marginBottom: '8px',
              fontWeight: '600'
            }}>
              Current Market Loss Estimate
            </div>
            <div style={{ 
              fontSize: '28px', 
              fontWeight: '600',
              color: '#0052FF',
              marginBottom: '4px'
            }}>
              {eventData.marketLoss || 'TBD'}
            </div>
            {eventData.marketLossSource && (
              <div style={{ fontSize: '12px', color: '#6B7280' }}>
                Source: {eventData.marketLossSource}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Market Loss Alert Panel */}
      {(eventData.marketLossNotes || eventData.trackImmediately) && (
        <div style={{ 
          backgroundColor: '#FFFBEB',
          borderLeft: '3px solid #F59E0B',
          padding: '20px 48px'
        }}>
          <div style={{ 
            fontSize: '13px', 
            fontWeight: '600',
            textTransform: 'uppercase',
            letterSpacing: '0.5px',
            color: '#92400E',
            marginBottom: '8px'
          }}>
            Market Loss Status
          </div>
          {eventData.marketLossNotes && (
            <div style={{ fontSize: '14px', color: '#78350F', lineHeight: '1.5', marginBottom: '12px' }}>
              {eventData.marketLossNotes}
            </div>
          )}
          {eventData.trackImmediately && (
            <div style={{ 
              backgroundColor: '#7F1D1D',
              color: '#FFFFFF',
              padding: '8px 16px',
              fontSize: '13px',
              fontWeight: '600',
              display: 'inline-block',
              marginTop: '8px'
            }}>
              IMMEDIATE TRACKING REQUIRED
            </div>
          )}
        </div>
      )}

      {/* Main Content */}
      <div style={{ padding: '48px' }}>

        {/* Deadline Cards */}
        {(eventData.deadline1 || eventData.deadline2 || eventData.deadline3 || eventData.deadline4) && (
          <div style={{ marginBottom: '48px' }}>
            <h2 style={{ 
              fontSize: '13px', 
              fontWeight: '600',
              color: '#111827',
              marginBottom: '24px',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Critical Deadlines
            </h2>
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '24px'
            }}>
              {eventData.deadline1 && (
                <div style={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #D1D5DB',
                  padding: '24px'
                }}>
                  <div style={{ 
                    fontSize: '11px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#6B7280',
                    marginBottom: '8px',
                    fontWeight: '600'
                  }}>
                    Deadline 1
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '8px' }}>
                    High-Level Exposure Estimates
                  </div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: '#0052FF', marginBottom: '8px' }}>
                    {formatDateTime(eventData.deadline1)}
                  </div>
                  <div style={{ fontSize: '13px', color: '#6B7280', lineHeight: '1.4' }}>
                    Initial portfolio exposure analysis and gross loss estimates
                  </div>
                </div>
              )}
              {eventData.deadline2 && (
                <div style={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #D1D5DB',
                  padding: '24px'
                }}>
                  <div style={{ 
                    fontSize: '11px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#6B7280',
                    marginBottom: '8px',
                    fontWeight: '600'
                  }}>
                    Deadline 2
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '8px' }}>
                    Contract-Level Estimates
                  </div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: '#0052FF', marginBottom: '8px' }}>
                    {formatDateTime(eventData.deadline2)}
                  </div>
                  <div style={{ fontSize: '13px', color: '#6B7280', lineHeight: '1.4' }}>
                    Detailed contract-by-contract loss assessments
                  </div>
                </div>
              )}
              {eventData.deadline3 && (
                <div style={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #D1D5DB',
                  padding: '24px'
                }}>
                  <div style={{ 
                    fontSize: '11px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#6B7280',
                    marginBottom: '8px',
                    fontWeight: '600'
                  }}>
                    Deadline 3
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '8px' }}>
                    Reserving Extract
                  </div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: '#0052FF', marginBottom: '8px' }}>
                    {formatDateTime(eventData.deadline3)}
                  </div>
                  <div style={{ fontSize: '13px', color: '#6B7280', lineHeight: '1.4' }}>
                    Final reserve data for financial reporting
                  </div>
                </div>
              )}
              {eventData.deadline4 && (
                <div style={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #D1D5DB',
                  padding: '24px'
                }}>
                  <div style={{ 
                    fontSize: '11px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#6B7280',
                    marginBottom: '8px',
                    fontWeight: '600'
                  }}>
                    Deadline 4
                  </div>
                  <div style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '8px' }}>
                    CAT Model Run Updates
                  </div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: '#0052FF', marginBottom: '8px' }}>
                    {formatDateTime(eventData.deadline4)}
                  </div>
                  <div style={{ fontSize: '13px', color: '#6B7280', lineHeight: '1.4' }}>
                    Updated model outputs with refined parameters
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Stakeholder Summary */}
        {eventData.functionalTeams?.length > 0 && (
          <div style={{ marginBottom: '48px' }}>
            <h2 style={{ 
              fontSize: '13px', 
              fontWeight: '600',
              color: '#111827',
              marginBottom: '24px',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Stakeholder Summary
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
              {/* Stakeholder Table */}
              <div style={{ 
                backgroundColor: '#F9FAFB',
                border: '1px solid #D1D5DB'
              }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#F3F4F6', borderBottom: '1px solid #D1D5DB' }}>
                      <th style={{ 
                        padding: '12px 16px', 
                        textAlign: 'left',
                        fontSize: '11px',
                        fontWeight: '600',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px',
                        color: '#6B7280'
                      }}>
                        Team
                      </th>
                      <th style={{ 
                        padding: '12px 16px', 
                        textAlign: 'left',
                        fontSize: '11px',
                        fontWeight: '600',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px',
                        color: '#6B7280'
                      }}>
                        Lead
                      </th>
                      <th style={{ 
                        padding: '12px 16px', 
                        textAlign: 'left',
                        fontSize: '11px',
                        fontWeight: '600',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px',
                        color: '#6B7280'
                      }}>
                        Contact
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {eventData.functionalTeams.map((team: string, index: number) => {
                      const leader = getTeamLeader(team);
                      return (
                        <tr key={team} style={{ borderBottom: index < eventData.functionalTeams.length - 1 ? '1px solid #E5E7EB' : 'none' }}>
                          <td style={{ padding: '12px 16px', fontSize: '14px', color: '#111827', fontWeight: '500' }}>
                            {team}
                          </td>
                          <td style={{ padding: '12px 16px', fontSize: '14px', color: '#374151' }}>
                            {leader.name}
                          </td>
                          <td style={{ padding: '12px 16px', fontSize: '13px', color: '#6B7280' }}>
                            {leader.email}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Responsibilities Summary */}
              <div style={{ 
                backgroundColor: '#F9FAFB',
                border: '1px solid #D1D5DB',
                padding: '24px'
              }}>
                <div style={{ 
                  fontSize: '11px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  color: '#6B7280',
                  marginBottom: '12px',
                  fontWeight: '600'
                }}>
                  Next Steps
                </div>
                <div style={{ fontSize: '14px', color: '#374151', lineHeight: '1.6' }}>
                  {eventData.operationalSummary || 'Stakeholders will coordinate on event assessment and reporting per established workflows. All teams are expected to provide updates according to the deadline schedule.'}
                </div>
                {eventData.executiveAreas?.length > 0 && (
                  <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #D1D5DB' }}>
                    <div style={{ 
                      fontSize: '11px',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px',
                      color: '#6B7280',
                      marginBottom: '8px',
                      fontWeight: '600'
                    }}>
                      Executive Notification
                    </div>
                    <div style={{ fontSize: '13px', color: '#374151' }}>
                      {eventData.executiveAreas.join(', ')}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Event Details Grid */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ 
            fontSize: '13px', 
            fontWeight: '600',
            color: '#111827',
            marginBottom: '24px',
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }}>
            Event Details
          </h2>
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '24px',
            marginBottom: '24px'
          }}>
            {/* Event Identity */}
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '16px',
                fontWeight: '600'
              }}>
                Event Identity
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Event Type</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.eventType || 'N/A'}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Event Date</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{formatDate(eventData.lossDate)}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>CAT Code</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.catCode || 'N/A'}</div>
              </div>
              <div>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Event ID</div>
                <div style={{ fontSize: '14px', color: '#0052FF', fontWeight: '600' }}>{eventData.eventId || 'N/A'}</div>
              </div>
            </div>

            {/* Geography */}
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '16px',
                fontWeight: '600'
              }}>
                Geography
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Region</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.region || 'N/A'}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Country</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.impactedCountries || 'N/A'}</div>
              </div>
              {eventData.impactedStates && (
                <div style={{ marginBottom: '12px' }}>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>States/Provinces</div>
                  <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.impactedStates}</div>
                </div>
              )}
              {eventData.secondaryPerils && (
                <div>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Secondary Perils</div>
                  <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.secondaryPerils}</div>
                </div>
              )}
            </div>

            {/* Classification */}
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '16px',
                fontWeight: '600'
              }}>
                Classification
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Event Type</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.eventType || 'N/A'}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Peril Type</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.peril || 'N/A'}</div>
              </div>
              <div style={{ marginBottom: '12px' }}>
                <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Business Unit</div>
                <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.businessUnit || 'N/A'}</div>
              </div>
              {eventData.subBusinessUnit && (
                <div>
                  <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Sub-Business Unit</div>
                  <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.subBusinessUnit}</div>
                </div>
              )}
            </div>
          </div>

          {/* Event Description */}
          {eventData.description && (
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px',
              marginBottom: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '12px',
                fontWeight: '600'
              }}>
                Event Description
              </div>
              <div style={{ fontSize: '14px', color: '#374151', lineHeight: '1.6' }}>
                {eventData.description}
              </div>
            </div>
          )}

          {/* Operational Summary */}
          {eventData.operationalSummary && (
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '12px',
                fontWeight: '600'
              }}>
                Operational Summary
              </div>
              <div style={{ fontSize: '14px', color: '#374151', lineHeight: '1.6' }}>
                {eventData.operationalSummary}
              </div>
            </div>
          )}

          {/* External Identifiers */}
          {(eventData.rmsEventId || eventData.airEventId || eventData.pcsCode || eventData.sigmaEventId) && (
            <div style={{ 
              backgroundColor: '#F9FAFB',
              border: '1px solid #D1D5DB',
              padding: '24px',
              marginTop: '24px'
            }}>
              <div style={{ 
                fontSize: '11px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                color: '#6B7280',
                marginBottom: '16px',
                fontWeight: '600'
              }}>
                External Identifiers
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
                {eventData.rmsEventId && (
                  <div>
                    <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>RMS Event ID</div>
                    <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.rmsEventId}</div>
                  </div>
                )}
                {eventData.airEventId && (
                  <div>
                    <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>AIR Event ID</div>
                    <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.airEventId}</div>
                  </div>
                )}
                {eventData.pcsCode && (
                  <div>
                    <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>PCS Code</div>
                    <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.pcsCode}</div>
                  </div>
                )}
                {eventData.sigmaEventId && (
                  <div>
                    <div style={{ fontSize: '11px', color: '#9CA3AF', marginBottom: '4px' }}>Sigma Event ID</div>
                    <div style={{ fontSize: '14px', color: '#111827', fontWeight: '500' }}>{eventData.sigmaEventId}</div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Footer */}
      <div style={{ 
        backgroundColor: '#F3F4F6',
        padding: '24px 48px',
        borderTop: '1px solid #D1D5DB'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: '14px', color: '#6B7280' }}>
            <span style={{ fontWeight: '600', color: '#0052FF' }}>Dream Re</span> — Large Loss Event Platform
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '13px', color: '#6B7280', marginBottom: '4px' }}>
              Generated: {new Date().toLocaleString('en-US', { 
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </div>
            <div style={{ fontSize: '12px', color: '#9CA3AF' }}>
              Confidential - Internal Use Only
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}