import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Users, 
  KeyRound,
  ArrowLeft
} from 'lucide-react';
import { MainLayout } from './layouts/MainLayout';
import { UsersDirectory } from './admin/UsersDirectory';
import { SailPointAccessForm } from './SailPointAccessForm';

const adminTabs = [
  { id: 'sailpoint', label: 'User Onboarding', icon: KeyRound },
  { id: 'users', label: 'Users', icon: Users },
];

export function Administration() {
  const [activeSection, setActiveSection] = useState('sailpoint');
  const navigate = useNavigate();

  return (
    <MainLayout>
      <div className="h-screen flex flex-col overflow-hidden bg-gray-50">
        {/* Top Navigation Bar */}
        <div className="bg-white border-b border-gray-200 flex-shrink-0 shadow-sm">
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/events')}
                className="p-1.5 hover:bg-gray-100 rounded-md transition-colors"
                title="Back to Dashboard"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-xl text-gray-900">Back to Events</h1>
                
              </div>
            </div>
          </div>
          {/* Horizontal Tabs */}
          <div className="px-6 flex gap-1 items-center">
            {adminTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeSection === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSection(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 text-sm transition-all border-b-2 -mb-px ${
                    isActive
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto">
          {activeSection === 'sailpoint' && <SailPointAccessForm onSubmitSuccess={() => setActiveSection('users')} />}
          {activeSection === 'users' && <UsersDirectory />}
        </div>
      </div>
    </MainLayout>
  );
}