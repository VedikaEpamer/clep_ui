import { ReactNode } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { ShieldCheck, User } from 'lucide-react';
import { TaskInbox } from '../TaskInbox';
import { NotificationCenter } from '../NotificationCenter';
import { useRole } from '../../lib/roleContext';
import everestLogo from 'figma:asset/caba23401a17fe2f9b2a6d285e246c7856b7dfec.png';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { userName, permissions, currentRole } = useRole();

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 max-w-[100vw] overflow-x-hidden">
      {/* Top Header Bar - Full width */}
      <div className="h-16 bg-[#001f3f] border-b border-blue-900/30 flex items-center justify-between px-0 fixed top-0 left-0 right-0 z-50">
        {/* Left: Logo + SONAR */}
        <div className="h-full flex items-center px-5 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img 
              src={everestLogo} 
              alt="Everest Logo" 
              className="h-10 object-contain pointer-events-none" 
            />
            <span className="text-white text-xl font-semibold tracking-wide flex items-center">SONAR</span>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-4 pr-8">
          {/* Task Inbox */}
          <TaskInbox />
          
          {/* Notifications */}
          <NotificationCenter />
          
          {/* Administration */}
          {permissions.canAccessAdmin && (
            <button
              onClick={() => navigate('/administration')}
              className={`relative p-2 rounded-lg transition-all ${
                isActive('/administration')
                  ? 'bg-white/20 text-white'
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`}
              title="Administration"
            >
              <ShieldCheck className="w-5 h-5" />
            </button>
          )}
          
          {/* User Info */}
          <div className="flex items-center gap-2 pl-4 border-l border-white/20">
            <div className="flex items-center gap-2 px-2 py-1.5">
              <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex flex-col items-start">
                <span className="text-sm text-white">{userName}</span>
                <span className="text-[10px] text-white/60 leading-tight">{currentRole}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden pt-16">
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}