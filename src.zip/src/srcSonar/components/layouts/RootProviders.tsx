import { Outlet } from 'react-router';
import { RoleProvider } from '../../lib/roleContext';
import { WorkflowProvider } from '../../lib/workflowContext';
import { TaskProvider } from '../../lib/taskContext';
import { CommentProvider } from '../../lib/commentContext';
import { CurrencyProvider } from '../../lib/currencyContext';
import { EventDataProvider } from '../../lib/eventDataContext';
import { Toaster } from 'sonner@2.0.3';

export function RootProviders() {
  return (
    <WorkflowProvider>
      <EventDataProvider>
        <RoleProvider>
          <TaskProvider>
            <CommentProvider>
              <CurrencyProvider>
                <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50 max-w-[100vw] overflow-x-hidden">
                  <Outlet />
                  <Toaster position="top-right" richColors />
                </div>
              </CurrencyProvider>
            </CommentProvider>
          </TaskProvider>
        </RoleProvider>
      </EventDataProvider>
    </WorkflowProvider>
  );
}