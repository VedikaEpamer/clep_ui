import { useState } from 'react';
import { Search, Filter, Clock, CheckCircle2, AlertCircle, Users, ArrowRight } from 'lucide-react';
import { useTasks } from '../../lib/taskContext';

export function TaskManagement() {
  const { tasks } = useTasks();
  const [activeTab, setActiveTab] = useState<'open' | 'reallocation'>('open'); {/* Removed 'assignment-rules' from type */}
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'in-progress' | 'completed' | 'overdue'>('all');

  const filteredTasks = tasks.filter((task) => {
    if (filterStatus !== 'all' && task.status !== filterStatus) return false;
    if (searchQuery && !task.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !task.eventName.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !task.assignedTo.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const openTasks = tasks.filter((t) => t.status === 'pending' || t.status === 'in-progress');
  const overdueTasks = tasks.filter((t) => t.status === 'overdue');
  const completedTasks = tasks.filter((t) => t.status === 'completed');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'in-progress':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'overdue':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'medium':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="mb-2">Task Management</h2>
        <p className="text-sm text-slate-600">
          View all tasks, manage assignment rules, and reallocate workload
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-slate-600">Open Tasks</div>
            <Clock className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{openTasks.length}</div>
          <div className="text-xs text-slate-500 mt-1">Across all users</div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-slate-600">Overdue Tasks</div>
            <AlertCircle className="w-5 h-5 text-red-600" />
          </div>
          <div className="text-3xl font-bold text-red-600">{overdueTasks.length}</div>
          <div className="text-xs text-slate-500 mt-1">Requires attention</div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-slate-600">Completed Today</div>
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="text-3xl font-bold text-emerald-600">{completedTasks.length}</div>
          <div className="text-xs text-slate-500 mt-1">Last 24 hours</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg border border-slate-200 mb-6">
        <div className="border-b border-slate-200">
          <div className="flex gap-1 p-2">
            <button
              onClick={() => setActiveTab('open')}
              className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                activeTab === 'open'
                  ? 'bg-everest-blue text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Open Tasks
            </button>
            <button
              onClick={() => setActiveTab('reallocation')}
              className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                activeTab === 'reallocation'
                  ? 'bg-everest-blue text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Task Reallocation
            </button>
          </div>
        </div>

        {/* Open Tasks Tab */}
        {activeTab === 'open' && (
          <div className="p-6">
            {/* Filters */}
            <div className="flex gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by task, event, or assignee..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="overdue">Overdue</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            {/* Tasks Table */}
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Task / Event
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Assigned To
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Priority
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Due Date
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTasks.map((task) => (
                    <tr key={task.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="font-medium text-sm text-slate-900 mb-0.5">
                          {task.title}
                        </div>
                        <div className="text-xs text-slate-500">
                          {task.eventName} • {task.eventId}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
                            <Users className="w-4 h-4 text-slate-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-slate-900">
                              {task.assignedTo}
                            </div>
                            <div className="text-xs text-slate-500">
                              By {task.assignedBy}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={`px-2.5 py-1 text-xs font-medium rounded-md border ${getPriorityColor(
                            task.priority
                          )}`}
                        >
                          {task.priority.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={`px-2.5 py-1 text-xs font-medium rounded-md border ${getStatusColor(
                            task.status
                          )}`}
                        >
                          {task.status.replace('-', ' ').toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm text-slate-900">
                          {new Date(task.dueDate).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </div>
                        <div className="text-xs text-slate-500">
                          {new Date(task.dueDate).toLocaleTimeString('en-US', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <button className="text-sm text-everest-blue hover:text-blue-700 font-medium">
                          Reassign
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredTasks.length === 0 && (
              <div className="text-center py-12">
                <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-sm text-slate-500">No tasks found</p>
              </div>
            )}
          </div>
        )}

        {/* Task Reallocation Tab */}
        {activeTab === 'reallocation' && (
          <div className="p-6">
            <div className="mb-6">
              <h3 className="mb-4">Task Reallocation</h3>
              <p className="text-sm text-slate-600">
                Reassign tasks when team members change roles or leave the organization
              </p>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium text-amber-900 mb-1">Use with Caution</div>
                  <div className="text-sm text-amber-800">
                    Reallocating tasks will notify all affected users and may impact workflow timelines.
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="border border-slate-200 rounded-lg p-6">
                <h4 className="mb-4">Reassign All Tasks from User</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      From User
                    </label>
                    <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue">
                      <option>Select user...</option>
                      <option>Underwriting Leadership Team</option>
                      <option>Cat Modeling Team</option>
                      <option>Finance Team</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      To User
                    </label>
                    <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue">
                      <option>Select user...</option>
                      <option>Claims Team</option>
                      <option>North America Treaty Team</option>
                      <option>International Treaty Team</option>
                    </select>
                  </div>
                  <button className="w-full px-4 py-2 bg-everest-blue text-white rounded-lg hover:bg-[#0041CC] transition-colors font-medium">
                    Reassign All Tasks
                  </button>
                </div>
              </div>

              <div className="border border-slate-200 rounded-lg p-6">
                <h4 className="mb-4">Reassign by Event</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Event
                    </label>
                    <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue">
                      <option>Select event...</option>
                      <option>EVT-2024-001 - Hurricane Milton</option>
                      <option>EVT-2024-002 - California Wildfires</option>
                      <option>EVT-2024-003 - Texas Tornado</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      New Assignee
                    </label>
                    <select className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-everest-blue">
                      <option>Select user...</option>
                      <option>Michael Ross</option>
                      <option>Sarah Johnson</option>
                      <option>David Chen</option>
                    </select>
                  </div>
                  <button className="w-full px-4 py-2 bg-everest-blue text-white rounded-lg hover:bg-[#0041CC] transition-colors font-medium">
                    Reassign Event Tasks
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}