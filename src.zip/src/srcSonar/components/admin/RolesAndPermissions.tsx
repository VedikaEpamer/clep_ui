import { useState } from 'react';
import { Shield, Check, Info, UserCheck, Users, Eye, BarChart3, Upload, FileText, Settings, Lock, ClipboardList } from 'lucide-react';

// ─── SONAR Role Definitions (from spreadsheet) ──────────────────────────────

interface RoleDef {
  id: string;
  name: string;
  team: string;
  accessLevel: string;
  description: string;
  executiveAreas: string[];
  permissions: string[];
  userCount: number;
  isLead?: boolean;
}

const sonarRoles: RoleDef[] = [
  {
    id: 'administrator',
    name: 'Administrator',
    team: 'Admin',
    accessLevel: 'Admin',
    description: 'Full system access including all read/edit permissions across every module and business unit. Global admin override, emergency unlock/lock, and admin controls.',
    executiveAreas: ['Administration'],
    permissions: [
      'read_all_priorities', 'read_all_units',
      'edit_finance', 'edit_cat', 'edit_uw',
      'lock_estimates', 'reopen_estimate',
      'approve', 'admin_override'
    ],
    userCount: 1,
  },
  {
    id: 'claim_contributor',
    name: 'Event Coordinator',
    team: 'Claim',
    accessLevel: 'Contributor',
    description: 'All Business Units (read). Reads all modules (read-only), edits Overview/Finance. Creates and modifies events, updates estimates, locks estimates, and reopens estimates. No approve permission.',
    executiveAreas: ['Claims'],
    permissions: [
      'read_all_priorities', 'read_all_units',
      'edit_finance', 'edit_cat', 'edit_uw',
      'lock_estimates', 'reopen_estimate'
    ],
    userCount: 6,
  },
  {
    id: 'finance_contributor',
    name: 'Finance Contributor',
    team: 'Finance',
    accessLevel: 'Contributor',
    description: 'All Business Units (read). Edits Finance & UW modules. Locks/reopens estimates. Completes reserving extract. No approve permission.',
    executiveAreas: ['Finance'],
    permissions: [
      'read_all_priorities', 'read_all_units',
      'edit_finance', 'edit_uw',
      'lock_estimates', 'reopen_estimate'
    ],
    userCount: 3,
  },
  {
    id: 'cat_contributor',
    name: 'CAT Contributor',
    team: 'CAT',
    accessLevel: 'Contributor',
    description: 'All Business Units (read). Reads all modules (read-only), edits CAT and Finance modules. Performs event footprint/severity assessment. Locks/unlocks CAT data.',
    executiveAreas: ['Cat Modeling'],
    permissions: [
      'read_all_priorities', 'read_all_units',
      'edit_cat', 'edit_finance', 'lock_estimates'
    ],
    userCount: 2,
  },
  {
    id: 'unit_lead',
    name: 'Business Unit Lead',
    team: 'Underwriting',
    accessLevel: 'Contributor',
    description: 'Scoped to own Business Unit only. Read-only view of own BU data across all modules. Assigns tasks, approves estimates within own BU scope.',
    executiveAreas: [
      'Facultative', 'International Treaty',
      'North America Treaty', 'Product', 'Financial Lines'
    ],
    permissions: [
      'edit_uw',
      'reopen_estimate',
      'approve'
    ],
    userCount: 4,
    isLead: true,
  },
  {
    id: 'sub_unit_lead',
    name: 'Executive Area Lead',
    team: 'Underwriting',
    accessLevel: 'Contributor',
    description: 'Reads across all Business Units and all modules within own Executive Area. Assigns tasks, approves estimates scoped to own Executive Area domain. Largest role group (24 users).',
    executiveAreas: [
      'Facultative', 'International Treaty',
      'North America Treaty', 'Product', 'Financial Lines', 'Risk Management'
    ],
    permissions: [
      'read_all_priorities', 'read_all_units',
      'edit_uw', 'reopen_estimate', 'approve'
    ],
    userCount: 24,
    isLead: true,
  },
  {
    id: 'uw_contributor',
    name: 'UW Contributor',
    team: 'Underwriting',
    accessLevel: 'Contributor',
    description: 'Scoped to Business Unit. Reads Underwriting plus read permissions as granted. Edits Underwriting module. Uploads underwriting loss data within assigned profit center scope.',
    executiveAreas: [
      'Facultative', 'International Treaty',
      'North America Treaty', 'Product', 'Financial Lines', 'Risk Management'
    ],
    permissions: [
      'edit_uw'
    ],
    userCount: 7,
  },
  {
    id: 'reader',
    name: 'Reader',
    team: 'Management',
    accessLevel: 'Reader',
    description: 'All Business Units. Reads all modules (read-only). No edit permissions. Prod checkout validation only.',
    executiveAreas: ['Group Underwriting'],
    permissions: [
      'read_all_priorities', 'read_all_units'
    ],
    userCount: 3,
  },
];

// ─── Permission definitions grouped by category ─────────────────────────────

interface PermDef {
  id: string;
  label: string;
  description: string;
  icon: React.ElementType;
}

interface PermGroup {
  title: string;
  permissions: PermDef[];
}

const permissionGroups: PermGroup[] = [
  {
    title: 'Read Access',
    permissions: [
      { id: 'read_all_priorities', label: 'Read All Priorities', description: 'Read access across all priority levels and event classifications', icon: Eye },
      { id: 'read_all_units', label: 'Read All Units', description: 'Read access across all business units and executive areas', icon: Eye },
    ],
  },
  {
    title: 'Edit Permissions',
    permissions: [
      { id: 'edit_finance', label: 'Edit Finance', description: 'Edit financial data, overview, and finance module fields', icon: BarChart3 },
      { id: 'edit_cat', label: 'Edit CAT', description: 'Edit CAT modeling data, scenarios, and industry loss figures', icon: Upload },
      { id: 'edit_uw', label: 'Edit UW', description: 'Edit underwriting loss data within assigned profit center scope', icon: FileText },
    ],
  },
  {
    title: 'Lifecycle Controls',
    permissions: [
      { id: 'lock_estimates', label: 'Lock Estimates', description: 'Lock estimates to prevent further modifications', icon: Lock },
      { id: 'reopen_estimate', label: 'Reopen Estimate', description: 'Reopen a previously closed or locked estimate', icon: Settings },
    ],
  },
  {
    title: 'Approval & Admin',
    permissions: [
      { id: 'approve', label: 'Approve', description: 'Approve or reject UW estimate submissions within scope', icon: Check },
      { id: 'admin_override', label: 'Admin Override', description: 'Global admin override, emergency unlock/lock, and system controls', icon: Settings },
    ],
  },
];

// Flatten for matrix view
const allPermissions = permissionGroups.flatMap(g => g.permissions);

type ViewMode = 'detail' | 'matrix';

export function RolesAndPermissions() {
  const [selectedRole, setSelectedRole] = useState<RoleDef>(sonarRoles[0]);
  const [viewMode, setViewMode] = useState<ViewMode>('detail');

  const hasPermission = (roleId: string, permId: string) => {
    const role = sonarRoles.find(r => r.id === roleId);
    return role?.permissions.includes(permId) ?? false;
  };

  const getRoleIcon = (role: RoleDef) => {
    if (role.id === 'administrator') return Settings;
    if (role.isLead) return UserCheck;
    if (role.id === 'reader') return Eye;
    return Shield;
  };

  const getTeamColor = (team: string) => {
    switch (team) {
      case 'CAT': return 'bg-purple-100 text-purple-800';
      case 'Claim': return 'bg-orange-100 text-orange-800';
      case 'Finance': return 'bg-emerald-100 text-emerald-800';
      case 'Management': return 'bg-slate-200 text-slate-700';
      case 'Underwriting': return 'bg-blue-100 text-blue-800';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getAccessColor = (access: string) => {
    switch (access) {
      case 'Contributor': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Reader': return 'bg-slate-50 text-slate-600 border-slate-200';
      case 'Admin': return 'bg-red-50 text-red-700 border-red-200';
      default: return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="flex h-full">
      {/* Left Panel - Roles List */}
      <div className="w-80 bg-white border-r border-slate-200 flex flex-col">
        <div className="px-6 py-6 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Roles & Responsibilities</h2>
          <p className="text-sm text-slate-500 mt-1">SONAR Role Matrix · {sonarRoles.length} Roles · {sonarRoles.reduce((s, r) => s + r.userCount, 0)} Users</p>
        </div>

        <div className="flex-1 overflow-y-auto py-3">
          <div className="px-3 space-y-1">
            {sonarRoles.map((role) => {
              const Icon = getRoleIcon(role);
              const isActive = selectedRole.id === role.id;
              return (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role)}
                  className={`w-full text-left px-3 py-3 rounded-lg transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  } ${role.isLead ? 'ml-4 w-[calc(100%-1rem)] border-l-2 border-blue-300' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isActive ? 'bg-white/20' : 'bg-slate-100'
                    }`}>
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-600'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm font-medium mb-0.5 ${isActive ? 'text-white' : 'text-slate-900'}`}>
                        {role.name}
                      </div>
                      <div className={`text-xs ${isActive ? 'text-white/70' : 'text-slate-500'}`}>
                        {role.team} · {role.userCount} user{role.userCount !== 1 ? 's' : ''}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* View toggle */}
        <div className="px-4 py-3 border-t border-slate-200">
          <div className="flex bg-slate-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('detail')}
              className={`flex-1 text-xs py-1.5 rounded-md transition-all ${
                viewMode === 'detail' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'
              }`}
            >
              Detail View
            </button>
            <button
              onClick={() => setViewMode('matrix')}
              className={`flex-1 text-xs py-1.5 rounded-md transition-all ${
                viewMode === 'matrix' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'
              }`}
            >
              Matrix View
            </button>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex-1 overflow-auto bg-slate-50">
        {viewMode === 'detail' ? (
          <DetailView
            role={selectedRole}
            getRoleIcon={getRoleIcon}
            getTeamColor={getTeamColor}
            getAccessColor={getAccessColor}
            permissionGroups={permissionGroups}
          />
        ) : (
          <MatrixView
            roles={sonarRoles}
            permissionGroups={permissionGroups}
            allPermissions={allPermissions}
            hasPermission={hasPermission}
            getTeamColor={getTeamColor}
          />
        )}
      </div>
    </div>
  );
}

// ─── Detail View ─────────────────────────────────────────────────────────────

function DetailView({
  role,
  getRoleIcon,
  getTeamColor,
  getAccessColor,
  permissionGroups,
}: {
  role: RoleDef;
  getRoleIcon: (r: RoleDef) => React.ElementType;
  getTeamColor: (t: string) => string;
  getAccessColor: (a: string) => string;
  permissionGroups: PermGroup[];
}) {
  const Icon = getRoleIcon(role);

  return (
    <div className="p-8 max-w-4xl">
      {/* Role Header Card */}
      <div className="bg-white rounded-lg border border-slate-200 p-6 mb-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-slate-900 mb-2">{role.name}</h3>
            <div className="flex items-center gap-2 flex-wrap mb-3">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTeamColor(role.team)}`}>
                Team: {role.team}
              </span>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getAccessColor(role.accessLevel)}`}>
                Access: {role.accessLevel}
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
                {role.userCount} active user{role.userCount !== 1 ? 's' : ''}
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
                {role.permissions.length} permissions
              </span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">{role.description}</p>
          </div>
        </div>

        {/* Executive Areas */}
        <div className="mt-4 pt-4 border-t border-slate-100">
          <div className="text-xs font-medium text-slate-500 mb-2">EXECUTIVE AREAS</div>
          <div className="flex flex-wrap gap-1.5">
            {role.executiveAreas.map(ea => (
              <span key={ea} className="inline-flex items-center px-2 py-1 rounded bg-slate-100 text-xs text-slate-700">
                {ea}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Info banner for Segment Lead */}
      {role.isLead && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6 flex items-start gap-3">
          <UserCheck className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-900">
            {role.id === 'unit_lead' ? (
              <>
                <span className="font-semibold">Business Unit Scope:</span> This role is scoped to a single Business Unit.
                Business Unit Leads can read only their own BU data, assign tasks, and approve or reject UW estimate submissions within their assigned BU before final Finance sign-off.
              </>
            ) : (
              <>
                <span className="font-semibold">Executive Area Scope:</span> This role has cross-BU read access within their Executive Area.
                Executive Area Leads can read across all Business Units in their domain (e.g., all of International Treaty), assign estimation tasks, and approve estimates within their Executive Area scope.
              </>
            )}
          </div>
        </div>
      )}

      {/* Scope info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-blue-900">
          <span className="font-semibold">Scope Enforcement:</span> Access is further limited by event assignment. 
          Users must be assigned to an event to view it. 
          <span className="font-medium"> Profit Center Scope</span> limits which contracts a Contributor can edit. 
          <span className="font-medium"> Track Scope</span> (UW / CAT / Finance) determines which screens are editable.
        </div>
      </div>

      {/* Permission Groups */}
      <div className="space-y-4">
        {permissionGroups.map((group) => {
          const groupPerms = group.permissions.filter(p => role.permissions.includes(p.id));
          const hasAny = groupPerms.length > 0;

          return (
            <div key={group.title} className={`bg-white rounded-lg border ${hasAny ? 'border-slate-200' : 'border-slate-100 opacity-50'}`}>
              <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between">
                <h4 className="text-sm font-semibold text-slate-900">{group.title}</h4>
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  hasAny ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-400'
                }`}>
                  {groupPerms.length} / {group.permissions.length}
                </span>
              </div>
              <div className="p-4 space-y-2">
                {group.permissions.map((perm) => {
                  const granted = role.permissions.includes(perm.id);
                  const PermIcon = perm.icon;
                  return (
                    <div
                      key={perm.id}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                        granted ? 'bg-emerald-50/60' : 'bg-slate-50/50'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded flex items-center justify-center flex-shrink-0 ${
                        granted ? 'bg-emerald-100' : 'bg-slate-100'
                      }`}>
                        {granted ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <span className="w-2 h-0.5 bg-slate-300 rounded" />
                        )}
                      </div>
                      <PermIcon className={`w-4 h-4 flex-shrink-0 ${granted ? 'text-slate-600' : 'text-slate-300'}`} />
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm ${granted ? 'text-slate-900' : 'text-slate-400'}`}>{perm.label}</div>
                        <div className={`text-xs ${granted ? 'text-slate-500' : 'text-slate-300'}`}>{perm.description}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-6 bg-white rounded-lg border border-slate-200 p-5">
        <div className="flex items-center gap-3 mb-2">
          <Check className="w-5 h-5 text-emerald-600" />
          <span className="font-medium text-slate-900">Permission Summary</span>
        </div>
        <p className="text-sm text-slate-600">
          The <span className="font-medium text-slate-900">{role.name}</span> role has{' '}
          <span className="font-medium text-slate-900">{role.permissions.length}</span> of{' '}
          {allPermissions.length} total permissions granted, mapped to the{' '}
          <span className="font-medium text-slate-900">{role.team}</span> team with{' '}
          <span className="font-medium text-slate-900">{role.accessLevel}</span> access.
        </p>
      </div>
    </div>
  );
}

// ─── Matrix View ─────────────────────────────────────────────────────────────

function MatrixView({
  roles,
  permissionGroups,
  allPermissions: _allPermissions,
  hasPermission,
  getTeamColor,
}: {
  roles: RoleDef[];
  permissionGroups: PermGroup[];
  allPermissions: PermDef[];
  hasPermission: (roleId: string, permId: string) => boolean;
  getTeamColor: (t: string) => string;
}) {
  return (
    <div className="p-6">
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900">Full Permission Matrix</h3>
          <p className="text-xs text-slate-500 mt-1">All roles × all permissions</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="text-left text-xs font-medium text-slate-500 px-4 py-3 min-w-[220px] sticky left-0 bg-slate-50 z-10">
                  Permission
                </th>
                {roles.map(role => (
                  <th key={role.id} className="text-center px-2 py-3 min-w-[100px]">
                    <div className="text-xs font-medium text-slate-900 leading-tight">{role.name}</div>
                    <span className={`inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] font-medium ${getTeamColor(role.team)}`}>
                      {role.team}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {permissionGroups.map((group, gi) => {
                const rows = [
                  <tr key={`gh-${gi}`} className="bg-slate-50/70">
                    <td colSpan={roles.length + 1} className="px-4 py-2 text-xs font-semibold text-slate-700 uppercase tracking-wider sticky left-0 bg-slate-50/70">
                      {group.title}
                    </td>
                  </tr>,
                  ...group.permissions.map((perm) => (
                    <tr key={perm.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                      <td className="px-4 py-2.5 text-sm text-slate-700 sticky left-0 bg-white z-10">
                        {perm.label}
                      </td>
                      {roles.map(role => {
                        const granted = hasPermission(role.id, perm.id);
                        return (
                          <td key={role.id} className="text-center px-2 py-2.5">
                            {granted ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100">
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                              </span>
                            ) : (
                              <span className="inline-block w-4 h-0.5 bg-slate-200 rounded" />
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ];
                return rows;
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}