import { Users, ChevronRight } from 'lucide-react';

export function OrganizationHierarchy() {
  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
      <div className="flex items-start gap-3 mb-4">
        <Users className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="text-sm font-semibold text-blue-900 mb-1">Organizational Hierarchy & Roles</h3>
          <p className="text-xs text-blue-800 mb-3">
            LLEP uses a cascading assignment model. Routing Rules automatically allocate tasks based on this structure.
          </p>
        </div>
      </div>

      <div className="space-y-4 text-xs">
        {/* Executive Management */}
        <div className="bg-white rounded-lg p-4 border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            <span className="font-semibold text-slate-900">Executive Management</span>
            <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs">Executive Viewer</span>
          </div>
          <div className="text-slate-600 ml-4">CEO, CUO, CFO • Read-only access, notifications on major events</div>
        </div>

        <div className="flex items-center justify-center text-slate-400">
          <ChevronRight className="w-4 h-4 rotate-90" />
        </div>

        {/* Executive Areas */}
        <div className="bg-white rounded-lg p-4 border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="font-semibold text-slate-900">Executive Areas (Phase 1 Coordinators)</span>
            <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">Event Coordinator</span>
          </div>
          <div className="text-slate-600 ml-4 mb-2">Artur King, Jiten Thakkar, Emily Chen, Michael Rodriguez (Cat Modeling Head)</div>
          <div className="text-slate-500 ml-4 text-xs">
            <strong>Auto-assigned on event creation.</strong> Responsible for assigning Business Unit Leads and Underwriters via Participants Tab.
          </div>
        </div>

        <div className="flex items-center justify-center text-slate-400">
          <ChevronRight className="w-4 h-4 rotate-90" />
        </div>

        {/* Business Units */}
        <div className="bg-white rounded-lg p-4 border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
            <span className="font-semibold text-slate-900">Business Units (Regional Heads)</span>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded text-xs">UW Lead</span>
          </div>
          <div className="text-slate-600 ml-4 mb-2">
            North America Treaty, International Treaty, Facultative, LATAM, Specialties
          </div>
          <div className="text-slate-500 ml-4 text-xs">
            Assigned by Event Coordinators. Responsible for managing their underwriting team's estimates.
          </div>
        </div>

        <div className="flex items-center justify-center text-slate-400">
          <ChevronRight className="w-4 h-4 rotate-90" />
        </div>

        {/* Underwriters */}
        <div className="bg-white rounded-lg p-4 border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
            <span className="font-semibold text-slate-900">Underwriters</span>
            <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded text-xs">UW Contributor</span>
          </div>
          <div className="text-slate-600 ml-4 mb-2">Individual underwriters within each Business Unit</div>
          <div className="text-slate-500 ml-4 text-xs">
            Assigned by Event Coordinators or UW Leads. Upload and update contract-level estimates.
          </div>
        </div>

        {/* Supporting Roles */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white rounded-lg p-3 border border-slate-200">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
              <span className="font-semibold text-slate-900">Modeling</span>
            </div>
            <div className="text-xs text-slate-600 ml-4">
              <span className="px-1.5 py-0.5 bg-indigo-100 text-indigo-700 rounded text-xs mr-1">Modeler</span>
              Upload CAT models
            </div>
          </div>

          <div className="bg-white rounded-lg p-3 border border-slate-200">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
              <span className="font-semibold text-slate-900">Finance</span>
            </div>
            <div className="text-xs text-slate-600 ml-4">
              <span className="px-1.5 py-0.5 bg-teal-100 text-teal-700 rounded text-xs mr-1">Finance Owner</span>
              Gross estimates, locking
            </div>
          </div>

          <div className="bg-white rounded-lg p-3 border border-slate-200">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
              <span className="font-semibold text-slate-900">Claims</span>
            </div>
            <div className="text-xs text-slate-600 ml-4">
              <span className="px-1.5 py-0.5 bg-rose-100 text-rose-700 rounded text-xs mr-1">Claims Reviewer</span>
              Review process
            </div>
          </div>

          <div className="bg-white rounded-lg p-3 border border-slate-200">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
              <span className="font-semibold text-slate-900">Other</span>
            </div>
            <div className="text-xs text-slate-600 ml-4">
              <span className="px-1.5 py-0.5 bg-cyan-100 text-cyan-700 rounded text-xs mr-1">Retro, Reserving</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}