import { useState } from 'react';
import { Plus, Search, Edit2, X, Users as UsersIcon, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { FullscreenTable } from '../ui/FullscreenTable';
import { OrganizationHierarchy } from './OrganizationHierarchy';

interface RoutingRule {
  id: string;
  name: string;
  region: string;
  lob: string;
  eventType: string;
  trigger: string;
  targetRole: string;
  defaultAssignees: string[];
  notificationType: string;
  status: 'Active' | 'Inactive';
}

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

const regions = ['Global', 'North America', 'EMEA', 'APAC', 'Latin America'];
const lobs = ['All LOBs', 'Property', 'Casualty', 'Professional Lines', 'Product', 'Marine'];
const eventTypes = ['All Types', 'CAT', 'Man-Made', 'Aggregated Non-CAT'];
const triggers = [
  'Event Created',
  'Estimation Window Opened',
  'Estimation Window Closed',
  'Threshold Breach',
  'Recalc Required',
  'Approval Requested',
  'Deadline Approaching'
];
const targetRoles = [
  'Finance Owner',
  'Event Coordinator',
  'UW Lead',
  'UW Contributor',
  'Modeler',
  'Claims Reviewer',
  'Reserving Reviewer',
  'Retro Analyst',
  'Executive Viewer'
];
const notificationTypes = ['Task + Email', 'Task only', 'Email only'];

// Mock users for assignee selection
const mockUsers: User[] = [
  { id: 'U001', name: 'Underwriting Leadership Team', email: 'uwleadership@everest.com', role: 'UW Lead' },
  { id: 'U002', name: 'Cat Modeling Team', email: 'catmodeling@everest.com', role: 'Modeler' },
  { id: 'U003', name: 'Finance Team', email: 'finance@everest.com', role: 'Finance Owner' },
  { id: 'U004', name: 'North America Treaty Team', email: 'natreaty@everest.com', role: 'UW Contributor' },
  { id: 'U005', name: 'Claims Team', email: 'claims@everest.com', role: 'Claims Reviewer' },
  { id: 'U006', name: 'Admin Team', email: 'admin@everest.com', role: 'System Admin' },
  { id: 'U007', name: 'International Treaty Team', email: 'intltreaty@everest.com', role: 'Modeler' },
  { id: 'U008', name: 'Facultative Team', email: 'facultative@everest.com', role: 'UW Lead' },
  { id: 'U009', name: 'Group Underwriting Team', email: 'groupuw@everest.com', role: 'Event Coordinator' },
  { id: 'U010', name: 'Retro Analysis Team', email: 'retro@everest.com', role: 'Retro Analyst' }
];

const mockRules: RoutingRule[] = [
  {
    id: 'R001',
    name: 'Phase 1: Executive Coordinators - Event Created',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Event Created',
    targetRole: 'Event Coordinator',
    defaultAssignees: ['U004', 'U005', 'U006', 'U007'],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R002',
    name: 'Phase 1: Notify Executive Management',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Event Created',
    targetRole: 'Executive Viewer',
    defaultAssignees: ['U001', 'U002', 'U003'],
    notificationType: 'Email only',
    status: 'Active'
  },
  {
    id: 'R003',
    name: 'Phase 1: UW Estimation Window Opened',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Estimation Window Opened',
    targetRole: 'UW Lead',
    defaultAssignees: [],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R004',
    name: 'Phase 1: UW Contributors - Assigned',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Estimation Window Opened',
    targetRole: 'UW Contributor',
    defaultAssignees: [],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R005',
    name: 'CAT Modeler - Event Created',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'CAT',
    trigger: 'Event Created',
    targetRole: 'Modeler',
    defaultAssignees: ['U007'],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R006',
    name: 'Modelers - Assigned by Lead',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'CAT',
    trigger: 'Estimation Window Opened',
    targetRole: 'Modeler',
    defaultAssignees: [],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R007',
    name: 'Finance Owner - Gross Estimate Required',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Event Created',
    targetRole: 'Finance Owner',
    defaultAssignees: ['U008'],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R008',
    name: 'Claims Review - Large Loss Events',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Threshold Breach',
    targetRole: 'Claims Reviewer',
    defaultAssignees: ['U023'],
    notificationType: 'Task + Email',
    status: 'Active'
  },
  {
    id: 'R009',
    name: 'Reserving Review - Estimation Complete',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Estimation Window Closed',
    targetRole: 'Reserving Reviewer',
    defaultAssignees: ['U024'],
    notificationType: 'Task only',
    status: 'Active'
  },
  {
    id: 'R010',
    name: 'Retro Analysis - CAT Events',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'CAT',
    trigger: 'Estimation Window Closed',
    targetRole: 'Retro Analyst',
    defaultAssignees: ['U025'],
    notificationType: 'Task only',
    status: 'Active'
  },
  {
    id: 'R011',
    name: 'Executive Briefing - Threshold Breach',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Threshold Breach',
    targetRole: 'Executive Viewer',
    defaultAssignees: ['U001', 'U002', 'U003'],
    notificationType: 'Email only',
    status: 'Active'
  },
  {
    id: 'R012',
    name: 'Deadline Approaching - All Coordinators',
    region: 'Global',
    lob: 'All LOBs',
    eventType: 'All Types',
    trigger: 'Deadline Approaching',
    targetRole: 'Event Coordinator',
    defaultAssignees: ['U004', 'U005', 'U006', 'U007'],
    notificationType: 'Email only',
    status: 'Active'
  }
];

export function RoutingRules() {
  const [rules, setRules] = useState<RoutingRule[]>(mockRules);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRegion, setFilterRegion] = useState('');
  const [filterLOB, setFilterLOB] = useState('');
  const [filterEventType, setFilterEventType] = useState('');
  const [filterTargetRole, setFilterTargetRole] = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<RoutingRule | null>(null);

  // Form state
  const [formName, setFormName] = useState('');
  const [formRegion, setFormRegion] = useState('Global');
  const [formLOB, setFormLOB] = useState('All LOBs');
  const [formEventType, setFormEventType] = useState('All Types');
  const [formTrigger, setFormTrigger] = useState('Event Created');
  const [formTargetRole, setFormTargetRole] = useState('');
  const [formAssignees, setFormAssignees] = useState<string[]>([]);
  const [formNotificationType, setFormNotificationType] = useState('Task + Email');
  const [formStatus, setFormStatus] = useState(true);

  const filteredRules = rules.filter(rule => {
    const matchesSearch = searchQuery === '' || 
      rule.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRegion = filterRegion === '' || rule.region === filterRegion;
    const matchesLOB = filterLOB === '' || rule.lob === filterLOB;
    const matchesEventType = filterEventType === '' || rule.eventType === filterEventType;
    const matchesTargetRole = filterTargetRole === '' || rule.targetRole === filterTargetRole;
    
    return matchesSearch && matchesRegion && matchesLOB && matchesEventType && matchesTargetRole;
  });

  const handleAddRule = () => {
    setEditingRule(null);
    setFormName('');
    setFormRegion('Global');
    setFormLOB('All LOBs');
    setFormEventType('All Types');
    setFormTrigger('Event Created');
    setFormTargetRole('');
    setFormAssignees([]);
    setFormNotificationType('Task + Email');
    setFormStatus(true);
    setDrawerOpen(true);
  };

  const handleEditRule = (rule: RoutingRule) => {
    setEditingRule(rule);
    setFormName(rule.name);
    setFormRegion(rule.region);
    setFormLOB(rule.lob);
    setFormEventType(rule.eventType);
    setFormTrigger(rule.trigger);
    setFormTargetRole(rule.targetRole);
    setFormAssignees(rule.defaultAssignees);
    setFormNotificationType(rule.notificationType);
    setFormStatus(rule.status === 'Active');
    setDrawerOpen(true);
  };

  const handleSaveRule = () => {
    // In a real app, this would save to backend
    setDrawerOpen(false);
  };

  const toggleAssignee = (userId: string) => {
    if (formAssignees.includes(userId)) {
      setFormAssignees(formAssignees.filter(id => id !== userId));
    } else {
      setFormAssignees([...formAssignees, userId]);
    }
  };

  const getUsersByIds = (userIds: string[]) => {
    return mockUsers.filter(user => userIds.includes(user.id));
  };

  const getUsersByRole = (role: string) => {
    return mockUsers.filter(user => user.role === role);
  };

  const getPreviewRecipients = () => {
    const selectedUsers = getUsersByIds(formAssignees);
    const roleUsers = formTargetRole ? getUsersByRole(formTargetRole) : [];
    
    // Combine selected users and role-based users, removing duplicates
    const allUsers = [...selectedUsers];
    roleUsers.forEach(ru => {
      if (!allUsers.find(u => u.id === ru.id)) {
        allUsers.push(ru);
      }
    });
    
    return allUsers;
  };

  const tableContent = (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-slate-200">
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Rule Name</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Region</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">LOB / Portfolio</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Event Type</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Trigger</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Target Role</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Assignees</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Notification</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Status</th>
            <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredRules.map((rule) => {
            const assignees = getUsersByIds(rule.defaultAssignees);
            return (
              <tr
                key={rule.id}
                className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => handleEditRule(rule)}
              >
                <td className="py-3 px-4">
                  <div className="text-sm font-medium text-slate-900">{rule.name}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="text-sm text-slate-900">{rule.region}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="text-sm text-slate-900">{rule.lob}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="text-sm text-slate-900">{rule.eventType}</div>
                </td>
                <td className="py-3 px-4">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700">
                    {rule.trigger}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <div className="text-sm font-medium text-slate-900">{rule.targetRole}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-1">
                    <UsersIcon className="w-4 h-4 text-slate-400" />
                    <span className="text-sm text-slate-600">{assignees.length} assigned</span>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <div className="text-sm text-slate-900">{rule.notificationType}</div>
                </td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    rule.status === 'Active'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-slate-100 text-slate-600'
                  }`}>
                    {rule.status}
                  </span>
                </td>
                <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => handleEditRule(rule)}
                    className="p-1.5 hover:bg-slate-200 rounded-lg transition-colors"
                    title="Edit rule"
                  >
                    <Edit2 className="w-4 h-4 text-slate-600" />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-8 py-6 border-b border-slate-200 bg-white">
        <h1 className="text-2xl font-semibold text-slate-900">Routing Rules</h1>
        <p className="text-sm text-slate-600 mt-1">Configure assignment logic and notification workflows</p>
      </div>

      {/* Organization Hierarchy Info */}
      <div className="px-8 py-6 bg-white border-b border-slate-200">
        <OrganizationHierarchy />
      </div>

      {/* Filters and Actions Bar */}
      <div className="px-8 py-4 bg-white border-b border-slate-200">
        <div className="flex items-center gap-3 mb-4">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search routing rules..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
            />
          </div>

          {/* Add Button */}
          <button
            onClick={handleAddRule}
            className="px-4 py-2 bg-everest-blue text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Routing Rule
          </button>
        </div>

        {/* Filters Row */}
        <div className="flex items-center gap-3">
          <select
            value={filterRegion}
            onChange={(e) => setFilterRegion(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
          >
            <option value="">All Regions</option>
            {regions.map(region => (
              <option key={region} value={region}>{region}</option>
            ))}
          </select>

          <select
            value={filterLOB}
            onChange={(e) => setFilterLOB(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
          >
            <option value="">All LOBs</option>
            {lobs.map(lob => (
              <option key={lob} value={lob}>{lob}</option>
            ))}
          </select>

          <select
            value={filterEventType}
            onChange={(e) => setFilterEventType(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
          >
            <option value="">All Event Types</option>
            {eventTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>

          <select
            value={filterTargetRole}
            onChange={(e) => setFilterTargetRole(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
          >
            <option value="">All Target Roles</option>
            {targetRoles.map(role => (
              <option key={role} value={role}>{role}</option>
            ))}
          </select>

          {(filterRegion || filterLOB || filterEventType || filterTargetRole) && (
            <button
              onClick={() => {
                setFilterRegion('');
                setFilterLOB('');
                setFilterEventType('');
                setFilterTargetRole('');
              }}
              className="text-sm text-slate-600 hover:text-slate-900"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 bg-white">
        <FullscreenTable title="Routing Rules">
          {tableContent}
        </FullscreenTable>
      </div>

      {/* Rule Drawer */}
      {drawerOpen && (
        <>
          <div 
            className="fixed inset-0 bg-slate-900/20 z-40"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="fixed right-0 top-0 h-full w-[600px] bg-white shadow-xl z-50 flex flex-col">
            {/* Drawer Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingRule ? 'Edit Routing Rule' : 'Add New Routing Rule'}
              </h2>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            {/* Drawer Content */}
            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-5">
              {/* Rule Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Rule Name
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                  placeholder="e.g., CAT Event Auto-Assignment"
                />
              </div>

              {/* Event Matching Criteria */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900 mb-3">Event Matching Criteria</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Region
                    </label>
                    <select
                      value={formRegion}
                      onChange={(e) => setFormRegion(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      {regions.map(region => (
                        <option key={region} value={region}>{region}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      LOB / Portfolio
                    </label>
                    <select
                      value={formLOB}
                      onChange={(e) => setFormLOB(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      {lobs.map(lob => (
                        <option key={lob} value={lob}>{lob}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Event Type
                    </label>
                    <select
                      value={formEventType}
                      onChange={(e) => setFormEventType(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      {eventTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Trigger & Assignment */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900 mb-3">Trigger & Assignment</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Trigger
                    </label>
                    <select
                      value={formTrigger}
                      onChange={(e) => setFormTrigger(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      {triggers.map(trigger => (
                        <option key={trigger} value={trigger}>{trigger}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Target Role
                    </label>
                    <select
                      value={formTargetRole}
                      onChange={(e) => setFormTargetRole(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      <option value="">Select target role</option>
                      {targetRoles.map(role => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Notification Type
                    </label>
                    <select
                      value={formNotificationType}
                      onChange={(e) => setFormNotificationType(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-everest-blue focus:border-transparent"
                    >
                      {notificationTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Default Assignees */}
              <div className="pt-4 border-t border-slate-200">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Default Assignees (Optional)
                </label>
                <p className="text-xs text-slate-500 mb-3">
                  If not specified, tasks will be assigned to all users with the target role
                </p>
                <div className="border border-slate-300 rounded-lg p-3 space-y-2 max-h-64 overflow-y-auto">
                  {mockUsers.map(user => (
                    <label key={user.id} className="flex items-start gap-2 cursor-pointer hover:bg-slate-50 p-2 rounded">
                      <input
                        type="checkbox"
                        checked={formAssignees.includes(user.id)}
                        onChange={() => toggleAssignee(user.id)}
                        className="w-4 h-4 rounded border-slate-300 text-everest-blue focus:ring-everest-blue mt-0.5"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-slate-900">{user.name}</div>
                        <div className="text-xs text-slate-500">{user.email} • {user.role}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Preview Recipients */}
              {formTargetRole && (
                <div className="pt-4 border-t border-slate-200">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-2 mb-3">
                      <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="text-sm font-medium text-blue-900 mb-1">
                          Preview Recipients ({getPreviewRecipients().length})
                        </div>
                        <div className="text-xs text-blue-800 mb-3">
                          The following users will receive {formNotificationType.toLowerCase()} when this rule is triggered:
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {getPreviewRecipients().map(user => (
                        <div key={user.id} className="flex items-center gap-2 text-xs bg-white rounded p-2">
                          <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-medium">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div className="flex-1">
                            <div className="text-slate-900 font-medium">{user.name}</div>
                            <div className="text-slate-500">{user.email}</div>
                          </div>
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-xs">
                            {user.role}
                          </span>
                        </div>
                      ))}
                      {getPreviewRecipients().length === 0 && (
                        <div className="text-xs text-slate-500 italic">
                          No users match the selected criteria
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Status */}
              <div className="pt-4 border-t border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formStatus}
                    onChange={(e) => setFormStatus(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-everest-blue focus:ring-everest-blue"
                  />
                  <span className="text-sm font-medium text-slate-700">Active</span>
                </label>
                <p className="text-xs text-slate-500 mt-1 ml-6">
                  Inactive rules will not trigger task assignments or notifications
                </p>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setDrawerOpen(false)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveRule}
                className="px-4 py-2 bg-everest-blue text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
              >
                Save Rule
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}