import { useState } from 'react';
import { Search, Pencil, X, CheckCircle2, Shield, Check } from 'lucide-react';

interface User {
  id: string;
  executiveArea: string;
  unitSegment: string;
  name: string;
  teams: string[];
  roles: string[];
  access: string;
  status: 'Active' | 'Inactive';
}

const mockUsers: User[] = [
  // Administration
  { id: 'U000', executiveArea: 'Administration', unitSegment: 'Administration', name: 'David Chen', teams: ['Admin'], roles: ['Administrator'], access: 'Admin', status: 'Active' },
  // Cat Modeling
  { id: 'U001', executiveArea: 'Cat Modeling', unitSegment: 'Cat Modeling', name: 'Neil Schwarzenberger', teams: ['CAT'], roles: ['CAT Contributor'], access: 'Contributor', status: 'Active' },
  { id: 'U002', executiveArea: 'Cat Modeling', unitSegment: 'Cat Modeling', name: 'Huy Hong', teams: ['CAT'], roles: ['CAT Contributor'], access: 'Contributor', status: 'Active' },
  // Claims
  { id: 'U003', executiveArea: 'Claims', unitSegment: 'Claims', name: 'Andrew McBride', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  { id: 'U004', executiveArea: 'Claims', unitSegment: 'Claims', name: 'Lope Garcia', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  { id: 'U005', executiveArea: 'Claims', unitSegment: 'Claims', name: 'Tim Carter', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  { id: 'U006', executiveArea: 'Claims', unitSegment: 'Claims', name: 'James Parker', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  { id: 'U007', executiveArea: 'Claims', unitSegment: 'Claims', name: 'Barbara Toro', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  { id: 'U008', executiveArea: 'Claims', unitSegment: 'Claims', name: 'Patricia McMahon', teams: ['Claim'], roles: ['Event Coordinator'], access: 'Contributor', status: 'Active' },
  // Finance
  { id: 'U009', executiveArea: 'Finance', unitSegment: 'Finance', name: 'Clem Demetz', teams: ['Finance'], roles: ['Finance Contributor'], access: 'Contributor', status: 'Active' },
  { id: 'U010', executiveArea: 'Finance', unitSegment: 'Finance', name: 'Nigel Smith', teams: ['Finance'], roles: ['Finance Contributor'], access: 'Contributor', status: 'Active' },
  { id: 'U011', executiveArea: 'Finance', unitSegment: 'Finance', name: 'Tim Ritter', teams: ['Finance'], roles: ['Finance Contributor'], access: 'Contributor', status: 'Active' },
  // Group Underwriting
  { id: 'U012', executiveArea: 'Group Underwriting', unitSegment: 'Group Underwriting', name: 'Reena Boltax', teams: ['Management'], roles: ['Reader'], access: 'Reader', status: 'Active' },
  { id: 'U013', executiveArea: 'Group Underwriting', unitSegment: 'Group Underwriting', name: 'Chris Downey', teams: ['Management'], roles: ['Reader'], access: 'Reader', status: 'Active' },
  { id: 'U014', executiveArea: 'Group Underwriting', unitSegment: 'Group Underwriting', name: 'Jill Beggs', teams: ['Management'], roles: ['Reader'], access: 'Reader', status: 'Active' },
  // Facultative
  { id: 'U015', executiveArea: 'Facultative', unitSegment: 'Facultative', name: 'Mike Cellura', teams: ['Underwriting'], roles: ['Business Unit Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U016', executiveArea: 'Facultative', unitSegment: 'Facultative', name: 'Juan Delgado', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U047', executiveArea: 'Facultative', unitSegment: 'Facultative', name: 'Leo Fernandez', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  { id: 'U018', executiveArea: 'Facultative', unitSegment: 'Facultative', name: 'Nicholas Pozzebon', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U048', executiveArea: 'Facultative', unitSegment: 'Facultative', name: 'Derek Hollis', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  // International Treaty
  { id: 'U019', executiveArea: 'International Treaty', unitSegment: 'International Treaty', name: 'Artur Klinger', teams: ['Underwriting'], roles: ['Business Unit Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U020', executiveArea: 'International Treaty', unitSegment: 'Zurich/Dublin', name: 'Harad Jacobsen', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U021', executiveArea: 'International Treaty', unitSegment: 'Latam', name: 'Rui Marliere', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U022', executiveArea: 'International Treaty', unitSegment: 'London', name: 'Mark Wallace', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U023', executiveArea: 'International Treaty', unitSegment: 'Middle East', name: 'Melissa Ford', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U024', executiveArea: 'International Treaty', unitSegment: 'Singapore', name: 'Kevin Bogardus', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U043', executiveArea: 'International Treaty', unitSegment: 'Zurich/Dublin', name: 'Thomas Brennan', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  // North America Treaty
  { id: 'U025', executiveArea: 'North America Treaty', unitSegment: 'North America Treaty', name: 'Jiten Voralia', teams: ['Underwriting'], roles: ['Business Unit Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U026', executiveArea: 'North America Treaty', unitSegment: 'Bermuda', name: 'Peter Bell', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U027', executiveArea: 'North America Treaty', unitSegment: 'Canada', name: 'Scott Paddington', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U028', executiveArea: 'North America Treaty', unitSegment: 'Treaty Casualty', name: 'Mayur Doshi', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U029', executiveArea: 'North America Treaty', unitSegment: 'Treaty Property', name: 'Chuck Volker', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U044', executiveArea: 'North America Treaty', unitSegment: 'Bermuda', name: 'Sarah Lindqvist', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  // Product
  { id: 'U030', executiveArea: 'Product', unitSegment: 'Product', name: 'Emily Davis', teams: ['Underwriting'], roles: ['Business Unit Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U031', executiveArea: 'Product', unitSegment: 'Aviation', name: 'Tim Hewer', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U032', executiveArea: 'Product', unitSegment: 'Marine', name: 'Wesley Zeliff', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U036', executiveArea: 'Product', unitSegment: 'Parametric', name: 'Erick Davidson', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U045', executiveArea: 'Product', unitSegment: 'Marine', name: 'Daniel Okoro', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U049', executiveArea: 'Product', unitSegment: 'Aviation', name: 'Karen Whitfield', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  // Financial Lines
  { id: 'U037', executiveArea: 'Financial Lines', unitSegment: 'Financial Lines', name: 'Levi Mayer', teams: ['Underwriting'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U050', executiveArea: 'Financial Lines', unitSegment: 'Financial Lines', name: 'Greg Patel', teams: ['Underwriting'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
  // Risk Management
  { id: 'U039', executiveArea: 'Risk Management', unitSegment: 'Risk Management', name: 'Atilla Kerenyi', teams: ['Management'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U040', executiveArea: 'Risk Management', unitSegment: 'Risk Management', name: 'Nick Dimuzio', teams: ['Management'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U041', executiveArea: 'Risk Management', unitSegment: 'Risk Management', name: 'Kathy Garrigan', teams: ['Management'], roles: ['Executive Area Lead'], access: 'Contributor', status: 'Active' },
  { id: 'U051', executiveArea: 'Risk Management', unitSegment: 'Risk Management', name: 'Monica Ivanova', teams: ['Management'], roles: ['UW Contributor'], access: 'Contributor', status: 'Active' },
];

const allTeams = ['Admin', 'CAT', 'Claim', 'Finance', 'Management', 'Underwriting'];

const teamRoleMap: Record<string, string[]> = {
  'Admin': ['Administrator'],
  'CAT': ['CAT Contributor'],
  'Claim': ['Event Coordinator'],
  'Finance': ['Finance Contributor'],
  'Management': ['Reader', 'Executive Area Lead', 'UW Contributor'],
  'Underwriting': ['Executive Area Lead', 'Business Unit Lead', 'UW Contributor'],
};

const roleToAccess: Record<string, string> = {
  'Administrator': 'Admin',
  'Event Coordinator': 'Contributor',
  'Finance Contributor': 'Contributor',
  'CAT Contributor': 'Contributor',
  'UW Contributor': 'Contributor',
  'Business Unit Lead': 'Contributor',
  'Executive Area Lead': 'Contributor',
  'Reader': 'Reader',
};

const accessRank: Record<string, number> = {
  'Admin': 4,
  'Contributor': 2,
  'Reader': 1,
};

const roleInfo: Record<string, { description: string; permissions: string[] }> = {
  'Administrator': {
    description: 'Full system access. Read/edit all modules and units. Global admin override, emergency unlock/lock.',
    permissions: ['Read All', 'Edit All Modules', 'Lock/Unlock', 'Reopen', 'Approve', 'Admin Override'],
  },
  'Event Coordinator': {
    description: 'All units (read). Edits Overview & Finance. Creates/modifies events, updates & locks estimates.',
    permissions: ['Read All', 'Edit Finance', 'Edit CAT', 'Edit UW', 'Lock Estimates', 'Reopen'],
  },
  'Finance Contributor': {
    description: 'All units (read). Edits Overview & Finance. Creates/modifies events, updates & locks estimates.',
    permissions: ['Read All', 'Edit Finance', 'Edit CAT', 'Edit UW', 'Lock Estimates', 'Reopen'],
  },
  'CAT Contributor': {
    description: 'All units (read). Edits CAT module. Uploads CAT data, locks/unlocks CAT.',
    permissions: ['Read All', 'Edit CAT'],
  },
  'Business Unit Lead': {
    description: 'Scoped to own Business Unit only. Read-only view of own BU data. Assigns tasks, approves estimates within own BU scope.',
    permissions: ['Read Own BU', 'Edit UW (own BU)', 'Reopen (own BU)', 'Approve (own BU)'],
  },
  'Executive Area Lead': {
    description: 'Reads across all BUs within own Executive Area. Assigns tasks, approves estimates scoped to own Executive Area domain.',
    permissions: ['Read All BUs in Exec Area', 'Edit UW (Exec Area)', 'Reopen (Exec Area)', 'Approve (Exec Area)'],
  },
  'UW Contributor': {
    description: 'Scoped to Unit/Segment. Reads UW + granted permissions. Uploads UW loss data within profit center scope.',
    permissions: ['Edit UW'],
  },
  'Reader': {
    description: 'All units (read-only). No edit permissions. View-only access across all modules.',
    permissions: ['Read All'],
  },
};

/** Derive highest access from an array of roles */
function deriveAccess(roles: string[]): string {
  if (roles.length === 0) return 'Reader';
  let highest = 'Reader';
  for (const r of roles) {
    const a = roleToAccess[r] || 'Reader';
    if ((accessRank[a] || 0) > (accessRank[highest] || 0)) highest = a;
  }
  return highest;
}

/** Get combined roles across multiple teams */
function getAvailableRoles(selectedTeams: string[]): string[] {
  const roleSet = new Set<string>();
  for (const t of selectedTeams) {
    const roles = teamRoleMap[t] || [];
    roles.forEach(r => roleSet.add(r));
  }
  return Array.from(roleSet);
}

export function UsersDirectory() {
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<User[]>(mockUsers);

  // Modal state
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editTeams, setEditTeams] = useState<string[]>([]);
  const [editRoles, setEditRoles] = useState<string[]>([]);

  const filteredUsers = users.filter(user =>
    searchQuery === '' ||
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const accessBadgeColor = (access: string) => {
    switch (access) {
      case 'Admin': return 'bg-red-100 text-red-700';
      case 'Contributor': return 'bg-blue-50 text-blue-700';
      case 'Reader': return 'bg-slate-100 text-slate-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setEditTeams([...user.teams]);
    setEditRoles([...user.roles]);
  };

  const closeModal = () => {
    setEditingUser(null);
    setEditTeams([]);
    setEditRoles([]);
  };

  const toggleTeam = (team: string) => {
    setEditTeams(prev => {
      const next = prev.includes(team)
        ? prev.filter(t => t !== team)
        : prev.length < 2
          ? [...prev, team]
          : prev; // max 2
      // Remove roles that are no longer valid for selected teams
      const validRoles = getAvailableRoles(next);
      setEditRoles(prevR => prevR.filter(r => validRoles.includes(r)));
      return next;
    });
  };

  const toggleRole = (role: string) => {
    setEditRoles(prev =>
      prev.includes(role)
        ? prev.filter(r => r !== role)
        : [...prev, role]
    );
  };

  const saveChanges = () => {
    if (!editingUser || editTeams.length === 0 || editRoles.length === 0) return;
    const newAccess = deriveAccess(editRoles);
    setUsers(prev => prev.map(u =>
      u.id === editingUser.id
        ? { ...u, teams: editTeams, roles: editRoles, access: newAccess }
        : u
    ));
    closeModal();
  };

  const availableRoles = getAvailableRoles(editTeams);
  const derivedAccess = deriveAccess(editRoles);
  const hasChanges = editingUser && (
    JSON.stringify(editTeams.sort()) !== JSON.stringify([...editingUser.teams].sort()) ||
    JSON.stringify(editRoles.sort()) !== JSON.stringify([...editingUser.roles].sort())
  );

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-8 py-6 border-b border-slate-200 bg-white">
        <h1 className="text-2xl font-semibold text-slate-900">Users</h1>
      </div>

      {/* Search Bar */}
      <div className="px-8 py-4 bg-white border-b border-slate-200">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto bg-white px-8">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Executive Area</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Business Unit Lead / Segment Lead</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Employee Name</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Team</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Role</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Access</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900">Status</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-slate-900 w-12"></th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr
                  key={user.id}
                  className="border-b border-slate-100 hover:bg-slate-50 transition-colors"
                >
                  <td className="py-3 px-4 text-sm text-slate-900">{user.executiveArea}</td>
                  <td className="py-3 px-4 text-sm text-slate-900">{user.unitSegment}</td>
                  <td className="py-3 px-4 text-sm font-medium text-slate-900">{user.name}</td>
                  <td className="py-3 px-4">
                    <div className="flex flex-wrap gap-1">
                      {user.teams.map(t => (
                        <span key={t} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-700">
                          {t}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-wrap gap-1">
                      {user.roles.map(r => (
                        <span key={r} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700">
                          {r}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${accessBadgeColor(user.access)}`}>
                      {user.access}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      user.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => openEditModal(user)}
                      className="p-1.5 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                      title="Edit team & role"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ─── Edit Modal ─── */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={closeModal} />

          {/* Modal — larger */}
          <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto border border-slate-200">
            {/* Header */}
            <div className="px-8 py-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white flex items-center justify-between sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">
                  {editingUser.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">{editingUser.name}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{editingUser.executiveArea} &middot; {editingUser.unitSegment}</p>
                </div>
              </div>
              <button onClick={closeModal} className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current assignment */}
            <div className="px-8 py-4 bg-slate-50 border-b border-slate-200">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block mb-2">Current Assignment</span>
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-500">Teams:</span>
                  {editingUser.teams.map(t => (
                    <span key={t} className="text-xs text-slate-700 bg-white px-2.5 py-1 rounded border border-slate-200">{t}</span>
                  ))}
                </div>
                <span className="text-slate-300 text-lg">&rarr;</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-500">Roles:</span>
                  {editingUser.roles.map(r => (
                    <span key={r} className="text-xs text-blue-700 bg-blue-50 px-2.5 py-1 rounded border border-blue-200">{r}</span>
                  ))}
                </div>
                <span className="text-slate-300 text-lg">&rarr;</span>
                <span className={`text-xs px-2.5 py-1 rounded-full ${accessBadgeColor(editingUser.access)}`}>{editingUser.access}</span>
              </div>
            </div>

            {/* Step 1: Select Teams (up to 2) */}
            <div className="px-8 py-5 border-b border-slate-100">
              <div className="flex items-center gap-2.5 mb-4">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center flex-shrink-0">1</span>
                <span className="text-sm font-semibold text-slate-800">Team</span>
                <span className="text-xs text-slate-400 ml-1">(select up to 2)</span>
              </div>
              <div className="ml-8 flex flex-wrap gap-2">
                {allTeams.map(t => {
                  const isSelected = editTeams.includes(t);
                  const isDisabled = !isSelected && editTeams.length >= 2;
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => !isDisabled && toggleTeam(t)}
                      disabled={isDisabled}
                      className={`px-4 py-2 rounded-lg border text-sm transition-all flex items-center gap-2 ${
                        isSelected
                          ? 'bg-blue-50 border-blue-400 text-blue-700 ring-2 ring-blue-200'
                          : isDisabled
                            ? 'bg-slate-50 border-slate-200 text-slate-300 cursor-not-allowed'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5" />}
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Assign Roles (multi-select) */}
            <div className="px-8 py-5 border-b border-slate-100">
              <div className="flex items-center gap-2.5 mb-4">
                <span className={`w-6 h-6 rounded-full text-xs flex items-center justify-center flex-shrink-0 ${editRoles.length > 0 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>2</span>
                <span className="text-sm font-semibold text-slate-800">Role</span>
                <span className="text-xs text-slate-400 ml-1">(select one or more)</span>
              </div>
              {editTeams.length === 0 ? (
                <div className="ml-8 py-6 text-center text-sm text-slate-400 bg-slate-50 rounded-lg border border-dashed border-slate-200">
                  Select at least one team first
                </div>
              ) : (
                <div className="ml-8 space-y-2 max-h-72 overflow-y-auto pr-1">
                  {availableRoles.map(role => {
                    const info = roleInfo[role];
                    const isSelected = editRoles.includes(role);
                    const access = roleToAccess[role] || 'Reader';
                    return (
                      <button
                        key={role}
                        type="button"
                        onClick={() => toggleRole(role)}
                        className={`w-full text-left px-4 py-3 rounded-lg border transition-all ${
                          isSelected
                            ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-200'
                            : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {/* Checkbox */}
                          <div className={`w-4.5 h-4.5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                            isSelected ? 'bg-blue-600 border-blue-600' : 'border-slate-300'
                          }`}>
                            {isSelected && <Check className="w-3 h-3 text-white" />}
                          </div>

                          <span className={`text-sm ${isSelected ? 'text-blue-800 font-medium' : 'text-slate-800'}`}>{role}</span>
                          <span className={`text-[11px] px-2 py-0.5 rounded ${
                            access === 'Admin' ? 'bg-red-100 text-red-600' :
                            access === 'Contributor' ? 'bg-blue-100 text-blue-600' :
                            'bg-slate-100 text-slate-500'
                          }`}>
                            {access}
                          </span>
                        </div>
                        {info && (
                          <p className="text-xs text-slate-400 mt-1.5 ml-7 leading-relaxed">{info.description}</p>
                        )}
                        {info && isSelected && (
                          <div className="flex flex-wrap gap-1.5 mt-2 ml-7">
                            {info.permissions.map(p => (
                              <span key={p} className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-600 border border-blue-200">
                                {p}
                              </span>
                            ))}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Auto-Derived Access Summary */}
            <div className="px-8 py-4 bg-slate-50">
              <div className="flex items-center gap-2.5 mb-3">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span className="text-sm font-semibold text-slate-700">Derived Access Summary</span>
              </div>
              <div className="ml-6 flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Teams:</span>
                  {editTeams.length > 0 ? editTeams.map(t => (
                    <span key={t} className="text-xs text-slate-700 bg-white px-2.5 py-1 rounded border border-slate-200">{t}</span>
                  )) : (
                    <span className="text-xs text-slate-300 italic">none</span>
                  )}
                </div>
                <span className="text-slate-300 text-lg">&rarr;</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Roles:</span>
                  {editRoles.length > 0 ? editRoles.map(r => (
                    <span key={r} className="text-xs text-blue-700 bg-blue-50 px-2.5 py-1 rounded border border-blue-200">{r}</span>
                  )) : (
                    <span className="text-xs text-slate-300 italic">none</span>
                  )}
                </div>
                <span className="text-slate-300 text-lg">&rarr;</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Access:</span>
                  <span className={`text-xs px-2.5 py-1 rounded-full ${accessBadgeColor(derivedAccess)}`}>{derivedAccess}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-5 border-t border-slate-200 bg-white flex items-center justify-between sticky bottom-0">
              <button
                onClick={closeModal}
                className="px-5 py-2.5 text-sm text-slate-600 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <div className="flex items-center gap-3">
                {hasChanges && (
                  <span className="text-xs text-amber-600 bg-amber-50 px-3 py-1 rounded border border-amber-200">
                    Unsaved changes
                  </span>
                )}
                <button
                  onClick={saveChanges}
                  disabled={!hasChanges || editTeams.length === 0 || editRoles.length === 0}
                  className={`px-5 py-2.5 text-sm rounded-lg transition-colors flex items-center gap-2 ${
                    hasChanges && editTeams.length > 0 && editRoles.length > 0
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}