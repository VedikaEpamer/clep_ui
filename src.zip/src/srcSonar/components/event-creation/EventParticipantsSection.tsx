import { useState } from 'react';
import { ClipboardList, ChevronDown, ChevronRight } from 'lucide-react';

interface Recipient {
  name: string;
  region?: string;
  task: string | null;
  indent?: boolean;
  status?: 'Not Started' | 'In Progress' | 'Completed' | 'Pending Review';
}

interface TeamGroup {
  section: string;
  members: Recipient[];
}

const participantGroups: TeamGroup[] = [
  {
    section: 'Group Underwriting',
    members: [
      { name: 'Reena Boltax', task: null },
      { name: 'Chris Downey', task: null },
    ],
  },
  {
    section: 'Finance',
    members: [
      { name: 'Clem Demetz', task: 'Financial impact analysis' },
      { name: 'Nigel Smith', task: 'Financial impact analysis' },
      { name: 'Tim Ritter', task: 'Financial impact analysis' },
    ],
  },
  {
    section: 'Claims',
    members: [
      { name: 'Andrew McBride', task: null },
      { name: 'Lope Garcia', task: 'Create event backup' },
      { name: 'Tim Carter', task: 'Create event backup', indent: true },
      { name: 'James Parker', task: 'Create event backup', indent: true },
      { name: 'Barbara Toro', task: 'Create event backup', indent: true },
      { name: 'Patricia McMahon', task: 'Create event backup', indent: true },
    ],
  },
  {
    section: 'Risk Management',
    members: [
      { name: 'Atilla Kerenyi', task: null },
      { name: 'Nick Dimuzio', task: null },
      { name: 'Kathy Garrigan', task: null },
    ],
  },
  {
    section: 'Cat Modeling',
    members: [
      { name: 'Neil Schwarzenberger', task: 'Cat modeling loss estimation and NET calculations', status: 'In Progress' },
      { name: 'Huy Hong', task: 'Cat modeling loss estimation and NET calculations', status: 'Not Started' },
    ],
  },
  {
    section: 'Underwriting Leadership',
    members: [
      { name: 'Jill Beggs', region: 'CUO', task: null },
      // Mike Cellura - Facultative
      { name: 'Mike Cellura', region: 'Facultative', task: 'Review & approve loss estimates', status: 'Pending Review' },
      { name: 'Juan Delgado', region: 'Facultative', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Nicholas Pozzebon', region: 'Facultative', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      // Artur Klinger - International Treaty
      { name: 'Artur Klinger', region: 'International Treaty', task: 'Review & approve loss estimates', status: 'Pending Review' },
      { name: 'Harad Jacobsen', region: 'Zurich/Dublin', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Rui Marliere', region: 'Latam', task: 'Regional loss estimation', indent: true, status: 'In Progress' },
      { name: 'Mark Wallace', region: 'London', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Melissa Ford', region: 'Middle East', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Kevin Bogardus', region: 'Singapore', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      // Jiten Voralia - North America Treaty
      { name: 'Jiten Voralia', region: 'North America Treaty', task: 'Review & approve loss estimates', status: 'Pending Review' },
      { name: 'Peter Bell', region: 'Bermuda', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Scott Paddington', region: 'Canada', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Mayur Doshi', region: 'Treaty Casualty', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Chuck Volker', region: 'Treaty Property', task: 'Regional loss estimation', indent: true, status: 'In Progress' },
      // Emily Davis - Product
      { name: 'Emily Davis', region: 'Product', task: 'Review & approve loss estimates', status: 'Pending Review' },
      { name: 'Tim Hewer', region: 'Aviation', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      { name: 'Wesley Zeliff', region: 'Marine', task: 'Regional loss estimation', indent: true, status: 'Not Started' },

      { name: 'Erick Davidson', region: 'Parametric', task: 'Regional loss estimation', indent: true, status: 'Not Started' },
      // Levi Mayer - Financial Lines
      { name: 'Levi Mayer', region: 'Financial Lines', task: 'Review & approve loss estimates', status: 'Pending Review' },

    ],
  },
];

const totalRecipients = participantGroups.reduce((sum, g) => sum + g.members.length, 0);

function StatusBadge({ status }: { status?: string }) {
  if (!status) return <span className="text-xs text-gray-300">—</span>;
  const styles =
    status === 'Completed' ? 'bg-green-100 text-green-700 border border-green-200' :
    status === 'In Progress' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
    status === 'Pending Review' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
    'bg-gray-100 text-gray-500 border border-gray-200';
  return <span className={`text-xs px-2 py-0.5 rounded ${styles}`}>{status}</span>;
}

function CollapsibleSection({ group }: { group: TeamGroup }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border-b border-gray-200 last:border-b-0">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-4 py-2.5 bg-slate-50/80 hover:bg-slate-100 transition-colors text-left cursor-pointer"
      >
        {open ? (
          <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
        )}
        <span className="text-sm text-gray-900" style={{ fontWeight: 600 }}>{group.section}</span>
        <span className="text-xs text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full ml-1">
          {group.members.length}
        </span>
      </button>
      {open && (
        <table className="w-full text-sm">
          <tbody>
            {group.members.map((person, idx) => (
              <tr
                key={`${person.name}-${person.region || idx}`}
                className={`border-t border-gray-100 hover:bg-gray-50/50 ${idx === group.members.length - 1 ? '' : ''}`}
              >
                <td className="px-4 py-2 pl-10 text-gray-900 w-[28%]" style={{ fontWeight: person.indent ? 400 : 500 }}>
                  <span className={person.indent ? 'pl-5 text-gray-700' : ''}>
                    {person.indent && <span className="text-gray-300 mr-1.5">└</span>}
                    {person.name}
                  </span>
                </td>
                <td className="px-4 py-2 w-[15%]">
                  {person.region ? (
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      !person.indent
                        ? 'bg-slate-200 text-slate-700'
                        : 'bg-gray-100 text-gray-600'
                    }`} style={{ fontWeight: person.indent ? 400 : 600 }}>
                      {person.region}
                    </span>
                  ) : (
                    <span className="text-xs text-gray-300">—</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {person.task ? (
                    <span className="text-xs text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                      {person.task}
                    </span>
                  ) : (
                    <span className="text-xs text-gray-400">Notification only</span>
                  )}
                </td>
                <td className="px-4 py-2 w-[130px]">
                  <StatusBadge status={person.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export function EventParticipantsSection() {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b bg-gray-50">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded flex items-center justify-center text-sm border bg-blue-600 text-white border-blue-600" style={{ fontWeight: 500 }}>
            6
          </div>
          <div className="flex items-center gap-2">
            <h3 className="text-base text-gray-900">Event Notification Recipients</h3>
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">{totalRecipients} people</span>
          </div>
        </div>
      </div>

      {/* Column headers */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="flex text-xs text-gray-500 px-4 py-2.5">
          <div className="w-[28%] pl-6" style={{ fontWeight: 600 }}>Name</div>
          <div className="w-[15%]" style={{ fontWeight: 600 }}>Region</div>
          <div className="flex-1" style={{ fontWeight: 600 }}>
            <span className="flex items-center gap-1">
              <ClipboardList className="w-3 h-3" />
              Task
            </span>
          </div>
          <div className="w-[130px]" style={{ fontWeight: 600 }}>Status</div>
        </div>
      </div>

      {/* Collapsible sections */}
      <div>
        {participantGroups.map((group) => (
          <CollapsibleSection key={group.section} group={group} />
        ))}
      </div>
    </div>
  );
}