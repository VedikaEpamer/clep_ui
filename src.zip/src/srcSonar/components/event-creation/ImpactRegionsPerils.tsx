import { useState, useMemo, useRef, useEffect } from 'react';
import { X, ChevronDown, Check, Search, Trash2 } from 'lucide-react';

interface ImpactRegionsPerilsProps {
  data: any;
  onChange: (data: any) => void;
  showValidation?: boolean;
  validationErrors?: string[];
  isEventPublished?: boolean;
}

// ---------- Parsed RDM Country Code hierarchy ----------
interface CodeEntry { code: string; label: string; }

const RAW_CODES: CodeEntry[] = [
  { code: 'A00', label: 'ASIA' },
  { code: 'A10', label: 'NORTHEAST ASIA' },
  { code: 'A11', label: 'CHINA' },
  { code: 'A12', label: 'HONG KONG' },
  { code: 'A13', label: 'JAPAN' },
  { code: 'A14', label: 'MACAU' },
  { code: 'A15', label: 'MONGOLIA' },
  { code: 'A16', label: 'NORTH KOREA' },
  { code: 'A17', label: 'SOUTH KOREA' },
  { code: 'A18', label: 'TAIWAN' },
  { code: 'A20', label: 'SOUTHEAST ASIA' },
  { code: 'A21', label: 'BRUNEI' },
  { code: 'A22', label: 'MYANMAR' },
  { code: 'A23', label: 'CAMBODIA' },
  { code: 'A24', label: 'INDONESIA' },
  { code: 'A25', label: 'KAMPUCHEA, DEMOCRATIC RE' },
  { code: 'A26', label: 'LAOS' },
  { code: 'A27', label: 'MALAYSIA' },
  { code: 'A28', label: 'PHILIPPINES' },
  { code: 'A29', label: 'SINGAPORE' },
  { code: 'A2A', label: 'THAILAND' },
  { code: 'A2B', label: 'VIETNAM' },
  { code: 'A30', label: 'WEST ASIA' },
  { code: 'A31', label: 'AFGHANISTAN' },
  { code: 'A32', label: 'ARMENIA' },
  { code: 'A33', label: 'AZERBAIJAN' },
  { code: 'A34', label: 'BANGLADESH' },
  { code: 'A35', label: 'GEORGIA (ASIA)' },
  { code: 'A36', label: 'INDIA' },
  { code: 'A37', label: 'KAZAKSTAN' },
  { code: 'A38', label: 'KYRGYZSTAN' },
  { code: 'A39', label: 'MALDIVES' },
  { code: 'A3A', label: 'NEPAL' },
  { code: 'A3B', label: 'PAKISTAN' },
  { code: 'A3C', label: 'SRI LANKA' },
  { code: 'A3D', label: 'TURKMENISTAN' },
  { code: 'A3E', label: 'UZBEKISTAN' },
  { code: 'A3F', label: 'TAJIKISTAN' },
  { code: 'A40', label: 'PACIFIC ASIA' },
  { code: 'A41', label: 'FIJI' },
  { code: 'A42', label: 'GUAM' },
  { code: 'A43', label: 'MICRONESIA' },
  { code: 'A44', label: 'PAPUA NEW GUINEA' },
  { code: 'C00', label: 'CANADA' },
  { code: 'C10', label: 'MARITIME PROVINCES' },
  { code: 'C11', label: 'NEW BRUNSWICK' },
  { code: 'C12', label: 'NEWFOUNDLAND' },
  { code: 'C13', label: 'NOVA SCOTIA' },
  { code: 'C14', label: 'PRINCE EDWARD ISLAND' },
  { code: 'C20', label: 'WESTERN CANADIAN PROVS' },
  { code: 'C21', label: 'ALBERTA' },
  { code: 'C22', label: 'BRITISH COLUMBIA' },
  { code: 'C23', label: 'MANITOBA' },
  { code: 'C24', label: 'NORTHWEST TERRITORY' },
  { code: 'C25', label: 'SASKATCHEWAN' },
  { code: 'C26', label: 'YUKON TERRITORY' },
  { code: 'C27', label: 'NUNAVUT' },
  { code: 'C30', label: 'CENTRAL CANADIAN PROVS' },
  { code: 'C31', label: 'ONTARIO' },
  { code: 'C32', label: 'QUEBEC' },
  { code: 'D00', label: 'NORTH AMERICA' },
  { code: 'D10', label: 'NORTH AMERICA EXC MEXICO' },
  { code: 'E00', label: 'EUROPE' },
  { code: 'E10', label: 'CENTRAL EUROPE' },
  { code: 'E11', label: 'AUSTRIA' },
  { code: 'E12', label: 'CZECH REPUBLIC' },
  { code: 'E13', label: 'GERMANY' },
  { code: 'E14', label: 'HUNGARY' },
  { code: 'E15', label: 'POLAND' },
  { code: 'E16', label: 'SLOVAKIA' },
  { code: 'E20', label: 'EASTERN EUROPE' },
  { code: 'E21', label: 'BELARUS' },
  { code: 'E22', label: 'ESTONIA' },
  { code: 'E23', label: 'LATVIA' },
  { code: 'E24', label: 'LITHUANIA' },
  { code: 'E25', label: 'RUSSIA' },
  { code: 'E26', label: 'UKRAINE' },
  { code: 'E30', label: 'NORTH EUROPE' },
  { code: 'E31', label: 'DENMARK' },
  { code: 'E32', label: 'FAEROE ISLANDS' },
  { code: 'E33', label: 'FINLAND' },
  { code: 'E34', label: 'NETHERLANDS' },
  { code: 'E35', label: 'NORWAY' },
  { code: 'E36', label: 'SWEDEN' },
  { code: 'E40', label: 'SOUTH EUROPE' },
  { code: 'E41', label: 'ALBANIA' },
  { code: 'E42', label: 'ANDORRA' },
  { code: 'E43', label: 'BOSNIA-HERZEGOVINA' },
  { code: 'E44', label: 'BULGARIA' },
  { code: 'E45', label: 'CROATIA' },
  { code: 'E46', label: 'CYPRUS' },
  { code: 'E47', label: 'GIBRALTAR' },
  { code: 'E48', label: 'GREECE' },
  { code: 'E49', label: 'ITALY' },
  { code: 'E4A', label: 'MACEDONIA' },
  { code: 'E4B', label: 'MALTA' },
  { code: 'E4C', label: 'MOLDOVA' },
  { code: 'E4D', label: 'MONACO' },
  { code: 'E4E', label: 'PORTUGAL' },
  { code: 'E4F', label: 'ROMANIA' },
  { code: 'E4G', label: 'SAN MARINO' },
  { code: 'E4H', label: 'SLOVENIA' },
  { code: 'E4I', label: 'SPAIN' },
  { code: 'E4J', label: 'VATICAN CITY' },
  { code: 'E4K', label: 'MONTENEGRO' },
  { code: 'E4L', label: 'SERBIA' },
  { code: 'E4M', label: 'KOSOVO' },
  { code: 'E50', label: 'WEST EUROPE' },
  { code: 'E51', label: 'BELGIUM' },
  { code: 'E52', label: 'FRANCE' },
  { code: 'E53', label: 'IRELAND' },
  { code: 'E54', label: 'LIECHTENSTEIN' },
  { code: 'E55', label: 'LUXEMBOURG' },
  { code: 'E56', label: 'SWITZERLAND' },
  { code: 'E57', label: 'UNITED KINGDOM' },
  { code: 'E58', label: 'BAILIWICK OF GUERNSEY' },
  { code: 'E59', label: 'ISLE OF MAN' },
  { code: 'F00', label: 'AFRICA' },
  { code: 'F10', label: 'CENTRAL AFRICAN CONTINENT' },
  { code: 'F11', label: 'ANGOLA' },
  { code: 'F12', label: 'CAMEROON' },
  { code: 'F13', label: 'CENTRAL AFRICAN REPUBLIC' },
  { code: 'F14', label: 'CONGO' },
  { code: 'F15', label: 'EQUATORIAL GUINEA' },
  { code: 'F16', label: 'GABON' },
  { code: 'F17', label: 'MALAWI' },
  { code: 'F18', label: 'SAO TOME & PRINCIPE' },
  { code: 'F19', label: 'DEMOCRATIC REPUBLIC OF CONGO' },
  { code: 'F1A', label: 'ZAMBIA' },
  { code: 'F20', label: 'EAST AFRICAN CONTINENT' },
  { code: 'F21', label: 'BURUNDI' },
  { code: 'F22', label: 'DJIBOUTI' },
  { code: 'F23', label: 'ERITREA' },
  { code: 'F24', label: 'ETHIOPIA' },
  { code: 'F25', label: 'KENYA' },
  { code: 'F26', label: 'RWANDA' },
  { code: 'F27', label: 'SOMALIA' },
  { code: 'F28', label: 'SUDAN' },
  { code: 'F29', label: 'TANZANIA' },
  { code: 'F2A', label: 'UGANDA' },
  { code: 'F2B', label: 'SOUTH SUDAN' },
  { code: 'F30', label: 'NORTH AFRICAN CONTINENT' },
  { code: 'F31', label: 'ALGERIA' },
  { code: 'F32', label: 'CHAD' },
  { code: 'F33', label: 'LIBYA' },
  { code: 'F34', label: 'MALI' },
  { code: 'F35', label: 'MAURITANIA' },
  { code: 'F36', label: 'MOROCCO' },
  { code: 'F37', label: 'NIGER' },
  { code: 'F38', label: 'TUNISIA' },
  { code: 'F39', label: 'WESTERN SAHARA' },
  { code: 'F40', label: 'SOUTH AFRICAN CONTINENT' },
  { code: 'F41', label: 'BOTSWANA' },
  { code: 'F42', label: 'LESOTHO' },
  { code: 'F43', label: 'MOZAMBIQUE' },
  { code: 'F44', label: 'NAMIBIA' },
  { code: 'F45', label: 'SOUTH AFRICA - REPUBLIC' },
  { code: 'F46', label: 'SWAZILAND' },
  { code: 'F47', label: 'ZIMBABWE' },
  { code: 'F50', label: 'WEST AFRICAN CONTINENT' },
  { code: 'F51', label: 'BENIN' },
  { code: 'F52', label: 'BURKINA FASO' },
  { code: 'F53', label: 'GAMBIA' },
  { code: 'F54', label: 'GHANA' },
  { code: 'F55', label: 'GUINEA' },
  { code: 'F56', label: 'GUINEA-BISSAU' },
  { code: 'F57', label: 'IVORY COAST' },
  { code: 'F58', label: 'LIBERIA' },
  { code: 'F59', label: 'NIGERIA' },
  { code: 'F5A', label: 'SENEGAL' },
  { code: 'F5B', label: 'SIERRA LEONE' },
  { code: 'F5C', label: 'TOGO' },
  { code: 'F60', label: 'MISC AFRICAN ISLANDS' },
  { code: 'F61', label: 'CANARY ISLANDS' },
  { code: 'F62', label: 'CAPE VERDE' },
  { code: 'F63', label: 'COMOROS ISLANDS' },
  { code: 'F64', label: 'MADAGASCAR' },
  { code: 'F65', label: 'MADEIRA ISLANDS' },
  { code: 'F66', label: 'MAURITIUS' },
  { code: 'F67', label: 'REUNION' },
  { code: 'F68', label: 'SEYCHELLES' },
  { code: 'F69', label: 'SUB-SAHARAN AFRICA' },
  { code: 'I00', label: 'ISLANDS' },
  { code: 'I10', label: 'ATLANTIC OCEAN ISLANDS' },
  { code: 'I11', label: 'BERMUDA' },
  { code: 'I12', label: 'BOUVET ISLAND' },
  { code: 'I13', label: 'FALKLAND ISLANDS' },
  { code: 'I14', label: 'GREENLAND' },
  { code: 'I15', label: 'ICELAND' },
  { code: 'I16', label: 'ST PIERRE & MIQUEON' },
  { code: 'I17', label: 'ST HELENA' },
  { code: 'I20', label: 'INDIAN OCEAN ISLANDS' },
  { code: 'I21', label: 'BRITISH INDIAN OCEAN TER' },
  { code: 'I22', label: 'CHRISTMAS ISLAND' },
  { code: 'I23', label: 'COCOS ISLANDS' },
  { code: 'I24', label: 'HEARD & MCDONALD ISLANDS' },
  { code: 'I30', label: 'PACIFIC OCEAN ISLANDS' },
  { code: 'I31', label: 'AMERICAN SAMOA' },
  { code: 'I32', label: 'BHUTAN' },
  { code: 'I33', label: 'CANTON & ENDERBURY ISLANDS' },
  { code: 'I34', label: 'COOK ISLANDS' },
  { code: 'I35', label: 'EAST TIMOR / TIMOR-LESTE' },
  { code: 'I36', label: 'FRENCH POLYNESIA' },
  { code: 'I37', label: 'JOHNSTON ISLANDS' },
  { code: 'I38', label: 'MARSHALL ISLANDS' },
  { code: 'I39', label: 'NAURU' },
  { code: 'I3A', label: 'NEW CALEDONIA' },
  { code: 'I3B', label: 'NIUE' },
  { code: 'I3C', label: 'NORFOLK ISLANDS' },
  { code: 'I3D', label: 'NORTHERN MARIANA ISLANDS' },
  { code: 'I3E', label: 'PALAU' },
  { code: 'I3F', label: 'PITCAIRN ISLANDS' },
  { code: 'I3G', label: 'SOLOMON ISLANDS' },
  { code: 'I3H', label: 'TOKELAU' },
  { code: 'I3I', label: 'TONGA' },
  { code: 'I3J', label: 'TRUST TERRITORY' },
  { code: 'I3K', label: 'TUVALU' },
  { code: 'I3L', label: 'US MINOR OUTLYING ISLAND' },
  { code: 'I3M', label: 'VANUATU' },
  { code: 'I3N', label: 'WALLIS & FUTUNA ISLANDS' },
  { code: 'I3O', label: 'SAMOA' },
  { code: 'I3P', label: 'KIRIBATI' },
  { code: 'I40', label: 'ARCTIC OCEAN ISLANDS' },
  { code: 'I41', label: 'SVALBARD & JAN MAYEN' },
  { code: 'L00', label: 'LATIN AMERICA' },
  { code: 'L10', label: 'SOUTH AMERICA' },
  { code: 'L11', label: 'ARGENTINA' },
  { code: 'L12', label: 'BOLIVIA' },
  { code: 'L13', label: 'BRAZIL' },
  { code: 'L14', label: 'CHILE' },
  { code: 'L15', label: 'COLOMBIA' },
  { code: 'L16', label: 'ECUADOR' },
  { code: 'L17', label: 'FRENCH GUIANA' },
  { code: 'L18', label: 'GUYANA' },
  { code: 'L19', label: 'PARAGUAY' },
  { code: 'L1A', label: 'PERU' },
  { code: 'L1B', label: 'SURINAME' },
  { code: 'L1C', label: 'URUGUAY' },
  { code: 'L1D', label: 'VENEZUELA' },
  { code: 'L20', label: 'CENTRAL AMERICA' },
  { code: 'L21', label: 'BELIZE' },
  { code: 'L22', label: 'COSTA RICA' },
  { code: 'L23', label: 'EL SALVADOR' },
  { code: 'L24', label: 'GUATEMALA' },
  { code: 'L25', label: 'HONDURAS' },
  { code: 'L26', label: 'NICARAGUA' },
  { code: 'L27', label: 'PANAMA' },
  { code: 'L30', label: 'MEXICO' },
  { code: 'L40', label: 'CARIBBEAN ISLANDS' },
  { code: 'L41', label: 'ANTIGUA & BARBUDA' },
  { code: 'L42', label: 'ARUBA' },
  { code: 'L43', label: 'BAHAMAS' },
  { code: 'L44', label: 'BARBADOS' },
  { code: 'L45', label: 'BRITISH VIRGIN ISLANDS' },
  { code: 'L46', label: 'CAYMAN ISLANDS' },
  { code: 'L47', label: 'CUBA' },
  { code: 'L48', label: 'DOMINICA' },
  { code: 'L49', label: 'DOMINICAN REPUBLIC' },
  { code: 'L4A', label: 'GRENADA' },
  { code: 'L4B', label: 'GUADELOUPE' },
  { code: 'L4C', label: 'HAITI' },
  { code: 'L4D', label: 'JAMAICA' },
  { code: 'L4E', label: 'MARTINIQUE' },
  { code: 'L4F', label: 'MONTSERRAT' },
  { code: 'L4G', label: 'NETHERLANDS ANTILLES' },
  { code: 'L4H', label: 'PUERTO RICO' },
  { code: 'L4I', label: 'ST KITTS-NEVIS-ANGUI' },
  { code: 'L4J', label: 'ST LUCIA' },
  { code: 'L4K', label: 'ST VINCENT & GRENADINE' },
  { code: 'L4L', label: 'TRINIDAD & TOBAGO' },
  { code: 'L4M', label: 'TURKS & CAICOS ISLANDS' },
  { code: 'L4N', label: 'US VIRGIN ISLANDS' },
  { code: 'L4O', label: 'CURACAO' },
  { code: 'L4P', label: 'ST MAARTEN' },
  { code: 'M00', label: 'MIDDLE EAST' },
  { code: 'M11', label: 'BAHRAIN' },
  { code: 'M12', label: 'EGYPT' },
  { code: 'M13', label: 'IRAN' },
  { code: 'M14', label: 'IRAQ' },
  { code: 'M15', label: 'ISRAEL' },
  { code: 'M16', label: 'JORDAN' },
  { code: 'M17', label: 'KUWAIT' },
  { code: 'M18', label: 'LEBANON' },
  { code: 'M19', label: 'OMAN' },
  { code: 'M1A', label: 'QATAR' },
  { code: 'M1B', label: 'SAUDI ARABIA' },
  { code: 'M1C', label: 'SYRIA' },
  { code: 'M1D', label: 'TURKEY' },
  { code: 'M1E', label: 'UNITED ARAB EMIRATES' },
  { code: 'M1F', label: 'YEMEN' },
  { code: 'M1G', label: 'YEMEN - PEOPLES DEM REP' },
  { code: 'R00', label: 'OUTERSPACE' },
  { code: 'S00', label: 'OCEANS & SEAS' },
  { code: 'S01', label: 'MIDDLE EAST & CASPIAN SEA' },
  { code: 'S10', label: 'ANTARCTIC OCEAN' },
  { code: 'S20', label: 'ARCTIC OCEAN' },
  { code: 'S30', label: 'ATLANTIC OCEAN' },
  { code: 'S40', label: 'BALTIC SEA' },
  { code: 'S50', label: 'INDIAN OCEAN' },
  { code: 'S60', label: 'GULF OF MEXICO' },
  { code: 'S70', label: 'MEDITERRANEAN SEA' },
  { code: 'S80', label: 'NORTH SEA' },
  { code: 'S90', label: 'PACIFIC OCEAN' },
  { code: 'SA0', label: 'OTHER SEAS & OCEANS' },
  { code: 'T00', label: 'ANTARCTIC CONTINENT' },
  { code: 'T01', label: 'ANTARCTICA' },
  { code: 'T02', label: 'DRONNING MAUD ISLAND' },
  { code: 'U00', label: 'UNITED STATES' },
  { code: 'U10', label: 'NEW ENGLAND STATES' },
  { code: 'U11', label: 'CONNECTICUT' },
  { code: 'U12', label: 'MAINE' },
  { code: 'U13', label: 'MASSACHUSETTS' },
  { code: 'U14', label: 'NEW HAMPSHIRE' },
  { code: 'U15', label: 'NEW YORK' },
  { code: 'U16', label: 'RHODE ISLAND' },
  { code: 'U17', label: 'VERMONT' },
  { code: 'U20', label: 'MIDATLANTIC STATES' },
  { code: 'U21', label: 'DISTRICT OF COLUMBIA' },
  { code: 'U22', label: 'DELAWARE' },
  { code: 'U23', label: 'MARYLAND' },
  { code: 'U24', label: 'NEW JERSEY' },
  { code: 'U25', label: 'PENNSYLVANIA' },
  { code: 'U26', label: 'VIRGINIA' },
  { code: 'U27', label: 'WEST VIRGINIA' },
  { code: 'U30', label: 'SOUTHEASTERN STATES' },
  { code: 'U31', label: 'ALABAMA' },
  { code: 'U32', label: 'FLORIDA' },
  { code: 'U33', label: 'GEORGIA (US)' },
  { code: 'U34', label: 'LOUISIANA' },
  { code: 'U35', label: 'MISSISSIPPI' },
  { code: 'U36', label: 'NORTH CAROLINA' },
  { code: 'U37', label: 'SOUTH CAROLINA' },
  { code: 'U41', label: 'TEXAS' },
  { code: 'U50', label: 'MIDAMERICAN STATES' },
  { code: 'U51', label: 'ILLINOIS' },
  { code: 'U52', label: 'INDIANA' },
  { code: 'U53', label: 'KENTUCKY' },
  { code: 'U54', label: 'MICHIGAN' },
  { code: 'U55', label: 'OHIO' },
  { code: 'U56', label: 'TENNESSEE' },
  { code: 'U57', label: 'WISCONSIN' },
  { code: 'U60', label: 'MIDWESTERN STATES' },
  { code: 'U61', label: 'ARKANSAS' },
  { code: 'U62', label: 'IOWA' },
  { code: 'U63', label: 'KANSAS' },
  { code: 'U64', label: 'MINNESOTA' },
  { code: 'U65', label: 'MISSOURI' },
  { code: 'U66', label: 'NEBRASKA' },
  { code: 'U67', label: 'NORTH DAKOTA' },
  { code: 'U68', label: 'OKLAHOMA' },
  { code: 'U69', label: 'SOUTH DAKOTA' },
  { code: 'U70', label: 'WESTERN STATES' },
  { code: 'U71', label: 'ARIZONA' },
  { code: 'U72', label: 'COLORADO' },
  { code: 'U73', label: 'IDAHO' },
  { code: 'U74', label: 'MONTANA' },
  { code: 'U75', label: 'NEVADA' },
  { code: 'U76', label: 'NEW MEXICO' },
  { code: 'U77', label: 'UTAH' },
  { code: 'U78', label: 'WYOMING' },
  { code: 'U81', label: 'CALIFORNIA' },
  { code: 'U90', label: 'NORTHWESTERN STATES' },
  { code: 'U91', label: 'ALASKA' },
  { code: 'U92', label: 'OREGON' },
  { code: 'U93', label: 'WASHINGTON' },
  { code: 'UA1', label: 'HAWAII' },
  { code: 'W00', label: 'WORLDWIDE' },
  { code: 'W01', label: 'WORLDWIDE EX NORTH AMER' },
  { code: 'W02', label: 'WORLDWIDE EX US & CANADA' },
  { code: 'W03', label: 'WORLDWIDE EX US' },
  { code: 'X00', label: 'CONVERSION ONLY GROUP' },
  { code: 'X01', label: 'CONV ONLY - NORTH AMER' },
  { code: 'X02', label: 'CONV ONLY - NEUTRAL ZONE' },
  { code: 'X03', label: 'CONV ONLY - ADDITIONAL CODE' },
  { code: 'X04', label: 'CONV ONLY - TBA' },
  { code: 'Z00', label: 'AUSTRALIA / NEW ZEALAND' },
  { code: 'Z10', label: 'AUSTRALIA' },
  { code: 'Z20', label: 'NEW ZEALAND' },
  { code: 'Z30', label: 'WESTERN AUSTRALIA' },
];

// ---------- Hierarchy helpers ----------

const codeMap = new Map(RAW_CODES.map(e => [e.code, e]));

function isMainArea(code: string): boolean { return code.slice(1) === '00'; }
function isZone(code: string): boolean { return !isMainArea(code) && code.length === 3 && code[2] === '0'; }
function isCountry(code: string): boolean { return !isMainArea(code) && !isZone(code); }
function getMainAreaCode(code: string): string { return code[0] + '00'; }
function findZoneCode(code: string): string | null {
  const candidate = code.slice(0, 2) + '0';
  if (codeMap.has(candidate) && isZone(candidate)) return candidate;
  return null;
}

const broaderRiskZoneOptions = RAW_CODES.filter(e => isMainArea(e.code) && e.code !== 'W00');

function getZonesForArea(areaCode: string): CodeEntry[] {
  return RAW_CODES.filter(e => e.code[0] === areaCode[0] && isZone(e.code));
}
function getCountriesForZone(zoneCode: string): CodeEntry[] {
  return RAW_CODES.filter(e => isCountry(e.code) && findZoneCode(e.code) === zoneCode);
}
function getAllCountriesForArea(areaCode: string): CodeEntry[] {
  return RAW_CODES.filter(e => e.code[0] === areaCode[0] && isCountry(e.code));
}
function getZonesForAreas(areaCodes: string[]): CodeEntry[] {
  const prefixes = new Set(areaCodes.map(c => c[0]));
  return RAW_CODES.filter(e => prefixes.has(e.code[0]) && isZone(e.code));
}
function getCountriesForZones(zoneCodes: string[]): CodeEntry[] {
  const zoneSet = new Set(zoneCodes);
  return RAW_CODES.filter(e => {
    if (!isCountry(e.code)) return false;
    const z = findZoneCode(e.code);
    return z !== null && zoneSet.has(z);
  });
}
function getCountriesForAreas(areaCodes: string[]): CodeEntry[] {
  const prefixes = new Set(areaCodes.map(c => c[0]));
  return RAW_CODES.filter(e => prefixes.has(e.code[0]) && isCountry(e.code));
}

const allCountries = RAW_CODES.filter(e => isCountry(e.code) && e.code[0] !== 'W');
const worldwideOptions = RAW_CODES.filter(e => e.code[0] === 'W');

// ---------- Multi-Select Dropdown Component ----------

interface MultiSelectDropdownProps {
  label: string;
  placeholder: string;
  options: CodeEntry[];
  selected: string[];
  onToggle: (code: string) => void;
  onSelectAll?: (codes: string[]) => void;
  onClearAll?: () => void;
  disabled?: boolean;
  searchable?: boolean;
}

function MultiSelectDropdown({ label, placeholder, options, selected, onToggle, onSelectAll, onClearAll, disabled, searchable }: MultiSelectDropdownProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setSearch('');
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filtered = useMemo(() => {
    if (!search) return options;
    const q = search.toLowerCase().trim();
    return options.filter(o => {
      const codeLower = o.code.toLowerCase();
      const labelLower = o.label.toLowerCase();
      if (codeLower.includes(q)) return true;
      if (labelLower.includes(q)) return true;
      const words = labelLower.split(/\s+/);
      const initials = words.map(w => w[0]).join('');
      if (initials.includes(q)) return true;
      if (q.length <= 3 && words.some(w => w.startsWith(q))) return true;
      return false;
    });
  }, [search, options]);

  const filteredCodes = filtered.map(o => o.code);
  const allFilteredSelected = filtered.length > 0 && filtered.every(o => selected.includes(o.code));
  const someFilteredSelected = filtered.some(o => selected.includes(o.code));

  const handleSelectAll = () => {
    if (allFilteredSelected) {
      // Deselect all filtered
      if (onClearAll && !search) {
        onClearAll();
      } else {
        filteredCodes.forEach(code => {
          if (selected.includes(code)) onToggle(code);
        });
      }
    } else {
      // Select all filtered
      if (onSelectAll && !search) {
        onSelectAll(filteredCodes);
      } else {
        filteredCodes.forEach(code => {
          if (!selected.includes(code)) onToggle(code);
        });
      }
    }
  };

  const selectedLabels = selected
    .map(code => codeMap.get(code))
    .filter(Boolean)
    .map(e => e!.label);

  const displayText = selected.length === 0
    ? placeholder
    : selected.length <= 2
      ? selectedLabels.join(', ')
      : `${selected.length} selected`;

  return (
    <div ref={ref} className="relative">
      <label className="block text-xs text-gray-500 mb-1.5 font-medium uppercase tracking-wider">{label}</label>
      <button
        type="button"
        onClick={() => { if (!disabled) { setOpen(!open); setSearch(''); } }}
        disabled={disabled}
        className={`w-full flex items-center justify-between bg-white border rounded-lg px-3 py-2.5 text-sm text-left transition-colors ${
          disabled
            ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed'
            : open
              ? 'border-blue-500 ring-2 ring-blue-500/20'
              : 'border-gray-300 hover:border-gray-400 cursor-pointer'
        }`}
      >
        <span className={`truncate ${selected.length === 0 ? 'text-gray-400' : 'text-gray-900'}`}>
          {displayText}
        </span>
        <ChevronDown className={`w-4 h-4 flex-shrink-0 ml-2 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && !disabled && (
        <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-72 flex flex-col">
          {searchable !== false && (
            <div className="p-2 border-b border-gray-100">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Type name, code, or initials..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  autoFocus
                />
              </div>
            </div>
          )}
          {/* Select All row */}
          {filtered.length > 1 && (
            <button
              type="button"
              onClick={handleSelectAll}
              className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs text-left transition-colors border-b border-gray-100 ${
                allFilteredSelected ? 'bg-blue-50' : 'hover:bg-gray-50'
              }`}
            >
              <div className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
                allFilteredSelected
                  ? 'bg-blue-600 border-blue-600'
                  : someFilteredSelected
                    ? 'bg-blue-200 border-blue-400'
                    : 'border-gray-300'
              }`}>
                {allFilteredSelected && <Check className="w-3 h-3 text-white" />}
                {!allFilteredSelected && someFilteredSelected && <div className="w-2 h-0.5 bg-white rounded" />}
              </div>
              <span className="text-gray-900" style={{ fontWeight: 600 }}>
                {search ? `Select all ${filtered.length} matches` : `Select All (${filtered.length})`}
              </span>
            </button>
          )}
          <div className="overflow-y-auto flex-1">
            {filtered.length === 0 && (
              <div className="px-3 py-4 text-xs text-gray-400 text-center">No matches found</div>
            )}
            {filtered.map(opt => {
              const isSelected = selected.includes(opt.code);
              return (
                <button
                  key={opt.code}
                  type="button"
                  onClick={() => onToggle(opt.code)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs text-left transition-colors ${
                    isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
                    isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300'
                  }`}>
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <span className="text-gray-400 font-mono w-8 flex-shrink-0">{opt.code}</span>
                  <span className={`truncate ${isSelected ? 'text-blue-900' : 'text-gray-700'}`}>{opt.label}</span>
                </button>
              );
            })}
          </div>
          {selected.length > 0 && (
            <div className="border-t border-gray-100 px-3 py-1.5 flex items-center justify-between">
              <span className="text-[10px] text-gray-400">{selected.length} selected</span>
              <button
                type="button"
                onClick={() => { if (onClearAll) onClearAll(); else selected.forEach(code => onToggle(code)); }}
                className="text-[10px] text-red-500 hover:text-red-700 transition-colors"
              >
                Clear all
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------- Main Component ----------

export function ImpactRegionsPerils({ data, onChange, showValidation, validationErrors, isEventPublished }: ImpactRegionsPerilsProps) {
  const [selectedItems, setSelectedItems] = useState<CodeEntry[]>(() => {
    return (data.impactedCountries || []).map((val: string) => {
      const found = RAW_CODES.find(e => `${e.code}-${e.label}` === val || e.label === val || e.code === val);
      return found || { code: '', label: val };
    });
  });

  // Multi-select state: arrays of selected codes per dropdown
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [selectedZones, setSelectedZones] = useState<string[]>([]);
  const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [selectedWorldwides, setSelectedWorldwides] = useState<string[]>([]);

  // Sync master selectedItems list whenever any dropdown changes
  const syncItems = (countries: string[], zones: string[], areas: string[], wws: string[]) => {
    const allCodes = new Set([...countries, ...zones, ...areas, ...wws]);
    const entries = Array.from(allCodes)
      .map(code => codeMap.get(code))
      .filter(Boolean) as CodeEntry[];
    setSelectedItems(entries);
    onChange({ impactedCountries: entries.map(i => `${i.code}-${i.label}`) });
  };

  // Toggle a country → auto-add its zone, area, and W00
  const toggleCountry = (code: string) => {
    const isRemoving = selectedCountries.includes(code);
    const newCountries = isRemoving
      ? selectedCountries.filter(c => c !== code)
      : [...selectedCountries, code];
    setSelectedCountries(newCountries);

    let newZones = [...selectedZones];
    let newAreas = [...selectedAreas];
    let newWWs = [...selectedWorldwides];

    if (!isRemoving) {
      // Auto-add zone
      const zoneCode = findZoneCode(code);
      if (zoneCode && !newZones.includes(zoneCode)) newZones.push(zoneCode);
      // Auto-add area
      const areaCode = getMainAreaCode(code);
      if (!newAreas.includes(areaCode)) newAreas.push(areaCode);
      // Auto-add Worldwide
      if (!newWWs.includes('W00')) newWWs.push('W00');
    }

    setSelectedZones(newZones);
    setSelectedAreas(newAreas);
    setSelectedWorldwides(newWWs);
    syncItems(newCountries, newZones, newAreas, newWWs);
  };

  // Toggle a zone
  const toggleZone = (code: string) => {
    const isRemoving = selectedZones.includes(code);
    const newZones = isRemoving
      ? selectedZones.filter(c => c !== code)
      : [...selectedZones, code];
    setSelectedZones(newZones);

    let newAreas = [...selectedAreas];
    if (!isRemoving) {
      const areaCode = getMainAreaCode(code);
      if (!newAreas.includes(areaCode)) newAreas.push(areaCode);
    }
    setSelectedAreas(newAreas);
    syncItems(selectedCountries, newZones, newAreas, selectedWorldwides);
  };

  // Toggle a broader area
  const toggleArea = (code: string) => {
    const newAreas = selectedAreas.includes(code)
      ? selectedAreas.filter(c => c !== code)
      : [...selectedAreas, code];
    setSelectedAreas(newAreas);
    syncItems(selectedCountries, selectedZones, newAreas, selectedWorldwides);
  };

  // Toggle worldwide — all W-codes freely toggleable
  const toggleWorldwide = (code: string) => {
    const newWWs = selectedWorldwides.includes(code)
      ? selectedWorldwides.filter(c => c !== code)
      : [...selectedWorldwides, code];
    setSelectedWorldwides(newWWs);
    syncItems(selectedCountries, selectedZones, selectedAreas, newWWs);
  };

  // Bulk select/clear handlers for Select All
  const selectAllAreas = (codes: string[]) => {
    const newAreas = [...new Set([...selectedAreas, ...codes])];
    // Cascade: also select all zones and countries under these areas
    const cascadedZones = [...selectedZones];
    const cascadedCountries = [...selectedCountries];
    codes.forEach(areaCode => {
      getZonesForArea(areaCode).forEach(z => {
        if (!cascadedZones.includes(z.code)) cascadedZones.push(z.code);
      });
      getAllCountriesForArea(areaCode).forEach(c => {
        if (!cascadedCountries.includes(c.code)) cascadedCountries.push(c.code);
      });
    });
    const newWWs = [...selectedWorldwides];
    if (cascadedCountries.length > 0 && !newWWs.includes('W00')) newWWs.push('W00');
    setSelectedAreas(newAreas);
    setSelectedZones(cascadedZones);
    setSelectedCountries(cascadedCountries);
    setSelectedWorldwides(newWWs);
    syncItems(cascadedCountries, cascadedZones, newAreas, newWWs);
  };
  const clearAllAreas = () => {
    // Cascade: also clear zones and countries that belong to currently selected areas
    const areaLetters = new Set(selectedAreas.map(c => c[0]));
    const newZones = selectedZones.filter(c => !areaLetters.has(c[0]));
    const newCountries = selectedCountries.filter(c => !areaLetters.has(c[0]));
    setSelectedAreas([]);
    setSelectedZones(newZones);
    setSelectedCountries(newCountries);
    syncItems(newCountries, newZones, [], selectedWorldwides);
  };

  const selectAllZones = (codes: string[]) => {
    const newZones = [...new Set([...selectedZones, ...codes])];
    // Auto-add parent areas
    const newAreas = [...selectedAreas];
    codes.forEach(zc => {
      const ac = getMainAreaCode(zc);
      if (!newAreas.includes(ac)) newAreas.push(ac);
    });
    // Cascade: also select all countries under these zones
    const cascadedCountries = [...selectedCountries];
    codes.forEach(zoneCode => {
      getCountriesForZone(zoneCode).forEach(c => {
        if (!cascadedCountries.includes(c.code)) cascadedCountries.push(c.code);
      });
    });
    const newWWs = [...selectedWorldwides];
    if (cascadedCountries.length > 0 && !newWWs.includes('W00')) newWWs.push('W00');
    setSelectedZones(newZones);
    setSelectedAreas(newAreas);
    setSelectedCountries(cascadedCountries);
    setSelectedWorldwides(newWWs);
    syncItems(cascadedCountries, newZones, newAreas, newWWs);
  };
  const clearAllZones = () => {
    // Cascade: also clear countries that belong to currently selected zones
    const zoneSet = new Set(selectedZones);
    const newCountries = selectedCountries.filter(c => {
      const z = findZoneCode(c);
      return z === null || !zoneSet.has(z);
    });
    setSelectedZones([]);
    setSelectedCountries(newCountries);
    syncItems(newCountries, [], selectedAreas, selectedWorldwides);
  };

  const selectAllCountries = (codes: string[]) => {
    const newCountries = [...new Set([...selectedCountries, ...codes])];
    setSelectedCountries(newCountries);
    // Auto-add parent zones, areas, worldwide
    const newZones = [...selectedZones];
    const newAreas = [...selectedAreas];
    let newWWs = [...selectedWorldwides];
    codes.forEach(code => {
      const zc = findZoneCode(code);
      if (zc && !newZones.includes(zc)) newZones.push(zc);
      const ac = getMainAreaCode(code);
      if (!newAreas.includes(ac)) newAreas.push(ac);
    });
    if (newCountries.length > 0 && !newWWs.includes('W00')) newWWs.push('W00');
    setSelectedZones(newZones);
    setSelectedAreas(newAreas);
    setSelectedWorldwides(newWWs);
    syncItems(newCountries, newZones, newAreas, newWWs);
  };
  const clearAllCountries = () => {
    setSelectedCountries([]);
    syncItems([], selectedZones, selectedAreas, selectedWorldwides);
  };

  const selectAllWorldwide = (codes: string[]) => {
    const newWWs = [...new Set([...selectedWorldwides, ...codes])];
    setSelectedWorldwides(newWWs);
    syncItems(selectedCountries, selectedZones, selectedAreas, newWWs);
  };
  const clearAllWorldwide = () => {
    setSelectedWorldwides([]);
    syncItems(selectedCountries, selectedZones, selectedAreas, []);
  };

  // Derived: filter country options based on selected areas/zones
  const countryOptions = useMemo(() => {
    if (selectedZones.length > 0) return getCountriesForZones(selectedZones);
    if (selectedAreas.length > 0) return getCountriesForAreas(selectedAreas);
    return allCountries;
  }, [selectedAreas, selectedZones]);

  // Derived: filter zone options based on selected areas
  const zoneOptions = useMemo(() => {
    if (selectedAreas.length > 0) return getZonesForAreas(selectedAreas);
    // Show all zones
    return RAW_CODES.filter(e => isZone(e.code));
  }, [selectedAreas]);

  // Remove from master badge list
  const removeItem = (code: string) => {
    const newCountries = selectedCountries.filter(c => c !== code);
    const newZones = selectedZones.filter(c => c !== code);
    const newAreas = selectedAreas.filter(c => c !== code);
    const newWWs = selectedWorldwides.filter(c => c !== code);
    setSelectedCountries(newCountries);
    setSelectedZones(newZones);
    setSelectedAreas(newAreas);
    setSelectedWorldwides(newWWs);
    syncItems(newCountries, newZones, newAreas, newWWs);
  };

  // Master clear all
  const clearEverything = () => {
    setSelectedCountries([]);
    setSelectedZones([]);
    setSelectedAreas([]);
    setSelectedWorldwides([]);
    setSelectedItems([]);
    onChange({ impactedCountries: [] });
  };

  // Helper: check if a field has a validation error
  const hasRegionError = showValidation && validationErrors?.includes('Impacted Regions');
  const isNatCat = data.everestEventType === 'NAT CAT';

  return (
    <div className="space-y-8">
      {/* Impacted Regions Card */}
      <div className={`rounded-lg border p-6 transition-colors ${
        hasRegionError
          ? 'bg-red-50 border-red-200'
          : isNatCat
            ? 'bg-amber-50/40 border-amber-100/60'
            : 'bg-white border-gray-200'
      }`}>
        <div className="flex items-center justify-between mb-1">
          <div>
            
            <p className="text-sm text-gray-600">
              Define the geographic and peril scope of the event for internal classification, reporting, and validation against RDM.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4 mt-4 pt-4 border-t border-gray-100">
          <label className="block text-gray-700 font-medium">
            Impacted Regions {isNatCat && <span className="text-red-500">*</span>}
            {!isNatCat && <span className="text-gray-400 text-xs ml-1">(optional)</span>}
          </label>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600">
              {selectedItems.length} location{selectedItems.length !== 1 ? 's' : ''} selected
            </span>
            {selectedItems.length > 0 && (
              <button
                type="button"
                onClick={clearEverything}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded-lg text-xs hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear All
              </button>
            )}
          </div>
        </div>

        {hasRegionError && (
          <p className="text-xs text-red-500 mt-2">At least one impacted region is required for NAT CAT events</p>
        )}

        {/* 4 Multi-Select Cascading Dropdowns — broadest to most granular */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Broader Risk Zone = Main area (broadest) */}
          <MultiSelectDropdown
            label="Broader Risk Zone"
            placeholder="Select areas..."
            options={broaderRiskZoneOptions}
            selected={selectedAreas}
            onToggle={toggleArea}
            onSelectAll={selectAllAreas}
            onClearAll={clearAllAreas}
            disabled={isEventPublished}
          />

          {/* 2. Risk Zone = Sub-region */}
          <MultiSelectDropdown
            label="Risk Zone"
            placeholder="Select zones..."
            options={zoneOptions}
            selected={selectedZones}
            onToggle={toggleZone}
            onSelectAll={selectAllZones}
            onClearAll={clearAllZones}
            disabled={isEventPublished}
            searchable
          />

          {/* 3. Main Risk Area = Country/State (most granular) */}
          <MultiSelectDropdown
            label="Main Risk Area"
            placeholder="Select countries..."
            options={countryOptions}
            selected={selectedCountries}
            onToggle={toggleCountry}
            onSelectAll={selectAllCountries}
            onClearAll={clearAllCountries}
            disabled={isEventPublished}
            searchable
          />

          {/* 4. Worldwide */}
          <MultiSelectDropdown
            label="Worldwide"
            placeholder="Select scope..."
            options={worldwideOptions}
            selected={selectedWorldwides}
            onToggle={toggleWorldwide}
            onSelectAll={selectAllWorldwide}
            onClearAll={clearAllWorldwide}
            disabled={isEventPublished}
          />
        </div>

        <p className="text-xs text-gray-500 mt-4">
          {data.everestEventType === 'NAT CAT'
            ? <>Start with <strong>Broader Risk Zone</strong> to filter Risk Zones and Main Risk Areas top-down. Or select countries directly in <strong>Main Risk Area</strong> — parent zones and areas auto-fill upward. All dropdowns support multi-select with Select All.</>
            : <>Geographic selection is optional for <strong>{data.everestEventType || 'non-NatCat'}</strong> events. You may still define regions for reporting purposes, or leave blank if scope is determined at the contract level.</>
          }
        </p>
      </div>
    </div>
  );
}