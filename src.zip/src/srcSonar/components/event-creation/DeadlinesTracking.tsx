import { useState, useEffect } from 'react';

interface DeadlinesTrackingProps {
  data: any;
  onChange: (data: any) => void;
}

interface NotifyPerson {
  name: string;
  region?: string;
  task: string | null;
  indent?: boolean;
}

interface NotifyGroup {
  section: string;
  members: NotifyPerson[];
}

const MONITORING_GROUPS = ['Group Underwriting', 'Finance', 'Cat Modeling', 'Claims'];
const EXECUTIVE_AREA_GROUPS = [
  'Facultative - Executive Area Lead',
  'International Treaty - Executive Area Lead',
  'North America Treaty - Executive Area Lead',
  'Product - Executive Area Lead',
  'Financial Products - Executive Area Lead',
];

const notificationGroups: NotifyGroup[] = [
  {
    section: 'Group Underwriting',
    members: [{ name: 'Group Underwriting Team', task: null }],
  },
  {
    section: 'Finance',
    members: [{ name: 'Finance Team', task: 'Financial impact analysis' }],
  },
  {
    section: 'Claims',
    members: [{ name: 'Claims Team', task: 'Create event backup' }],
  },
  {
    section: 'Cat Modeling',
    members: [{ name: 'Cat Modeling Team', task: 'Cat modeling loss estimation and NET calculations' }],
  },
  {
    section: 'Facultative - Executive Area Lead',
    members: [
      { name: 'Facultative - Executive Area Lead', region: 'Facultative', task: 'Review & approve loss estimates' },
      { name: 'International Facultative', region: 'International Facultative', task: 'Regional loss estimation', indent: true },
      { name: 'North America Facultative', region: 'North America Facultative', task: 'Regional loss estimation', indent: true },
    ],
  },
  {
    section: 'International Treaty - Executive Area Lead',
    members: [
      { name: 'International Treaty - Executive Area Lead', region: 'International Treaty', task: 'Review & approve loss estimates' },
      { name: 'Zurich/Dublin', region: 'Zurich/Dublin', task: 'Regional loss estimation', indent: true },
      { name: 'Latam', region: 'Latam', task: 'Regional loss estimation', indent: true },
      { name: 'London', region: 'London', task: 'Regional loss estimation', indent: true },
      { name: 'Middle East', region: 'Middle East', task: 'Regional loss estimation', indent: true },
      { name: 'Singapore', region: 'Singapore', task: 'Regional loss estimation', indent: true },
    ],
  },
  {
    section: 'North America Treaty - Executive Area Lead',
    members: [
      { name: 'North America Treaty - Executive Area Lead', region: 'North America Treaty', task: 'Review & approve loss estimates' },
      { name: 'Bermuda', region: 'Bermuda', task: 'Regional loss estimation', indent: true },
      { name: 'Canada', region: 'Canada', task: 'Regional loss estimation', indent: true },
      { name: 'Treaty Casualty', region: 'Treaty Casualty', task: 'Regional loss estimation', indent: true },
      { name: 'Treaty Property', region: 'Treaty Property', task: 'Regional loss estimation', indent: true },
    ],
  },
  {
    section: 'Product - Executive Area Lead',
    members: [
      { name: 'Product - Executive Area Lead', region: 'Product', task: 'Review & approve loss estimates' },
      { name: 'Aviation', region: 'Aviation', task: 'Regional loss estimation', indent: true },
      { name: 'Cyber', region: 'Cyber', task: 'Regional loss estimation', indent: true },
      { name: 'Engineering', region: 'Engineering', task: 'Regional loss estimation', indent: true },
      { name: 'Marine', region: 'Marine', task: 'Regional loss estimation', indent: true },
      { name: 'Parametric', region: 'Parametric', task: 'Regional loss estimation', indent: true },
      { name: 'Energy', region: 'Energy', task: 'Regional loss estimation', indent: true },
    ],
  },
  {
    section: 'Financial Products - Executive Area Lead',
    members: [
      { name: 'Financial Products - Executive Area Lead', region: 'Financial Products', task: 'Review & approve loss estimates' },
      { name: 'Financial', region: 'Financial', task: 'Regional loss estimation', indent: true },
      { name: 'Mortgage', region: 'Mortgage', task: 'Regional loss estimation', indent: true },
    ],
  },
];

const allNames = notificationGroups.flatMap(g => g.members.map(m => m.name));

const eaParentNames = notificationGroups
  .filter(g => EXECUTIVE_AREA_GROUPS.includes(g.section))
  .flatMap(g => g.members.filter(m => !m.indent).map(m => m.name));

const monitoringNames = [
  ...notificationGroups
    .filter(g => MONITORING_GROUPS.includes(g.section))
    .flatMap(g => g.members.map(m => m.name)),
  ...eaParentNames,
];

// EA chip → child BU names (drives batch-select and isSelected state)
const EA_CONFIG = [
  { display: 'Facultative',         children: ['International Facultative', 'North America Facultative'] },
  { display: 'International Treaty', children: ['Zurich/Dublin', 'Latam', 'London', 'Middle East', 'Singapore'] },
  { display: 'North America Treaty', children: ['Bermuda', 'Canada', 'Treaty Casualty', 'Treaty Property'] },
  { display: 'Product',              children: ['Aviation', 'Cyber', 'Engineering', 'Marine', 'Parametric', 'Energy'] },
  { display: 'Financial Lines',      children: ['Financial', 'Mortgage'] },
];

// BU chip list — leaf-level only, no EA parents, no Surety
const BU_LIST = [
  { display: "Int'l Facultative",  name: 'International Facultative' },
  { display: 'NA Facultative',     name: 'North America Facultative' },
  { display: 'Zurich/Dublin',      name: 'Zurich/Dublin' },
  { display: 'Latam',              name: 'Latam' },
  { display: 'London',             name: 'London' },
  { display: 'Middle East',        name: 'Middle East' },
  { display: 'Singapore',          name: 'Singapore' },
  { display: 'Bermuda',            name: 'Bermuda' },
  { display: 'Canada',             name: 'Canada' },
  { display: 'Treaty Casualty',    name: 'Treaty Casualty' },
  { display: 'Treaty Property',    name: 'Treaty Property' },
  { display: 'Aviation',           name: 'Aviation' },
  { display: 'Cyber',              name: 'Cyber' },
  { display: 'Engineering',        name: 'Engineering' },
  { display: 'Marine',             name: 'Marine' },
  { display: 'Parametric',         name: 'Parametric' },
  { display: 'Energy',             name: 'Energy' },
  { display: 'Financial',          name: 'Financial' },
  { display: 'Mortgage',           name: 'Mortgage' },
];

export function DeadlinesTracking({ data, onChange }: DeadlinesTrackingProps) {
  const [monitoring, setMonitoring] = useState(data.monitoring !== undefined ? data.monitoring : true);
  const [trackImmediately, setTrackImmediately] = useState(data.trackImmediately || false);
  const [selectedNames, setSelectedNames] = useState<Set<string>>(() => {
    if (data.selectedRecipients) return new Set(data.selectedRecipients);
    return new Set(monitoringNames);
  });

  const handleChange = (field: string, value: any) => {
    onChange({ [field]: value });
  };

  useEffect(() => {
    if (!data.selectedRecipients && monitoring) {
      handleChange('selectedRecipients', monitoringNames);
      handleChange('monitoring', true);
    }
  }, []);

  // When Monitoring or Track Immediately toggles, only monitoring-group names
  // are auto-applied — EA/BU chips always start unchecked for manual selection.
  const applySelectionFromCheckboxes = (isMonitoring: boolean) => {
    const next = new Set<string>();
    if (isMonitoring) {
      monitoringNames.forEach(n => next.add(n));
    }
    setSelectedNames(next);
    handleChange('selectedRecipients', Array.from(next));
  };

  const handleMonitoringChange = (checked: boolean) => {
    setMonitoring(checked);
    handleChange('monitoring', checked);
    applySelectionFromCheckboxes(checked);
  };

  const handleTrackImmediatelyChange = (checked: boolean) => {
    setTrackImmediately(checked);
    handleChange('trackImmediately', checked);
    // Do NOT auto-select EA/BU chips — user picks them manually
  };

  const toggleName = (name: string) => {
    const next = new Set(selectedNames);
    if (next.has(name)) next.delete(name);
    else next.add(name);
    setSelectedNames(next);
    handleChange('selectedRecipients', Array.from(next));
  };

  // Batch-toggle all children of an EA chip
  const toggleEAChildren = (children: string[]) => {
    const allChecked = children.every(c => selectedNames.has(c));
    const next = new Set(selectedNames);
    if (allChecked) children.forEach(c => next.delete(c));
    else children.forEach(c => next.add(c));
    setSelectedNames(next);
    handleChange('selectedRecipients', Array.from(next));
  };

  // Shared chip style matching onboarding Scope & Overrides
  const chipCls = (sel: boolean) =>
    `flex items-center gap-1.5 px-2 py-1 rounded border text-xs cursor-pointer transition-all ${
      sel
        ? 'bg-blue-50 border-blue-300 text-blue-700'
        : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
    }`;

  return (
    <div className="space-y-8">
      <div>
        <h3 className="mb-6">Deadlines &amp; Operational Tracking</h3>
        <p className="text-gray-600 mb-8">
          Define the operational timeline for the event and determine when the workflow officially begins.
        </p>
      </div>

      {/* Monitoring */}
      <div className={`border rounded-lg p-6 ${monitoring ? 'bg-amber-50 border-amber-200' : 'bg-gray-50 border-gray-200'}`}>
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={monitoring}
            onChange={(e) => handleMonitoringChange(e.target.checked)}
            className="w-5 h-5 text-amber-600 rounded focus:ring-2 focus:ring-amber-500 mt-0.5"
          />
          <div>
            <div className="text-gray-900 mb-1" style={{ fontWeight: 500 }}>
              Monitoring — Awareness only. Event recorded but underwriting estimation is not required.
            </div>
            <div className="text-sm text-gray-500">
              Use this when the event is being monitored but has not yet triggered underwriting exposure analysis.
            </div>
          </div>
        </label>

        {monitoring && (
          <div className="mt-5 pt-5 border-t border-amber-200 space-y-4">
            <div>
              <div className="text-sm text-gray-700 mb-2" style={{ fontWeight: 500 }}>Notified Teams</div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { display: 'Claims',       name: 'Claims Team' },
                  { display: 'Finance',      name: 'Finance Team' },
                  { display: 'Management',   name: 'Group Underwriting Team' },
                  { display: 'Cat Modeling', name: 'Cat Modeling Team' },
                ].map(({ display, name }) => {
                  const isSel = selectedNames.has(name);
                  return (
                    <label
                      key={name}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded border text-xs cursor-pointer transition-all ${
                        isSel
                          ? 'bg-amber-50 border-amber-300 text-amber-700'
                          : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isSel}
                        onChange={() => toggleName(name)}
                        className="w-3 h-3 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                      />
                      {display}
                    </label>
                  );
                })}
              </div>
              <p className="text-[10px] text-amber-600 mt-1.5">Select teams to notify in monitoring mode</p>
            </div>
          </div>
        )}
      </div>

      {/* Track Immediately */}
      <div className={`border rounded-lg p-6 ${trackImmediately ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'}`}>
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={trackImmediately}
            onChange={(e) => handleTrackImmediatelyChange(e.target.checked)}
            className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500 mt-0.5"
          />
          <div>
            <div className="text-gray-900 mb-1" style={{ fontWeight: 500 }}>Track Immediately – Kick Off Workflow</div>
            <div className="text-sm text-gray-500">
              Activates the event immediately after publishing, starts the countdown for operational deadlines, and triggers notifications to assigned participants.
            </div>
          </div>
        </label>

        {trackImmediately && (
          <div className="mt-5 pt-5 border-t border-blue-200 space-y-4">

            {/* Executive Area */}
            <div>
              <div className="text-sm text-gray-700 mb-2" style={{ fontWeight: 500 }}>Executive Area</div>
              <div className="flex flex-wrap gap-1.5">
                {EA_CONFIG.map(ea => {
                  const isSel = ea.children.some(c => selectedNames.has(c));
                  return (
                    <label key={ea.display} className={chipCls(isSel)}>
                      <input
                        type="checkbox"
                        checked={isSel}
                        onChange={() => toggleEAChildren(ea.children)}
                        className="w-3 h-3 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                      {ea.display}
                    </label>
                  );
                })}
              </div>
              
            </div>

            {/* Business Units */}
            <div>
              <div className="text-sm text-gray-700 mb-2" style={{ fontWeight: 500 }}>Business Units</div>
              <div className="flex flex-wrap gap-1.5">
                {BU_LIST.map(bu => {
                  const isSel = selectedNames.has(bu.name);
                  return (
                    <label key={bu.name} className={chipCls(isSel)}>
                      <input
                        type="checkbox"
                        checked={isSel}
                        onChange={() => toggleName(bu.name)}
                        className="w-3 h-3 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                      {bu.display}
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Scope confirmation banner */}
            {(() => {
              const selectedBUs = BU_LIST.filter(bu => selectedNames.has(bu.name));
              const selectedEAs = EA_CONFIG.filter(ea => ea.children.some(c => selectedNames.has(c)));
              const total = selectedBUs.length + selectedEAs.length;
              return (
                <div className="flex items-start gap-2 rounded-md bg-blue-100 border border-blue-200 px-3 py-2.5 mt-1">
                  <svg className="w-3.5 h-3.5 text-blue-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10A8 8 0 11 2 10a8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                  <p className="text-[11px] text-blue-700 leading-snug">
                    {total === 0
                      ? 'No teams selected — no tracking scope will be set in the Underwriting Estimate.'
                      : <>
                          Only the <span style={{ fontWeight: 600 }}>{total} selection{total !== 1 ? 's' : ''}</span> above
                          {selectedEAs.length > 0 && <> ({selectedEAs.map(e => e.display).join(', ')})</>}
                          {selectedBUs.length > 0 && selectedEAs.length > 0 && ' + '}
                          {selectedBUs.length > 0 && <> ({selectedBUs.map(b => b.display).join(', ')})</>}
                          {' '}will be tracked in the <span style={{ fontWeight: 600 }}>Underwriting Estimate</span>.
                        </>
                    }
                  </p>
                </div>
              );
            })()}

          </div>
        )}
      </div>

      {/* Operational Summary */}
      <div>
        <label className="block text-gray-700 mb-2">Operational Summary</label>
        <textarea
          rows={3}
          placeholder="Describe urgency, special instructions, and sensitivity considerations..."
          value={data.operationalSummary || ''}
          onChange={(e) => handleChange('operationalSummary', e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Workflow Deadlines */}
      <div>
        <h4 className="mb-4">Workflow Deadlines</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 mb-2">High-Level Exposure Estimates Deadline</label>
            <input
              type="datetime-local"
              value={data.deadline1 || ''}
              onChange={(e) => handleChange('deadline1', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-2">Contract-Level Estimates Deadline</label>
            <input
              type="datetime-local"
              value={data.deadline2 || ''}
              onChange={(e) => handleChange('deadline2', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-2">Reserving Extract Deadline</label>
            <input
              type="datetime-local"
              value={data.deadline3 || ''}
              onChange={(e) => handleChange('deadline3', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-2">CAT Model Run Updates Deadline</label>
            <input
              type="datetime-local"
              value={data.deadline4 || ''}
              onChange={(e) => handleChange('deadline4', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
}