import { useState, useRef, useEffect } from 'react';
import { Search } from 'lucide-react';
import { BACKEND_CAT_CODES } from '../../lib/eventDataContext';

// BACKEND_CAT_CODES is now imported from the shared eventDataContext so all tabs stay in sync

// CAT Code Lookup component with search
function CatCodeLookup({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filtered = BACKEND_CAT_CODES.filter(c =>
    c.label.toLowerCase().includes(search.toLowerCase()) ||
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  const selectedLabel = BACKEND_CAT_CODES.find(c => c.code === value)?.label || '';

  return (
    <div className="relative" ref={ref}>
      <div
        className={`w-full px-3 py-2 text-sm border rounded-md cursor-pointer flex items-center justify-between transition-all ${
          isOpen ? 'border-blue-500 ring-2 ring-blue-500' : 'border-gray-200 hover:border-gray-300'
        }`}
        onClick={() => { setIsOpen(!isOpen); setSearch(''); setTimeout(() => inputRef.current?.focus(), 50); }}
      >
        <span className={value ? 'text-gray-900' : 'text-gray-400'}>
          {value || 'Search CAT codes...'}
        </span>
        <div className="flex items-center gap-1.5">
          {value && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); onChange(''); }}
              className="text-gray-400 hover:text-gray-600"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          )}
          <Search className="w-4 h-4 text-gray-400" />
        </div>
      </div>
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-[280px] flex flex-col">
          <div className="p-2 border-b border-gray-100">
            <input
              ref={inputRef}
              type="text"
              placeholder="Type to search CAT codes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-2.5 py-1.5 text-sm border border-gray-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          <div className="overflow-y-auto flex-1">
            {filtered.length === 0 ? (
              <div className="px-3 py-4 text-sm text-gray-400 text-center">No matching CAT codes found</div>
            ) : (
              filtered.map((cat) => (
                <div
                  key={cat.code}
                  className={`px-3 py-2 text-sm cursor-pointer transition-colors ${
                    cat.code === value
                      ? 'bg-blue-50 text-blue-700 font-medium'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                  onClick={() => { onChange(cat.code); setIsOpen(false); setSearch(''); }}
                >
                  {cat.label}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// Custom select component that always opens downward
function CustomSelect({ value, onChange, options, placeholder, required, disabled }: {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  placeholder: string;
  required?: boolean;
  disabled?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedLabel = options.find(o => o.value === value)?.label || '';

  return (
    <div className="relative" ref={ref}>
      <div
        className={`w-full px-3 py-2 text-sm border border-gray-200 rounded-md bg-white flex items-center justify-between cursor-pointer transition-all ${
          disabled ? 'bg-gray-50 text-gray-500 cursor-not-allowed' : 'hover:border-blue-400 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent'
        }`}
        onClick={() => !disabled && setIsOpen(!isOpen)}
      >
        <span className={`flex-1 truncate ${!value ? 'text-gray-400' : ''}`}>
          {value ? selectedLabel : placeholder}
        </span>
        <svg className={`w-4 h-4 text-gray-400 ml-2 flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
      {isOpen && (
        <div className="absolute z-50 w-full bg-white border border-gray-200 rounded-md shadow-lg mt-1 max-h-60 overflow-y-auto" style={{ top: '100%' }}>
          {options.map(opt => (
            <div
              key={opt.value}
              className={`px-3 py-2 text-sm cursor-pointer transition-colors ${
                opt.value === value ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
              }`}
              onClick={() => {
                onChange(opt.value);
                setIsOpen(false);
              }}
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
      {/* Hidden native select for form validation */}
      {required && (
        <select value={value || ''} required tabIndex={-1} className="absolute opacity-0 h-0 w-0 pointer-events-none" onChange={() => {}}>
          <option value="">{placeholder}</option>
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      )}
    </div>
  );
}

interface EventIdentityProps {
  data: any;
  onChange: (data: any) => void;
  showValidation?: boolean;
  validationErrors?: string[];
  isEventPublished?: boolean;
}

const eventSubTypes: Record<string, string[]> = {
  'Natural Catastrophe': [
    'Hurricane',
    'Earthquake',
    'Flood',
    'Wildfire',
    'Wind - Non Hurricane',
    'Hail',
    'Tornado',
    'Tsunami',
    'Drought',
    'Volcano'
  ],
  'Large Loss (Single Risk)': [
    'Major Fire',
    'Factory / Plant Explosion',
    'Energy / Offshore Loss',
    'Large Construction Loss',
    'Mining Loss',
    'Power Generation Loss',
    'Airplane Crash',
    'Dam Collapse',
    'Train Derailment',
    'Ship Collision',
    'Ship Sinking',
    'Ship Grounding',
    'Airplane Grounding'
  ],
  'Casualty Event': [
    'Product Liability',
    'Product Recall',
    'Architect / Design',
    'Motor Liability',
    'Mal Practice Liability'
  ],
  'Cyber': [
    'Ransomware',
    'Malware',
    'Virus',
    'Terrorist Attack'
  ],
  'Financial / Credit': [
    'Bank Bankruptcy',
    'Other Financial Institution Bankruptcy',
    'Non Financial Bankruptcy',
    'Economic Downturn',
    'D&O / E&O',
    'Reps & Warranties',
    'Credit/Surety Default',
    'Expropriation',
    'Governmental Actions',
    'Fraud'
  ],
  'Pandemic / Biological': [
    'Epidemic (One Country)',
    'Pandemic (Several Countries)'
  ],
  'War & Terror': [
    'SRCC',
    'Political Violence',
    'Terrorist Attack',
    'War'
  ]
};

const businessUnits = [
  'Property CAT',
  'Property Risk',
  'Property PR',
  'Parametric',
  'Accident & Health',
  'Alternative Risk',
  'Aviation',
  'Casualty',
  'Crop',
  'Cyber',
  'Energy',
  'Engineering',
  'Financial',
  'Marine',
  'Mortgage',
  'Motor',
  'PVT &Terror',
  'REGEAR'
];

export function EventIdentity({ data, onChange, showValidation, validationErrors, isEventPublished }: EventIdentityProps) {
  const [isBusinessGroupsOpen, setIsBusinessGroupsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Helper: check if a field has a validation error
  const hasError = (fieldName: string) => showValidation && validationErrors?.includes(fieldName);
  // Helper: mandatory field wrapper classes — always light highlight, red border on error
  const mandatoryFieldClass = (fieldName: string) =>
    `rounded-lg px-3 py-3 -mx-3 transition-colors ${
      hasError(fieldName)
        ? 'bg-red-50 border border-red-200'
        : 'bg-amber-50/40 border border-amber-100/60'
    }`;

  // Default business group(s) per Event Type
  const defaultBusinessGroups: Record<string, string[]> = {
    'Natural Catastrophe': ['Property CAT'],
    'Large Loss (Single Risk)': ['Property Risk'],
    'Casualty Event': ['Casualty'],
    'Cyber': ['Cyber'],
    'Financial / Credit': ['Financial'],
    'Pandemic / Biological': ['Accident & Health'],
    'War & Terror': ['PVT &Terror'],
  };

  const handleChange = (field: string, value: any) => {
    // If Type of Everest Event changes, auto-set Event Type
    if (field === 'everestEventType') {
      const updates: any = { [field]: value };
      if (value === 'NAT CAT') {
        updates.eventType = 'Natural Catastrophe';
        updates.premiumAllocation = 'Premium Allocated';
        updates.eventSubType = '';
        // Auto-select default business group for Natural Catastrophe
        updates.businessGroups = defaultBusinessGroups['Natural Catastrophe'];
      } else {
        updates.eventType = '';
        updates.eventSubType = '';
        updates.premiumAllocation = 'Premium Not Allocated';
        // Clear business groups when switching away from NAT CAT
        updates.businessGroups = [];
      }
      onChange(updates);
    // If event type changes, clear sub-type so user must pick one
    } else if (field === 'eventType') {
      const subs = eventSubTypes[value] || [];
      const updates: any = {
        [field]: value,
        eventSubType: '',
      };
      // Auto-set premium allocation based on event type
      if (value === 'Natural Catastrophe') {
        updates.premiumAllocation = 'Premium Allocated';
      } else if (value) {
        updates.premiumAllocation = 'Premium Not Allocated';
      }
      // Auto-select default business group for the chosen event type
      if (value && defaultBusinessGroups[value]) {
        updates.businessGroups = defaultBusinessGroups[value];
      } else {
        updates.businessGroups = [];
      }
      onChange(updates);
    } else if (field === 'lossStartDate') {
      // Auto-populate lossEndDate with start date only if end date hasn't been set yet
      const updates: any = { lossStartDate: value };
      if (!data.lossEndDate) {
        updates.lossEndDate = value;
      }
      onChange(updates);
    } else {
      onChange({ [field]: value });
    }
  };

  const toggleBusinessGroup = (unit: string) => {
    const current = data.businessGroups || [];
    const updated = current.includes(unit)
      ? current.filter((u: string) => u !== unit)
      : [...current, unit];
    handleChange('businessGroups', updated);
  };

  const handleSelectAllBusinessGroups = () => {
    const allSelected = data.businessGroups?.length === businessUnits.length;
    handleChange('businessGroups', allSelected ? [] : [...businessUnits]);
  };

  const selectedCount = data.businessGroups?.length || 0;

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsBusinessGroupsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const availableSubTypes = data.eventType ? eventSubTypes[data.eventType] || [] : [];

  // Filter event types based on Everest Event Type selection
  const availableEventTypes = (() => {
    const allTypes = Object.keys(eventSubTypes);
    if (data.everestEventType === 'NAT CAT') {
      return allTypes.filter(t => t === 'Natural Catastrophe');
    }
    if (data.everestEventType === 'Man Made CAT') {
      return allTypes.filter(t => t !== 'Natural Catastrophe');
    }
    return allTypes;
  })();

  return (
    <div className="space-y-8">
      {/* Form Fields Card */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="grid grid-cols-2 gap-x-6 gap-y-5">
          <div>
            <label className="block text-gray-700 mb-1.5">Event Status</label>
            <input
              type="text"
              value={data.status || 'Draft'}
              disabled
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md bg-gray-50 text-gray-500 cursor-not-allowed"
            />
            
          </div>

          <div>
            <label className="block text-gray-700 mb-1.5">Event ID </label>
            <input
              type="text"
              value={data.eventId || ''}
              disabled
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md bg-gray-50 text-gray-500 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-gray-700 mb-1.5">CAT code-Headline Loss code  <span className="text-gray-400 font-normal">(Optional)</span></label>
            <CatCodeLookup
              value={data.catCode || ''}
              onChange={(value) => handleChange('catCode', value)}
            />
          </div>



          <div className={`col-span-2 ${mandatoryFieldClass('Event Name')}`}>
            <label className="block text-gray-700 mb-1.5">Event Name <span className="text-red-500">*</span></label>
            <input
              type="text"
              placeholder="e.g., Hurricane Milton"
              value={data.eventName || ''}
              onChange={(e) => handleChange('eventName', e.target.value)}
              className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${hasError('Event Name') ? 'border-red-300' : 'border-gray-200'}`}
              required
            />
            {hasError('Event Name') && <p className="text-xs text-red-500 mt-1">Event Name is required</p>}
          </div>

          {/* 3-column row: Type of Everest Event → Event Type → Event Sub-Type */}
          <div className={`col-span-2 grid grid-cols-3 gap-x-6 ${mandatoryFieldClass('Type of Everest Event')}`}>
            <div>
              <label className="block text-gray-700 mb-1.5">Type of Everest Event <span className="text-red-500">*</span></label>
              <CustomSelect
                value={data.everestEventType || ''}
                onChange={(value) => handleChange('everestEventType', value)}
                options={[
                  { value: 'NAT CAT', label: 'NAT CAT' },
                  { value: 'Man Made CAT', label: 'Man Made CAT' },
                ]}
                placeholder="Select type"
                required
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-1.5">Event Type <span className="text-red-500">*</span></label>
              <CustomSelect
                value={data.eventType || ''}
                onChange={(value) => handleChange('eventType', value)}
                options={availableEventTypes.map(key => ({ value: key, label: key }))}
                placeholder="Select event type"
                required
              />
            </div>

            <div className="relative z-30">
              <label className="block text-gray-700 mb-1.5">Event Sub-Type <span className="text-red-500">*</span></label>
              <CustomSelect
                value={data.eventSubType || ''}
                onChange={(value) => handleChange('eventSubType', value)}
                options={availableSubTypes.map((subType: string) => ({ value: subType, label: subType }))}
                placeholder="Select event sub-type"
                required
              />
              {hasError('Event Sub-Type') && <p className="text-xs text-red-500 mt-1">Required</p>}
            </div>
          </div>

          <div className={`col-span-2 ${mandatoryFieldClass('Business Groups')}`}>
            <label className="block text-gray-700 mb-1.5">Products <span className="text-red-500">*</span></label>
            <div className="relative" ref={dropdownRef}>
              <div
                className={`w-full px-3 py-2 text-sm border rounded-md ${isEventPublished ? 'bg-gray-50 cursor-not-allowed' : 'cursor-pointer bg-white hover:border-blue-400'} transition-colors flex items-center justify-between ${hasError('Business Groups') ? 'border-red-300' : 'border-gray-200'}`}
                onClick={() => !isEventPublished && setIsBusinessGroupsOpen(!isBusinessGroupsOpen)}
              >
                <span className="flex-1 truncate">
                  {selectedCount > 0 ? (
                    <>
                      {data.businessGroups.slice(0, 2).join(', ')}
                      {selectedCount > 2 && <span className="text-gray-500"> +{selectedCount - 2} more</span>}
                    </>
                  ) : (
                    <span className="text-gray-400">Select business groups</span>
                  )}
                </span>
                <svg className="w-4 h-4 text-gray-400 ml-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
              {isBusinessGroupsOpen && (
                <div className="absolute z-10 w-full bg-white border border-gray-200 rounded-md shadow-lg mt-1">
                  <div className="p-2 border-b border-gray-100">
                    <button
                      type="button"
                      className="w-full px-3 py-1.5 text-xs text-left text-blue-600 hover:bg-blue-50 rounded transition-colors"
                      onClick={handleSelectAllBusinessGroups}
                    >
                      {selectedCount === businessUnits.length ? 'Deselect All' : 'Select All'}
                    </button>
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    {businessUnits.map(unit => (
                      <div key={unit} className="px-3 py-1.5 hover:bg-gray-50 transition-colors">
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={data.businessGroups?.includes(unit) || false}
                            onChange={() => toggleBusinessGroup(unit)}
                            className="mr-2 w-4 h-4 rounded"
                            style={{ accentColor: '#0050FF' }}
                          />
                          <span className="text-sm">{unit}</span>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {hasError('Business Groups') && <p className="text-xs text-red-500 mt-1">At least one Business Group is required</p>}
            </div>
          </div>

          <div className={mandatoryFieldClass('Loss Start Date')}>
            <label className="block text-gray-700 mb-1.5">Loss Start Date <span className="text-red-500">*</span></label>
            <input
              type="date"
              value={data.lossStartDate || ''}
              onChange={(e) => handleChange('lossStartDate', e.target.value)}
              disabled={isEventPublished}
              className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${isEventPublished ? 'bg-gray-50 text-gray-500 cursor-not-allowed' : ''} ${hasError('Loss Start Date') ? 'border-red-300' : 'border-gray-200'}`}
              required
            />
            {hasError('Loss Start Date') && <p className="text-xs text-red-500 mt-1">Required</p>}
          </div>

          <div className={mandatoryFieldClass('Loss End Date')}>
            <label className="block text-gray-700 mb-1.5">Loss End Date <span className="text-red-500">*</span></label>
            <input
              type="date"
              value={data.lossEndDate || ''}
              onChange={(e) => handleChange('lossEndDate', e.target.value)}
              className={`w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${hasError('Loss End Date') ? 'border-red-300' : 'border-gray-200'}`}
              required
            />
            {hasError('Loss End Date') && <p className="text-xs text-red-500 mt-1">Required</p>}
          </div>

          <div className="col-span-2">
            <label className="block text-gray-700 mb-1.5">Short Description</label>
            <input
              type="text"
              placeholder="Brief description of the event"
              value={data.shortDescription || ''}
              onChange={(e) => handleChange('shortDescription', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />
          </div>

          <div className="col-span-2">
            <label className="block text-gray-700 mb-1.5">Long Description</label>
            <textarea
              rows={4}
              placeholder="Detailed description including scope, impact areas, and key details"
              value={data.longDescription || ''}
              onChange={(e) => handleChange('longDescription', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}