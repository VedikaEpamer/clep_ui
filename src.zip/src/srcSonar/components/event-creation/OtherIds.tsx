import { useState, useRef, useEffect } from 'react';
import { Plus, Trash2, ExternalLink } from 'lucide-react';

interface EventIdentifier {
  id: string;
  name: string;
  value: string;
  link?: string;
  customName?: string;
}

interface OtherIdsProps {
  data: any;
  onChange: (data: any) => void;
}

const commonSources = [
  'Swiss Re',
  'Munich Re',
  'PCS',
  'NOAA',
  'AIR Worldwide',
  'Verisk',
  'Moody\'s RMS',
  'Aon',
  'Guy Carpenter',
  'Gallagher Re',
  'Howden',
  'CoreLogic',
  'Karen Clark & Co',
  'PERILS AG',
  'Insurance',
  'Claim Group from SICs',
  'Custom'
];

// Custom select component that always opens downward
function CustomSelect({ value, onChange, options, placeholder }: {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  placeholder: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedLabel = options.find(o => o.value === value)?.label || '';

  return (
    <div className="relative" ref={ref}>
      <div
        className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md bg-white flex items-center justify-between cursor-pointer transition-all hover:border-blue-400 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className={`flex-1 truncate ${!value ? 'text-gray-400' : ''}`}>
          {value ? selectedLabel : placeholder}
        </span>
        <svg className={`w-4 h-4 text-gray-400 ml-2 flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
      {isOpen && (
        <div className="absolute z-20 w-full bg-white border border-gray-200 rounded-md shadow-lg mt-1 max-h-60 overflow-y-auto" style={{ top: '100%' }}>
          {options.map(opt => (
            <div
              key={opt.value}
              className={`px-3 py-2 text-sm cursor-pointer transition-colors ${
                opt.value === value ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
              }`}
              onClick={() => {
                onChange(opt.value);
                setIsOpen(false);
              }}
            >
              {opt.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function OtherIds({ data, onChange }: OtherIdsProps) {
  const [identifiers, setIdentifiers] = useState<EventIdentifier[]>(
    data.externalIds || []
  );

  const addIdentifier = () => {
    const newIdentifier: EventIdentifier = {
      id: Date.now().toString(),
      name: '',
      value: ''
    };
    const updated = [...identifiers, newIdentifier];
    setIdentifiers(updated);
    onChange({ externalIds: updated });
  };

  const updateIdentifier = (id: string, field: 'name' | 'value' | 'customName' | 'link', value: string) => {
    const updated = identifiers.map(item =>
      item.id === id ? { ...item, [field]: value } : item
    );
    setIdentifiers(updated);
    onChange({ externalIds: updated });
  };

  const removeIdentifier = (id: string) => {
    const updated = identifiers.filter(item => item.id !== id);
    setIdentifiers(updated);
    onChange({ externalIds: updated });
  };

  return (
    <div className="space-y-8">
      {/* Section Header */}
      

      {/* Form Card */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <p className="text-sm text-gray-600">
          Add external event IDs to link the event with industry or third-party identifiers.
        </p>
        <div className="space-y-4 mt-4">
          {identifiers.map((identifier) => (
            <div key={identifier.id} className="flex gap-4 items-start">
              <div className="flex-1">
                <label className="block text-gray-700 mb-1.5 text-sm font-medium">External Source</label>
                {identifier.name === 'Custom' ? (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter custom source name"
                      value={identifier.customName || ''}
                      onChange={(e) => updateIdentifier(identifier.id, 'customName' as any, e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => updateIdentifier(identifier.id, 'name', '')}
                      className="px-2 py-2 text-xs text-gray-500 hover:text-gray-700 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors whitespace-nowrap"
                    >
                      Back
                    </button>
                  </div>
                ) : (
                  <CustomSelect
                    value={identifier.name}
                    onChange={(value) => updateIdentifier(identifier.id, 'name', value)}
                    options={commonSources.map(source => ({ value: source, label: source }))}
                    placeholder="Select source"
                  />
                )}
              </div>

              <div className="flex-1">
                <label className="block text-gray-700 mb-1.5 text-sm font-medium">Event ID</label>
                <input
                  type="text"
                  placeholder="Enter external event ID"
                  value={identifier.value}
                  onChange={(e) => updateIdentifier(identifier.id, 'value', e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>

              <div className="flex-1">
                <label className="block text-gray-700 mb-1.5 text-sm font-medium">Link</label>
                <div className="relative">
                  <input
                    type="url"
                    placeholder="https://..."
                    value={identifier.link || ''}
                    onChange={(e) => updateIdentifier(identifier.id, 'link' as any, e.target.value)}
                    className="w-full px-3 py-2 pr-9 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                  {identifier.link && (
                    <a
                      href={identifier.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-blue-500 hover:text-blue-700 transition-colors"
                      title="Open link"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>

              <div className="pt-7">
                <button
                  onClick={() => removeIdentifier(identifier.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}

          <button
            onClick={addIdentifier}
            className="w-full px-4 py-3 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 text-gray-600 hover:text-blue-600 font-medium"
          >
            <Plus className="w-4 h-4" />
            Add External Event ID
          </button>
        </div>

        {identifiers.length === 0 && (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center mt-4">
            <p className="text-sm text-gray-600">
              No external event IDs added yet. Click the button above to add industry or third-party event identifiers.
            </p>
            <p className="text-xs text-gray-500 mt-2">
              External IDs are optional but support industry reconciliation and reporting.
            </p>
          </div>
        )}

        {identifiers.length > 0 && (
          null
        )}
      </div>
    </div>
  );
}