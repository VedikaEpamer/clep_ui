import { Routes, Route, Navigate } from 'react-router';
import { Component, type ReactNode } from 'react';
import { EventDetailLayout } from './event-detail/EventDetailLayout';
import { EventOverview } from './event-detail/EventOverview-NEW';
import { UnderwriterEstimationNew } from './event-detail/UnderwriterEstimationNew';
import { ModelingWorkspace } from './event-detail/ModelingWorkspace';
import { FinanceEstimation } from './event-detail/FinanceEstimation';
import { ClaimsEstimation } from './event-detail/ClaimsEstimation';
import { Documents } from './event-detail/Documents';
import { AuditLog } from './event-detail/AuditLog';

// Error boundary to catch and display runtime errors with useful diagnostics
class TabErrorBoundary extends Component<
  { children: ReactNode; tabName: string },
  { hasError: boolean; error: Error | null; errorInfo: string }
> {
  constructor(props: { children: ReactNode; tabName: string }) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: { componentStack?: string | null }) {
    const errorInfo = info.componentStack || '';
    this.setState({ errorInfo });
    console.error(`[SONAR ${this.props.tabName}] Runtime error:`, error);
    console.error(`[SONAR ${this.props.tabName}] Component stack:`, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      const { error, errorInfo } = this.state;
      return (
        <div className="p-8 max-w-4xl mx-auto">
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <h2 className="text-red-800 text-lg font-semibold mb-2">
              Runtime Error in {this.props.tabName}
            </h2>
            <p className="text-red-700 text-sm mb-4">
              {error?.message || 'Unknown error'}
            </p>
            {error?.stack && (
              <details className="mb-4">
                <summary className="text-red-600 text-xs cursor-pointer font-medium">
                  Stack Trace
                </summary>
                <pre className="mt-2 text-xs text-red-600 bg-red-100 p-3 rounded overflow-auto max-h-48 whitespace-pre-wrap">
                  {error.stack}
                </pre>
              </details>
            )}
            {errorInfo && (
              <details className="mb-4">
                <summary className="text-red-600 text-xs cursor-pointer font-medium">
                  Component Stack
                </summary>
                <pre className="mt-2 text-xs text-red-600 bg-red-100 p-3 rounded overflow-auto max-h-48 whitespace-pre-wrap">
                  {errorInfo}
                </pre>
              </details>
            )}
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => {
                  // Clear sessionStorage for this event to force reinit
                  const keys = Object.keys(sessionStorage);
                  keys.forEach(k => {
                    if (k.startsWith('uwEstimates') || k.startsWith('modeling')) {
                      sessionStorage.removeItem(k);
                    }
                  });
                  this.setState({ hasError: false, error: null, errorInfo: '' });
                }}
                className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700 transition-colors"
              >
                Clear Cache & Retry
              </button>
              <button
                onClick={() => this.setState({ hasError: false, error: null, errorInfo: '' })}
                className="px-4 py-2 bg-white border border-red-300 text-red-700 rounded-lg text-sm hover:bg-red-50 transition-colors"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export function EventDetail() {
  return (
    <Routes>
      <Route path="/" element={<EventDetailLayout />}>
        <Route index element={<Navigate to="overview" replace />} />
        <Route path="overview" element={
          <TabErrorBoundary tabName="Event Overview">
            <EventOverview />
          </TabErrorBoundary>
        } />
        <Route path="uw-estimation" element={
          <TabErrorBoundary tabName="UW Estimation">
            <UnderwriterEstimationNew />
          </TabErrorBoundary>
        } />
        <Route path="modeling" element={
          <TabErrorBoundary tabName="Modeling Workspace">
            <ModelingWorkspace />
          </TabErrorBoundary>
        } />
        <Route path="finance" element={
          <TabErrorBoundary tabName="Finance Estimation">
            <FinanceEstimation />
          </TabErrorBoundary>
        } />
        <Route path="claims" element={
          <TabErrorBoundary tabName="Claims Estimation">
            <ClaimsEstimation />
          </TabErrorBoundary>
        } />
        <Route path="documents" element={
          <TabErrorBoundary tabName="Documents">
            <Documents />
          </TabErrorBoundary>
        } />
        <Route path="audit" element={
          <TabErrorBoundary tabName="Audit Log">
            <AuditLog />
          </TabErrorBoundary>
        } />
      </Route>
    </Routes>
  );
}
