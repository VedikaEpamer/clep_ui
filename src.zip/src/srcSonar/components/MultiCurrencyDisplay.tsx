import { Info } from 'lucide-react';
import { useCurrency, MultiCurrencyAmount } from '../lib/currencyContext';
import { useState } from 'react';

interface MultiCurrencyDisplayProps {
  amount: MultiCurrencyAmount;
  showTooltip?: boolean;
  className?: string;
  boldBase?: boolean;
}

export function MultiCurrencyDisplay({ 
  amount, 
  showTooltip = true, 
  className = '',
  boldBase = false
}: MultiCurrencyDisplayProps) {
  const { settings, formatCurrency, getFXRate } = useCurrency();
  const [showDetails, setShowDetails] = useState(false);

  // Calculate FX rate between original and base
  const fxRate = getFXRate(amount.original.currency, amount.base.currency);

  if (settings.displayMode === 'all') {
    // Show all three currencies side by side
    return (
      <div className={`flex gap-4 ${className}`}>
        <div className="text-center">
          <div className="text-xs text-slate-500 mb-0.5">Original</div>
          <div className="font-medium text-slate-900">
            {formatCurrency(amount.original.amount, amount.original.currency)}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-500 mb-0.5">Accounting</div>
          <div className="font-medium text-slate-900">
            {formatCurrency(amount.accounting.amount, amount.accounting.currency)}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-500 mb-0.5">Base (USD)</div>
          <div className={`font-medium ${boldBase ? 'text-blue-700 font-semibold' : 'text-slate-900'}`}>
            {formatCurrency(amount.base.amount, amount.base.currency)}
          </div>
        </div>
      </div>
    );
  }

  // Show single currency with optional tooltip
  const displayValue = (() => {
    switch (settings.displayMode) {
      case 'original':
        return formatCurrency(amount.original.amount, amount.original.currency);
      case 'accounting':
        return formatCurrency(amount.accounting.amount, amount.accounting.currency);
      case 'base':
      default:
        return formatCurrency(amount.base.amount, amount.base.currency);
    }
  })();

  if (!showTooltip) {
    return <span className={className}>{displayValue}</span>;
  }

  return (
    <div className={`relative inline-flex items-center gap-1 ${className}`}>
      <span>{displayValue}</span>
      <button
        onMouseEnter={() => setShowDetails(true)}
        onMouseLeave={() => setShowDetails(false)}
        className="text-slate-400 hover:text-slate-600 transition-colors"
      >
        <Info className="w-3.5 h-3.5" />
      </button>

      {/* Tooltip */}
      {showDetails && (
        <div className="absolute z-50 top-full left-0 mt-1 w-64 bg-slate-900 text-white text-xs rounded-lg shadow-xl p-3">
          <div className="space-y-2">
            <div className="flex justify-between items-center pb-2 border-b border-slate-700">
              <span className="text-slate-400">Multi-Currency View</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-slate-400">Original:</span>
              <span className="font-medium">
                {formatCurrency(amount.original.amount, amount.original.currency)}
              </span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-slate-400">Accounting:</span>
              <span className="font-medium">
                {formatCurrency(amount.accounting.amount, amount.accounting.currency)}
              </span>
            </div>
            
            <div className="flex justify-between border-t border-slate-700 pt-2">
              <span className="text-slate-400">Base (USD):</span>
              <span className="font-semibold text-blue-300">
                {formatCurrency(amount.base.amount, amount.base.currency)}
              </span>
            </div>

            {amount.original.currency !== amount.base.currency && (
              <div className="text-slate-400 text-[10px] mt-2 pt-2 border-t border-slate-700">
                FX Rate: {fxRate.toFixed(4)} ({amount.original.currency}/{amount.base.currency})
                <br />
                Source: {settings.fxSource} | {new Date(settings.fxEffectiveDate).toLocaleDateString()}
              </div>
            )}
          </div>
          
          {/* Arrow pointing up */}
          <div className="absolute -top-1 left-4 w-2 h-2 bg-slate-900 transform rotate-45"></div>
        </div>
      )}
    </div>
  );
}

interface CurrencyBadgeProps {
  currency: string;
  className?: string;
}

export function CurrencyBadge({ currency, className = '' }: CurrencyBadgeProps) {
  const colorMap: Record<string, string> = {
    'USD': 'bg-blue-100 text-blue-700 border-blue-200',
    'EUR': 'bg-purple-100 text-purple-700 border-purple-200',
    'GBP': 'bg-green-100 text-green-700 border-green-200',
    'JPY': 'bg-red-100 text-red-700 border-red-200',
    'BRL': 'bg-yellow-100 text-yellow-700 border-yellow-200',
    'CLP': 'bg-orange-100 text-orange-700 border-orange-200',
    'MXN': 'bg-pink-100 text-pink-700 border-pink-200',
    'CAD': 'bg-indigo-100 text-indigo-700 border-indigo-200'
  };

  const colorClass = colorMap[currency] || 'bg-slate-100 text-slate-700 border-slate-200';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${colorClass} ${className}`}>
      {currency}
    </span>
  );
}
