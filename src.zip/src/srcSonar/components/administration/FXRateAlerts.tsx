import { useState } from 'react';
import { Bell, AlertTriangle, TrendingUp, TrendingDown, Plus, Edit2, Trash2, Check } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface FXAlert {
  id: string;
  currencyPair: string;
  condition: 'above' | 'below' | 'change';
  threshold: number;
  currentRate: number;
  status: 'active' | 'triggered' | 'inactive';
  createdBy: string;
  createdDate: string;
  lastTriggered?: string;
}

const mockAlerts: FXAlert[] = [
  {
    id: '1',
    currencyPair: 'USD/EUR',
    condition: 'above',
    threshold: 0.95,
    currentRate: 0.92,
    status: 'active',
    createdBy: 'Underwriting Team',
    createdDate: '2024-12-15'
  },
  {
    id: '2',
    currencyPair: 'USD/GBP',
    condition: 'below',
    threshold: 0.75,
    currentRate: 0.79,
    status: 'active',
    createdBy: 'Cat Modeling Team',
    createdDate: '2024-12-18'
  },
  {
    id: '3',
    currencyPair: 'USD/BRL',
    condition: 'change',
    threshold: 5.0,
    currentRate: 4.98,
    status: 'triggered',
    createdBy: 'LATAM Treaty Team',
    createdDate: '2024-12-10',
    lastTriggered: '2024-12-20'
  },
  {
    id: '4',
    currencyPair: 'USD/JPY',
    condition: 'above',
    threshold: 155.0,
    currentRate: 149.50,
    status: 'active',
    createdBy: 'Singapore Team',
    createdDate: '2024-12-12'
  }
];

export function FXRateAlerts() {
  const [alerts, setAlerts] = useState(mockAlerts);
  const [showCreateAlert, setShowCreateAlert] = useState(false);
  const [newAlert, setNewAlert] = useState({
    currencyPair: 'USD/EUR',
    condition: 'above' as 'above' | 'below' | 'change',
    threshold: 1.0
  });

  const handleCreateAlert = () => {
    const alert: FXAlert = {
      id: Date.now().toString(),
      ...newAlert,
      currentRate: 0.92,
      status: 'active',
      createdBy: 'Current User',
      createdDate: new Date().toISOString().split('T')[0]
    };
    
    setAlerts([...alerts, alert]);
    setShowCreateAlert(false);
    setNewAlert({ currencyPair: 'USD/EUR', condition: 'above', threshold: 1.0 });
    toast.success('FX rate alert created successfully');
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts(alerts.filter(a => a.id !== id));
    toast.success('FX rate alert deleted');
  };

  const activeAlerts = alerts.filter(a => a.status === 'active').length;
  const triggeredAlerts = alerts.filter(a => a.status === 'triggered').length;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Active Alerts</div>
            <Bell className="w-5 h-5 text-blue-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900 mb-1">{activeAlerts}</div>
          <div className="text-xs text-slate-500">Monitoring FX rates</div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Triggered Alerts</div>
            <AlertTriangle className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-3xl font-bold text-amber-600 mb-1">{triggeredAlerts}</div>
          <div className="text-xs text-slate-500">Require attention</div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Total Alerts</div>
            <Check className="w-5 h-5 text-green-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900 mb-1">{alerts.length}</div>
          <div className="text-xs text-slate-500">All configurations</div>
        </div>
      </div>

      {/* Create Alert Button */}
      <div className="flex justify-end">
        <button
          onClick={() => setShowCreateAlert(!showCreateAlert)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Create FX Alert
        </button>
      </div>

      {/* Create Alert Form */}
      {showCreateAlert && (
        <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm">
          <h3 className="font-semibold text-slate-900 mb-4">Create New FX Rate Alert</h3>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Currency Pair
              </label>
              <select
                value={newAlert.currencyPair}
                onChange={(e) => setNewAlert({ ...newAlert, currencyPair: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option>USD/EUR</option>
                <option>USD/GBP</option>
                <option>USD/JPY</option>
                <option>USD/BRL</option>
                <option>USD/CLP</option>
                <option>USD/MXN</option>
                <option>EUR/GBP</option>
                <option>EUR/JPY</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Condition
              </label>
              <select
                value={newAlert.condition}
                onChange={(e) => setNewAlert({ ...newAlert, condition: e.target.value as any })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="above">Rate goes above</option>
                <option value="below">Rate goes below</option>
                <option value="change">Rate changes by ±</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Threshold
              </label>
              <input
                type="number"
                step="0.01"
                value={newAlert.threshold}
                onChange={(e) => setNewAlert({ ...newAlert, threshold: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              onClick={() => setShowCreateAlert(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleCreateAlert}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all"
            >
              Create Alert
            </button>
          </div>
        </div>
      )}

      {/* Alerts Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="font-semibold text-slate-900">FX Rate Alerts</h3>
          <p className="text-sm text-slate-600 mt-1">Automated notifications when rates meet conditions</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Currency Pair
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Condition
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Threshold
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Current Rate
                </th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Created By
                </th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {alerts.map((alert) => {
                const conditionMet = 
                  (alert.condition === 'above' && alert.currentRate > alert.threshold) ||
                  (alert.condition === 'below' && alert.currentRate < alert.threshold);

                return (
                  <tr key={alert.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-900">{alert.currencyPair}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1 text-sm text-slate-600">
                        {alert.condition === 'above' && <TrendingUp className="w-4 h-4 text-green-600" />}
                        {alert.condition === 'below' && <TrendingDown className="w-4 h-4 text-red-600" />}
                        <span className="capitalize">{alert.condition}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-slate-900">
                      {alert.threshold.toFixed(4)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className={`font-semibold ${
                        conditionMet ? 'text-amber-600' : 'text-slate-900'
                      }`}>
                        {alert.currentRate.toFixed(4)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${
                        alert.status === 'triggered'
                          ? 'bg-amber-100 text-amber-700'
                          : alert.status === 'active'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {alert.status === 'triggered' && '⚠️ '}
                        {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-slate-900">{alert.createdBy}</div>
                      <div className="text-xs text-slate-500">{alert.createdDate}</div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          className="text-blue-600 hover:text-blue-800 transition-colors"
                          title="Edit alert"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteAlert(alert.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                          title="Delete alert"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bloomberg Integration Note */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <Bell className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="font-medium text-blue-900 mb-1">Bloomberg RDM Alert Integration</div>
          <div className="text-sm text-blue-700">
            Alerts are evaluated in real-time against Bloomberg Reference Data Management rates. 
            Notifications are sent via email and platform when conditions are met. 
            Configure notification preferences in User Settings.
          </div>
        </div>
      </div>
    </div>
  );
}
