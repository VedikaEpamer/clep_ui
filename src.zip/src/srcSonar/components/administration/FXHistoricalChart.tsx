import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp, TrendingDown, Calendar } from 'lucide-react';

interface FXHistoricalChartProps {
  fromCurrency: string;
  toCurrency: string;
}

// Generate mock historical data (will be replaced by Bloomberg RDM feed)
const generateHistoricalData = (baserate: number, days: number = 30) => {
  const data = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Simulate realistic FX fluctuations
    const variance = (Math.random() - 0.5) * 0.02; // ±2% daily variance
    const rate = baserate * (1 + variance * (i / days));
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      fullDate: date.toISOString().split('T')[0],
      rate: parseFloat(rate.toFixed(4)),
      bid: parseFloat((rate * 0.9995).toFixed(4)),
      ask: parseFloat((rate * 1.0005).toFixed(4))
    });
  }
  
  return data;
};

export function FXHistoricalChart({ fromCurrency, toCurrency }: FXHistoricalChartProps) {
  const [timeRange, setTimeRange] = useState<'7D' | '30D' | '90D' | '1Y'>('30D');
  
  // Mock base rates (will be replaced by Bloomberg RDM)
  const baseRates: Record<string, number> = {
    'USD-EUR': 0.92,
    'USD-GBP': 0.79,
    'USD-JPY': 149.50,
    'USD-BRL': 4.98,
    'USD-CLP': 973.50,
    'EUR-GBP': 0.86,
    'EUR-JPY': 162.80,
    'GBP-JPY': 189.30
  };
  
  const pairKey = `${fromCurrency}-${toCurrency}`;
  const baseRate = baseRates[pairKey] || 1.0;
  
  const days = {
    '7D': 7,
    '30D': 30,
    '90D': 90,
    '1Y': 365
  }[timeRange];
  
  const data = generateHistoricalData(baseRate, days);
  
  const currentRate = data[data.length - 1].rate;
  const previousRate = data[0].rate;
  const change = currentRate - previousRate;
  const changePercent = ((change / previousRate) * 100).toFixed(2);
  const isPositive = change >= 0;

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 bg-blue-100 text-blue-700 text-sm font-semibold rounded">
              {fromCurrency}
            </span>
            <span className="text-slate-400">→</span>
            <span className="px-2.5 py-1 bg-purple-100 text-purple-700 text-sm font-semibold rounded">
              {toCurrency}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-3xl font-bold text-slate-900">
              {currentRate.toFixed(4)}
            </div>
            <div className={`flex items-center gap-1 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {isPositive ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              <span className="font-semibold">
                {isPositive ? '+' : ''}{changePercent}%
              </span>
              <span className="text-sm text-slate-500">({timeRange})</span>
            </div>
          </div>
        </div>
        
        {/* Time Range Selector */}
        <div className="flex items-center gap-2 bg-slate-100 rounded-lg p-1">
          {(['7D', '30D', '90D', '1Y'] as const).map(range => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                timeRange === range
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis 
            dataKey="date" 
            stroke="#64748b"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            stroke="#64748b"
            tick={{ fontSize: 12 }}
            domain={['dataMin - 0.01', 'dataMax + 0.01']}
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
            }}
            formatter={(value: number) => value.toFixed(4)}
          />
          <Area 
            type="monotone" 
            dataKey="rate" 
            stroke="#3b82f6" 
            strokeWidth={2}
            fill="url(#colorRate)"
            name="Mid Rate"
          />
        </AreaChart>
      </ResponsiveContainer>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-200">
        <div>
          <div className="text-xs text-slate-500 mb-1">Current Rate</div>
          <div className="font-semibold text-slate-900">{currentRate.toFixed(4)}</div>
        </div>
        <div>
          <div className="text-xs text-slate-500 mb-1">High ({timeRange})</div>
          <div className="font-semibold text-green-600">
            {Math.max(...data.map(d => d.rate)).toFixed(4)}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 mb-1">Low ({timeRange})</div>
          <div className="font-semibold text-red-600">
            {Math.min(...data.map(d => d.rate)).toFixed(4)}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 mb-1">Avg ({timeRange})</div>
          <div className="font-semibold text-slate-900">
            {(data.reduce((sum, d) => sum + d.rate, 0) / data.length).toFixed(4)}
          </div>
        </div>
      </div>

      {/* Bloomberg RDM Integration Note */}
      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-2">
        <Calendar className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-blue-800">
          <span className="font-medium">Bloomberg RDM Ready:</span> Historical data will sync from Bloomberg Reference Data Management feed
        </div>
      </div>
    </div>
  );
}
