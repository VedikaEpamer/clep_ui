import { useState } from 'react';
import { RefreshCw, Download, Upload, TrendingUp, TrendingDown, AlertCircle, CheckCircle, Edit2, Save, X, BarChart2, Bell } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { FXHistoricalChart } from './FXHistoricalChart';
import { CurrencyGainLoss } from './CurrencyGainLoss';
import { FXRateAlerts } from './FXRateAlerts';

interface FXRateEntry {
  fromCurrency: string;
  toCurrency: string;
  rate: number;
  bidRate: number;
  askRate: number;
  midRate: number;
  effectiveDate: string;
  source: string;
  change24h: number;
  lastUpdated: string;
}

const currencyPairs = [
  { from: 'USD', to: 'EUR', rate: 0.92, bid: 0.9195, ask: 0.9205, mid: 0.92, change: -0.15, source: 'Bloomberg' },
  { from: 'USD', to: 'GBP', rate: 0.79, bid: 0.7895, ask: 0.7905, mid: 0.79, change: 0.22, source: 'Bloomberg' },
  { from: 'USD', to: 'JPY', rate: 149.50, bid: 149.45, ask: 149.55, mid: 149.50, change: 0.67, source: 'Bloomberg' },
  { from: 'USD', to: 'BRL', rate: 4.98, bid: 4.977, ask: 4.983, mid: 4.98, change: -1.24, source: 'Bloomberg' },
  { from: 'USD', to: 'CLP', rate: 973.50, bid: 973.00, ask: 974.00, mid: 973.50, change: 0.45, source: 'Bloomberg' },
  { from: 'USD', to: 'MXN', rate: 17.15, bid: 17.14, ask: 17.16, mid: 17.15, change: -0.34, source: 'Bloomberg' },
  { from: 'USD', to: 'CAD', rate: 1.35, bid: 1.3495, ask: 1.3505, mid: 1.35, change: 0.11, source: 'Bloomberg' },
  { from: 'EUR', to: 'GBP', rate: 0.86, bid: 0.8595, ask: 0.8605, mid: 0.86, change: 0.18, source: 'Bloomberg' },
  { from: 'EUR', to: 'JPY', rate: 162.80, bid: 162.75, ask: 162.85, mid: 162.80, change: 0.52, source: 'Bloomberg' },
  { from: 'GBP', to: 'JPY', rate: 189.30, bid: 189.20, ask: 189.40, mid: 189.30, change: 0.38, source: 'Bloomberg' },
];

export function FXRateManagement() {
  const [rates, setRates] = useState(currencyPairs);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSource, setSelectedSource] = useState('All Sources');
  const effectiveDate = new Date().toISOString().split('T')[0];
  const lastUpdated = new Date().toLocaleString();

  const handleRefreshRates = async () => {
    setIsRefreshing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Update rates with small random changes
    setRates(prevRates => 
      prevRates.map(rate => ({
        ...rate,
        rate: rate.rate * (1 + (Math.random() - 0.5) * 0.01),
        change24h: (Math.random() - 0.5) * 2,
        lastUpdated: new Date().toLocaleString()
      }))
    );
    
    setIsRefreshing(false);
    toast.success('FX rates updated successfully');
  };

  const handleDownloadRates = () => {
    const csvContent = 'From Currency,To Currency,Rate,Bid,Ask,Mid,Change 24h,Source,Effective Date\n' +
      rates.map(r => `${r.from},${r.to},${r.rate.toFixed(4)},${r.bid.toFixed(4)},${r.ask.toFixed(4)},${r.mid.toFixed(4)},${r.change.toFixed(2)}%,${r.source},${effectiveDate}`).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FX_Rates_${effectiveDate}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    toast.success('FX rates exported successfully');
  };

  const filteredRates = rates.filter(rate => {
    const matchesSearch = searchQuery === '' || 
      rate.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rate.to.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSource = selectedSource === 'All Sources' || rate.source === selectedSource;
    return matchesSearch && matchesSource;
  });

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">FX Rate Management</h1>
        <p className="text-slate-600">Manage foreign exchange rates for multi-currency loss calculations</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm opacity-90">Total Currency Pairs</div>
            <RefreshCw className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold">{rates.length}</div>
          <div className="text-xs mt-2 opacity-80">Active pairs</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Base Currency</div>
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">
              $
            </div>
          </div>
          <div className="text-3xl font-bold text-slate-900">USD</div>
          <div className="text-xs mt-2 text-slate-500">Corporate standard</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Last Updated</div>
            <CheckCircle className="w-5 h-5 text-green-600" />
          </div>
          <div className="text-lg font-semibold text-slate-900">{new Date().toLocaleTimeString()}</div>
          <div className="text-xs mt-2 text-slate-500">{effectiveDate}</div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Rate Source</div>
            <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-purple-700" />
            </div>
          </div>
          <div className="text-lg font-semibold text-slate-900">Bloomberg</div>
          <div className="text-xs mt-2 text-slate-500">Live feed</div>
        </div>
      </div>

      {/* Actions Bar */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 mb-6 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Search */}
            <input
              type="text"
              placeholder="Search currency pairs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3 py-2 border border-slate-300 rounded-lg text-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            {/* Source Filter */}
            <select
              value={selectedSource}
              onChange={(e) => setSelectedSource(e.target.value)}
              className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option>All Sources</option>
              <option>Bloomberg</option>
              <option>Reuters</option>
              <option>Manual</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            {/* Refresh Rates */}
            <button
              onClick={handleRefreshRates}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Updating...' : 'Refresh Rates'}
            </button>

            {/* Download */}
            <button
              onClick={handleDownloadRates}
              className="flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-all text-sm"
            >
              <Download className="w-4 h-4" />
              Export
            </button>

            {/* Upload */}
            <button
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all text-sm"
            >
              <Upload className="w-4 h-4" />
              Import Rates
            </button>
          </div>
        </div>
      </div>

      {/* FX Rates Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Currency Pair
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Mid Rate
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Bid
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Ask
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  24h Change
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Source
                </th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRates.map((rate, index) => {
                const pairId = `${rate.from}-${rate.to}`;
                const isEditing = editingId === pairId;

                return (
                  <tr key={index} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded">
                            {rate.from}
                          </span>
                          <span className="text-slate-400">→</span>
                          <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-semibold rounded">
                            {rate.to}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="font-semibold text-slate-900">
                        {rate.mid.toFixed(4)}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right text-sm text-slate-600">
                      {rate.bid.toFixed(4)}
                    </td>
                    <td className="px-6 py-4 text-right text-sm text-slate-600">
                      {rate.ask.toFixed(4)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className={`flex items-center justify-end gap-1 ${
                        rate.change > 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {rate.change > 0 ? (
                          <TrendingUp className="w-4 h-4" />
                        ) : (
                          <TrendingDown className="w-4 h-4" />
                        )}
                        <span className="font-medium">{Math.abs(rate.change).toFixed(2)}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700">
                        {rate.source}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button
                        className="text-blue-600 hover:text-blue-800 transition-colors"
                        title="Edit rate"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Info Banner */}
      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="font-medium text-blue-900 mb-1">Multi-Currency Support Active</div>
          <div className="text-sm text-blue-700">
            FX rates are automatically applied to all loss calculations. Original, accounting, and base currency values are maintained throughout the system. 
            Rates are updated every 15 minutes during market hours from Bloomberg.
          </div>
        </div>
      </div>

      {/* Historical Chart */}
      <div className="mt-8">
        <FXHistoricalChart fromCurrency="USD" toCurrency="EUR" />
      </div>

      {/* Currency Gain/Loss */}
      <div className="mt-8">
        <CurrencyGainLoss />
      </div>

      {/* FX Rate Alerts */}
      <div className="mt-8">
        <FXRateAlerts />
      </div>
    </div>
  );
}