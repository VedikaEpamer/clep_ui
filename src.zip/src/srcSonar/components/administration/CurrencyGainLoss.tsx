import { useState } from 'react';
import { TrendingUp, TrendingDown, AlertCircle, DollarSign, Calendar } from 'lucide-react';

interface CurrencyExposure {
  currency: string;
  exposure: number;
  exposureUSD: number;
  gainLoss: number;
  gainLossPercent: number;
  contracts: number;
}

// Mock currency exposure data (will be calculated from actual contracts)
const mockExposures: CurrencyExposure[] = [
  { currency: 'EUR', exposure: 125000000, exposureUSD: 136250000, gainLoss: 1250000, gainLossPercent: 0.92, contracts: 47 },
  { currency: 'GBP', exposure: 89000000, exposureUSD: 112030000, gainLoss: -890000, gainLossPercent: -0.79, contracts: 32 },
  { currency: 'BRL', exposure: 450000000, exposureUSD: 90361000, gainLoss: 2250000, gainLossPercent: 2.49, contracts: 18 },
  { currency: 'JPY', exposure: 12500000000, exposureUSD: 83612000, gainLoss: -410000, gainLossPercent: -0.49, contracts: 15 },
  { currency: 'CLP', exposure: 62000000000, exposureUSD: 63700000, gainLoss: 320000, gainLossPercent: 0.50, contracts: 12 },
  { currency: 'MXN', exposure: 980000000, exposureUSD: 56860000, gainLoss: -180000, gainLossPercent: -0.32, contracts: 8 },
];

export function CurrencyGainLoss() {
  const [selectedPeriod, setSelectedPeriod] = useState<'MTD' | 'QTD' | 'YTD'>('MTD');
  
  const totalExposureUSD = mockExposures.reduce((sum, exp) => sum + exp.exposureUSD, 0);
  const totalGainLoss = mockExposures.reduce((sum, exp) => sum + exp.gainLoss, 0);
  const totalGainLossPercent = (totalGainLoss / totalExposureUSD) * 100;
  
  const formatCurrency = (amount: number, currency: string = 'USD') => {
    const absAmount = Math.abs(amount);
    if (absAmount >= 1_000_000_000) {
      return `${currency} ${(amount / 1_000_000_000).toFixed(2)}B`;
    } else if (absAmount >= 1_000_000) {
      return `${currency} ${(amount / 1_000_000).toFixed(2)}M`;
    }
    return `${currency} ${amount.toLocaleString()}`;
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm opacity-90">Total Exposure (USD)</div>
            <DollarSign className="w-5 h-5 opacity-80" />
          </div>
          <div className="text-3xl font-bold mb-1">
            ${(totalExposureUSD / 1_000_000).toFixed(1)}M
          </div>
          <div className="text-xs opacity-80">Across 132 contracts</div>
        </div>

        <div className={`rounded-xl p-6 text-white shadow-lg ${
          totalGainLoss >= 0 
            ? 'bg-gradient-to-br from-green-500 to-green-600' 
            : 'bg-gradient-to-br from-red-500 to-red-600'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm opacity-90">FX Gain/Loss ({selectedPeriod})</div>
            {totalGainLoss >= 0 ? (
              <TrendingUp className="w-5 h-5 opacity-80" />
            ) : (
              <TrendingDown className="w-5 h-5 opacity-80" />
            )}
          </div>
          <div className="text-3xl font-bold mb-1">
            {totalGainLoss >= 0 ? '+' : ''}${(totalGainLoss / 1_000_000).toFixed(2)}M
          </div>
          <div className="text-xs opacity-80">
            {totalGainLossPercent >= 0 ? '+' : ''}{totalGainLossPercent.toFixed(2)}% of exposure
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-slate-600">Period</div>
            <Calendar className="w-5 h-5 text-slate-400" />
          </div>
          <div className="flex gap-2 mb-2">
            {(['MTD', 'QTD', 'YTD'] as const).map(period => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedPeriod === period
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
          <div className="text-xs text-slate-500 mt-2">
            {selectedPeriod === 'MTD' && 'Month to Date: Dec 1-22'}
            {selectedPeriod === 'QTD' && 'Quarter to Date: Oct 1 - Dec 22'}
            {selectedPeriod === 'YTD' && 'Year to Date: Jan 1 - Dec 22'}
          </div>
        </div>
      </div>

      {/* Currency Exposure Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="font-semibold text-slate-900">Currency Exposure Analysis</h3>
          <p className="text-sm text-slate-600 mt-1">FX gain/loss by currency ({selectedPeriod})</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Currency
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Exposure (Original)
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Exposure (USD)
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  FX Gain/Loss
                </th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  % Change
                </th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  Contracts
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {mockExposures.map((exp, index) => {
                const isGain = exp.gainLoss >= 0;
                
                return (
                  <tr key={index} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 bg-blue-100 text-blue-700 text-sm font-semibold rounded">
                          {exp.currency}
                        </span>
                        <div className="w-32 bg-slate-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${(exp.exposureUSD / totalExposureUSD) * 100}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-slate-900">
                      {formatCurrency(exp.exposure, exp.currency)}
                    </td>
                    <td className="px-6 py-4 text-right font-semibold text-slate-900">
                      {formatCurrency(exp.exposureUSD, 'USD')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className={`flex items-center justify-end gap-1 font-semibold ${
                        isGain ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {isGain ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                        <span>
                          {isGain ? '+' : ''}{formatCurrency(exp.gainLoss, 'USD')}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${
                        isGain 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {isGain ? '+' : ''}{exp.gainLossPercent.toFixed(2)}%
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center text-sm text-slate-600">
                      {exp.contracts}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-50 border-t-2 border-slate-300">
              <tr>
                <td className="px-6 py-4 font-semibold text-slate-900">
                  TOTAL
                </td>
                <td className="px-6 py-4 text-right font-semibold text-slate-900">
                  —
                </td>
                <td className="px-6 py-4 text-right font-bold text-slate-900">
                  {formatCurrency(totalExposureUSD, 'USD')}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className={`flex items-center justify-end gap-1 font-bold ${
                    totalGainLoss >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {totalGainLoss >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span>
                      {totalGainLoss >= 0 ? '+' : ''}{formatCurrency(totalGainLoss, 'USD')}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${
                    totalGainLoss >= 0 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {totalGainLoss >= 0 ? '+' : ''}{totalGainLossPercent.toFixed(2)}%
                  </span>
                </td>
                <td className="px-6 py-4 text-center font-semibold text-slate-900">
                  {mockExposures.reduce((sum, exp) => sum + exp.contracts, 0)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="font-medium text-blue-900 mb-1">Real-Time FX Impact Tracking</div>
          <div className="text-sm text-blue-700">
            Currency gain/loss is calculated by comparing contract values at inception FX rates vs. current Bloomberg rates. 
            These calculations update automatically as FX rates change in the Bloomberg RDM feed.
          </div>
        </div>
      </div>
    </div>
  );
}
