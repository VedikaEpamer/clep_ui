import { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import { X, Save, Send, FileText, Bell, AlertTriangle, Users } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { EventIdentity } from './event-creation/EventIdentity';
import { ImpactRegionsPerils } from './event-creation/ImpactRegionsPerils';
import { OtherIds } from './event-creation/OtherIds';
import { MarketLoss } from './event-creation/MarketLoss';
import { DeadlinesTracking } from './event-creation/DeadlinesTracking';
import { mockEvents } from '../lib/mockData';
import { useWorkflow } from '../lib/workflowContext';
import type { WorkflowPhase } from '../lib/workflowContext';
import everestLogo from 'figma:asset/caba23401a17fe2f9b2a6d285e246c7856b7dfec.png';

const steps = [
  { id: 1, name: 'Event Identity', component: EventIdentity },
  { id: 2, name: 'Impact Regions & Perils', component: ImpactRegionsPerils },
  { id: 3, name: 'Other IDs', component: OtherIds },
  { id: 4, name: 'Industry Market Loss', component: MarketLoss },
  { id: 5, name: 'Deadlines & Tracking', component: DeadlinesTracking }
];

export function EventCreation() {
  const navigate = useNavigate();
  const { setPhase } = useWorkflow();
  const [currentStep, setCurrentStep] = useState(1);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [rosterCreated, setRosterCreated] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [showValidation, setShowValidation] = useState(false);
  const [isEventPublished, setIsEventPublished] = useState(false);
  const [eventData, setEventData] = useState<any>({
    eventId: `EVT-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
    phase: 1
  });
  const sectionRefs = useRef<{ [key: number]: HTMLDivElement | null }>({});

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const sections = container.querySelectorAll('[data-step]');
    
    sections.forEach((section) => {
      const rect = section.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      
      // Check if section is in the middle of the viewport
      if (rect.top <= containerRect.height / 2 && rect.bottom >= containerRect.height / 2) {
        const stepNumber = parseInt(section.getAttribute('data-step') || '1');
        setCurrentStep(stepNumber);
      }
    });
  };

  const handleSaveDraft = () => {
    setIsSavingDraft(true);
    
    // Create the draft event object with partial data
    const draftEvent = {
      id: eventData.eventId,
      eventName: eventData.eventName || 'Untitled Event Draft',
      peril: eventData.peril || 'Hurricane',
      status: 'Draft' as const,
      lossDate: eventData.lossDate || new Date().toISOString().split('T')[0],
      grossAmountRange: eventData.marketLoss || 'TBD',
      contracts: 0,
      progress: Math.round((currentStep / steps.length) * 100),
      phase: 1,
      region: eventData.region || 'North America',
      owner: 'Sarah Johnson',
      catCode: eventData.catCode,
      eventType: eventData.eventType || 'CAT',
      businessUnit: eventData.businessUnit || 'Property',
      description: eventData.description || 'Event in draft - completion pending',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };

    // Add to mock events (simulating API call)
    mockEvents.unshift(draftEvent);

    // Simulate API delay
    setTimeout(() => {
      setIsSavingDraft(false);
      toast.success('Draft saved successfully!', {
        description: `${draftEvent.eventName} has been saved. You can continue editing later.`
      });
      
      // Navigate to events dashboard to show the draft
      navigate('/events');
    }, 1000);
  };

  const handlePublish = () => {
    // Validate mandatory fields before publishing
    const errors: string[] = [];
    
    // Event Identity mandatory fields
    if (!eventData.eventName?.trim()) errors.push('Event Name');
    if (!eventData.everestEventType) errors.push('Type of Everest Event');
    if (!eventData.eventType) errors.push('Event Type');
    if (!eventData.eventSubType) errors.push('Event Sub-Type');
    if (!eventData.businessGroups || eventData.businessGroups.length === 0) errors.push('Business Groups');
    if (!eventData.lossStartDate) errors.push('Loss Start Date');
    if (!eventData.lossEndDate) errors.push('Loss End Date');
    
    // Impact Regions — mandatory only for NAT CAT
    if (eventData.everestEventType === 'NAT CAT') {
      if (!eventData.impactedCountries || eventData.impactedCountries.length === 0) {
        errors.push('Impacted Regions');
      }
    }
    
    if (errors.length > 0) {
      setValidationErrors(errors);
      setShowValidation(true);
      setIsPublishing(false);
      toast.error(`Cannot publish — ${errors.length} mandatory field${errors.length > 1 ? 's' : ''} missing`, {
        description: errors.join(', '),
        duration: 6000,
      });
      // Scroll to top to show first error
      const contentEl = document.getElementById('event-creation-content');
      if (contentEl) contentEl.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    
    setShowValidation(false);
    setValidationErrors([]);
    setIsPublishing(true);
    
    // Determine the initial phase based on monitoring and tracking selections
    let initialPhase: WorkflowPhase = 'Event Creation';
    const hasMonitoring = eventData.monitoring !== false; // default true
    const hasTracking = eventData.trackImmediately || false;
    
    if (hasTracking) {
      // If both Monitoring and Tracking are selected → move to Tracking (Estimation & Approval)
      initialPhase = 'Estimation & Approval';
    } else if (hasMonitoring) {
      // If only Monitoring is selected → move to Monitoring
      initialPhase = 'Monitoring';
    }
    
    // Create the new event object with realistic data
    // Status depends on monitoring/tracking selection:
    // Neither checked → Draft, Monitoring only → Active, Tracking → Active
    const eventStatus = initialPhase === 'Event Creation' ? 'Draft' as const : 'Active' as const;
    const newEvent = {
      id: eventData.eventId,
      eventName: eventData.eventName || 'New Event',
      peril: eventData.peril || 'Hurricane',
      status: eventStatus,
      lossDate: eventData.lossDate || new Date().toISOString().split('T')[0],
      grossAmountRange: eventData.marketLoss || '$0 - $0',
      contracts: Math.floor(Math.random() * 500) + 100,
      progress: 5,
      phase: 1,
      region: eventData.region || 'North America',
      owner: 'Sarah Johnson',
      catCode: eventData.catCode,
      eventType: eventData.eventType || 'CAT',
      businessUnit: eventData.businessUnit || 'Property',
      description: eventData.description || 'New event created via Event Creation Wizard',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };

    // Add to mock events (simulating API call)
    mockEvents.unshift(newEvent);
    
    // Set the workflow phase based on selections
    setPhase(eventData.eventId, initialPhase);

    // Simulate API delay
    setTimeout(() => {
      setIsPublishing(false);
      setIsEventPublished(true); // Lock fields after publishing
      const phaseMessage = initialPhase === 'Estimation & Approval' 
        ? 'Event is now in Estimation & Approval phase.'
        : initialPhase === 'Monitoring'
        ? 'Event is now in Monitoring phase.'
        : 'Event saved as Draft. Enable Monitoring or Tracking to activate.';
      toast.success('Event published successfully!', {
        description: `${newEvent.eventName} has been created. ${phaseMessage}`
      });
      
      // Navigate to the new event's overview page
      navigate(`/events/${eventData.eventId}/overview`);
    }, 1500);
  };

  const handleCreateRoster = () => {
    // Validate mandatory fields before creating roster (same validation as Publish)
    const errors: string[] = [];
    
    // Event Identity mandatory fields
    if (!eventData.eventName?.trim()) errors.push('Event Name');
    if (!eventData.everestEventType) errors.push('Type of Everest Event');
    if (!eventData.eventType) errors.push('Event Type');
    if (!eventData.eventSubType) errors.push('Event Sub-Type');
    if (!eventData.businessGroups || eventData.businessGroups.length === 0) errors.push('Business Groups');
    if (!eventData.lossStartDate) errors.push('Loss Start Date');
    if (!eventData.lossEndDate) errors.push('Loss End Date');
    
    // Impact Regions — mandatory only for NAT CAT
    if (eventData.everestEventType === 'NAT CAT') {
      if (!eventData.impactedCountries || eventData.impactedCountries.length === 0) {
        errors.push('Impacted Regions');
      }
    }
    
    if (errors.length > 0) {
      setValidationErrors(errors);
      setShowValidation(true);
      toast.error(`Cannot create roster — ${errors.length} mandatory field${errors.length > 1 ? 's' : ''} missing`, {
        description: errors.join(', '),
        duration: 6000,
      });
      // Scroll to top to show first error
      const contentEl = document.getElementById('event-creation-content');
      if (contentEl) contentEl.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    
    // All validations passed - create the roster
    setRosterCreated(true);
    setShowValidation(false);
    setValidationErrors([]);
    toast.success('Roster created — you can now Publish & Notify');
  };

  const updateEventData = (data: any) => {
    setEventData({ ...eventData, ...data });
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Top Header Bar - Matches MainLayout exactly */}
      <div className="h-16 bg-[#001f3f] border-b border-blue-900/30 flex items-center justify-between px-0 flex-shrink-0 z-50">
        {/* Left: Logo + SONAR */}
        <div className="h-full flex items-center px-5 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img 
              src={everestLogo} 
              alt="Everest Logo" 
              className="h-10 object-contain pointer-events-none" 
            />
            <span className="text-white text-xl font-semibold tracking-wide flex items-center">SONAR</span>
          </div>
        </div>
        {/* Right: Cancel */}
        <div className="flex items-center gap-4 pr-8">
          <button
            onClick={() => navigate('/events')}
            className="p-2 hover:bg-white/10 rounded-md transition-colors"
          >
            
          </button>
        </div>
      </div>

      {/* Content Area - Full Width */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Sub Header - Create New Event */}
        <div className="bg-white border-b border-gray-200 px-8 py-4 shadow-sm flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-gray-900">Create New Event</h2>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/events')}
                className="px-4 py-2 text-sm border border-gray-200 rounded-md hover:bg-gray-50 transition-colors text-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveDraft}
                disabled={isSavingDraft}
                className="px-4 py-2 text-sm border border-gray-200 rounded-md hover:bg-gray-50 transition-colors text-gray-700 flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSavingDraft ? (
                  <>
                    <div className="w-4 h-4 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save as Draft
                  </>
                )}
              </button>
              <button
                onClick={handleCreateRoster}
                className={`px-4 py-2 text-sm rounded-md transition-colors flex items-center gap-1.5 border ${
                  rosterCreated
                    ? 'bg-green-50 border-green-400 text-green-700 cursor-default'
                    : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Users className="w-4 h-4" />
                {rosterCreated ? 'Roster Created ✓' : 'Create Roster'}
              </button>
              <button
                onClick={handlePublish}
                disabled={isPublishing || !rosterCreated}
                className="px-4 py-2 text-sm text-white rounded-md transition-colors flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ backgroundColor: rosterCreated && !isPublishing ? '#0052FF' : '#94a3b8' }}
                onMouseEnter={(e) => rosterCreated && !isPublishing && (e.currentTarget.style.backgroundColor = '#003DAA')}
                onMouseLeave={(e) => rosterCreated && !isPublishing && (e.currentTarget.style.backgroundColor = '#0052FF')}
                title={!rosterCreated ? 'Create the Roster first to enable this action' : undefined}
              >
                {isPublishing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Publish & Notify
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Form Content - White Clean Background */}
        <div className="flex-1 overflow-auto bg-gray-50" onScroll={handleScroll}>
          <div className="max-w-6xl mx-auto px-8 py-8 space-y-6" id="event-creation-content">
            {steps.map((step) => (
              <div key={step.id} data-step={step.id} className="scroll-mt-8" ref={el => sectionRefs.current[step.id] = el}>
                {/* Clean White Card */}
                <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
                  {/* Step Header */}
                  <div className={`px-6 py-4 border-b transition-colors ${
                    step.id === currentStep 
                      ? 'bg-blue-50 border-blue-100' 
                      : 'bg-gray-50 border-gray-200'
                  }`}>
                    <div className="flex items-center gap-3">
                      <div 
                        className={`w-8 h-8 rounded-md flex items-center justify-center text-sm font-medium ${
                          step.id === currentStep 
                            ? 'text-white' 
                            : step.id < currentStep
                            ? 'bg-green-500 text-white'
                            : 'bg-gray-200 text-gray-500'
                        }`}
                        style={step.id === currentStep ? { backgroundColor: '#0052FF' } : undefined}
                      >
                        {step.id < currentStep ? '✓' : step.id}
                      </div>
                      <div>
                        <h3 className="text-base font-medium text-gray-900">{step.name}</h3>
                      </div>
                    </div>
                  </div>
                  
                  {/* Step Content */}
                  <div className="px-6 py-6">
                    {step.component && (
                      <step.component 
                        data={eventData} 
                        onChange={updateEventData} 
                        showValidation={showValidation} 
                        validationErrors={validationErrors}
                        isEventPublished={isEventPublished}
                      />
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {/* Publish Section */}
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
              <div className="px-6 py-10">
                <div className="text-center max-w-2xl mx-auto">
                  <div className="w-14 h-14 rounded-lg bg-blue-50 flex items-center justify-center mx-auto mb-4 border border-blue-100">
                    <FileText className="w-7 h-7 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Review and Publish</h3>
                  <p className="text-sm text-gray-600 mb-8">
                    Review all sections above to ensure accuracy, then publish to create the event and notify stakeholders.
                  </p>
                  <div className="flex items-center justify-center gap-4">
                    <button
                      onClick={handleSaveDraft}
                      disabled={isSavingDraft}
                      className="px-6 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-md hover:bg-gray-50 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
                    >
                      {isSavingDraft ? (
                        <>
                          <div className="w-4 h-4 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin" />
                          <span>Saving...</span>
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          <span>Save as Draft</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={handlePublish}
                      disabled={isPublishing || !rosterCreated}
                      className="px-8 py-2.5 text-white rounded-md transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm text-sm font-medium"
                      style={{ backgroundColor: rosterCreated && !isPublishing ? '#0052FF' : '#94a3b8' }}
                      onMouseEnter={(e) => rosterCreated && !isPublishing && (e.currentTarget.style.backgroundColor = '#003DAA')}
                      onMouseLeave={(e) => rosterCreated && !isPublishing && (e.currentTarget.style.backgroundColor = '#0052FF')}
                      title={!rosterCreated ? 'Create the Roster first to enable this action' : undefined}
                    >
                      {isPublishing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Publishing...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Publish & Notify</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}