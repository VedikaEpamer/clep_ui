import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Plus, Clock, Activity, AlertCircle, CheckCircle2, UserCheck, Users, ArrowUpDown, ArrowUp, ArrowDown, Search, Filter, Archive, Eye, EyeOff } from 'lucide-react';
import { MainLayout } from './layouts/MainLayout';
import { mockEvents } from '../lib/mockData';
import type { Event } from '../lib/mockData';
import { useRole } from '../lib/roleContext';
import { useWorkflow } from '../lib/workflowContext';

// Safe string match helper
function safeMatch(value: unknown, filter: string): boolean {
  if (!filter) return true;
  const str = String(value ?? '');
  return str.toLowerCase().includes(filter.toLowerCase());
}

// Convert financial string values to millions format with $ sign and M suffix
// Examples: '$8B' -> '$8,000M', '$950M' -> '$950M', '$1.5B' -> '$1,500M', '$500M - $1.5B' -> '$500M - $1,500M'
function formatToMillions(value: string): string {
  if (!value || value === '—') return '—';
  
  // Handle range format (e.g., '$500M - $1.5B')
  if (value.includes(' - ')) {
    const parts = value.split(' - ');
    return parts.map(p => formatToMillions(p.trim())).join(' - ');
  }
  
  // Remove $ and any commas
  let cleaned = value.replace(/\$/g, '').replace(/,/g, '').trim();
  
  // Extract number and suffix
  const match = cleaned.match(/^([\d.]+)([MB]?)$/i);
  if (!match) return value; // Return original if can't parse
  
  const num = parseFloat(match[1]);
  const suffix = match[2].toUpperCase();
  
  let millions = 0;
  if (suffix === 'B') {
    millions = num * 1000; // Billions to millions
  } else if (suffix === 'M') {
    millions = num; // Already in millions
  } else {
    millions = num; // Assume millions if no suffix
  }
  
  // Format with commas, $ sign, and M suffix
  return '$' + millions.toLocaleString('en-US', { maximumFractionDigits: 0 }) + 'M';
}

export function EventDashboard() {
  const navigate = useNavigate();
  const { permissions } = useRole();
  const { getWorkflowStatus, getEventStatus } = useWorkflow();
  const [events] = useState<Event[]>(mockEvents);
  
  // Active/Inactive filter state
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('active');
  
  // Separate sort state for Active and Inactive views
  const [activeSortColumn, setActiveSortColumn] = useState<string>('');
  const [activeSortDirection, setActiveSortDirection] = useState<'asc' | 'desc'>('asc');
  const [inactiveSortColumn, setInactiveSortColumn] = useState<string>('');
  const [inactiveSortDirection, setInactiveSortDirection] = useState<'asc' | 'desc'>('asc');

  // Separate column filters for Active and Inactive views
  const [activeFilters, setActiveFilters] = useState({
    eventName: '',
    catCode: '',
    region: '',
    phase: '',
    eventType: '',
    tracked: ''
  });
  
  const [inactiveFilters, setInactiveFilters] = useState({
    eventName: '',
    catCode: '',
    region: '',
    phase: '',
    eventType: '',
    tracked: ''
  });

  // Get current filters and sort based on active status
  const filters = statusFilter === 'inactive' ? inactiveFilters : activeFilters;
  const setFilters = statusFilter === 'inactive' ? setInactiveFilters : setActiveFilters;
  const sortColumn = statusFilter === 'inactive' ? inactiveSortColumn : activeSortColumn;
  const setSortColumn = statusFilter === 'inactive' ? setInactiveSortColumn : setActiveSortColumn;
  const sortDirection = statusFilter === 'inactive' ? inactiveSortDirection : activeSortDirection;
  const setSortDirection = statusFilter === 'inactive' ? setInactiveSortDirection : setActiveSortDirection;

  // Filter dropdown state
  const [openFilter, setOpenFilter] = useState<string | null>(null);

  // Define helper functions before they are used
  const getPhaseLabel = (phase: number) => {
    switch (phase) {
      case 0: return 'Event Creation';
      case 1: return 'Monitoring';
      case 2: return 'Estimation & Approval';
      case 3: return 'Finance Review';
      case 4: return 'Reporting & Close';
      default: return `Phase ${phase}`;
    }
  };

  // Mock assignment status
  const getAssignmentStatus = (eventId: string) => {
    if (eventId === 'EVT-2024-001') return { status: 'In Progress', buSelected: true, managerSelected: true, underwriterSelected: false, deadline: '2024-12-15' };
    if (eventId === 'EVT-2024-002') return { status: 'In Progress', buSelected: true, managerSelected: false, underwriterSelected: false, deadline: '2024-12-16' };
    if (eventId === 'EVT-2024-005') return { status: 'Not Started', buSelected: false, managerSelected: false, underwriterSelected: false, deadline: '2024-12-20' };
    return { status: 'Complete', buSelected: true, managerSelected: true, underwriterSelected: true, deadline: null };
  };

  // Get unique values for dropdown filters
  const uniqueRegions = Array.from(new Set(events.map(e => e.region))).sort();
  const uniquePhases = Array.from(new Set(events.map(e => getWorkflowStatus(e.id).currentPhase))).filter(phase => phase !== 'Event Creation');
  const uniqueEventTypes = Array.from(new Set(events.map(e => e.eventType))).sort();

  // Handle filter change
  const handleFilterChange = (column: string, value: string) => {
    setFilters(prev => ({ ...prev, [column]: value }));
  };

  // Determine if event is active or inactive based on estimationStatus
  const getEventActivityStatus = (event: Event): 'active' | 'inactive' => {
    return event.estimationStatus === 'Archived' ? 'inactive' : 'active';
  };

  // Count inactive events for badge
  const inactiveCount = events.filter(e => getEventActivityStatus(e) === 'inactive').length;
  const activeCount = events.filter(e => getEventActivityStatus(e) === 'active').length;

  // Filter events based on filter criteria
  let filteredEvents = events.filter(event => {
    try {
      // Filter by active/inactive status
      const activityStatus = getEventActivityStatus(event);
      if (statusFilter === 'active' && activityStatus !== 'active') return false;
      if (statusFilter === 'inactive' && activityStatus !== 'inactive') return false;
      // 'all' shows both active and inactive

      const currentPhase = getWorkflowStatus(event.id)?.currentPhase;
      
      return (
        safeMatch(event.eventName, filters.eventName) &&
        safeMatch(event.catCode, filters.catCode) &&
        safeMatch(currentPhase, filters.phase) &&
        safeMatch(event.region, filters.region) &&
        safeMatch(event.eventType, filters.eventType) &&
        safeMatch(event.tracked === true ? 'Tracked' : event.tracked === false ? 'Untracked' : '', filters.tracked)
      );
    } catch {
      return true;
    }
  });
  
  // Apply sorting
  if (sortColumn) {
    filteredEvents = [...filteredEvents].sort((a, b) => {
      let aVal: any = a[sortColumn as keyof Event];
      let bVal: any = b[sortColumn as keyof Event];
      
      if (sortColumn === 'lossDate') {
        aVal = new Date(aVal).getTime();
        bVal = new Date(bVal).getTime();
      }
      
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }
  
  const displayEvents = filteredEvents;
  
  // S1.1.7: Sort handler
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };
  
  const getSortIcon = (column: string) => {
    if (sortColumn !== column) {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-400">
            <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
          </svg>
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-400">
            <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
          </svg>
        </div>
      );
    }
    
    if (sortDirection === 'asc') {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-blue-600">
            <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
          </svg>
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-300">
            <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
          </svg>
        </div>
      );
    } else {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-300">
            <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
          </svg>
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-blue-600">
            <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
          </svg>
        </div>
      );
    }
  };

  // Phase badge — uniform width for all phases
  const getPhaseDisplay = (event: Event) => {
    const phase = getWorkflowStatus(event.id).currentPhase;
    const estStatus = event.estimationStatus || 'Open';

    const badgeStyles: Record<string, string> = {
      'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
      'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
      'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
      'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
      'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'Reopened': 'bg-red-50 text-red-700 border-red-200',
    };

    const estStatusStyles: Record<string, string> = {
      'Closed for Estimating': 'bg-orange-50 text-orange-700 border-orange-200',
      'Archived': 'bg-gray-200 text-gray-500 border-gray-300',
    };

    return (
      <div className="flex flex-col items-center gap-1">
        <span
          className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full text-[11px] font-medium border whitespace-nowrap text-center ${
            estStatus === 'Archived' ? estStatusStyles['Archived'] : (badgeStyles[phase] || 'bg-slate-100 text-slate-600 border-slate-200')
          }`}
        >
          {phase}
        </span>
        {estStatus !== 'Open' && !(estStatus === 'Closed for Estimating' && phase === 'Finance Review') && (
          null
        )}
      </div>
    );
  };
  
  return (
    <MainLayout>
      <div className="p-8 bg-gray-50">
        {/* Header Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-gray-900 mb-1">Event Dashboard</h1>
              <p className="text-gray-600 text-sm">Catastrophe and Large Loss Estimation</p>
            </div>
            <div className="flex items-center gap-3">
              {/* Active/Inactive Filter Buttons */}
              <button
                onClick={() => setStatusFilter('active')}
                className={`px-4 py-2.5 rounded-md shadow-sm transition-all text-sm font-medium border flex items-center gap-2 ${
                  statusFilter === 'active'
                    ? 'bg-green-600 text-white border-green-600 hover:bg-green-700'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                }`}
              >
                Active
                <span className={`inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                  statusFilter === 'active' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {activeCount}
                </span>
              </button>
              <button
                onClick={() => setStatusFilter('inactive')}
                className={`px-4 py-2.5 rounded-md shadow-sm transition-all text-sm font-medium border flex items-center gap-2 ${
                  statusFilter === 'inactive'
                    ? 'bg-green-600 text-white border-green-600 hover:bg-green-700'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                }`}
              >
                Inactive
                <span className={`inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                  statusFilter === 'inactive' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {inactiveCount}
                </span>
              </button>
              {permissions.canCreateEvents && (
                <button
                  onClick={() => navigate('/events/new')}
                  className="px-5 py-2.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 shadow-sm transition-all flex items-center gap-2 font-medium"
                >
                  <Plus className="w-4 h-4" />
                  Create New Event
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Table - Modern DataGrid Style */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-x-auto">
          <table className="w-full" style={{ tableLayout: 'auto' }}>
            <thead>
              <tr className="border-b border-gray-300 bg-gradient-to-r from-gray-50 to-gray-100">
                {/* EVENT NAME */}
                <th className="px-4 py-3 text-left hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Event Name</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'eventName' ? null : 'eventName'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.eventName ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('eventName'); }} className="cursor-pointer">
                      {getSortIcon('eventName')}
                    </button>
                  </div>
                  {openFilter === 'eventName' && (
                    <div className="absolute top-full left-0 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <input 
                        type="text" 
                        placeholder="Filter..." 
                        value={filters.eventName} 
                        onChange={(e) => handleFilterChange('eventName', e.target.value)} 
                        onKeyDown={(e) => { 
                          if (e.key === 'Enter') { 
                            setOpenFilter(null); 
                          } 
                        }}
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500" 
                      />
                    </div>
                  )}
                </th>

                {/* EVENT CODE - NEW COLUMN after Event Name */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Event Code</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'catCode' ? null : 'catCode'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.catCode ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('catCode'); }} className="cursor-pointer">
                      {getSortIcon('catCode')}
                    </button>
                  </div>
                  {openFilter === 'catCode' && (
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <input 
                        type="text" 
                        placeholder="Filter..." 
                        value={filters.catCode} 
                        onChange={(e) => handleFilterChange('catCode', e.target.value)} 
                        onKeyDown={(e) => { 
                          if (e.key === 'Enter') { 
                            setOpenFilter(null); 
                          } 
                        }}
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500" 
                      />
                    </div>
                  )}
                </th>

                {/* REGION */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Region</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'region' ? null : 'region'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.region ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('region'); }} className="cursor-pointer">
                      {getSortIcon('region')}
                    </button>
                  </div>
                  {openFilter === 'region' && (
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <select 
                        value={filters.region} 
                        onChange={(e) => { 
                          handleFilterChange('region', e.target.value); 
                          setOpenFilter(null); 
                        }} 
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">All Regions</option>
                        {uniqueRegions.map(region => (<option key={region} value={region}>{region}</option>))}
                      </select>
                    </div>
                  )}
                </th>

                {/* CONTRACTS - NEW COLUMN after Region */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Contracts</span>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('contracts'); }} className="cursor-pointer">
                      {getSortIcon('contracts')}
                    </button>
                  </div>
                </th>

                {/* LOSS DATE — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Loss Date</span>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('lossDate'); }} className="cursor-pointer">
                      {getSortIcon('lossDate')}
                    </button>
                  </div>
                </th>

                {/* PHASE */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Phase</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'phase' ? null : 'phase'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.phase ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('phase'); }} className="cursor-pointer">
                      {getSortIcon('phase')}
                    </button>
                  </div>
                  {openFilter === 'phase' && (
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <select 
                        value={filters.phase} 
                        onChange={(e) => { 
                          handleFilterChange('phase', e.target.value); 
                          setOpenFilter(null); 
                        }} 
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">All Phases</option>
                        {uniquePhases.map(phase => (<option key={phase} value={phase}>{phase}</option>))}
                      </select>
                    </div>
                  )}
                </th>

                {/* MARKET LOSS (Everest View) — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Market Loss ($B)</span>
                </th>

                {/* GROSS AMOUNT RANGE (Everest) — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Gross Amount Range ($M)</span>
                </th>

                {/* NET AMOUNT USD (Everest) — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Net Amount ($M)</span>
                </th>

                {/* CREATION DATE - NEW COLUMN after Net Amount */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Creation Date</span>
                    <button onClick={(e) => { e.stopPropagation(); handleSort('creationDate'); }} className="cursor-pointer">
                      {getSortIcon('creationDate')}
                    </button>
                  </div>
                </th>

                {/* TOTAL INCURRED — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Total Incurred ($M)</span>
                </th>

                {/* BEST ESTIMATE — no filter */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors whitespace-nowrap">
                  <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Best Estimate ($M)</span>
                </th>

                {/* TYPE OF EVENT */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Type of Event</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'eventType' ? null : 'eventType'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.eventType ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                  </div>
                  {openFilter === 'eventType' && (
                    <div className="absolute top-full right-0 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <select 
                        value={filters.eventType} 
                        onChange={(e) => { 
                          handleFilterChange('eventType', e.target.value); 
                          setOpenFilter(null); 
                        }} 
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">All Types</option>
                        {uniqueEventTypes.map(t => (<option key={t} value={t}>{t}</option>))}
                      </select>
                    </div>
                  )}
                </th>

                {/* TRACKED/UNTRACKED */}
                <th className="px-4 py-3 text-center hover:bg-gray-100 transition-colors relative whitespace-nowrap">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wider">Tracked/Untracked</span>
                    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === 'tracked' ? null : 'tracked'); }}>
                      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters.tracked ? 'text-blue-600' : 'text-gray-400'}`} />
                    </button>
                  </div>
                  {openFilter === 'tracked' && (
                    <div className="absolute top-full right-0 mt-1 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[200px]">
                      <select 
                        value={filters.tracked} 
                        onChange={(e) => { 
                          handleFilterChange('tracked', e.target.value); 
                          setOpenFilter(null); 
                        }} 
                        onClick={(e) => e.stopPropagation()} 
                        className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">All</option>
                        <option value="Tracked">Tracked</option>
                        <option value="Untracked">Untracked</option>
                      </select>
                    </div>
                  )}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {displayEvents.map((event, index) => {
                const isArchived = event.estimationStatus === 'Archived';
                return (
                  <tr 
                    key={event.id} 
                    className={`hover:bg-blue-50/50 cursor-pointer transition-all duration-150 group border-b border-gray-100 ${
                      isArchived ? 'opacity-60' : ''
                    } ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50/40'}`}
                    onClick={() => navigate(`/events/${event.id}/overview`)}
                  >
                    {/* Event Name */}
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-gray-900 text-sm leading-tight">{event.eventName}</div>
                        {isArchived && (
                          <Archive className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        )}
                      </div>
                    </td>

                    {/* Event Code */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.catCode}</div>
                    </td>

                    {/* Region */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.region}</div>
                    </td>

                    {/* Contracts */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.contracts}</div>
                    </td>

                    {/* Loss Date */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(event.lossDate).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}
                      </div>
                    </td>

                    {/* Phase */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      {getPhaseDisplay(event)}
                    </td>

                    {/* Market Loss (Everest View) */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.marketLoss}</div>
                    </td>

                    {/* Gross Amount Range (Everest) */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatToMillions(event.grossAmountRange)}</div>
                    </td>

                    {/* Net Amount USD (Everest) */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatToMillions(event.netAmount)}</div>
                    </td>

                    {/* Creation Date */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(event.creationDate).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}
                      </div>
                    </td>

                    {/* Total Incurred */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatToMillions(event.totalIncurred || '—')}</div>
                    </td>

                    {/* Best Estimate */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatToMillions(event.bestEstimate || '—')}</div>
                    </td>

                    {/* Type of Event (Nat CAT / Man Made) */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${
                        event.eventType === 'Nat CAT'
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-purple-50 text-purple-700 border-purple-200'
                      }`}>
                        {event.eventType}
                      </span>
                    </td>

                    {/* Tracked/Untracked */}
                    <td className="px-4 py-4 text-center whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${
                        event.tracked
                          ? 'bg-green-50 text-green-700 border-green-200'
                          : 'bg-gray-100 text-gray-600 border-gray-200'
                      }`}>
                        {event.tracked ? 'Tracked' : 'Untracked'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {displayEvents.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-lg bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-gray-400" />
              </div>
              <div className="text-gray-900 font-medium mb-1">No events found</div>
              <p className="text-sm text-gray-500">
                No events match your current filters
              </p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}