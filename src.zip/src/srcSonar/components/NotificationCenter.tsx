import { useState } from 'react';
import { Bell, X } from 'lucide-react';
import { useTasks } from '../lib/taskContext';
import { useRole } from '../lib/roleContext';
import { useNavigate } from 'react-router';

export function NotificationCenter() {
  const [isOpen, setIsOpen] = useState(false);
  const { userName } = useRole();
  const navigate = useNavigate();
  
  const {
    getTasksForUser,
    getNotificationsForUser,
    markNotificationRead,
  } = useTasks();

  const tasks = getTasksForUser(userName);
  const notifications = getNotificationsForUser(userName);
  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = (notif: any) => {
    markNotificationRead(notif.id);
    
    if (notif.taskId) {
      const task = tasks.find((t) => t.id === notif.taskId);
      if (task) {
        // Navigate to appropriate screen based on task type
        if (task.type === 'assignment') {
          navigate(`/events/${task.eventId}/overview`);
        } else if (task.type === 'estimation') {
          navigate(`/events/${task.eventId}/uw-estimation`);
        } else if (task.type === 'approval') {
          navigate(`/events/${task.eventId}/uw-estimation`);
        } else if (task.type === 'modeling') {
          navigate(`/events/${task.eventId}/cat-modeling`);
        } else {
          navigate(`/events/${task.eventId}/overview`);
        }
      }
    } else if (notif.eventId) {
      navigate(`/events/${notif.eventId}/overview`);
    }
    
    setIsOpen(false);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="relative">
      {/* Bell Icon */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-lg hover:bg-white/10 transition-colors"
      >
        <Bell className="w-5 h-5 text-white" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Panel */}
          <div className="absolute right-0 top-12 w-96 bg-white rounded-lg shadow-xl border border-slate-200 z-50 overflow-hidden">
            {/* Header */}
            <div className="px-4 py-3 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-slate-900">Notifications</h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-6 h-6 rounded hover:bg-slate-200 flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4 text-slate-600" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="max-h-[500px] overflow-y-auto">
              <div className="p-2">
                {notifications.length > 0 ? (
                  notifications.map((notif) => (
                    <button
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif)}
                      className={`w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors mb-1 ${
                        !notif.read ? 'bg-blue-50/50' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${!notif.read ? 'bg-blue-600' : 'bg-slate-300'}`} />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm text-slate-900 mb-0.5">
                            {notif.title}
                          </div>
                          <div className="text-xs text-slate-600 mb-1">
                            {notif.message}
                          </div>
                          <div className="text-xs text-slate-400">
                            {formatDate(notif.createdAt)}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="p-8 text-center">
                    <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-sm text-slate-500">No notifications</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}