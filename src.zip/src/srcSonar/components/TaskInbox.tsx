import { useState } from 'react';
import { Inbox, CheckCircle2, Clock, AlertCircle, X, Circle } from 'lucide-react';
import { useTasks } from '../lib/taskContext';
import { useRole } from '../lib/roleContext';
import { useNavigate } from 'react-router';

export function TaskInbox() {
  const [isOpen, setIsOpen] = useState(false);
  const { currentRole } = useRole();
  const navigate = useNavigate();
  
  const {
    getTasksForUser,
    updateTaskStatus,
  } = useTasks();

  // Map role to user name
  const roleToUser: Record<string, string> = {
    'Administrator': 'David Chen',
    'Event Coordinator': 'Andrew McBride',
    'Finance Contributor': 'Clem Demetz',
    'CAT Contributor': 'Neil Schwarzenberger',
    'UW Contributor': 'Thomas Brennan',
    'Executive Area Lead': 'Juan Delgado',
    'Business Unit Lead': 'Mike Cellura',
    'Reader': 'Reena Boltax',
  };

  const currentUser = roleToUser[currentRole] || 'Demo User';
  const tasks = getTasksForUser(currentUser);

  const pendingTasks = tasks.filter((t) => t.status === 'pending' || t.status === 'in-progress');
  const completedTasks = tasks.filter((t) => t.status === 'completed');

  const handleTaskClick = (task: any) => {
    updateTaskStatus(task.id, 'in-progress');
    
    // Navigate to appropriate screen based on task type
    if (task.type === 'assignment') {
      navigate(`/events/${task.eventId}/overview`);
    } else if (task.type === 'estimation') {
      navigate(`/events/${task.eventId}/uw-estimation`);
    } else if (task.type === 'approval') {
      navigate(`/events/${task.eventId}/uw-estimation`);
    } else if (task.type === 'modeling') {
      navigate(`/events/${task.eventId}/cat-modeling`);
    } else {
      navigate(`/events/${task.eventId}/overview`);
    }
    
    setIsOpen(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'medium':
        return 'text-amber-600 bg-amber-50 border-amber-200';
      default:
        return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'in-progress':
        return <Clock className="w-4 h-4 text-amber-600" />;
      case 'overdue':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Circle className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="relative">
      {/* Inbox Icon */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-lg hover:bg-white/10 transition-colors"
      >
        <Inbox className="w-5 h-5 text-white" />
        {pendingTasks.length > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
            {pendingTasks.length > 9 ? '9+' : pendingTasks.length}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Panel */}
          <div className="absolute right-0 top-12 w-96 bg-white rounded-lg shadow-xl border border-slate-200 z-50 overflow-hidden">
            {/* Header */}
            <div className="px-4 py-3 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-slate-900">Tasks</h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-6 h-6 rounded hover:bg-slate-200 flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4 text-slate-600" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="max-h-[500px] overflow-y-auto">
              {/* Pending Tasks */}
              {pendingTasks.length > 0 && (
                <div className="p-2">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 py-1 mb-1">
                    Pending ({pendingTasks.length})
                  </div>
                  {pendingTasks.map((task) => (
                    <button
                      key={task.id}
                      onClick={() => handleTaskClick(task)}
                      className="w-full text-left p-3 rounded-lg hover:bg-slate-50 transition-colors mb-1"
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">{getStatusIcon(task.status)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs text-slate-500">
                              {task.eventName}
                            </span>
                            <span
                              className={`px-1.5 py-0.5 text-xs rounded border ${getPriorityColor(
                                task.priority
                              )}`}
                            >
                              {task.priority}
                            </span>
                          </div>
                          <div className="font-medium text-sm text-slate-900 mb-1">
                            {task.title}
                          </div>
                          <div className="text-xs text-slate-600 mb-2">
                            {task.description}
                          </div>
                          <div className="text-xs text-slate-500">
                            Due: {new Date(task.dueDate).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Completed Tasks */}
              {completedTasks.length > 0 && (
                <div className="p-2 border-t border-slate-100">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 py-1 mb-1">
                    Completed
                  </div>
                  {completedTasks.slice(0, 3).map((task) => (
                    <div
                      key={task.id}
                      className="p-3 rounded-lg bg-slate-50/50 mb-1 opacity-60"
                    >
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5" />
                        <div className="flex-1">
                          <div className="text-xs text-slate-500 mb-0.5">
                            {task.eventName}
                          </div>
                          <div className="font-medium text-sm text-slate-700">
                            {task.title}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Empty State */}
              {tasks.length === 0 && (
                <div className="p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm text-slate-500">No tasks assigned</p>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}