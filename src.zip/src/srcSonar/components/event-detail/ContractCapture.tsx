import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { FileText, ChevronDown, ChevronRight, ArrowRight, Building2, CheckCircle, Download } from 'lucide-react';
import { mockEvents } from '../../lib/mockData';
import { downloadCSV } from '../../lib/exportUtils';
import { toast } from 'sonner@2.0.3';

export interface ContractMetadata {
  contractNumber: string;
  contractName: string;
  cedant: string;
  programType: 'QS' | 'XL' | 'SS' | 'PR' | 'Specialty' | 'FAC' | 'Other';
  limit: string;
  deductible: string;
  everestLine: string;
  treatyHierarchy: 'QS→XL' | 'XL→QS' | 'PR Only' | 'N/A';
  effectiveDate: string;
  expiryDate: string;
  broker: string;
  reportingLevel: string;
  currency: string;
  reinstatementTerms: string;
  uwName?: string; // Underwriter assigned to this contract
}

// Mock contract data grouped by cedant
const mockContracts: ContractMetadata[] = [
  { contractNumber: 'PROP-2024-001', contractName: 'California Wildfire Coverage', cedant: 'ABC Insurance Company', programType: 'XL', limit: '$50M xs $10M', deductible: '$10M', everestLine: '15.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'AON', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'PROP-2024-002', contractName: 'Texas Windstorm Treaty', cedant: 'ABC Insurance Company', programType: 'QS', limit: '25% of $200M', deductible: 'N/A', everestLine: '12.0%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'AON', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'PROP-2024-003', contractName: 'Florida Hurricane Treaty', cedant: 'ABC Insurance Company', programType: 'XL', limit: '$75M xs $25M', deductible: '$25M', everestLine: '18.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%, 1 @ 110%' },
  { contractNumber: 'PROP-2024-004', contractName: 'Gulf Coast Property XL', cedant: 'ABC Insurance Company', programType: 'XL', limit: '$40M xs $8M', deductible: '$8M', everestLine: '14.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'Willis Towers Watson', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'TRES-2024-045', contractName: 'Mexico QS Property', cedant: 'Global Reinsurance Ltd', programType: 'QS', limit: '30% of $150M', deductible: 'N/A', everestLine: '20.0%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-06-01', expiryDate: '2025-05-31', broker: 'Willis Towers Watson', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'TRES-2024-046', contractName: 'Mexico CAT XL', cedant: 'Global Reinsurance Ltd', programType: 'XL', limit: '$100M xs $20M', deductible: '$20M', everestLine: '25.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-06-01', expiryDate: '2025-05-31', broker: 'Willis Towers Watson', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'TRES-2024-047', contractName: 'Mexico Regional QS', cedant: 'Global Reinsurance Ltd', programType: 'QS', limit: '18% of $90M', deductible: 'N/A', everestLine: '16.5%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-06-01', expiryDate: '2025-05-31', broker: 'AON', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'LATAM-2024-023', contractName: 'Brazil CAT XL', cedant: 'LATAM Insurance Group', programType: 'XL', limit: '$30M xs $5M', deductible: '$5M', everestLine: '10.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-03-01', expiryDate: '2025-02-28', broker: 'Guy Carpenter', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%' },
  { contractNumber: 'LATAM-2024-024', contractName: 'Brazil QS Property', cedant: 'LATAM Insurance Group', programType: 'QS', limit: '15% of $80M', deductible: 'N/A', everestLine: '8.5%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-03-01', expiryDate: '2025-02-28', broker: 'Guy Carpenter', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'LATAM-2024-025', contractName: 'Chile Earthquake Coverage', cedant: 'LATAM Insurance Group', programType: 'XL', limit: '$55M xs $12M', deductible: '$12M', everestLine: '19.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-03-01', expiryDate: '2025-02-28', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'CAS-2024-012', contractName: 'General Liability XL', cedant: 'North American Mutual', programType: 'XL', limit: '$20M xs $10M', deductible: '$10M', everestLine: '5.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'AON', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: 'None' },
  { contractNumber: 'CAS-2024-013', contractName: 'Workers Comp XL', cedant: 'North American Mutual', programType: 'XL', limit: '$15M xs $5M', deductible: '$5M', everestLine: '7.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%' },
  { contractNumber: 'CAS-2024-014', contractName: 'Auto Liability Treaty', cedant: 'North American Mutual', programType: 'QS', limit: '22% of $120M', deductible: 'N/A', everestLine: '11.0%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-01-01', expiryDate: '2024-12-31', broker: 'Willis Towers Watson', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'EUR-2024-067', contractName: 'European Storm XL', cedant: 'European Risk Partners', programType: 'XL', limit: '€40M xs €15M', deductible: '€15M', everestLine: '12.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'Willis Towers Watson', reportingLevel: 'Occurrence', currency: 'EUR', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'EUR-2024-068', contractName: 'UK QS Property', cedant: 'European Risk Partners', programType: 'QS', limit: '20% of €100M', deductible: 'N/A', everestLine: '9.0%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'Guy Carpenter', reportingLevel: 'Aggregate', currency: 'EUR', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'EUR-2024-069', contractName: 'France Wind & Hail', cedant: 'European Risk Partners', programType: 'XL', limit: '€35M xs €10M', deductible: '€10M', everestLine: '13.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'AON', reportingLevel: 'Occurrence', currency: 'EUR', reinstatementTerms: '1 @ 100%' },
  { contractNumber: 'ASIA-2024-089', contractName: 'Japan Earthquake XL', cedant: 'Asia Pacific Re', programType: 'XL', limit: '$60M xs $15M', deductible: '$15M', everestLine: '22.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%' },
  { contractNumber: 'ASIA-2024-090', contractName: 'Taiwan Typhoon Coverage', cedant: 'Asia Pacific Re', programType: 'XL', limit: '$45M xs $12M', deductible: '$12M', everestLine: '17.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'Willis Towers Watson', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'ASIA-2024-091', contractName: 'Australia Cyclone XL', cedant: 'Asia Pacific Re', programType: 'XL', limit: '$38M xs $9M', deductible: '$9M', everestLine: '14.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-04-01', expiryDate: '2025-03-31', broker: 'Guy Carpenter', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%, 1 @ 110%' },
  { contractNumber: 'MARINE-2024-055', contractName: 'Marine Hull & Cargo', cedant: 'Maritime Insurance Corp', programType: 'XL', limit: '$25M xs $7M', deductible: '$7M', everestLine: '6.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-02-01', expiryDate: '2025-01-31', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: 'None' },
  { contractNumber: 'MARINE-2024-056', contractName: 'Offshore Energy XL', cedant: 'Maritime Insurance Corp', programType: 'XL', limit: '$80M xs $18M', deductible: '$18M', everestLine: '21.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-02-01', expiryDate: '2025-01-31', broker: 'Willis Towers Watson', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '2 @ 100%' },
  { contractNumber: 'SPEC-2024-078', contractName: 'Specialty Lines XL', cedant: 'Specialty Risk Group', programType: 'XL', limit: '$28M xs $6M', deductible: '$6M', everestLine: '9.5%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-05-01', expiryDate: '2025-04-30', broker: 'AON', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%' },
  { contractNumber: 'SPEC-2024-079', contractName: 'Cyber & Tech E&O', cedant: 'Specialty Risk Group', programType: 'QS', limit: '12% of $65M', deductible: 'N/A', everestLine: '4.5%', treatyHierarchy: 'QS→XL', effectiveDate: '2024-05-01', expiryDate: '2025-04-30', broker: 'Guy Carpenter', reportingLevel: 'Aggregate', currency: 'USD', reinstatementTerms: 'Pro-rata' },
  { contractNumber: 'AGRI-2024-032', contractName: 'Agricultural Multi-Peril', cedant: 'Farm & Crop Mutual', programType: 'XL', limit: '$22M xs $4M', deductible: '$4M', everestLine: '8.0%', treatyHierarchy: 'XL→QS', effectiveDate: '2024-03-15', expiryDate: '2025-03-14', broker: 'Marsh', reportingLevel: 'Occurrence', currency: 'USD', reinstatementTerms: '1 @ 100%' }
];

export function ContractCapture() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const event = mockEvents.find(e => e.id === eventId);

  // Group contracts by cedant
  const cedantGroups = mockContracts.reduce((acc, contract) => {
    if (!acc[contract.cedant]) {
      acc[contract.cedant] = [];
    }
    acc[contract.cedant].push(contract);
    return acc;
  }, {} as Record<string, ContractMetadata[]>);

  const [expandedCedants, setExpandedCedants] = useState<Set<string>>(
    new Set(Object.keys(cedantGroups)) // Expand all by default
  );

  const toggleCedant = (cedant: string) => {
    setExpandedCedants(prev => {
      const next = new Set(prev);
      if (next.has(cedant)) {
        next.delete(cedant);
      } else {
        next.add(cedant);
      }
      return next;
    });
  };

  const handleContinueToEstimates = () => {
    // Store contract metadata in sessionStorage for UW Estimation screen
    sessionStorage.setItem('contractMetadata', JSON.stringify(mockContracts));
    
    // Navigate to UW Estimation screen (use /events/ plural to match routing)
    navigate(`/events/${eventId}/uw-estimation`);
  };

  const totalContracts = mockContracts.length;
  const totalCedants = Object.keys(cedantGroups).length;

  return (
    <div className="flex-1 flex flex-col bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-8 py-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-2xl mb-1" style={{ color: '#0052FF' }}>
              Contract Exposure
            </h2>
            <p className="text-sm text-slate-600">{event?.eventName}</p>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const headers = ['Contract #', 'Contract Name', 'Cedant', 'Program Type', 'Limit', 'Deductible', 'Everest Line', 'Treaty Hierarchy', 'Effective Date', 'Expiry Date', 'Broker', 'Reporting Level', 'Currency', 'Reinstatement Terms'];
                const rows = mockContracts.map(c => [c.contractNumber, c.contractName, c.cedant, c.programType, c.limit, c.deductible, c.everestLine, c.treatyHierarchy, c.effectiveDate, c.expiryDate, c.broker, c.reportingLevel, c.currency, c.reinstatementTerms]);
                downloadCSV(headers, rows, `SONAR_Contract_Exposure_${event?.eventName || eventId}`);
                toast.success('Contract Exposure table exported to CSV');
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
            <button
              onClick={handleContinueToEstimates}
              className="px-6 py-3 bg-everest-blue text-white rounded-lg hover:bg-[#0041CC] transition-all flex items-center gap-2 shadow-sm hover:shadow font-medium"
            >
              Continue to Estimates
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Summary Bar */}
        <div className="px-8 py-4 bg-gradient-to-r from-blue-50 to-white border-b border-slate-200">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-sm text-slate-600">Total Cedants</div>
                <div className="text-xl font-semibold text-slate-900">{totalCedants}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                <FileText className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <div className="text-sm text-slate-600">Total Contracts</div>
                <div className="text-xl font-semibold text-slate-900">{totalContracts}</div>
              </div>
            </div>
            <div className="flex-1"></div>
            <div className="text-xs text-slate-500 bg-blue-50 px-3 py-2 rounded-lg border border-blue-200">
              <span className="font-semibold text-blue-900">Note:</span> All contract metadata is read-only. Click "Continue to Estimates" to proceed with loss estimation.
            </div>
          </div>
        </div>
      </div>

      {/* Contract Table - Grouped by Cedant */}
      <div className="flex-1 overflow-auto p-8">
        <div className="space-y-4">
          {Object.entries(cedantGroups).map(([cedant, contracts]) => {
            const isExpanded = expandedCedants.has(cedant);
            
            return (
              <div
                key={cedant}
                className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                {/* Cedant Header */}
                <button
                  onClick={() => toggleCedant(cedant)}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-50 transition-colors"
                  style={{ backgroundColor: isExpanded ? '#F8FAFC' : '#FFFFFF' }}
                >
                  <div className="flex items-center gap-4">
                    {isExpanded ? (
                      <ChevronDown className="w-5 h-5 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-slate-400" />
                    )}
                    <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-slate-900">{cedant}</div>
                      <div className="text-sm text-slate-600">{contracts.length} contract{contracts.length !== 1 ? 's' : ''}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-100 border border-blue-200 rounded-full">
                    <CheckCircle className="w-4 h-4 text-blue-700" />
                    <span className="text-xs font-semibold text-blue-700">
                      {contracts.length} Contracts
                    </span>
                  </div>
                </button>

                {/* Contract Details Table */}
                {isExpanded && (
                  <div className="border-t border-slate-200 overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200">
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Contract #</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Contract Name</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Type</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Limit</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Deductible</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Everest Line</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Hierarchy</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Effective</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Expiry</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Broker</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Reporting</th>
                          <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">Currency</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {contracts.map((contract) => (
                          <tr key={contract.contractNumber} className="hover:bg-slate-50 transition-colors">
                            <td className="px-4 py-3 text-sm font-medium text-slate-900">{contract.contractNumber}</td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.contractName}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                contract.programType === 'QS' 
                                  ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                                  : contract.programType === 'XL'
                                  ? 'bg-blue-100 text-blue-700 border border-blue-200'
                                  : 'bg-slate-100 text-slate-700 border border-slate-200'
                              }`}>
                                {contract.programType}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.limit}</td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.deductible}</td>
                            <td className="px-4 py-3 text-sm font-medium text-slate-900">{contract.everestLine}</td>
                            <td className="px-4 py-3">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded bg-amber-100 text-amber-700 border border-amber-200">
                                {contract.treatyHierarchy}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.effectiveDate}</td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.expiryDate}</td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.broker}</td>
                            <td className="px-4 py-3 text-sm text-slate-700">{contract.reportingLevel}</td>
                            <td className="px-4 py-3 text-sm font-medium text-slate-900">{contract.currency}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}