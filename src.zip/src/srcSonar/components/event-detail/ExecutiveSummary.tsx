import React, { useState, useMemo, useRef } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  CartesianGrid, Legend, AreaChart, Area,
} from 'recharts';
import {
  Globe, DollarSign, TrendingDown, TrendingUp, Shield, BarChart3, Users,
  AlertTriangle, CheckCircle2, Info,
  Download, Printer, Calendar,
  Target, Activity, Eye, Layers, FileText,
} from 'lucide-react';

const LOGAN_RETENTION = 0.85;

interface ExecutiveSummaryProps {
  event: any;
  marketEstimates: any[];
  top10Deals: any[];
  top10Companies: any[];
  hasContracts: boolean;
}

// ── Sub-tab IDs ──────────────────────────────────────────────────────
type ReportTab =
  | 'executive'
  | 'incurredVsEstimate'
  | 'lossDevelopment'
  | 'tripleComparison'
  | 'kpiAccuracy';

const REPORT_TABS: { id: ReportTab; label: string; icon: React.ElementType }[] = [
  { id: 'executive', label: 'Exec Report', icon: FileText },
  { id: 'incurredVsEstimate', label: 'Incurred vs Estimate', icon: BarChart3 },
  { id: 'lossDevelopment', label: 'Loss Development', icon: Activity },
  { id: 'tripleComparison', label: 'UW vs Model vs Incurred', icon: Layers },
  { id: 'kpiAccuracy', label: 'KPI Accuracy', icon: Target },
];

// ── Mock loss-development time series (months since event) ──────────
function buildDevSeries(totalGross: number) {
  const months = ['M0', 'M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8', 'M9', 'M10', 'M11', 'M12'];
  const incurredPcts = [0, 0.08, 0.18, 0.31, 0.42, 0.52, 0.61, 0.68, 0.74, 0.79, 0.83, 0.86, 0.89];
  const projectedPcts = [0, 0.08, 0.18, 0.31, 0.42, 0.52, 0.61, 0.70, 0.78, 0.84, 0.89, 0.93, 0.96];
  return months.map((m, i) => ({
    month: m,
    incurred: +(totalGross * incurredPcts[i]).toFixed(1),
    projected: +(totalGross * projectedPcts[i]).toFixed(1),
    estimate: totalGross,
  }));
}

// ── CSV export helper ────────────────────────────────────────────────
function downloadCSV(headers: string[], rows: (string | number)[][], filename: string) {
  const csv = [headers.join(','), ...rows.map(r => r.map(c => typeof c === 'string' && c.includes(',') ? `"${c}"` : c).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function ExecutiveSummary({
  event,
  marketEstimates,
  top10Deals,
  top10Companies,
  hasContracts,
}: ExecutiveSummaryProps) {
  const [activeReport, setActiveReport] = useState<ReportTab>('executive');
  const [varianceThreshold, setVarianceThreshold] = useState(20); // % for triple comparison filter
  const printRef = useRef<HTMLDivElement>(null);

  // ── Derived totals ─────────────────────────────────────────────────
  const totalGross = marketEstimates.reduce((s, b) => s + b.grossEst, 0);
  const totalNet = marketEstimates.reduce((s, b) => s + b.netEst, 0);
  const totalExposure = marketEstimates.reduce((s, b) => s + b.exposure, 0);
  const totalContracts = marketEstimates.reduce((s, b) => s + b.uwCount, 0);
  const netOfLogan = totalGross * LOGAN_RETENTION;
  const loganCession = totalGross - netOfLogan;
  const recoveryRate = totalGross > 0 ? ((totalGross - totalNet) / totalGross) * 100 : 0;
  const lossRatio = totalExposure > 0 ? (totalGross / totalExposure) * 100 : 0;
  const completedBUs = marketEstimates.filter((b) => b.status === 'Complete').length;

  const fmtM = (v: number) => {
    if (!v || isNaN(v)) return '$0';
    if (Math.abs(v) >= 1000) return `$${(v / 1000).toFixed(1)}B`;
    if (Math.abs(v) >= 1) return `$${v.toFixed(1)}M`;
    return `$${(v * 1000).toFixed(0)}K`;
  };

  const fmtPct = (v: number) => `${v >= 0 ? '+' : ''}${v.toFixed(1)}%`;

  // ── Mock incurred vs estimate per-claim data ───────────────────────
  const claimLevelData = useMemo(() => {
    return top10Deals.slice(0, 12).map((deal, i) => {
      const incurred = +(deal.grossEst * (0.75 + Math.random() * 0.5)).toFixed(1);
      const variance = incurred - deal.grossEst;
      const variancePct = deal.grossEst > 0 ? (variance / deal.grossEst) * 100 : 0;
      return {
        id: i + 1,
        uid: `claim-${i}`,
        contractId: deal.contractId,
        cedent: deal.cedent,
        bu: deal.bu || marketEstimates[i % marketEstimates.length]?.bu || 'N/A',
        uwEstimate: deal.grossEst,
        incurred,
        variance,
        variancePct,
        status: Math.abs(variancePct) <= 10 ? 'On Track' : variancePct > 0 ? 'Over' : 'Under',
      };
    });
  }, [top10Deals, marketEstimates]);

  // ── Triple comparison data (UW vs Model vs Incurred) ───────────────
  const tripleData = useMemo(() => {
    return top10Deals.slice(0, 10).map((deal, i) => {
      const modelEst = +(deal.grossEst * (0.85 + Math.random() * 0.3)).toFixed(1);
      const incurred = +(deal.grossEst * (0.7 + Math.random() * 0.6)).toFixed(1);
      const uwVsModel = deal.grossEst > 0 ? ((deal.grossEst - modelEst) / deal.grossEst) * 100 : 0;
      const uwVsIncurred = deal.grossEst > 0 ? ((incurred - deal.grossEst) / deal.grossEst) * 100 : 0;
      const modelVsIncurred = modelEst > 0 ? ((incurred - modelEst) / modelEst) * 100 : 0;
      const onlyUW = deal.grossEst > 0 && modelEst === 0;
      const onlyModel = deal.grossEst === 0 && modelEst > 0;
      return {
        uid: `triple-${i}`,
        contractId: deal.contractId,
        cedent: deal.cedent,
        uwEstimate: deal.grossEst,
        modelEstimate: modelEst,
        incurred,
        uwVsModel,
        uwVsIncurred,
        modelVsIncurred,
        onlyUW,
        onlyModel,
        maxVariance: Math.max(Math.abs(uwVsIncurred), Math.abs(modelVsIncurred)),
        flagged: Math.abs(uwVsIncurred) > varianceThreshold || Math.abs(modelVsIncurred) > varianceThreshold,
      };
    });
  }, [top10Deals, varianceThreshold]);

  // ── KPI per team/area data ─────────────────────────────────────────
  const kpiByTeam = useMemo(() => {
    return marketEstimates.map((bu, i) => {
      const estTotal = bu.grossEst;
      const incTotal = +(bu.grossEst * (0.8 + Math.random() * 0.4)).toFixed(1);
      const variance = incTotal - estTotal;
      const accuracy = estTotal > 0 ? Math.max(0, 100 - Math.abs((variance / estTotal) * 100)) : 0;
      const contractCount = bu.uwCount || 0;
      return {
        uid: `kpi-${i}`,
        bu: bu.bu,
        buLabel: bu.bu.length > 18 ? bu.bu.substring(0, 16) + '…' : bu.bu,
        area: bu.area || bu.bu.includes('Bermuda') ? 'Bermuda' : 'North America',
        estimated: estTotal,
        incurred: incTotal,
        variance,
        variancePct: estTotal > 0 ? (variance / estTotal) * 100 : 0,
        accuracy,
        contractCount,
        status: bu.status,
        grade: accuracy >= 90 ? 'A' : accuracy >= 80 ? 'B' : accuracy >= 70 ? 'C' : 'D',
      };
    });
  }, [marketEstimates]);

  const devSeries = useMemo(() => buildDevSeries(totalGross), [totalGross]);

  // ── Loss waterfall for exec report ─────────────────────────────────
  const waterfallData = [
    { name: 'Gross Loss', value: totalGross, color: '#ef4444' },
    { name: 'Logan Cession', value: -loganCession, color: '#f97316' },
    { name: 'Net of Logan', value: netOfLogan, color: '#0052FF' },
    { name: 'Net Loss', value: totalNet, color: '#003057' },
  ];

  // ── Chart data ─────────────────────────────────────────────────────
  const buBarData = [...marketEstimates]
    .sort((a, b) => b.grossEst - a.grossEst)
    .slice(0, 8)
    .map((b, i) => {
      const label = b.bu.length > 20 ? b.bu.substring(0, 18) + '…' : b.bu;
      return {
        name: `bu-bar-${i}`,
        displayName: label,
        gross: b.grossEst,
        net: b.netEst,
      };
    });

  // ── Empty state ────────────────────────────────────────────────────
  if (!hasContracts || marketEstimates.length === 0) {
    return (
      <div className="px-10 py-16 text-center">
        <BarChart3 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <h3 className="text-slate-700 mb-1" style={{ fontSize: '1rem', fontWeight: 600 }}>
          No Data Available
        </h3>
        <p className="text-sm text-slate-500">
          Executive summary will populate once business units submit estimates.
        </p>
      </div>
    );
  }

  // ── Print handler ──────────────────────────────────────────────────
  const handlePrint = () => {
    window.print();
  };

  // ──────────────────────────────────────────────────────────────────
  //  RENDER
  // ──────────────────────────────────────────────────────────────────
  return (
    <div className="px-4 lg:px-10 py-6 space-y-6" ref={printRef}>

      {/* ─── Report Navigation Tabs ──────────────────────────────────── */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center overflow-x-auto border-b border-slate-200">
          {REPORT_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeReport === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveReport(tab.id)}
                className={`flex items-center gap-2 px-5 py-3.5 text-sm whitespace-nowrap border-b-2 transition-all ${
                  isActive
                    ? 'border-[#0052FF] text-[#0052FF]'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
                style={isActive ? { fontWeight: 600 } : { fontWeight: 500 }}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* TAB 1 — EXECUTIVE MGT EVENT REPORT                           */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {activeReport === 'executive' && (
        <div className="space-y-6">
          {/* Actions bar */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900" style={{ fontSize: '1.125rem', fontWeight: 700 }}>
                Executive Event Report
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Tailored summary for management review — generated upon estimation completion
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 hover:bg-slate-50 transition-colors"
                style={{ fontWeight: 500 }}
              >
                <Printer className="w-3.5 h-3.5" />
                Print Report
              </button>
              <button
                onClick={() => {
                  const headers = ['Metric', 'Value'];
                  const rows: (string | number)[][] = [
                    ['Event', event?.eventName || event?.name || ''],
                    ['Loss Date', event?.lossDate || ''],
                    ['Region', event?.region || ''],
                    ['Peril', event?.peril || ''],
                    ['Industry Loss', event?.marketLoss || ''],
                    ['Gross Loss (USD M)', totalGross],
                    ['Logan Cession (USD M)', loganCession],
                    ['Net of Logan (USD M)', netOfLogan],
                    ['Net Loss (USD M)', totalNet],
                    ['Recovery Rate', `${recoveryRate.toFixed(1)}%`],
                    ['Loss Ratio', `${lossRatio.toFixed(1)}%`],
                    ['Total Contracts', totalContracts],
                    ['BUs Reporting', marketEstimates.length],
                    ['BUs Complete', completedBUs],
                  ];
                  downloadCSV(headers, rows, `Exec_Report_${event?.eventName || 'Event'}`);
                }}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            </div>
          </div>

          {/* Report Header Card */}
          <div className="bg-white rounded-xl p-8 border border-slate-200 shadow-sm">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-xs uppercase tracking-widest text-slate-400 mb-1">SONAR Event Report</div>
                <h1 className="text-slate-900" style={{ fontSize: '1.5rem', fontWeight: 700, lineHeight: '1.3' }}>
                  {event?.eventName || event?.name}
                </h1>
                <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
                  <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-slate-400" />{event?.lossDate ? new Date(event.lossDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : '—'}</span>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1.5"><Globe className="w-3.5 h-3.5 text-slate-400" />{event?.region || '—'}</span>
                  <span className="text-slate-300">•</span>
                  <span>{event?.peril || '—'}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Report Date</div>
                <div className="text-sm text-slate-800" style={{ fontWeight: 500 }}>
                  {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {completedBUs}/{marketEstimates.length} BUs reporting
                </div>
              </div>
            </div>

            {/* KPI strip inside header */}
            <div className="grid grid-cols-5 gap-4">
              {[
                { label: 'Industry Loss', value: event?.marketLoss ?? '—', accent: '#ef4444', bg: 'bg-red-50' },
                { label: 'Everest Gross', value: fmtM(totalGross), accent: '#f97316', bg: 'bg-orange-50' },
                { label: 'Logan Cession', value: fmtM(loganCession), accent: '#eab308', bg: 'bg-amber-50' },
                { label: 'Net Loss', value: fmtM(totalNet), accent: '#0052FF', bg: 'bg-blue-50' },
                { label: 'Recovery Rate', value: `${recoveryRate.toFixed(1)}%`, accent: '#10b981', bg: 'bg-emerald-50' },
              ].map((kpi) => (
                <div key={kpi.label} className={`${kpi.bg} rounded-lg px-4 py-3 border`} style={{ borderColor: `${kpi.accent}30` }}>
                  <div className="text-[10px] uppercase tracking-wider text-slate-500">{kpi.label}</div>
                  <div className="text-lg text-slate-900 mt-0.5" style={{ fontWeight: 700 }}>{kpi.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Waterfall + BU breakdown */}
          <div className="grid grid-cols-3 gap-6">
            <div className="col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <SectionHeader icon={BarChart3} title="Net Waterfall" sub="Gross to net loss deduction flow" />
              <div className="p-6 h-[260px] flex items-end justify-center gap-6">
                {(() => {
                  const maxAbs = Math.max(...waterfallData.map(d => Math.abs(d.value)), 1);
                  return waterfallData.map((d) => {
                    const pct = (Math.abs(d.value) / maxAbs) * 100;
                    return (
                      <div key={d.name} className="flex flex-col items-center gap-2 flex-1 max-w-[100px]">
                        <span className="text-xs text-slate-700" style={{ fontWeight: 600 }}>{fmtM(Math.abs(d.value))}</span>
                        <div className="w-full flex items-end justify-center" style={{ height: '160px' }}>
                          <div
                            className="w-full rounded-t-lg transition-all relative group"
                            style={{ height: `${Math.max(pct, 8)}%`, backgroundColor: d.color, minHeight: '16px' }}
                          >
                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                              {d.name}: {fmtM(Math.abs(d.value))}
                            </div>
                          </div>
                        </div>
                        <span className="text-[10px] text-slate-500 text-center" style={{ lineHeight: '1.2' }}>{d.name}</span>
                      </div>
                    );
                  });
                })()}
              </div>
            </div>

            {/* BU Status + Key Metrics */}
            <div className="space-y-4">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <SectionHeader icon={CheckCircle2} title="BU Status" sub={`${completedBUs} of ${marketEstimates.length} complete`} />
                <div className="p-5 space-y-2.5">
                  {marketEstimates.map((bu, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <span className="text-xs text-slate-600 truncate pr-2">{bu.bu.length > 22 ? bu.bu.substring(0, 20) + '…' : bu.bu}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                        bu.status === 'Complete' ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' :
                        bu.status === 'In Progress' ? 'bg-amber-50 text-amber-600 border border-amber-200' :
                        'bg-slate-50 text-slate-500 border border-slate-200'
                      }`} style={{ fontWeight: 500 }}>{bu.status}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                <div className="text-xs text-slate-500 uppercase tracking-wider mb-3" style={{ fontWeight: 600 }}>Key Ratios</div>
                {[
                  { label: 'Recovery Rate', value: recoveryRate, color: '#10b981' },
                  { label: 'Loss Ratio', value: lossRatio, color: '#ef4444' },
                  { label: 'Completion', value: marketEstimates.length > 0 ? (completedBUs / marketEstimates.length) * 100 : 0, color: '#0052FF' },
                ].map((m) => (
                  <div key={m.label} className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-500">{m.label}</span>
                      <span className="text-xs" style={{ color: m.color, fontWeight: 600 }}>{m.value.toFixed(1)}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${Math.min(m.value, 100)}%`, backgroundColor: m.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Top BUs by Gross + Top Contracts */}
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <SectionHeader icon={Users} title="Loss by Business Unit" sub="Gross vs Net comparison" />
              <div className="p-6 h-[280px] overflow-y-auto">
                {(() => {
                  const maxVal = Math.max(...buBarData.map(d => Math.max(d.gross, d.net)), 1);
                  return (
                    <div className="space-y-3">
                      {buBarData.map((d) => (
                        <div key={d.name} className="group">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] text-slate-600 truncate max-w-[140px]">{d.displayName}</span>
                            <div className="flex items-center gap-3 text-[10px]">
                              <span className="text-red-500" style={{ fontWeight: 600 }}>${d.gross}M</span>
                              <span style={{ color: '#0052FF', fontWeight: 600 }}>${d.net}M</span>
                            </div>
                          </div>
                          <div className="space-y-0.5">
                            <div className="h-[7px] bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full bg-red-500 rounded-full transition-all" style={{ width: `${(d.gross / maxVal) * 100}%` }} />
                            </div>
                            <div className="h-[7px] bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full rounded-full transition-all" style={{ width: `${(d.net / maxVal) * 100}%`, backgroundColor: '#0052FF' }} />
                            </div>
                          </div>
                        </div>
                      ))}
                      <div className="flex items-center gap-4 pt-2 justify-center">
                        <div className="flex items-center gap-1.5"><div className="w-3 h-2 bg-red-500 rounded-sm" /><span className="text-[10px] text-slate-500">Gross</span></div>
                        <div className="flex items-center gap-1.5"><div className="w-3 h-2 rounded-sm" style={{ backgroundColor: '#0052FF' }} /><span className="text-[10px] text-slate-500">Net</span></div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <SectionHeader icon={AlertTriangle} title="Top Impacted Contracts" sub={`Top ${Math.min(top10Deals.length, 6)} by gross loss`} iconBg="bg-amber-50" iconColor="#f59e0b" />
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    {['#', 'Contract', 'Cedent', 'Gross', 'Net', 'Util'].map(h => (
                      <th key={h} className={`px-4 py-2.5 text-[10px] text-slate-500 uppercase tracking-wider ${h === 'Gross' || h === 'Net' || h === 'Util' ? 'text-right' : 'text-left'}`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {top10Deals.slice(0, 6).map((deal, i) => {
                    const util = deal.limit > 0 ? (deal.grossEst / deal.limit) * 100 : 0;
                    return (
                      <tr key={`top-deal-${i}`} className="hover:bg-blue-50/30 transition-colors">
                        <td className="px-4 py-2.5">
                          <span className={`inline-flex items-center justify-center w-6 h-6 rounded text-[10px] ${i < 3 ? 'text-white' : 'bg-slate-100 text-slate-500'}`} style={i < 3 ? { backgroundColor: '#0052FF' } : {}}>
                            {i + 1}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-xs text-slate-800" style={{ fontWeight: 500 }}>{deal.contractId}</td>
                        <td className="px-4 py-2.5 text-xs text-slate-600">{deal.cedent}</td>
                        <td className="px-4 py-2.5 text-xs text-red-600 text-right" style={{ fontWeight: 600 }}>{fmtM(deal.grossEst)}</td>
                        <td className="px-4 py-2.5 text-xs text-right" style={{ color: '#0052FF', fontWeight: 600 }}>{fmtM(deal.netEst)}</td>
                        <td className="px-4 py-2.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(util, 100)}%`, backgroundColor: util > 80 ? '#ef4444' : util > 50 ? '#f59e0b' : '#10b981' }} />
                            </div>
                            <span className="text-[10px] text-slate-500">{util.toFixed(0)}%</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Management Recommendation */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                <Eye className="w-5 h-5 text-[#0052FF]" />
              </div>
              <div className="flex-1">
                <h3 className="text-slate-900 mb-2" style={{ fontSize: '0.875rem', fontWeight: 600 }}>
                  Management Recommendation
                </h3>
                <div className="text-sm text-slate-600 space-y-2 leading-relaxed">
                  <p>
                    Based on current estimates from {completedBUs} of {marketEstimates.length} reporting business units,
                    Everest's gross exposure to <span style={{ fontWeight: 600 }}>{event?.eventName || event?.name}</span> is
                    estimated at <span style={{ fontWeight: 600 }}>{fmtM(totalGross)}</span> across {totalContracts} contracts.
                  </p>
                  <p>
                    After the Mt. Logan quota share cession of {fmtM(loganCession)} ({((1 - LOGAN_RETENTION) * 100).toFixed(0)}%),
                    the net retained loss stands at <span style={{ fontWeight: 600 }}>{fmtM(totalNet)}</span>,
                    representing a recovery rate of {recoveryRate.toFixed(1)}%.
                    The event loss ratio against total exposed premium is {lossRatio.toFixed(1)}%.
                  </p>
                  {completedBUs < marketEstimates.length && (
                    <p className="text-amber-700 bg-amber-50 px-3 py-2 rounded-lg border border-amber-200" style={{ fontWeight: 500 }}>
                      <AlertTriangle className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />
                      Note: {marketEstimates.length - completedBUs} business unit{marketEstimates.length - completedBUs > 1 ? 's' : ''} still
                      have estimates pending. Final figures may differ.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-white rounded-xl border border-slate-200 px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Info className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs text-slate-500">All values in USD millions. Confidential — for internal Everest use only.</span>
            </div>
            <span className="text-xs text-slate-400">
              Generated {new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* TAB 2 — INCURRED VS ESTIMATE (CLAIM-LEVEL)                   */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {activeReport === 'incurredVsEstimate' && (
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900" style={{ fontSize: '1.125rem', fontWeight: 700 }}>
                Incurred vs Estimate Tracking
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Claim-level comparison of UW estimates against actual incurred losses</p>
            </div>
            <button
              onClick={() => {
                const headers = ['#', 'Contract ID', 'Cedent', 'Business Unit', 'UW Estimate ($M)', 'Incurred ($M)', 'Variance ($M)', 'Variance %', 'Status'];
                const rows = claimLevelData.map((c) => [c.id, c.contractId, c.cedent, c.bu, c.uwEstimate, c.incurred, c.variance.toFixed(1), `${c.variancePct.toFixed(1)}%`, c.status]);
                downloadCSV(headers, rows, `Incurred_vs_Estimate_${event?.eventName || 'Event'}`);
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
          </div>

          {/* Summary KPIs */}
          <div className="grid grid-cols-4 gap-4">
            {(() => {
              const totEst = claimLevelData.reduce((s, c) => s + c.uwEstimate, 0);
              const totInc = claimLevelData.reduce((s, c) => s + c.incurred, 0);
              const totVar = totInc - totEst;
              const onTrack = claimLevelData.filter(c => c.status === 'On Track').length;
              return [
                { label: 'Total Estimated', value: fmtM(totEst), icon: DollarSign, bg: 'bg-blue-50', color: '#0052FF' },
                { label: 'Total Incurred', value: fmtM(totInc), icon: Activity, bg: 'bg-indigo-50', color: '#6366f1' },
                { label: 'Net Variance', value: fmtM(totVar), icon: totVar > 0 ? TrendingUp : TrendingDown, bg: totVar > 0 ? 'bg-red-50' : 'bg-emerald-50', color: totVar > 0 ? '#ef4444' : '#10b981' },
                { label: 'On Track', value: `${onTrack}/${claimLevelData.length}`, icon: CheckCircle2, bg: 'bg-emerald-50', color: '#10b981' },
              ].map(kpi => {
                const Icon = kpi.icon;
                return (
                  <div key={kpi.label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                        <Icon className="w-4 h-4" style={{ color: kpi.color }} />
                      </div>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider">{kpi.label}</span>
                    </div>
                    <div className="text-xl text-slate-900" style={{ fontWeight: 600 }}>{kpi.value}</div>
                  </div>
                );
              });
            })()}
          </div>

          {/* Bar chart visualization */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={BarChart3} title="Estimate vs Incurred by Contract" sub="Side-by-side comparison" />
            <div className="p-6 h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart id="claim-bar-chart" data={claimLevelData.slice(0, 8)} margin={{ top: 10, right: 20, bottom: 5, left: 20 }}>
                  <CartesianGrid key="claim-grid" strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis key="claim-xaxis" dataKey="uid" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} tickLine={false} angle={-20} textAnchor="end" tickFormatter={(val) => { const item = claimLevelData.find(d => d.uid === val); return item ? item.contractId : val; }} />
                  <YAxis key="claim-yaxis" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}M`} />
                  <Tooltip key="claim-tooltip" contentStyle={tooltipStyle} formatter={(v: number, name: string) => [`$${v.toFixed(1)}M`, name]} labelFormatter={(val) => { const item = claimLevelData.find(d => d.uid === val); return item ? item.contractId : val; }} />
                  <Legend key="claim-legend" wrapperStyle={{ fontSize: 11 }} />
                  <Bar key="claim-uw-bar" dataKey="uwEstimate" name="UW Estimate" fill="#0052FF" radius={[4, 4, 0, 0]} barSize={20} id="claim-uw" />
                  <Bar key="claim-inc-bar" dataKey="incurred" name="Incurred" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={20} id="claim-inc" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Detail table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    {['#', 'Contract ID', 'Cedent', 'Business Unit', 'UW Estimate', 'Incurred', 'Variance', 'Var %', 'Status'].map(h => (
                      <th key={h} className={`px-4 py-3 text-[10px] text-slate-500 uppercase tracking-wider ${
                        ['UW Estimate', 'Incurred', 'Variance', 'Var %'].includes(h) ? 'text-right' : h === 'Status' ? 'text-center' : 'text-left'
                      }`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {claimLevelData.map((c, i) => (
                    <tr key={c.uid} className={`hover:bg-slate-50 transition-colors ${i % 2 === 1 ? 'bg-slate-50/50' : ''}`}>
                      <td className="px-4 py-3 text-xs text-slate-500">{c.id}</td>
                      <td className="px-4 py-3 text-xs text-slate-800" style={{ fontWeight: 500 }}>{c.contractId}</td>
                      <td className="px-4 py-3 text-xs text-slate-600">{c.cedent}</td>
                      <td className="px-4 py-3 text-xs text-slate-600">{c.bu}</td>
                      <td className="px-4 py-3 text-xs text-right" style={{ fontWeight: 500 }}>{fmtM(c.uwEstimate)}</td>
                      <td className="px-4 py-3 text-xs text-right" style={{ fontWeight: 500 }}>{fmtM(c.incurred)}</td>
                      <td className={`px-4 py-3 text-xs text-right ${c.variance > 0 ? 'text-red-600' : 'text-emerald-600'}`} style={{ fontWeight: 600 }}>
                        {c.variance > 0 ? '+' : ''}{fmtM(c.variance)}
                      </td>
                      <td className={`px-4 py-3 text-xs text-right ${c.variancePct > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                        {fmtPct(c.variancePct)}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                          c.status === 'On Track' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                          c.status === 'Over' ? 'bg-red-50 text-red-700 border border-red-200' :
                          'bg-amber-50 text-amber-700 border border-amber-200'
                        }`} style={{ fontWeight: 500 }}>{c.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* TAB 3 — LOSS DEVELOPMENT GRAPH                               */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {activeReport === 'lossDevelopment' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900" style={{ fontSize: '1.125rem', fontWeight: 700 }}>
                Loss Development Tracking
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Incurred loss development over time with projected ultimate line
              </p>
            </div>
            <button
              onClick={() => {
                const headers = ['Month', 'Incurred ($M)', 'Projected ($M)', 'Estimate ($M)'];
                const rows = devSeries.map(d => [d.month, d.incurred, d.projected, d.estimate]);
                downloadCSV(headers, rows, `Loss_Development_${event?.eventName || 'Event'}`);
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
          </div>

          {/* KPI strip */}
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: 'Current Incurred', value: fmtM(devSeries[devSeries.length - 1]?.incurred || 0), color: '#ef4444', bg: 'bg-red-50', icon: Activity },
              { label: 'Projected Ultimate', value: fmtM(devSeries[devSeries.length - 1]?.projected || 0), color: '#8b5cf6', bg: 'bg-violet-50', icon: TrendingUp },
              { label: 'Initial Estimate', value: fmtM(totalGross), color: '#0052FF', bg: 'bg-blue-50', icon: DollarSign },
              { label: 'Development %', value: totalGross > 0 ? `${((devSeries[devSeries.length - 1]?.incurred / totalGross) * 100).toFixed(1)}%` : '—', color: '#10b981', bg: 'bg-emerald-50', icon: Target },
            ].map(kpi => {
              const Icon = kpi.icon;
              return (
                <div key={kpi.label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-8 h-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                      <Icon className="w-4 h-4" style={{ color: kpi.color }} />
                    </div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider">{kpi.label}</span>
                  </div>
                  <div className="text-xl text-slate-900" style={{ fontWeight: 600 }}>{kpi.value}</div>
                </div>
              );
            })}
          </div>

          {/* Main chart */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={Activity} title="Incurred Loss Development Curve" sub="Monthly development with projected ultimate" />
            <div className="p-6 h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart id="loss-dev-chart" data={devSeries} margin={{ top: 10, right: 30, bottom: 5, left: 30 }}>
                  <defs key="lossDev-defs">
                    <linearGradient id="lossDev-gradIncurred" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="lossDev-gradProjected" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.1} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid key="lossDev-grid" strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis key="lossDev-xaxis" dataKey="month" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis key="lossDev-yaxis" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}M`} />
                  <Tooltip key="lossDev-tooltip" contentStyle={tooltipStyle} formatter={(v: number, name: string) => [`$${v.toFixed(1)}M`, name]} />
                  <Legend key="lossDev-legend" wrapperStyle={{ fontSize: 11 }} />
                  <Area key="lossDev-estimate" type="monotone" dataKey="estimate" name="Initial Estimate" stroke="#94a3b8" strokeWidth={1} strokeDasharray="6 3" fill="none" dot={false} />
                  <Area key="lossDev-projected" type="monotone" dataKey="projected" name="Projected Ultimate" stroke="#8b5cf6" strokeWidth={2} strokeDasharray="5 3" fill="url(#lossDev-gradProjected)" dot={false} />
                  <Area key="lossDev-incurred" type="monotone" dataKey="incurred" name="Incurred" stroke="#ef4444" strokeWidth={2.5} fill="url(#lossDev-gradIncurred)" dot={{ r: 3, fill: '#ef4444' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Development table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={BarChart3} title="Development Data" sub="Month-by-month figures" />
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    {['Month', 'Incurred ($M)', 'Projected ($M)', 'Estimate ($M)', 'Dev % of Estimate'].map(h => (
                      <th key={h} className={`px-4 py-3 text-[10px] text-slate-500 uppercase tracking-wider ${h === 'Month' ? 'text-left' : 'text-right'}`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {devSeries.map((d, i) => (
                    <tr key={d.month} className={`${i % 2 === 1 ? 'bg-slate-50/50' : ''}`}>
                      <td className="px-4 py-2.5 text-xs text-slate-800" style={{ fontWeight: 500 }}>{d.month}</td>
                      <td className="px-4 py-2.5 text-xs text-right text-red-600" style={{ fontWeight: 500 }}>${d.incurred.toFixed(1)}M</td>
                      <td className="px-4 py-2.5 text-xs text-right text-violet-600" style={{ fontWeight: 500 }}>${d.projected.toFixed(1)}M</td>
                      <td className="px-4 py-2.5 text-xs text-right text-slate-600">${d.estimate.toFixed(1)}M</td>
                      <td className="px-4 py-2.5 text-xs text-right text-slate-700" style={{ fontWeight: 500 }}>
                        {d.estimate > 0 ? `${((d.incurred / d.estimate) * 100).toFixed(1)}%` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* TAB 4 — UW vs MODEL vs INCURRED (TRIPLE COMPARISON)          */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {activeReport === 'tripleComparison' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900" style={{ fontSize: '1.125rem', fontWeight: 700 }}>
                UW Estimate vs Modelled Estimate vs Incurred
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Three-way comparison highlighting mismatches and coverage gaps
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs text-slate-500">Variance threshold:</label>
                <select
                  value={varianceThreshold}
                  onChange={(e) => setVarianceThreshold(Number(e.target.value))}
                  className="px-2 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  {[10, 15, 20, 25, 30, 50].map(v => <option key={v} value={v}>{v}%</option>)}
                </select>
              </div>
              <button
                onClick={() => {
                  const headers = ['Contract', 'Cedent', 'UW Est ($M)', 'Model Est ($M)', 'Incurred ($M)', 'UW vs Model %', 'UW vs Incurred %', 'Model vs Incurred %', 'Flagged'];
                  const rows = tripleData.map(c => [c.contractId, c.cedent, c.uwEstimate, c.modelEstimate.toFixed(1), c.incurred.toFixed(1), `${c.uwVsModel.toFixed(1)}%`, `${c.uwVsIncurred.toFixed(1)}%`, `${c.modelVsIncurred.toFixed(1)}%`, c.flagged ? 'YES' : '']);
                  downloadCSV(headers, rows, `Triple_Comparison_${event?.eventName || 'Event'}`);
                }}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            </div>
          </div>

          {/* Summary strip */}
          <div className="grid grid-cols-4 gap-4">
            {(() => {
              const flagged = tripleData.filter(c => c.flagged).length;
              const avgUwVsInc = tripleData.length > 0 ? tripleData.reduce((s, c) => s + Math.abs(c.uwVsIncurred), 0) / tripleData.length : 0;
              const avgModVsInc = tripleData.length > 0 ? tripleData.reduce((s, c) => s + Math.abs(c.modelVsIncurred), 0) / tripleData.length : 0;
              return [
                { label: 'Contracts Analyzed', value: tripleData.length, icon: FileText, bg: 'bg-blue-50', color: '#0052FF' },
                { label: 'Flagged (>' + varianceThreshold + '%)', value: flagged, icon: AlertTriangle, bg: flagged > 0 ? 'bg-red-50' : 'bg-emerald-50', color: flagged > 0 ? '#ef4444' : '#10b981' },
                { label: 'Avg |UW vs Incurred|', value: `${avgUwVsInc.toFixed(1)}%`, icon: BarChart3, bg: 'bg-indigo-50', color: '#6366f1' },
                { label: 'Avg |Model vs Incurred|', value: `${avgModVsInc.toFixed(1)}%`, icon: Target, bg: 'bg-violet-50', color: '#8b5cf6' },
              ].map(kpi => {
                const Icon = kpi.icon;
                return (
                  <div key={kpi.label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                        <Icon className="w-4 h-4" style={{ color: kpi.color }} />
                      </div>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider">{kpi.label}</span>
                    </div>
                    <div className="text-xl text-slate-900" style={{ fontWeight: 600 }}>{kpi.value}</div>
                  </div>
                );
              });
            })()}
          </div>

          {/* Triple bar chart */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={Layers} title="Three-Way Comparison" sub="UW Estimate (blue) vs Model (violet) vs Incurred (red)" />
            <div className="p-6 h-[320px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart id="triple-bar-chart" data={tripleData.slice(0, 8)} margin={{ top: 10, right: 20, bottom: 5, left: 20 }}>
                  <CartesianGrid key="triple-grid" strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis key="triple-xaxis" dataKey="uid" tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} tickLine={false} angle={-15} textAnchor="end" tickFormatter={(val) => { const item = tripleData.find(d => d.uid === val); return item ? item.contractId : val; }} />
                  <YAxis key="triple-yaxis" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}M`} />
                  <Tooltip key="triple-tooltip" contentStyle={tooltipStyle} formatter={(v: number, name: string) => [`$${v.toFixed(1)}M`, name]} labelFormatter={(val) => { const item = tripleData.find(d => d.uid === val); return item ? item.contractId : val; }} />
                  <Legend key="triple-legend" wrapperStyle={{ fontSize: 11 }} />
                  <Bar key="triple-uw-bar" dataKey="uwEstimate" name="UW Estimate" fill="#0052FF" radius={[3, 3, 0, 0]} barSize={16} id="triple-uw" />
                  <Bar key="triple-model-bar" dataKey="modelEstimate" name="Model Estimate" fill="#8b5cf6" radius={[3, 3, 0, 0]} barSize={16} id="triple-model" />
                  <Bar key="triple-inc-bar" dataKey="incurred" name="Incurred" fill="#ef4444" radius={[3, 3, 0, 0]} barSize={16} id="triple-inc" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Detail table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    {['Contract', 'Cedent', 'UW Est', 'Model Est', 'Incurred', 'UW vs Model', 'UW vs Inc', 'Model vs Inc', ''].map((h, i) => (
                      <th key={`${h}-${i}`} className={`px-4 py-3 text-[10px] text-slate-500 uppercase tracking-wider ${
                        ['UW Est', 'Model Est', 'Incurred', 'UW vs Model', 'UW vs Inc', 'Model vs Inc'].includes(h) ? 'text-right' : 'text-left'
                      }`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tripleData.map((c, i) => (
                    <tr key={c.uid} className={`hover:bg-slate-50 transition-colors ${c.flagged ? 'bg-red-50/30' : i % 2 === 1 ? 'bg-slate-50/50' : ''}`}>
                      <td className="px-4 py-3 text-xs text-slate-800" style={{ fontWeight: 500 }}>{c.contractId}</td>
                      <td className="px-4 py-3 text-xs text-slate-600">{c.cedent}</td>
                      <td className="px-4 py-3 text-xs text-right" style={{ fontWeight: 500, color: '#0052FF' }}>{fmtM(c.uwEstimate)}</td>
                      <td className="px-4 py-3 text-xs text-right text-violet-600" style={{ fontWeight: 500 }}>{fmtM(c.modelEstimate)}</td>
                      <td className="px-4 py-3 text-xs text-right text-red-600" style={{ fontWeight: 500 }}>{fmtM(c.incurred)}</td>
                      <td className={`px-4 py-3 text-xs text-right ${Math.abs(c.uwVsModel) > varianceThreshold ? 'text-red-600' : 'text-slate-600'}`} style={{ fontWeight: 500 }}>
                        {fmtPct(c.uwVsModel)}
                      </td>
                      <td className={`px-4 py-3 text-xs text-right ${Math.abs(c.uwVsIncurred) > varianceThreshold ? 'text-red-600' : 'text-slate-600'}`} style={{ fontWeight: 500 }}>
                        {fmtPct(c.uwVsIncurred)}
                      </td>
                      <td className={`px-4 py-3 text-xs text-right ${Math.abs(c.modelVsIncurred) > varianceThreshold ? 'text-red-600' : 'text-slate-600'}`} style={{ fontWeight: 500 }}>
                        {fmtPct(c.modelVsIncurred)}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {c.flagged && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-100 text-red-700 border border-red-200" style={{ fontWeight: 600 }}>
                            FLAGGED
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* TAB 5 — KPI ACCURACY PER TEAM / AREA                         */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      {activeReport === 'kpiAccuracy' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900" style={{ fontSize: '1.125rem', fontWeight: 700 }}>
                Estimation Accuracy by Team &amp; Area
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                KPI scorecard comparing estimate accuracy against actual incurred per business unit
              </p>
            </div>
            <button
              onClick={() => {
                const headers = ['Business Unit', 'Area', 'Estimated ($M)', 'Incurred ($M)', 'Variance ($M)', 'Variance %', 'Accuracy %', 'Grade', 'Contracts', 'Status'];
                const rows = kpiByTeam.map(t => [t.bu, t.area, t.estimated, t.incurred.toFixed(1), t.variance.toFixed(1), `${t.variancePct.toFixed(1)}%`, `${t.accuracy.toFixed(1)}%`, t.grade, t.contractCount, t.status]);
                downloadCSV(headers, rows, `KPI_Accuracy_${event?.eventName || 'Event'}`);
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
          </div>

          {/* Overall accuracy KPIs */}
          <div className="grid grid-cols-4 gap-4">
            {(() => {
              const avgAccuracy = kpiByTeam.length > 0 ? kpiByTeam.reduce((s, t) => s + t.accuracy, 0) / kpiByTeam.length : 0;
              const bestTeam = kpiByTeam.reduce((best, t) => t.accuracy > best.accuracy ? t : best, kpiByTeam[0]);
              const aCount = kpiByTeam.filter(t => t.grade === 'A').length;
              const flagCount = kpiByTeam.filter(t => t.grade === 'D').length;
              return [
                { label: 'Avg Accuracy', value: `${avgAccuracy.toFixed(1)}%`, icon: Target, bg: 'bg-blue-50', color: '#0052FF' },
                { label: 'Best Team', value: bestTeam?.bu?.length > 15 ? bestTeam.bu.substring(0, 13) + '…' : bestTeam?.bu || '—', icon: CheckCircle2, bg: 'bg-emerald-50', color: '#10b981' },
                { label: 'Grade A Teams', value: `${aCount}/${kpiByTeam.length}`, icon: Shield, bg: 'bg-blue-50', color: '#0052FF' },
                { label: 'Needs Review', value: flagCount, icon: AlertTriangle, bg: flagCount > 0 ? 'bg-red-50' : 'bg-emerald-50', color: flagCount > 0 ? '#ef4444' : '#10b981' },
              ].map(kpi => {
                const Icon = kpi.icon;
                return (
                  <div key={kpi.label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                        <Icon className="w-4 h-4" style={{ color: kpi.color }} />
                      </div>
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider">{kpi.label}</span>
                    </div>
                    <div className="text-xl text-slate-900" style={{ fontWeight: 600 }}>{kpi.value}</div>
                  </div>
                );
              });
            })()}
          </div>

          {/* Accuracy bar chart */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={Target} title="Accuracy Score by Business Unit" sub="Higher is better — threshold at 80%" />
            <div className="p-6 h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart id="kpi-bar-chart" data={kpiByTeam} layout="vertical" margin={{ top: 5, right: 30, bottom: 5, left: 10 }}>
                  <CartesianGrid key="kpi-grid" strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
                  <XAxis key="kpi-xaxis" type="number" domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                  <YAxis key="kpi-yaxis" type="category" dataKey="uid" width={130} tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false}
                    tickFormatter={(val) => { const item = kpiByTeam.find(d => d.uid === val); return item ? item.buLabel : val; }} />
                  <Tooltip key="kpi-tooltip" contentStyle={tooltipStyle} formatter={(v: number) => [`${v.toFixed(1)}%`, 'Accuracy']} labelFormatter={(val) => { const item = kpiByTeam.find(d => d.uid === val); return item ? item.bu : val; }} />
                  {/* 80% reference line */}
                  <Bar key="kpi-accuracy-bar" dataKey="accuracy" name="Accuracy %" radius={[0, 4, 4, 0]} barSize={18}>
                    {kpiByTeam.map((entry) => (
                      <Cell key={entry.uid} fill={entry.accuracy >= 90 ? '#10b981' : entry.accuracy >= 80 ? '#0052FF' : entry.accuracy >= 70 ? '#f59e0b' : '#ef4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Scorecard table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <SectionHeader icon={Users} title="Team Scorecard" sub="Detailed accuracy breakdown by business unit" />
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    {['Business Unit', 'Area', 'Estimated', 'Incurred', 'Variance', 'Var %', 'Accuracy', 'Grade', 'Contracts', 'Status'].map(h => (
                      <th key={h} className={`px-4 py-3 text-[10px] text-slate-500 uppercase tracking-wider ${
                        ['Estimated', 'Incurred', 'Variance', 'Var %', 'Accuracy', 'Contracts'].includes(h) ? 'text-right' :
                        ['Grade', 'Status'].includes(h) ? 'text-center' : 'text-left'
                      }`}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {kpiByTeam.map((t, i) => (
                    <tr key={t.uid} className={`hover:bg-slate-50 transition-colors ${i % 2 === 1 ? 'bg-slate-50/50' : ''}`}>
                      <td className="px-4 py-3 text-xs text-slate-800" style={{ fontWeight: 500 }}>{t.bu}</td>
                      <td className="px-4 py-3 text-xs text-slate-600">{t.area}</td>
                      <td className="px-4 py-3 text-xs text-right" style={{ fontWeight: 500 }}>{fmtM(t.estimated)}</td>
                      <td className="px-4 py-3 text-xs text-right" style={{ fontWeight: 500 }}>{fmtM(t.incurred)}</td>
                      <td className={`px-4 py-3 text-xs text-right ${t.variance > 0 ? 'text-red-600' : 'text-emerald-600'}`} style={{ fontWeight: 600 }}>
                        {t.variance > 0 ? '+' : ''}{fmtM(t.variance)}
                      </td>
                      <td className={`px-4 py-3 text-xs text-right ${Math.abs(t.variancePct) > 20 ? 'text-red-600' : 'text-slate-600'}`}>
                        {fmtPct(t.variancePct)}
                      </td>
                      <td className="px-4 py-3 text-xs text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="w-16 h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{
                              width: `${Math.min(t.accuracy, 100)}%`,
                              backgroundColor: t.accuracy >= 90 ? '#10b981' : t.accuracy >= 80 ? '#0052FF' : t.accuracy >= 70 ? '#f59e0b' : '#ef4444'
                            }} />
                          </div>
                          <span style={{ fontWeight: 600 }}>{t.accuracy.toFixed(0)}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs ${
                          t.grade === 'A' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                          t.grade === 'B' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                          t.grade === 'C' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                          'bg-red-50 text-red-700 border border-red-200'
                        }`} style={{ fontWeight: 700 }}>{t.grade}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-right text-slate-600">{t.contractCount}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                          t.status === 'Complete' ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' :
                          t.status === 'In Progress' ? 'bg-amber-50 text-amber-600 border border-amber-200' :
                          'bg-slate-50 text-slate-500 border border-slate-200'
                        }`} style={{ fontWeight: 500 }}>{t.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Grading legend */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm px-6 py-4">
            <div className="flex items-center gap-6">
              <span className="text-xs text-slate-500" style={{ fontWeight: 500 }}>Grading Scale:</span>
              {[
                { grade: 'A', range: '≥ 90%', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' },
                { grade: 'B', range: '80–89%', color: 'text-blue-700 bg-blue-50 border-blue-200' },
                { grade: 'C', range: '70–79%', color: 'text-amber-700 bg-amber-50 border-amber-200' },
                { grade: 'D', range: '< 70%', color: 'text-red-700 bg-red-50 border-red-200' },
              ].map(g => (
                <div key={g.grade} className="flex items-center gap-2">
                  <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-[10px] border ${g.color}`} style={{ fontWeight: 700 }}>{g.grade}</span>
                  <span className="text-xs text-slate-500">{g.range}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

/* ── Shared helpers ──────────────────────────────────────────────────── */

const tooltipStyle = {
  backgroundColor: '#fff',
  border: '1px solid #e2e8f0',
  borderRadius: '8px',
  color: '#1e293b',
  boxShadow: '0 4px 6px rgba(0,0,0,0.07)',
  fontSize: 12,
};

function SectionHeader({
  icon: Icon,
  title,
  sub,
  iconBg = '',
  iconColor = '#0052FF',
}: {
  icon: React.ElementType;
  title: string;
  sub?: string;
  iconBg?: string;
  iconColor?: string;
}) {
  return (
    <div className="px-6 py-3.5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white flex items-center gap-3">
      <div
        className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${iconBg || ''}`}
        style={!iconBg ? { backgroundColor: '#E6EFFF' } : {}}
      >
        <Icon className="w-4 h-4" style={{ color: iconColor }} />
      </div>
      <div className="flex-1 text-left">
        <h3 className="text-slate-900 uppercase tracking-wider text-xs" style={{ fontWeight: 600 }}>{title}</h3>
        {sub && <p className="text-[10px] text-slate-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}
