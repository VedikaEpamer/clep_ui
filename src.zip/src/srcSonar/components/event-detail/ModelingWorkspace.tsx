import { useState, useEffect, useRef, lazy, Suspense } from 'react';
import { Upload, Download, FileText, CheckCircle2, AlertCircle, Lock, X, Calendar, User, Building2, MapPin, XCircle, ChevronDown, ChevronRight, MessageSquare, Send, Clock, History } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useParams } from 'react-router';
import { mockEvents } from '../../lib/mockData';
import { CommentModal } from '../CommentModal';
import { CommentThread } from '../CommentThread';
import { useComments } from '../../lib/commentContext';
import { useWorkflow } from '../../lib/workflowContext';
import type { LossByContractRow } from './GrossLossTable';
const LazyGrossLossTable = lazy(() => import('./GrossLossTable').then(m => ({ default: m.GrossLossTable })));

// Layerkeys that appear in the UW Estimation contract listing
const IN_UW_EST_KEYS = new Set([
  '112','114','417744','68001','68002', // Chile / LatAm
  '2','106','102', // Cessions / Canada Fac
  '127','128','126', // London Fac
  '145','142','146','413664', // US Fac
  '139885','288755','48044','388129','276751','197195', // EI
  '297485', // EI EIID
  '40373', // EI Canada
  '297486','348580', // EI Syndicate
  '388342','329411','388306', // EI Recovery
  '406867','416633','419084','428282','417665','417506', // Treaty Property
  '408615','419128','403564', // Bermuda
  '403008','412751','417875', // London
  '403492', // Canada Treaty
  '411923','421191', // Zurich
  '329065', // EI Singapore
  '402525', // London Fac named
]);

// Helper to generate event2/event3 gross values from event1 gross
function _deriveEventGross(grossStr: string, multiplier: number): string {
  if (!grossStr || grossStr === '-' || grossStr === 'NULL') return '-';
  const cleaned = grossStr.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '');
  const num = Number(cleaned);
  if (isNaN(num) || num === 0) return '-';
  const derived = Math.round(num * multiplier);
  const abs = Math.abs(derived);
  const formatted = abs.toLocaleString('en-US');
  return derived < 0 ? `(${formatted})` : formatted;
}

const _rawLossByContractData: Record<string, any>[] = [
  // === Chile / Chile EQ area contracts ===
  { layerkey: '112', eventId: '270184630', department: 'LatAm Fac', company: 'QA LatAm Fac', subtype: 'RSK', contract: 'QA LatAm Fac', everestLimit: '718,602,363', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '9,494', netOfLogan: '9,494', netOfAllCessions: '9,494', expectedRIPs: '-', maxWind: '119.8', landfall: 'Valparaíso, Chile', industryLoss: '14,250', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '114', eventId: '270184630', department: 'LatAm Fac', company: 'QA LatAm Fac', subtype: 'RSK', contract: 'QA LatAm Fac', everestLimit: '811,887,392', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '153', netOfLogan: '153', netOfAllCessions: '153', expectedRIPs: '-', maxWind: '119.8', landfall: 'Valparaíso, Chile', industryLoss: '14,250', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '116', eventId: '270184630', department: 'LatAm Fac', company: 'QA LatAm Fac', subtype: 'RSK', contract: 'QA LatAm Fac', everestLimit: '97,882,387', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '10', netOfLogan: '10', netOfAllCessions: '10', expectedRIPs: '-', maxWind: '119.8', landfall: 'Santiago, Chile', industryLoss: '14,250', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '417744', eventId: '270184630', department: 'LatAm Fac', company: 'LAF25 Dynamic Re', subtype: 'PR', contract: 'AP10000516-2025-1', everestLimit: '65,744,229', limit100: '65,744,229', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '63,445', netOfLogan: '63,445', netOfAllCessions: '63,445', expectedRIPs: '-', maxWind: '120', landfall: 'Concepción, Chile', industryLoss: '14,250', manualOverride: 'N', departmentMap: 'FP' },
  // Chile EQ contracts
  { layerkey: '68001', eventId: '270184630', department: 'LatAm Fac', company: 'Renta Nacional Cia. De Seguros', subtype: 'QS', contract: 'FP10108831-2026-1', everestLimit: '1,861,732', limit100: '23,271,650', retention: '-', aggregateDeductible: '-', terms: 'QS', rol: '15.3%', share: '8.0%', gross: '465,433', netOfLogan: '465,433', netOfAllCessions: '465,433', expectedRIPs: '-', maxWind: '-', landfall: 'Santiago, Chile', industryLoss: '22,800', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '68002', eventId: '270184630', department: 'LatAm Fac', company: 'Consorcio Nacional De Seguros S.A.', subtype: 'QS', contract: 'FP10116737-2026-1', everestLimit: '3,709,304', limit100: '46,366,300', retention: '-', aggregateDeductible: '-', terms: 'QS', rol: '12.8%', share: '8.0%', gross: '927,326', netOfLogan: '927,326', netOfAllCessions: '927,326', expectedRIPs: '-', maxWind: '-', landfall: 'Valparaíso, Chile', industryLoss: '22,800', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '68003', eventId: '270184630', department: 'LatAm Fac', company: 'BCI Seguros Generales S.A.', subtype: 'XS', contract: 'FC10112979-2026-1', everestLimit: '4,000,000', limit100: '8,000,000', retention: '182,000,000', aggregateDeductible: '182,000,000', terms: 'XS', rol: '1.5%', share: '50.0%', gross: '0', netOfLogan: '0', netOfAllCessions: '0', expectedRIPs: '-', maxWind: '-', landfall: 'Santiago, Chile', industryLoss: '22,800', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '68004', eventId: '270184630', department: 'LatAm Fac', company: 'Consorcio Nacional De Seguros S.A.', subtype: 'QS', contract: 'FP10081715-2026-1', everestLimit: '4,000,000', limit100: '80,000,000', retention: '-', aggregateDeductible: '-', terms: 'QS', rol: '7.1%', share: '5.0%', gross: '1,000,000', netOfLogan: '1,000,000', netOfAllCessions: '1,000,000', expectedRIPs: '-', maxWind: '-', landfall: 'Concepción, Chile', industryLoss: '22,800', manualOverride: 'N', departmentMap: 'FP' },
  // === Cessions Recovery ===
  { layerkey: '2', eventId: '270184630', department: 'Cessions Recovery', company: 'AF', subtype: 'PR', contract: 'NULL', everestLimit: '(581,822,065)', limit100: '(581,822,065)', retention: '-', aggregateDeductible: '-', terms: 'NULL', rol: '-', share: '1', gross: '-', netOfLogan: '-', netOfAllCessions: '(6,855,361)', expectedRIPs: '(2,071,029)', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'AF' },
  // === Canada Fac ===
  { layerkey: '106', eventId: '270184630', department: 'Canada Fac', company: 'QA Canada Fac', subtype: 'RSK', contract: 'QA Canada Fac', everestLimit: '23,652,805', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '102,557', netOfLogan: '102,557', netOfAllCessions: '102,557', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '109', eventId: '270184630', department: 'Canada Fac', company: 'QA Canada Fac', subtype: 'RSK', contract: 'QA Canada Fac', everestLimit: '85,847,512', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '14,577', netOfLogan: '14,577', netOfAllCessions: '14,577', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '102', eventId: '270184630', department: 'Canada Fac', company: 'QA Canada Fac', subtype: 'RSK', contract: 'QA Canada Fac', everestLimit: '161,928,638', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '35', netOfLogan: '35', netOfAllCessions: '35', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '103', eventId: '270184630', department: 'Canada Fac', company: 'QA Canada Fac', subtype: 'RSK', contract: 'QA Canada Fac', everestLimit: '263,487,845', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '7,861', netOfLogan: '7,861', netOfAllCessions: '7,861', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  // === London Fac ===
  { layerkey: '127', eventId: '270184630', department: 'London Fac', company: 'QA London Fac', subtype: 'RSK', contract: 'QA London Fac', everestLimit: '84,983,198', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '9,323', netOfLogan: '9,323', netOfAllCessions: '9,323', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '124', eventId: '270184630', department: 'London Fac', company: 'QA London Fac', subtype: 'RSK', contract: 'QA London Fac', everestLimit: '58,179,346', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '3,969', netOfLogan: '3,969', netOfAllCessions: '3,969', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '128', eventId: '270184630', department: 'London Fac', company: 'QA London Fac', subtype: 'RSK', contract: 'QA London Fac', everestLimit: '54,942,304', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '22,688', netOfLogan: '22,688', netOfAllCessions: '22,688', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '126', eventId: '270184630', department: 'London Fac', company: 'QA London Fac', subtype: 'RSK', contract: 'QA London Fac', everestLimit: '50,025,364', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '17,865', netOfLogan: '17,865', netOfAllCessions: '17,865', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '122', eventId: '270184630', department: 'London Fac', company: 'QA London Fac', subtype: 'RSK', contract: 'QA London Fac', everestLimit: '65,934,315', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '661', netOfLogan: '661', netOfAllCessions: '661', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  // === US Fac ===
  { layerkey: '145', eventId: '270184630', department: 'US Fac', company: 'QA US Fac', subtype: 'RSK', contract: 'QA US Fac', everestLimit: '1,271,689,008', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '1,058,614', netOfLogan: '1,058,614', netOfAllCessions: '1,058,614', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '142', eventId: '270184630', department: 'US Fac', company: 'QA US Fac', subtype: 'RSK', contract: 'QA US Fac', everestLimit: '79,919,424', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '58,214', netOfLogan: '58,214', netOfAllCessions: '58,214', expectedRIPs: '-', maxWind: '119.8', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '146', eventId: '270184630', department: 'US Fac', company: 'QA US Fac', subtype: 'RSK', contract: 'QA US Fac', everestLimit: '1,866,630,983', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '1,802,968', netOfLogan: '1,802,968', netOfAllCessions: '1,802,968', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '148', eventId: '270184630', department: 'US Fac', company: 'QA US Fac', subtype: 'RSK', contract: 'QA US Fac', everestLimit: '1,456,218,798', limit100: '-', retention: '-', aggregateDeductible: '-', terms: 'FAC', rol: '-', share: '1', gross: '469,052', netOfLogan: '469,052', netOfAllCessions: '469,052', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '413357', eventId: '270184630', department: 'US Fac', company: 'AP25 GAIC AFA', subtype: 'RSK', contract: 'AP10000612-2025-1', everestLimit: '4,000,000', limit100: '20,000,000', retention: '-', aggregateDeductible: '-', terms: 'RSK: 10x5, 20x0 Occ', rol: '0', share: '0', gross: '2', netOfLogan: '2', netOfAllCessions: '2', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  { layerkey: '413664', eventId: '270184630', department: 'US Fac', company: 'AP25 Obsidian SRU Excess', subtype: 'PR', contract: 'AP10000763-2025-2', everestLimit: '7,500,000', limit100: '50,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 50x0', rol: '1', share: '0', gross: '216,192', netOfLogan: '216,192', netOfAllCessions: '216,192', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
  // === EI (Everest Insurance) ===
  { layerkey: '139885', eventId: '270184630', department: 'EI', company: 'QA EI RETAIL', subtype: 'PR', contract: 'EN0000000-2017-1', everestLimit: '1,221,622,509', limit100: '1,221,622,509', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '17,193,857', netOfLogan: '17,193,857', netOfAllCessions: '17,193,857', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '288755', eventId: '270184630', department: 'EI', company: 'QA EI SIG', subtype: 'PR', contract: 'EI000000', everestLimit: '11,425,183', limit100: '11,425,183', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '16,959', netOfLogan: '16,959', netOfAllCessions: '16,959', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '48044', eventId: '270184630', department: 'EI', company: 'QA EI WHOLESALE', subtype: 'PR', contract: 'EF0000000A-2015-1', everestLimit: '332,372,319', limit100: '332,372,319', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '1', share: '1', gross: '20,688,894', netOfLogan: '20,688,894', netOfAllCessions: '20,688,894', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '388129', eventId: '270184630', department: 'EI', company: 'QA EI AMRISC', subtype: 'PR', contract: 'EIAmrisc', everestLimit: '282,770,916', limit100: '282,770,916', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '6,823,374', netOfLogan: '6,823,374', netOfAllCessions: '6,823,374', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '326485', eventId: '270184630', department: 'EI', company: 'QA EI MIDDLE MARKET', subtype: 'PR', contract: 'EI000', everestLimit: '234,758,763', limit100: '234,758,763', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '473,577', netOfLogan: '473,577', netOfAllCessions: '473,577', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '276751', eventId: '270184630', department: 'EI', company: 'QA EI JEM', subtype: 'PR', contract: 'EI000000', everestLimit: '150,592,784', limit100: '150,592,784', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '1,798,860', netOfLogan: '1,798,860', netOfAllCessions: '1,798,860', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '197195', eventId: '270184630', department: 'EI', company: 'QA EI INLAND MARINE', subtype: 'PR', contract: 'EIM000000-2019-1', everestLimit: '224,435,562', limit100: '224,435,562', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '104,567', netOfLogan: '104,567', netOfAllCessions: '104,567', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  // === EI EIID ===
  { layerkey: '297485', eventId: '270184630', department: 'EI EIID', company: 'QA EI EIID Property', subtype: 'PR', contract: 'EIID', everestLimit: '1,121,804,627', limit100: '1,121,804,627', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '283,523', netOfLogan: '283,523', netOfAllCessions: '283,523', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '329067', eventId: '270184630', department: 'EI EIID', company: 'QA EI EIID Energy', subtype: 'PR', contract: 'EIID Energy', everestLimit: '103,045,568', limit100: '103,045,568', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '12,945', netOfLogan: '12,945', netOfAllCessions: '12,945', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  // === EI Canada ===
  { layerkey: '40373', eventId: '270184630', department: 'EI Canada', company: 'QA EI Canada Property', subtype: 'PR', contract: 'EC1234567A-2015-1', everestLimit: '1,086,772,515', limit100: '1,086,772,515', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '24,252', netOfLogan: '24,252', netOfAllCessions: '24,252', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  // === EI Syndicate ===
  { layerkey: '297486', eventId: '270184630', department: 'EI Syndicate', company: 'QA EI Syndicate Property', subtype: 'PR', contract: 'Synd', everestLimit: '359,770,614', limit100: '359,770,614', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '1,550,776', netOfLogan: '1,550,776', netOfAllCessions: '1,550,776', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  { layerkey: '348580', eventId: '270184630', department: 'EI Syndicate', company: 'QA EI Syndicate Marine', subtype: 'PR', contract: 'SyndCargo', everestLimit: '136,538,075', limit100: '136,538,075', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '763,409', netOfLogan: '763,409', netOfAllCessions: '763,409', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  // === EI Recovery ===
  { layerkey: '388342', eventId: '270184630', department: 'EI Recovery', company: 'QA EI NA QS', subtype: 'PR', contract: 'EINAQS', everestLimit: '(348,669,933)', limit100: '(348,669,933)', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '-', share: '1', gross: '-', netOfLogan: '-', netOfAllCessions: '(10,928,663)', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'EI Recovery^' },
  { layerkey: '329411', eventId: '270184630', department: 'EI Recovery', company: 'QA EI Energy QS Buy', subtype: 'PR', contract: 'ENBUY', everestLimit: '(55,164,737)', limit100: '(55,164,737)', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '-', share: '1', gross: '-', netOfLogan: '-', netOfAllCessions: '(6,472)', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'EI Recovery^' },
  { layerkey: '388306', eventId: '270184630', department: 'EI Recovery', company: 'QA EI Global Per Risk Buy', subtype: 'RSK', contract: 'EIPPR', everestLimit: '(162,750,154)', limit100: '(162,750,154)', retention: '-', aggregateDeductible: '-', terms: 'RSK: Unlx0', rol: '-', share: '1', gross: '-', netOfLogan: '-', netOfAllCessions: '(920,668)', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'EI Recovery^' },
  // === Treaty Property ===
  { layerkey: '406867', eventId: '270184630', department: 'Treaty Property', company: 'TP25 Westfield QS Layers', subtype: 'PR', contract: 'TP10021335-2025-1', everestLimit: '13,500,000', limit100: '225,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 225x0', rol: '1', share: '0', gross: '1,815,185', netOfLogan: '1,815,185', netOfAllCessions: '1,815,185', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '416633', eventId: '270184630', department: 'Treaty Property', company: 'TP25 MS Transverse Apex One', subtype: 'CAT', contract: 'TP10022377-2025-1', everestLimit: '5,550,000', limit100: '30,000,000', retention: '10,000,000', aggregateDeductible: '-', terms: 'CAT: 30x10', rol: '1', share: '0', gross: '4,311,655', netOfLogan: '3,243,278', netOfAllCessions: '3,243,278', expectedRIPs: '1,945,965', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '419084', eventId: '270184630', department: 'Treaty Property', company: 'TP25 Florida Pen Net QS', subtype: 'PR', contract: 'TP10000740-2025-1', everestLimit: '12,000,000', limit100: '75,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 75x0', rol: '15', share: '0', gross: '12,000,000', netOfLogan: '12,000,000', netOfAllCessions: '12,000,000', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '428282', eventId: '270184630', department: 'Treaty Property', company: 'TP25 UPCIC/APPCIC FOT', subtype: 'CAT', contract: 'TP10022865-2025-1', everestLimit: '29,340,000', limit100: '326,000,000', retention: '111,000,000', aggregateDeductible: '-', terms: 'CAT: 326x111', rol: '1', share: '0', gross: '25,243,976', netOfLogan: '19,154,669', netOfAllCessions: '19,154,669', expectedRIPs: '10,151,968', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '435540', eventId: '270184630', department: 'Treaty Property', company: 'TP25 Florida Peninsula', subtype: 'CAT', contract: 'TP00001339-2025-4', everestLimit: '13,500,000', limit100: '180,000,000', retention: '150,000,000', aggregateDeductible: '-', terms: 'CAT: 180x150', rol: '0', share: '0', gross: '13,500,000', netOfLogan: '10,244,499', netOfAllCessions: '10,244,499', expectedRIPs: '3,995,355', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '417665', eventId: '270184630', department: 'Treaty Property', company: 'TP25 Sompo Intl QS', subtype: 'PR', contract: 'TP10018563-2025-1', everestLimit: '40,000,000', limit100: '800,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 800x0', rol: '2', share: '0', gross: '2,588,277', netOfLogan: '2,588,277', netOfAllCessions: '2,588,277', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  { layerkey: '417506', eventId: '270184630', department: 'Treaty Property', company: 'TP25 Hiscox Binders QS', subtype: 'PR', contract: 'TP0288820A-2025-1', everestLimit: '45,000,000', limit100: '450,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 450x0', rol: '1', share: '0', gross: '1,330,843', netOfLogan: '1,330,843', netOfAllCessions: '1,330,843', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'TP' },
  // === Bermuda ===
  { layerkey: '408615', eventId: '270184630', department: 'Bermuda', company: 'BM25 Arch 1955 Regearing', subtype: 'PR', contract: 'TP10018260-2025-1', everestLimit: '50,102,778', limit100: '1,102,371,357', retention: '-', aggregateDeductible: '-', terms: 'PR: 948.63x0', rol: '1', share: '0', gross: '433,883', netOfLogan: '433,883', netOfAllCessions: '433,883', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Bermuda' },
  { layerkey: '419128', eventId: '270184630', department: 'Bermuda', company: 'BM25 Convex WA QS', subtype: 'PR', contract: 'TP10002757-2025-1', everestLimit: '65,700,000', limit100: '1,314,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 1314x0', rol: '3', share: '0', gross: '3,454,389', netOfLogan: '3,454,389', netOfAllCessions: '3,454,389', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Bermuda' },
  { layerkey: '420380', eventId: '270184630', department: 'Bermuda', company: 'BM25 Canopius Vave QS', subtype: 'PR', contract: 'TP10022728-2025-1', everestLimit: '175,577,955', limit100: '1,755,779,545', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '0', gross: '5,666,003', netOfLogan: '5,666,003', netOfAllCessions: '5,666,003', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Bermuda' },
  { layerkey: '403564', eventId: '270184630', department: 'Bermuda', company: 'BM25 Canopius WA QS', subtype: 'PR', contract: 'TP10023589-2025-1', everestLimit: '54,000,000', limit100: '1,350,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 1350x0', rol: '2', share: '0', gross: '2,315,285', netOfLogan: '2,315,285', netOfAllCessions: '2,315,285', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Bermuda' },
  // === London ===
  { layerkey: '403008', eventId: '270184630', department: 'London', company: 'UK25 Intact Eng', subtype: 'PR', contract: 'TP10022011-2025-1', everestLimit: '1,600,000', limit100: '80,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 80x0', rol: '2', share: '0', gross: '52,673', netOfLogan: '52,673', netOfAllCessions: '52,673', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'London' },
  { layerkey: '407205', eventId: '270184630', department: 'London', company: 'UK25 Aviva Tech Lines QS', subtype: 'PR', contract: 'TP10023618-2025-1', everestLimit: '17,280,415', limit100: '230,405,535', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '1', share: '0', gross: '219,808', netOfLogan: '219,808', netOfAllCessions: '219,808', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'London' },
  { layerkey: '412751', eventId: '270184630', department: 'London', company: 'UK25 Liberty Mutual Eng', subtype: 'PR', contract: 'TP10023731-2025-1', everestLimit: '9,000,000', limit100: '300,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 300x0', rol: '1', share: '0', gross: '35,078', netOfLogan: '35,078', netOfAllCessions: '35,078', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'London' },
  { layerkey: '417875', eventId: '270184630', department: 'London', company: 'UK25 AIG Eng', subtype: 'PR', contract: 'TP0007578L-2025-1', everestLimit: '35,000,000', limit100: '350,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 350x0', rol: '1', share: '0', gross: '77,849', netOfLogan: '77,849', netOfAllCessions: '77,849', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'London' },
  // === Canada (Treaty) ===
  { layerkey: '403492', eventId: '270184630', department: 'Canada', company: 'CAN24 AWAC Property QS', subtype: 'PR', contract: 'TP0299870A-2024-1', everestLimit: '15,506,364', limit100: '114,861,956', retention: '-', aggregateDeductible: '-', terms: 'PR: 160x0', rol: '1', share: '0', gross: '28,064', netOfLogan: '28,064', netOfAllCessions: '28,064', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Canada' },
  { layerkey: '417026', eventId: '270184630', department: 'Canada', company: 'CAN25 STARR QS', subtype: 'PR', contract: 'TP10003622-2025-1', everestLimit: '30,000,000', limit100: '600,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 600x0', rol: '0', share: '0', gross: '174,360', netOfLogan: '174,360', netOfAllCessions: '174,360', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Canada' },
  // === Zurich / Dublin ===
  { layerkey: '411923', eventId: '270184630', department: 'Zurich', company: 'GER25_AgcsOnshore_QS', subtype: 'PR', contract: 'EV0105443A-2025-1', everestLimit: '31,133,319', limit100: '478,974,143', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '1', share: '0', gross: '60,293', netOfLogan: '60,293', netOfAllCessions: '60,293', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Dublin' },
  { layerkey: '421191', eventId: '270184630', department: 'Zurich', company: 'GER25_AGCS_LowCarbonQS', subtype: 'PR', contract: 'EV10000338-2025-1', everestLimit: '10,000,000', limit100: '50,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 50x0', rol: '1', share: '0', gross: '226,275', netOfLogan: '226,275', netOfAllCessions: '226,275', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Dublin' },
  // === EI Singapore ===
  { layerkey: '329065', eventId: '270184630', department: 'EI Singapore', company: 'QA EI Singapore Property', subtype: 'PR', contract: 'Singapore', everestLimit: '261,914,893', limit100: '261,914,893', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '0', share: '1', gross: '12,742', netOfLogan: '12,742', netOfAllCessions: '12,742', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'Insurance' },
  // === ME Africa Treaty ===
  { layerkey: '417935', eventId: '270184630', department: 'ME Africa Treaty', company: 'MEA25 AIG Onshore Energy QS', subtype: 'PR', contract: 'TP10002373-2025-1', everestLimit: '37,500,000', limit100: '500,000,000', retention: '-', aggregateDeductible: '-', terms: 'PR: 500x0', rol: '2', share: '0', gross: '264,800', netOfLogan: '264,800', netOfAllCessions: '264,800', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'MEA' },
  // === London Fac (named) ===
  { layerkey: '402525', eventId: '270184630', department: 'London Fac', company: 'UKF24 UNICORN', subtype: 'PR', contract: 'AP10000610-2024', everestLimit: '40,051,449', limit100: '40,051,449', retention: '-', aggregateDeductible: '-', terms: 'PR', rol: '1', share: '1', gross: '406,575', netOfLogan: '406,575', netOfAllCessions: '406,575', expectedRIPs: '-', maxWind: '120', landfall: 'Manatee, FL', industryLoss: '18,411', manualOverride: 'N', departmentMap: 'FP' },
];

const lossByContractData: LossByContractRow[] = _rawLossByContractData.map(row => ({
  inUWEst: IN_UW_EST_KEYS.has(row.layerkey),
  layerkey: row.layerkey,
  department: row.department,
  company: row.company,
  subtype: row.subtype,
  contract: row.contract,
  everestLimit: row.everestLimit,
  limit100: row.limit100,
  retention: row.retention,
  aggregateDeductible: row.aggregateDeductible,
  terms: row.terms,
  rol: row.rol,
  share: row.share,
  event1Gross: row.gross,
  event2Gross: _deriveEventGross(row.gross, 0.72),
  event3Gross: _deriveEventGross(row.gross, 1.35),
  netOfLogan: row.netOfLogan,
  netOfAllCessions: row.netOfAllCessions,
  expectedRIPs: row.expectedRIPs,
}));

// ─── Dept/Type Breakdown Components ──────────────────────────────────────────

// Map raw departmentMap values → display labels
const DEPT_DISPLAY_LABELS: Record<string, string> = {
  'Bermuda': 'Bermuda',
  'London': 'London',
  'Singapore': 'Singapore',
  'MEA': 'MEA',
  'Lloyds': "Lloyd's",
  'Miami': 'Miami',
  'TP': 'TP',
  'FP': 'FP',
  'Dublin': 'Dublin',
  'Canada': 'Canada',
  'Insurance': 'Insurance',
  'Marine': 'Marine',
  'Parametric Solutions': 'Parametric Solutions',
  'Cat Bond Recovery': 'Cat Bond Recovery',
  'EI Recovery^': 'EI Recovery',
  'AF': 'AF Cessions Recovery',
};

// Flat ordered list of departments (matching modeling overview)
const DEPT_FLAT_ORDER = [
  'Bermuda', 'London', 'Singapore', 'MEA', 'Lloyds', 'Miami',
  'TP', 'FP', 'Dublin', 'Canada', 'Insurance', 'Marine',
  'Parametric Solutions', 'Cat Bond Recovery', 'EI Recovery^', 'AF',
];

function DeptBreakdownRows({ deptKey, label, subtypes, pivot, deptTotal, fmtM, isRecovery }: {
  deptKey: string; label: string; subtypes: string[];
  pivot: Record<string, { e1: number; e2: number; e3: number }>;
  deptTotal: { e1: number; e2: number; e3: number };
  fmtM: (v: number) => string;
  isRecovery?: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const hasNeg = deptTotal.e1 < 0 || deptTotal.e2 < 0 || deptTotal.e3 < 0;
  const valColor = hasNeg || isRecovery ? 'text-red-700' : 'text-slate-900';
  return (
    <>
      <tr
        className={`cursor-pointer transition-colors ${hasNeg ? 'hover:bg-red-50/60' : 'hover:bg-slate-50'}`}
        onClick={() => setExpanded(!expanded)}
      >
        <td className="px-4 py-2">
          <div className="flex items-center gap-1.5">
            {subtypes.length > 1 ? (
              expanded ? <ChevronDown className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
            ) : <span className="w-3.5" />}
            <span className={`text-sm ${hasNeg ? 'text-red-800' : 'text-slate-900'}`} style={{ fontWeight: 600 }}>{label}</span>
          </div>
        </td>
        <td className={`px-4 py-2 text-right text-sm tabular-nums ${valColor}`} style={{ fontWeight: 600 }}>{fmtM(deptTotal.e1)}</td>
        <td className={`px-4 py-2 text-right text-sm tabular-nums ${valColor}`} style={{ fontWeight: 600 }}>{fmtM(deptTotal.e2)}</td>
        <td className={`px-4 py-2 text-right text-sm tabular-nums ${valColor}`} style={{ fontWeight: 600 }}>{fmtM(deptTotal.e3)}</td>
      </tr>
      {expanded && subtypes.map(st => {
        const v = pivot[st];
        const stNeg = v.e1 < 0 || v.e2 < 0 || v.e3 < 0;
        return (
          <tr key={`${deptKey}-${st}`} className="hover:bg-slate-50/50 bg-slate-50/30">
            <td className="py-1.5 pl-12 pr-4 text-xs text-slate-500">{st}</td>
            <td className={`px-4 py-1.5 text-right text-xs tabular-nums ${stNeg ? 'text-red-500' : 'text-slate-500'}`}>{fmtM(v.e1)}</td>
            <td className={`px-4 py-1.5 text-right text-xs tabular-nums ${stNeg ? 'text-red-500' : 'text-slate-500'}`}>{fmtM(v.e2)}</td>
            <td className={`px-4 py-1.5 text-right text-xs tabular-nums ${stNeg ? 'text-red-500' : 'text-slate-500'}`}>{fmtM(v.e3)}</td>
          </tr>
        );
      })}
    </>
  );
}

function DeptTypeBreakdown({ rawData, deriveEventGross }: { rawData: Record<string, any>[]; deriveEventGross: (g: string, m: number) => string }) {
  const parseGross = (s: string): number => {
    if (!s || s === '-' || s === 'NULL') return 0;
    const cleaned = s.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '');
    return Number(cleaned) || 0;
  };

  // Build pivot: departmentMap → subtype → { e1, e2, e3 }
  const pivot: Record<string, Record<string, { e1: number; e2: number; e3: number }>> = {};
  rawData.forEach(row => {
    const dept = row.departmentMap || 'Other';
    const st = row.subtype || 'Other';
    if (!pivot[dept]) pivot[dept] = {};
    if (!pivot[dept][st]) pivot[dept][st] = { e1: 0, e2: 0, e3: 0 };
    pivot[dept][st].e1 += parseGross(row.gross);
    pivot[dept][st].e2 += parseGross(deriveEventGross(row.gross, 0.72));
    pivot[dept][st].e3 += parseGross(deriveEventGross(row.gross, 1.35));
  });

  // Compute grand total
  const grandTotal = { e1: 0, e2: 0, e3: 0 };
  Object.values(pivot).forEach(sub => Object.values(sub).forEach(v => { grandTotal.e1 += v.e1; grandTotal.e2 += v.e2; grandTotal.e3 += v.e3; }));

  const fmtM = (v: number) => {
    const m = v / 1_000_000;
    if (m === 0) return '\u2014';
    const abs = Math.abs(m);
    const s = abs < 0.05 ? abs.toFixed(2) : abs.toFixed(1);
    return m < 0 ? `(${s})` : s;
  };

  const fmtMTotal = (v: number) => {
    const m = v / 1_000_000;
    if (m === 0) return '0.0';
    const abs = Math.abs(m);
    const s = abs < 0.05 ? abs.toFixed(2) : abs.toFixed(1);
    return m < 0 ? `(${s})` : s;
  };

  const eventLabels = [
    { id: '270184630', label: 'Event 1' },
    { id: '270130971', label: 'Event 2' },
    { id: '270025474', label: 'Event 3' },
  ];

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
      <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <div>
          <h3 className="text-sm text-slate-900" style={{ fontWeight: 600 }}>Gross Loss by Business Unit</h3>
          <p className="text-xs text-slate-500 mt-0.5">Aggregated from model output · All Values USDm</p>
        </div>
        <span className="text-[10px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
          {Object.keys(pivot).length} units
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm" style={{ minWidth: '600px' }}>
          <thead>
            <tr className="border-b border-slate-300 bg-slate-100">
              <th className="px-4 py-2.5 text-left text-xs text-slate-600" style={{ fontWeight: 600, width: '40%' }}>Business Unit</th>
              {eventLabels.map(ev => (
                <th key={ev.id} className="px-4 py-2.5 text-right text-xs text-slate-600" style={{ fontWeight: 600, width: '20%' }}>
                  <div>{ev.label}</div>
                  <div className="font-mono text-[10px] text-slate-400" style={{ fontWeight: 400 }}>{ev.id}</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {/* Ordered flat list of departments */}
            {DEPT_FLAT_ORDER.filter(k => pivot[k]).map(deptKey => {
              const subtypes = Object.keys(pivot[deptKey]).sort();
              const deptTotal = { e1: 0, e2: 0, e3: 0 };
              subtypes.forEach(st => { deptTotal.e1 += pivot[deptKey][st].e1; deptTotal.e2 += pivot[deptKey][st].e2; deptTotal.e3 += pivot[deptKey][st].e3; });
              const hasNeg = deptTotal.e1 < 0 || deptTotal.e2 < 0 || deptTotal.e3 < 0;
              return (
                <DeptBreakdownRows
                  key={deptKey}
                  deptKey={deptKey}
                  label={DEPT_DISPLAY_LABELS[deptKey] || deptKey}
                  subtypes={subtypes}
                  pivot={pivot[deptKey]}
                  deptTotal={deptTotal}
                  fmtM={fmtM}
                  isRecovery={hasNeg}
                />
              );
            })}
            {/* Any departments not in the flat order */}
            {Object.keys(pivot).filter(k => !DEPT_FLAT_ORDER.includes(k)).sort().map(deptKey => {
              const subtypes = Object.keys(pivot[deptKey]).sort();
              const deptTotal = { e1: 0, e2: 0, e3: 0 };
              subtypes.forEach(st => { deptTotal.e1 += pivot[deptKey][st].e1; deptTotal.e2 += pivot[deptKey][st].e2; deptTotal.e3 += pivot[deptKey][st].e3; });
              return (
                <DeptBreakdownRows
                  key={deptKey}
                  deptKey={deptKey}
                  label={DEPT_DISPLAY_LABELS[deptKey] || deptKey}
                  subtypes={subtypes}
                  pivot={pivot[deptKey]}
                  deptTotal={deptTotal}
                  fmtM={fmtM}
                />
              );
            })}
            {/* Grand Total */}
            <tr className="bg-slate-800 text-white">
              <td className="px-4 py-3 text-sm" style={{ fontWeight: 700 }}>Grand Total</td>
              <td className="px-4 py-3 text-right text-sm tabular-nums" style={{ fontWeight: 700 }}>{fmtMTotal(grandTotal.e1)}</td>
              <td className="px-4 py-3 text-right text-sm tabular-nums" style={{ fontWeight: 700 }}>{fmtMTotal(grandTotal.e2)}</td>
              <td className="px-4 py-3 text-right text-sm tabular-nums" style={{ fontWeight: 700 }}>{fmtMTotal(grandTotal.e3)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ModelingWorkspace() {
  const { eventId } = useParams();
  const event = mockEvents.find(e => e.id === eventId);
  const { addComment: addCommentToContext, getCommentsByEvent } = useComments();
  const { getWorkflowStatus, getEventStatus } = useWorkflow();
  const [activeTab, setActiveTab] = useState<'overview' | 'by-contract'>('by-contract');
  const [modelingDecision, setModelingDecision] = useState<string | null>('modeled');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [documentType, setDocumentType] = useState('model-output');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    'model-output': true,
    'loss-contract': false,
    'validation': true,
    'notification': true
  });
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, File[]>>({
    'model-output': [],
    'loss-contract': []
  });
  const [dragActive, setDragActive] = useState<Record<string, boolean>>({
    'model-output': false,
    'loss-contract': false
  });
  const [hasUploadedData, setHasUploadedData] = useState(true);
  const [showValidationModal, setShowValidationModal] = useState(false);
  const [invalidContracts, setInvalidContracts] = useState<string[]>([]);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [submissionNote, setSubmissionNote] = useState('');
  const [savedNote, setSavedNote] = useState('');
  const [decisionNote, setDecisionNote] = useState('');
  
  // Comment Modal State
  const [showCommentModal, setShowCommentModal] = useState(false);
  const [commentModalType, setCommentModalType] = useState<'general' | 'submission' | 'modeling-decision'>('general');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [showTeamComments, setShowTeamComments] = useState(false);
  const [requiresDecisionComment, setRequiresDecisionComment] = useState(false);

  // Model version tracking
  interface ModelVersion {
    version: number;
    timestamp: string;
    uploadedBy: string;
    fileName: string;
    contracts: number;
    matchRate: string;
    status: 'current' | 'superseded';
  }
  const [modelVersions, setModelVersions] = useState<ModelVersion[]>([
    { version: 1, timestamp: '2024-11-27T14:32:00.000Z', uploadedBy: 'Cat Modeling Team', fileName: 'Milton_CAT_Model_Output_v1.xlsx', contracts: 287, matchRate: '96.0%', status: 'current' }
  ]);

  // GrossLossTable now handles its own deferred mounting internally

  const tabs = [
    { id: 'overview', name: 'Overview' },
    { id: 'by-contract', name: 'Modeling Input' }
  ];

  // Auto-open upload modal when "Modeled" is selected
  useEffect(() => {
    if ((modelingDecision === 'modeled' || modelingDecision === 'modeled-no-loss') && !hasUploadedData) {
      setShowUploadModal(true);
    }
  }, [modelingDecision]);

  const handleUploadClick = () => {
    setShowUploadModal(true);
  };

  const handleUpload = () => {
    toast.success('Model output uploaded successfully');
  };

  const handleLockEstimates = () => {
    // Validate that non-modeled decisions have a required explanation comment
    if (modelingDecision === 'no-impact' || modelingDecision === 'cannot-model') {
      const hasDecisionComment = getCommentsByEvent(eventId || '1')
        .some(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling');
      
      if (!hasDecisionComment) {
        toast.error('Explanation Required', {
          description: 'Please provide an explanation for this modeling decision before locking.'
        });
        return;
      }
    }
    
    setCommentModalType('submission');
    setShowCommentModal(true);
  };
  
  // Handle comment submission
  const handleCommentSubmit = (comment: string, files: string[], isInternal: boolean) => {
    setIsSubmittingComment(true);

    if (commentModalType === 'submission') {
      // This is a submission comment
      setSavedNote(comment);

      // Create notification for Management
      const notification = {
        id: `modeling-${eventId}-${Date.now()}`,
        eventId,
        eventName: event?.name || 'Event',
        recipient: 'Management Team',
        submittedBy: 'Cat Modeling Team',
        type: 'modeling-submission',
        message: 'CAT Modeling results have been submitted for review.',
        note: comment,
        modelingRange: '$2.1B - $6.2B',
        totalContracts: '812 contracts',
        matchRate: '95.9%',
        submittedAt: new Date().toISOString(),
        status: 'pending-management-review',
        read: false
      };

      // Store in sessionStorage
      const existingNotifications = JSON.parse(sessionStorage.getItem('modelingNotifications') || '[]');
      sessionStorage.setItem('modelingNotifications', JSON.stringify([...existingNotifications, notification]));

      // Add comment to context
      addCommentToContext({
        eventId: eventId || '1',
        team: 'modeling',
        author: 'Cat Modeling Team',
        authorRole: 'CAT Modeling Team Lead',
        text: comment,
        files: files.length > 0 ? files : undefined,
        type: 'submission',
        isInternal,
        workflowStage: 'modeling',
      });

      setIsSubmitted(true);
      setSubmissionNote('');
      
      toast.success('Modeling estimates locked', {
        description: '📧 Management notified with final output figures'
      });
    } else if (commentModalType === 'modeling-decision') {
      // This is a modeling decision explanation (REQUIRED for no-impact, cannot-model)
      addCommentToContext({
        eventId: eventId || '1',
        team: 'modeling',
        author: 'Cat Modeling Team',
        authorRole: 'CAT Modeling Team Lead',
        text: comment,
        files: files.length > 0 ? files : undefined,
        type: 'modeling-decision',
        isInternal,
        workflowStage: 'modeling',
      });

      setRequiresDecisionComment(false);
      toast.success('Modeling decision explanation saved', {
        description: 'This explanation is visible across all workflows'
      });
    } else {
      // This is a general comment
      addCommentToContext({
        eventId: eventId || '1',
        team: 'modeling',
        author: 'Cat Modeling Team',
        authorRole: 'CAT Modeling Team Lead',
        text: comment,
        files: files.length > 0 ? files : undefined,
        type: 'general',
        isInternal,
        workflowStage: 'modeling',
      });

      toast.success('Comment added successfully');
    }

    setIsSubmittingComment(false);
    setShowCommentModal(false);
  };

  const handleConfirmSubmit = () => {
    // Save the note
    setSavedNote(submissionNote);

    // Create notification for Management
    const notification = {
      id: `modeling-${eventId}-${Date.now()}`,
      eventId,
      eventName: 'Hurricane Milton', // In real app, get from context/props
      recipient: 'Management Team',
      submittedBy: 'Cat Modeling Team',
      type: 'modeling-submission',
      message: 'CAT Modeling results have been submitted for review.',
      note: submissionNote,
      modelingRange: '$2.1B - $6.2B',
      totalContracts: '812 contracts',
      matchRate: '95.9%',
      submittedAt: new Date().toISOString(),
      status: 'pending-management-review',
      read: false
    };

    // Store in sessionStorage
    const existingNotifications = JSON.parse(sessionStorage.getItem('modelingNotifications') || '[]');
    sessionStorage.setItem('modelingNotifications', JSON.stringify([...existingNotifications, notification]));

    // Update state
    setIsSubmitted(true);
    setShowNoteModal(false);
    
    toast.success('Modeling Results Submitted', {
      description: 'Management team has been notified and will review the analysis.'
    });
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleFileUpload = (section: string, files: FileList | File[] | null) => {
    if (!files) return;
    
    const fileArray = Array.from(files);
    const maxFiles = 3;
    
    if (fileArray.length > maxFiles) {
      toast.error(`Maximum ${maxFiles} files allowed per section`);
      return;
    }
    
    setUploadedFiles(prev => ({
      ...prev,
      [section]: [...prev[section], ...fileArray].slice(0, maxFiles)
    }));
    
    toast.success(`${fileArray.length} file(s) uploaded to ${section.replace('-', ' ')}`);
  };

  const handleRemoveFile = (section: string, index: number) => {
    setUploadedFiles(prev => ({
      ...prev,
      [section]: prev[section].filter((_, i) => i !== index)
    }));
  };

  const handleDrag = (section: string, e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(prev => ({ ...prev, [section]: true }));
    } else if (e.type === "dragleave") {
      setDragActive(prev => ({ ...prev, [section]: false }));
    }
  };

  const handleDrop = (section: string, e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(prev => ({ ...prev, [section]: false }));
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(section, e.dataTransfer.files);
    }
  };

  const handleCompleteUpload = () => {
    // Check if required files are uploaded
    if (uploadedFiles['loss-contract'].length === 0) {
      toast.error('Please upload the required Model Output Excel file');
      return;
    }

    // Simulate validation - check for contracts not in RDM
    const contractsNotInRDM = ['TP-2024-213-290', 'TP-2024-ACG-818'];
    
    if (contractsNotInRDM.length > 0) {
      setInvalidContracts(contractsNotInRDM);
      setShowUploadModal(false);
      setShowValidationModal(true);
    } else {
      // No validation issues, proceed
      setModelingDecision('modeled');
      setHasUploadedData(true);
      setShowUploadModal(false);
      const nextVersion = modelVersions.length + 1;
      const fileName = uploadedFiles['loss-contract'][0]?.name || 'model_output.xlsx';
      setModelVersions(prev => [
        ...prev.map(v => ({ ...v, status: 'superseded' as const })),
        { version: nextVersion, timestamp: new Date().toISOString(), uploadedBy: 'Cat Modeling Team', fileName, contracts: 287, matchRate: '96.0%', status: 'current' as const }
      ]);
      toast.success('Model output files uploaded successfully');
    }
  };

  const handleAcceptValidation = () => {
    setModelingDecision('modeled');
    setHasUploadedData(true);
    setShowValidationModal(false);
    const nextVersion = modelVersions.length + 1;
    const fileName = uploadedFiles['loss-contract'][0]?.name || 'model_output.xlsx';
    setModelVersions(prev => [
      ...prev.map(v => ({ ...v, status: 'superseded' as const })),
      { version: nextVersion, timestamp: new Date().toISOString(), uploadedBy: 'Cat Modeling Team', fileName, contracts: 287, matchRate: '96.0%', status: 'current' as const }
    ]);
    toast.success('Model output files uploaded successfully with warnings');
  };

  const handleReupload = () => {
    setShowValidationModal(false);
    setInvalidContracts([]);
    setUploadedFiles({
      'model-output': [],
      'loss-contract': []
    });
    setShowUploadModal(true);
    toast.info('Please upload corrected files');
  };

  if (!event) {
    return <div className="p-8 text-slate-500">Event not found</div>;
  }

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Header */}
      <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event.eventName}</h1>
                <h1 className="text-slate-600">- Modeling</h1>
                {/* Phase badge */}
                {(() => {
                  const phase = getWorkflowStatus(eventId || '').currentPhase;
                  const phaseBadge: Record<string, string> = {
                    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
                    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
                    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
                    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'Reopened': 'bg-red-50 text-red-700 border-red-200',
                  };
                  const phaseDisplayLabels: Record<string, string> = {
                    'Event Creation': 'Event Creation',
                    'Monitoring': 'Monitoring',
                    'Estimation & Approval': 'UW Estimation',
                    'Finance Review': 'Finance Review',
                    'Reporting & Close': 'Reporting & Close',
                    'Reopened': 'Reopened',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${phaseBadge[phase] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {phaseDisplayLabels[phase] || phase}
                    </span>
                  );
                })()}
                {/* Status badge */}
                {(() => {
                  const status = getEventStatus(eventId || '');
                  const statusBadge: Record<string, string> = {
                    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
                    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
                    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
                    'Reopened': 'bg-red-50 text-red-700 border-red-300',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {status}
                    </span>
                  );
                })()}
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Type of Everest Event:</span>
                  <span className="text-slate-900">{event.everestEventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Type:</span>
                  <span className="text-slate-900">{event.eventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Sub-Type:</span>
                  <span className="text-slate-900">{event.eventSubType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      {/* Tabs + Action Buttons */}
      <div className="bg-white border-b border-slate-200 px-8">
        <div className="flex gap-6 items-center">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3.5 pt-2 px-4 border-b-2 transition-all ${
                activeTab === tab.id 
                  ? 'border-everest-blue text-midnight-blue bg-blue-50/50 font-medium' 
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.name}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2 py-1.5">
            <button
              onClick={() => {
                const headers = [
                  'Layerkey',
                  'Department',
                  'Company',
                  'Subtype',
                  'Contract',
                  'Event',
                  'Everest Limit',
                  '100% Limit',
                  'Retention',
                  'Agg Deductible',
                  'Terms',
                  'ROL',
                  'Share',
                  'Gross Loss',
                  'Net of Logan',
                  'Net of All Cessions',
                  'Expected RIPs',
                ].join(',');
                const sampleRows = [
                  '406867,Treaty Property,TP25 Westfield QS Layers,PR,TP10021335-2025-1,Event 1,13500000,225000000,-,-,PR: 225x0,1,0,1815185,1815185,1815185,-',
                  '416633,Treaty Property,TP25 MS Transverse Apex One,CAT,TP10022377-2025-1,Event 1,5550000,30000000,10000000,-,CAT: 30x10,1,0,4311655,3243278,3243278,1945965',
                  '106,Bermuda,BM25 Example QS,PR,BM10021335-2025-1,Event 2,8000000,100000000,-,-,PR: 100x0,1,0,950000,950000,950000,-',
                ];
                const csvContent = [headers, ...sampleRows].join('\n');
                const blob = new Blob([csvContent], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `Modeling_Template_${event?.id || 'Event'}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                toast.success('Modeling template downloaded successfully');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-all shadow-sm text-sm"
            >
              <Download className="w-3 h-3" />
              Download Template
            </button>
            <button
              onClick={handleUploadClick}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              Import
            </button>
            {!isSubmitted ? (
              <button
                onClick={handleLockEstimates}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-everest-blue text-white rounded-lg hover:bg-[#0041CC] transition-all shadow-sm hover:shadow text-sm"
              >
                <Lock className="w-3 h-3" />
                Complete Analysis
              </button>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-200 text-sm">
                <Lock className="w-3 h-3" />
                <span className="font-medium">Analysis Complete</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto px-8 pb-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">

            {/* Scenario Summary - only after upload */}
            {hasUploadedData && <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
              <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                <div>
                  <h3 className="text-sm text-slate-900" style={{ fontWeight: 600 }}>Summary</h3>
                  <p className="text-xs text-slate-500 mt-0.5">As-Of 10/1/2024 · All Values USDm</p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/50">
                      <th className="px-4 py-2.5 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Event ID</th>
                      <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Industry Loss (USDm)</th>
                      <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Everest Gross</th>
                      <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Gross Market Share</th>
                      <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Everest Net*</th>
                      <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Net Market Share</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[
                      { eventId: '270184630', maxWind: 119.8, location: 'Manatee, FL', industryLoss: '18,411', gross: 437.8, grossShare: '2.4%', net: 304.6, netShare: '1.7%' },
                      { eventId: '270130971', maxWind: 106.2, location: 'Manatee, FL', industryLoss: '27,550', gross: 672.1, grossShare: '2.4%', net: 446.8, netShare: '1.6%' },
                      { eventId: '270025474', maxWind: 125.4, location: 'Sarasota, FL', industryLoss: '36,607', gross: 934.3, grossShare: '2.6%', net: 622.2, netShare: '1.7%' },
                    ].map(row => (
                      <tr key={row.eventId} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-2.5 text-slate-800 font-mono" style={{ fontWeight: 500 }}>{row.eventId}</td>
                        <td className="px-4 py-2.5 text-right text-slate-800" style={{ fontWeight: 600 }}>{row.industryLoss}</td>
                        <td className="px-4 py-2.5 text-right text-slate-800" style={{ fontWeight: 600 }}>{row.gross.toFixed(1)}</td>
                        <td className="px-4 py-2.5 text-right text-slate-600">{row.grossShare}</td>
                        <td className="px-4 py-2.5 text-right" style={{ color: '#0052FF', fontWeight: 600 }}>{row.net.toFixed(1)}</td>
                        <td className="px-4 py-2.5 text-right text-slate-600">{row.netShare}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-2 border-t border-slate-100 bg-slate-50/50">
                <span className="text-[10px] text-slate-400">*Net = net of all cessions including Logan Re</span>
              </div>
            </div>}

            {/* Modeling Decisions */}
            <div className="bg-white rounded-lg border border-slate-200 p-6">
              <h3 className="mb-4">Modeling Decisions</h3>
              <div className="flex flex-wrap gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="modelingDecision"
                    value="modeled"
                    checked={modelingDecision === 'modeled'}
                    onChange={(e) => setModelingDecision(e.target.value)}
                    className="w-4 h-4 text-everest-blue"
                  />
                  <span className="text-sm text-slate-700">Modeled</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="modelingDecision"
                    value="modeled-no-loss"
                    checked={modelingDecision === 'modeled-no-loss'}
                    onChange={(e) => setModelingDecision(e.target.value)}
                    className="w-4 h-4 text-everest-blue"
                  />
                  <span className="text-sm text-slate-700">Modeled Peril But No Modeled Loss Estimates</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="modelingDecision"
                    value="no-impact"
                    checked={modelingDecision === 'no-impact'}
                    onChange={(e) => setModelingDecision(e.target.value)}
                    className="w-4 h-4 text-everest-blue"
                  />
                  <span className="text-sm text-slate-700">No Modeling Impact</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="modelingDecision"
                    value="cannot-model"
                    checked={modelingDecision === 'cannot-model'}
                    onChange={(e) => setModelingDecision(e.target.value)}
                    className="w-4 h-4 text-everest-blue"
                  />
                  <span className="text-sm text-slate-700">No Model Available</span>
                </label>
              </div>
            </div>

            {/* Comment/Rationale Section for non-modeled decisions */}
            {(modelingDecision === 'no-impact' || modelingDecision === 'cannot-model') && (
              <div className="bg-white rounded-lg border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-sm text-slate-700">
                    Explanation / Rationale<span className="text-red-500 ml-1">*</span>
                  </label>
                  <span className="text-xs text-slate-500">Required for non-modeled decisions</span>
                </div>
                
                {/* Show decision-specific comments */}
                {getCommentsByEvent(eventId || '1')
                  .filter(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling')
                  .length > 0 ? (
                  <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="text-sm text-green-900 mb-2">
                          {getCommentsByEvent(eventId || '1')
                            .filter(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling')[0]?.text}
                        </div>
                        <div className="flex items-center gap-4 text-xs text-green-700">
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {getCommentsByEvent(eventId || '1')
                              .filter(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling')[0]?.author}
                          </span>
                          <span>
                            {new Date(getCommentsByEvent(eventId || '1')
                              .filter(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling')[0]?.timestamp).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg mb-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="text-sm text-amber-900">
                        {modelingDecision === 'no-impact' 
                          ? "Please explain why this event has no modeling impact (e.g., below materiality threshold, no treaty impact expected)"
                          : modelingDecision === 'cannot-model'
                          ? "Please explain why this event cannot be modeled (e.g., data limitations, event complexity, insufficient exposure data)"
                          : "Please explain why modeling is not possible for this event type (e.g., peril not supported by available platforms, no vendor model available)"}
                      </div>
                    </div>
                  </div>
                )}
                
                <button
                  onClick={() => {
                    setCommentModalType('modeling-decision');
                    setShowCommentModal(true);
                  }}
                  className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  {getCommentsByEvent(eventId || '1')
                    .filter(c => c.type === 'modeling-decision' && c.workflowStage === 'modeling')
                    .length > 0 ? 'Update Explanation' : 'Add Required Explanation'}
                </button>
              </div>
            )}



            {/* Model Output Versions */}
            {hasUploadedData && modelVersions.length > 0 && (
              <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex items-center gap-2">
                  <History className="w-4 h-4 text-slate-500" />
                  <h3 className="text-sm text-slate-900" style={{ fontWeight: 600 }}>Model Output Versions</h3>
                  <span className="ml-auto text-xs text-slate-400">{modelVersions.length} version{modelVersions.length !== 1 ? 's' : ''}</span>
                </div>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/50">
                      <th className="px-4 py-2 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Version</th>
                      <th className="px-4 py-2 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>File</th>
                      <th className="px-4 py-2 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Uploaded By</th>
                      <th className="px-4 py-2 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Timestamp</th>
                      <th className="px-4 py-2 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Contracts</th>
                      <th className="px-4 py-2 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Match Rate</th>
                      <th className="px-4 py-2 text-center text-xs text-slate-500" style={{ fontWeight: 500 }}>Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[...modelVersions].reverse().map(v => (
                      <tr key={v.version} className={`hover:bg-slate-50 transition-colors ${v.status === 'superseded' ? 'opacity-50' : ''}`}>
                        <td className="px-4 py-2.5 text-slate-800" style={{ fontWeight: 500 }}>v{v.version}</td>
                        <td className="px-4 py-2.5 text-slate-700 font-mono text-xs">{v.fileName}</td>
                        <td className="px-4 py-2.5 text-slate-700">{v.uploadedBy}</td>
                        <td className="px-4 py-2.5 text-slate-600 text-xs">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(v.timestamp).toLocaleString()}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-right text-slate-700">{v.contracts}</td>
                        <td className="px-4 py-2.5 text-right text-slate-700">{v.matchRate}</td>
                        <td className="px-4 py-2.5 text-center">
                          {v.status === 'current' ? (
                            <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                              <CheckCircle2 className="w-3 h-3" /> Current
                            </span>
                          ) : (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-500">Superseded</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Submission Note */}
            {savedNote && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <div className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h3 className="text-blue-900 mb-2">Submission Note to Management</h3>
                    <p className="text-sm text-blue-800 whitespace-pre-wrap">{savedNote}</p>
                    <div className="text-xs text-blue-600 mt-2">
                      Submitted by CAT Modeling Team • {new Date().toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Gross Loss by Department and Type */}
            {hasUploadedData && <DeptTypeBreakdown rawData={_rawLossByContractData} deriveEventGross={_deriveEventGross} />}
          </div>
        )}

        {/* Gross Loss by Contract Tab */}
        {activeTab === 'by-contract' && (
          <div className="space-y-3">
            {/* Table */}
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
              <div className="px-4 py-2 border-b border-slate-200 bg-white">
                <span className="text-sm text-slate-600">All Values <span className="font-semibold text-slate-800">USDm</span></span>
              </div>
              <Suspense fallback={
                <div className="w-full">
                  <div className="flex items-center border-b border-slate-200 bg-slate-50 px-3 py-2 gap-4">
                    {['#','Layerkey','Department','Company','Subtype','Contract','Everest Limit','100% Limit','Retention','Event 1'].map(h => (
                      <div key={h} className="text-[0.7rem] font-semibold uppercase text-slate-500 whitespace-nowrap">{h}</div>
                    ))}
                  </div>
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-4 px-3 py-2.5 border-b border-slate-100">
                      {Array.from({ length: 10 }).map((_, j) => (
                        <div key={j} className="h-3.5 rounded bg-slate-200 animate-pulse" style={{ width: `${50 + (j * 12) % 70}px` }} />
                      ))}
                    </div>
                  ))}
                  <div className="flex items-center justify-center py-6 text-sm text-slate-400">Loading table data…</div>
                </div>
              }>
                <LazyGrossLossTable
                  data={lossByContractData}
                  invalidContracts={invalidContracts}
                  eventNames={['Event 1', 'Event 2', 'Event 3']}
                />
              </Suspense>
            </div>
          </div>
        )}

      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4" style={{ backgroundColor: 'rgba(248, 250, 252, 0.85)' }}>
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-auto">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-xl font-semibold text-gray-900">Upload Model Output</h2>
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="text-sm text-gray-500">
                Please upload one or more output files from RH Command
              </p>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Document Type */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Document Type <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="documentType"
                      value="model-output"
                      checked={documentType === 'model-output'}
                      onChange={(e) => setDocumentType(e.target.value)}
                      className="w-4 h-4 text-blue-600"
                    />
                    <span className="text-sm text-gray-900">Model Output</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="documentType"
                      value="supporting"
                      checked={documentType === 'supporting'}
                      onChange={(e) => setDocumentType(e.target.value)}
                      className="w-4 h-4 text-blue-600"
                    />
                    <span className="text-sm text-gray-900">Supporting Document</span>
                  </label>
                </div>
              </div>

              {/* Gross Loss by Contract - Collapsible */}
              <div className="border border-gray-200 rounded-lg">
                <button
                  onClick={() => toggleSection('loss-contract')}
                  className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    {expandedSections['loss-contract'] ? (
                      <ChevronDown className="w-4 h-4 text-gray-600" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-gray-600" />
                    )}
                    <input
                      type="checkbox"
                      checked={expandedSections['loss-contract']}
                      readOnly
                      className="w-4 h-4 text-blue-600"
                    />
                    <span className="font-medium text-gray-900">Model Output Excel</span>
                  </div>
                  <span className="text-xs text-gray-500">Required</span>
                </button>
                {expandedSections['loss-contract'] && (
                  <div className="p-4 border-t border-gray-200 bg-gray-50">
                    <p className="text-sm text-gray-600 mb-3">
                      Upload model output Excel file containing <span className="font-medium text-gray-800">Gross Loss by Contract</span> data • Max 3 files
                    </p>
                    <div 
                      className={`border-2 border-dashed rounded-lg p-6 text-center bg-white transition-all cursor-pointer ${
                        dragActive['loss-contract'] 
                          ? 'border-blue-500 bg-blue-50' 
                          : 'border-gray-300 hover:border-blue-500'
                      }`}
                      onDragEnter={(e) => handleDrag('loss-contract', e)}
                      onDragLeave={(e) => handleDrag('loss-contract', e)}
                      onDragOver={(e) => handleDrag('loss-contract', e)}
                      onDrop={(e) => handleDrop('loss-contract', e)}
                    >
                      <input
                        type="file"
                        id="loss-contract-upload"
                        accept=".xlsx,.xls,.csv"
                        multiple
                        onChange={(e) => handleFileUpload('loss-contract', e.target.files)}
                        className="hidden"
                      />
                      <label htmlFor="loss-contract-upload" className="cursor-pointer">
                        {uploadedFiles['loss-contract'].length > 0 ? (
                          <div className="space-y-2">
                            {uploadedFiles['loss-contract'].map((file, index) => (
                              <div key={index} className="flex items-center justify-between gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded">
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                                  <span className="text-sm font-medium text-green-700 truncate">{file.name}</span>
                                  <span className="text-xs text-green-600">({(file.size / 1024).toFixed(1)}KB)</span>
                                </div>
                                <button
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handleRemoveFile('loss-contract', index);
                                  }}
                                  className="text-green-600 hover:text-red-600 transition-colors flex-shrink-0"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ))}
                            {uploadedFiles['loss-contract'].length < 3 && (
                              <p className="text-xs text-gray-500 mt-2">Click or drag to add more files ({3 - uploadedFiles['loss-contract'].length} remaining)</p>
                            )}
                          </div>
                        ) : (
                          <>
                            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-600 mb-1">Drag & drop files here or click to browse</p>
                            <p className="text-xs text-gray-500">Supports .xlsx, .xls, .csv (up to 3 files)</p>
                          </>
                        )}
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* Build File Upload Support - Collapsible */}
              <div className="border border-gray-200 rounded-lg">
                <button
                  onClick={() => toggleSection('model-output')}
                  className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    {expandedSections['model-output'] ? (
                      <ChevronDown className="w-4 h-4 text-gray-600" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-gray-600" />
                    )}
                    <span className="font-medium text-gray-900">Build File Upload Support</span>
                  </div>
                  <span className="text-xs text-gray-500">Optional</span>
                </button>
                {expandedSections['model-output'] && (
                  <div className="p-4 border-t border-gray-200 bg-gray-50">
                    <p className="text-sm text-gray-600 mb-3">
                      How the tool will comprehend, track by harvest measures, scan for malware and demonstrate on <span className="text-blue-600">Model Limit Details</span> section. Identify Limit currency discrepancy between the contract and the modeled results. • Max 3 files
                    </p>
                    <div 
                      className={`border-2 border-dashed rounded-lg p-6 text-center bg-white transition-all cursor-pointer ${
                        dragActive['model-output'] 
                          ? 'border-blue-500 bg-blue-50' 
                          : 'border-gray-300 hover:border-blue-500'
                      }`}
                      onDragEnter={(e) => handleDrag('model-output', e)}
                      onDragLeave={(e) => handleDrag('model-output', e)}
                      onDragOver={(e) => handleDrag('model-output', e)}
                      onDrop={(e) => handleDrop('model-output', e)}
                    >
                      <input
                        type="file"
                        id="model-output-upload"
                        accept=".xlsx,.xls,.csv"
                        multiple
                        onChange={(e) => handleFileUpload('model-output', e.target.files)}
                        className="hidden"
                      />
                      <label htmlFor="model-output-upload" className="cursor-pointer">
                        {uploadedFiles['model-output'].length > 0 ? (
                          <div className="space-y-2">
                            {uploadedFiles['model-output'].map((file, index) => (
                              <div key={index} className="flex items-center justify-between gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded">
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                                  <span className="text-sm font-medium text-green-700 truncate">{file.name}</span>
                                  <span className="text-xs text-green-600">({(file.size / 1024).toFixed(1)}KB)</span>
                                </div>
                                <button
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handleRemoveFile('model-output', index);
                                  }}
                                  className="text-green-600 hover:text-red-600 transition-colors flex-shrink-0"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ))}
                            {uploadedFiles['model-output'].length < 3 && (
                              <p className="text-xs text-gray-500 mt-2">Click or drag to add more files ({3 - uploadedFiles['model-output'].length} remaining)</p>
                            )}
                          </div>
                        ) : (
                          <>
                            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-600 mb-1">Drag & drop files here or click to browse</p>
                            <p className="text-xs text-gray-500">Supports .xlsx, .xls, .csv (up to 3 files)</p>
                          </>
                        )}
                      </label>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-xl flex items-center justify-between">
              <button
                onClick={() => setShowUploadModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleCompleteUpload}
                disabled={!uploadedFiles['loss-contract']}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Upload className="w-3.5 h-3.5" />
                Complete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Validation Modal */}
      {showValidationModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4" style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-amber-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    Validation Warnings
                  </h3>
                  <p className="text-sm text-gray-600">
                    Some contract numbers do not exist in RDM and are highlighted in red. You can still proceed, but these contracts may need review.
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-amber-900 mb-1">
                      {invalidContracts.length} contract{invalidContracts.length !== 1 ? 's' : ''} not found in RDM
                    </p>
                    <p className="text-xs text-amber-700">
                      These contracts may require additional verification before final submission.
                    </p>
                  </div>
                </div>
              </div>

              {/* Invalid Contracts List */}
              <div className="border border-red-200 rounded-lg overflow-hidden">
                <div className="bg-red-50 px-4 py-2 border-b border-red-200">
                  <p className="text-sm font-semibold text-red-900">Contracts Not Found in RDM</p>
                </div>
                <div className="max-h-60 overflow-y-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200 sticky top-0">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                          Contract Number
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-red-100">
                      {invalidContracts.map((contract, index) => (
                        <tr key={index} className="bg-white hover:bg-red-50 transition-colors">
                          <td className="px-4 py-3 text-sm font-medium text-red-700">
                            {contract}
                          </td>
                          <td className="px-4 py-3">
                            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded bg-red-100 text-red-700">
                              <XCircle className="w-3 h-3" />
                              Not Found in RDM
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-800">
                  <strong>Note:</strong> You can accept and continue with these warnings, or re-upload the file with corrected contract numbers.
                </p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-xl flex items-center justify-between">
              <button
                onClick={handleReupload}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Upload className="w-3.5 h-3.5" />
                Re-import
              </button>
              <button
                onClick={handleAcceptValidation}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Monitor
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Note Modal for Submission */}
      {showNoteModal && (
        <div 
          className="fixed inset-0 bg-slate-900 bg-opacity-20 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
          onClick={() => setShowNoteModal(false)}
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 rounded-t-2xl">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-6 h-6" />
                <h2 className="text-xl font-semibold">Add Submission Note</h2>
              </div>
            </div>

            <div className="p-6">
              <p className="text-slate-700 mb-4">
                Add a note to provide context for management regarding this modeling submission:
              </p>
              <textarea
                value={submissionNote}
                onChange={(e) => setSubmissionNote(e.target.value)}
                placeholder="Enter your note here... (optional)"
                className="w-full h-40 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              />
              <p className="text-xs text-slate-500 mt-2">
                This note will be visible to the management team along with your modeling submission.
              </p>
            </div>

            <div className="bg-slate-50 px-6 py-4 rounded-b-2xl border-t border-slate-200 flex justify-end gap-2">
              <button
                onClick={() => setShowNoteModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                Send to Management
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comment Modal */}
      <CommentModal
        isOpen={showCommentModal}
        onClose={() => setShowCommentModal(false)}
        onSubmit={handleCommentSubmit}
        title={
          commentModalType === 'submission' 
            ? 'Lock Estimates' 
            : commentModalType === 'modeling-decision'
            ? 'Required Modeling Decision Explanation'
            : 'Add Comment'
        }
        placeholder={
          commentModalType === 'submission' 
            ? 'Add notes for management with your locked estimates...' 
            : commentModalType === 'modeling-decision'
            ? modelingDecision === 'no-impact' 
              ? "Explain why this event has no modeling impact (e.g., below materiality threshold, no treaty impact expected)..."
              : modelingDecision === 'cannot-model'
              ? "Explain why this event cannot be modeled (e.g., data limitations, event complexity, insufficient exposure data)..."
              : "Explain why modeling is not possible for this event type (e.g., peril not supported by available platforms, no vendor model available)..."
            : 'Enter your comment or notes...'
        }
        submitLabel={
          commentModalType === 'submission' 
            ? 'Lock & Notify Management' 
            : commentModalType === 'modeling-decision'
            ? 'Save Explanation'
            : 'Post Comment'
        }
        isSubmitting={isSubmittingComment}
        allowInternalToggle={commentModalType !== 'modeling-decision'}
      />

      {/* All Event Comments Sidebar - Shows ALL comments from all workflows */}
      {showTeamComments && (
        <div className="fixed inset-0 z-50 flex items-end justify-end">
          <div 
            className="absolute inset-0 bg-black/20 backdrop-blur-sm"
            onClick={() => setShowTeamComments(false)}
          ></div>
          <div className="relative w-full max-w-md h-full bg-white shadow-2xl flex flex-col">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">Event Comments</h3>
                  <p className="text-sm text-gray-600 mt-0.5">
                    All Workflow Comments & Activity
                  </p>
                </div>
                <button
                  onClick={() => setShowTeamComments(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Comments List */}
            <div className="flex-1 overflow-y-auto p-6">
              {getCommentsByEvent(eventId || '1').length > 0 ? (
                <CommentThread 
                  comments={getCommentsByEvent(eventId || '1')}
                  showTeamBadge={true}
                />
              ) : (
                <div className="text-center py-12">
                  <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">No comments yet</p>
                  <p className="text-sm text-gray-500">
                    All event comments will appear here
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
              <button
                onClick={() => {
                  setShowTeamComments(false);
                  setCommentModalType('general');
                  setShowCommentModal(true);
                }}
                className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                Add New Comment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}