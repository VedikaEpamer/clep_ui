import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Filter, ArrowUpDown, Info } from 'lucide-react';

// ── Types ────────────────────────────────────────────────────────────
interface SubRow {
  type: string;
  values: (number | null)[];
}

interface DepartmentRow {
  department: string;
  totals: (number | null)[];
  subRows: SubRow[];
}

// ── Static scenario data ─────────────────────────────────────────────
const SCENARIOS = [
  { eventId: '270184630', maxWind: 119.8, location: 'Manatee, FL', industryLoss: '18,411', gross: 437.8, grossShare: '2.4%', net: 304.6, netShare: '1.7%' },
  { eventId: '270130971', maxWind: 106.2, location: 'Manatee, FL', industryLoss: '27,550', gross: 672.1, grossShare: '2.4%', net: 446.8, netShare: '1.6%' },
  { eventId: '270025474', maxWind: 125.4, location: 'Sarasota, FL', industryLoss: '36,607', gross: 934.3, grossShare: '2.6%', net: 622.2, netShare: '1.7%' },
];

// ── Static department data ───────────────────────────────────────────
const EVENT_IDS = ['270184630', '270130971', '270025474'];

const DEPARTMENT_DATA: DepartmentRow[] = [
  {
    department: 'Bermuda',
    totals: [23.4, 27.7, 42.1],
    subRows: [
      { type: 'CAT', values: [null, 0.2, 0.3] },
      { type: 'PR', values: [23.3, 27.4, 41.6] },
      { type: 'RSK', values: [0.1, 0.2, 0.2] },
    ],
  },
  {
    department: 'Canada',
    totals: [0.2, 0.0, 0.0],
    subRows: [
      { type: 'PR', values: [0.2, 0.0, 0.0] },
      { type: 'RSK', values: [0.0, 0.0, 0.0] },
    ],
  },
  {
    department: 'Dublin',
    totals: [0.4, 0.1, 1.5],
    subRows: [
      { type: 'PR', values: [0.4, 0.1, 1.5] },
    ],
  },
  {
    department: 'EI Recovery^',
    totals: [0.0, 0.0, 0.0],
    subRows: [
      { type: 'PR', values: [0.0, 0.0, 0.0] },
      { type: 'RSK', values: [0.0, 0.0, 0.0] },
    ],
  },
  {
    department: 'FP',
    totals: [7.4, 13.1, 17.2],
    subRows: [
      { type: 'CAT', values: [0.4, null, 2.0] },
      { type: 'PR', values: [2.8, 5.4, 6.2] },
      { type: 'RSK', values: [4.2, 7.7, 9.1] },
    ],
  },
  {
    department: 'Insurance',
    totals: [49.8, 73.9, 83.7],
    subRows: [
      { type: 'PR', values: [49.8, 73.9, 83.7] },
    ],
  },
  {
    department: 'London',
    totals: [1.4, 1.5, 2.4],
    subRows: [
      { type: 'PR', values: [1.4, 1.5, 2.4] },
    ],
  },
  {
    department: 'Marine',
    totals: [null, null, 3.5],
    subRows: [
      { type: 'PR', values: [null, null, 3.5] },
    ],
  },
  {
    department: 'MEA',
    totals: [0.3, 0.0, 0.7],
    subRows: [
      { type: 'PR', values: [0.3, 0.0, 0.7] },
    ],
  },
  {
    department: 'Miami',
    totals: [null, null, 2.1],
    subRows: [
      { type: 'PR', values: [null, null, 2.1] },
    ],
  },
  {
    department: 'Singapore',
    totals: [null, null, 0.0],
    subRows: [
      { type: 'PR', values: [null, null, 0.0] },
      { type: 'RSK', values: [null, null, 0.0] },
    ],
  },
  {
    department: 'TP',
    totals: [284.6, 467.9, 692.4],
    subRows: [
      { type: 'AGG', values: [null, 0.8, 3.6] },
      { type: 'CAT', values: [222.7, 386.5, 569.2] },
      { type: 'ILW', values: [null, null, 14.4] },
      { type: 'PR', values: [54.4, 64.1, 77.4] },
      { type: 'RPP', values: [5.8, 14.9, 22.2] },
      { type: 'RSK', values: [1.7, 1.6, 5.6] },
    ],
  },
  {
    department: 'AF',
    totals: [0.0, 0.0, 0.0],
    subRows: [
      { type: 'PR', values: [0.0, 0.0, 0.0] },
    ],
  },
  {
    department: 'Parametric Solutions',
    totals: [70.2, 87.8, 88.7],
    subRows: [
      { type: 'AGG', values: [null, null, 0.6] },
      { type: 'ILW', values: [70.0, 87.5, 87.5] },
      { type: 'PR', values: [0.2, 0.3, 0.6] },
    ],
  },
];

const GRAND_TOTAL: (number | null)[] = [437.8, 672.1, 934.3];

// ── Format helpers ───────────────────────────────────────────────────
function fmtVal(v: number | null): string {
  if (v === null) return '';
  return v.toFixed(1);
}

// ── Component ────────────────────────────────────────────────────────
export interface ModelingTabProps {
  eventName?: string;
}

export function ModelingTab({ eventName }: ModelingTabProps) {
  // Modeling decision state
  const [modelingDecision, setModelingDecision] = useState<string>('modeled');

  // Track which departments are expanded (all expanded by default)
  const [expanded, setExpanded] = useState<Set<string>>(
    () => new Set(DEPARTMENT_DATA.map((d) => d.department))
  );

  const toggle = (dept: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(dept)) next.delete(dept);
      else next.add(dept);
      return next;
    });

  const allExpanded = expanded.size === DEPARTMENT_DATA.length;
  const toggleAll = () => {
    if (allExpanded) setExpanded(new Set());
    else setExpanded(new Set(DEPARTMENT_DATA.map((d) => d.department)));
  };

  const decisionOptions = [
    { value: 'modeled', label: 'Modeled' },
    { value: 'modeled-no-loss', label: 'Modeled Peril But No Modeled Loss Estimates' },
    { value: 'no-impact', label: 'No Modeling Impact' },
    { value: 'cannot-model', label: 'No Model Available' },
  ];

  return (
    <div className="px-4 lg:px-10 py-8 space-y-6">

      {/* ── 1. Modeling Decision ────────────────────────────────────── */}
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <h3 className="text-slate-900 text-sm" style={{ fontWeight: 600 }}>Modeling Decision</h3>
          <div className="relative group">
            <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" />
            <div className="absolute left-6 top-0 z-50 hidden group-hover:block bg-slate-900 text-white text-xs rounded-lg px-3 py-2 w-64 shadow-lg">
              Select how this event was modeled by the CAT Modeling team.
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-6">
          {decisionOptions.map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="modelingDecision"
                value={opt.value}
                checked={modelingDecision === opt.value}
                onChange={(e) => setModelingDecision(e.target.value)}
                className="w-4 h-4"
                style={{ accentColor: '#0052FF' }}
              />
              <span className="text-sm text-slate-700">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* ── 2. Scenario Overview Summary ───────────────────────────── */}
      {(modelingDecision === 'modeled' || modelingDecision === 'modeled-no-loss') && (
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <h3 className="text-sm text-slate-900" style={{ fontWeight: 600 }}>Overview</h3>
              <p className="text-xs text-slate-500 mt-0.5">As-Of 10/1/2024 · All Values USDm</p>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/50">
                  <th className="px-4 py-2.5 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Event ID</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Max Wind (mph)</th>
                  <th className="px-4 py-2.5 text-left text-xs text-slate-500" style={{ fontWeight: 500 }}>Landfall Location</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Industry Loss (USDm)</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Everest Gross</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Gross Market Share</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Everest Net*</th>
                  <th className="px-4 py-2.5 text-right text-xs text-slate-500" style={{ fontWeight: 500 }}>Net Market Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SCENARIOS.map((row) => (
                  <tr key={row.eventId} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-4 py-2.5 text-slate-800 font-mono" style={{ fontWeight: 500 }}>{row.eventId}</td>
                    <td className="px-4 py-2.5 text-right text-slate-700">{row.maxWind}</td>
                    <td className="px-4 py-2.5 text-slate-700">{row.location}</td>
                    <td className="px-4 py-2.5 text-right text-slate-800" style={{ fontWeight: 600 }}>{row.industryLoss}</td>
                    <td className="px-4 py-2.5 text-right text-slate-800" style={{ fontWeight: 600 }}>{row.gross.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-right text-slate-600">{row.grossShare}</td>
                    <td className="px-4 py-2.5 text-right" style={{ color: '#0052FF', fontWeight: 600 }}>{row.net.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-right text-slate-600">{row.netShare}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-2 border-t border-slate-100 bg-slate-50/50">
            <span className="text-[10px] text-slate-400">*Net = net of all cessions including Logan Re</span>
          </div>
        </div>
      )}

      {/* ── 3. Gross Loss by Department and Type ───────────────────── */}
      {(modelingDecision === 'modeled' || modelingDecision === 'modeled-no-loss') && (
        <>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-slate-900 text-lg" style={{ fontWeight: 600 }}>
                Gross Loss by Department and Type
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                CAT model output across {EVENT_IDS.length} scenario event IDs &mdash; values in $M
              </p>
            </div>
            <button
              onClick={toggleAll}
              className="text-xs px-3 py-1.5 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            >
              {allExpanded ? 'Collapse All' : 'Expand All'}
            </button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden shadow-sm">
            <table className="w-full text-sm">
              <thead>
                {/* Super-header */}
                <tr className="bg-slate-700">
                  <th className="text-left text-white py-2 px-4 text-xs uppercase tracking-wider" style={{ fontWeight: 600 }}>
                    Gross Loss by Department and Type
                  </th>
                  <th
                    colSpan={EVENT_IDS.length}
                    className="text-center text-white py-2 px-4 text-xs uppercase tracking-wider"
                    style={{ fontWeight: 600 }}
                  >
                    <span className="inline-flex items-center gap-1.5">
                      Event ID
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </span>
                  </th>
                </tr>
                {/* Event ID columns */}
                <tr className="bg-slate-600">
                  <th className="text-left text-slate-200 py-2 px-4 text-xs" style={{ fontWeight: 600 }}>
                    <span className="inline-flex items-center gap-1">
                      Department
                      <Filter className="w-3 h-3 opacity-50" />
                    </span>
                  </th>
                  {EVENT_IDS.map((eid) => (
                    <th
                      key={eid}
                      className="text-right text-slate-200 py-2 px-4 text-xs tabular-nums"
                      style={{ fontWeight: 600, minWidth: 110 }}
                    >
                      {eid}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {DEPARTMENT_DATA.map((dept) => {
                  const isOpen = expanded.has(dept.department);
                  return (
                    <React.Fragment key={dept.department}>
                      {/* Department (parent) row */}
                      <tr
                        className="bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors group"
                        onClick={() => toggle(dept.department)}
                      >
                        <td className="py-2 px-4 text-slate-900" style={{ fontWeight: 700 }}>
                          <span className="inline-flex items-center gap-1.5">
                            {isOpen ? (
                              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 transition-colors" />
                            ) : (
                              <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 transition-colors" />
                            )}
                            {dept.department}
                          </span>
                        </td>
                        {dept.totals.map((v, i) => (
                          <td
                            key={i}
                            className="py-2 px-4 text-right tabular-nums text-slate-900"
                            style={{ fontWeight: 700 }}
                          >
                            {fmtVal(v)}
                          </td>
                        ))}
                      </tr>

                      {/* Sub-type rows */}
                      {isOpen &&
                        dept.subRows.map((sub) => (
                          <tr
                            key={`${dept.department}-${sub.type}`}
                            className="hover:bg-blue-50/40 transition-colors"
                          >
                            <td className="py-1.5 pl-10 pr-4 text-slate-600 text-xs">
                              {sub.type}
                            </td>
                            {sub.values.map((v, i) => (
                              <td
                                key={i}
                                className="py-1.5 px-4 text-right tabular-nums text-slate-600 text-xs"
                              >
                                {fmtVal(v)}
                              </td>
                            ))}
                          </tr>
                        ))}
                    </React.Fragment>
                  );
                })}

                {/* Grand Total */}
                <tr className="bg-slate-800">
                  <td className="py-2.5 px-4 text-white" style={{ fontWeight: 700 }}>
                    Grand Total
                  </td>
                  {GRAND_TOTAL.map((v, i) => (
                    <td
                      key={i}
                      className="py-2.5 px-4 text-right tabular-nums text-white"
                      style={{ fontWeight: 700 }}
                    >
                      {fmtVal(v)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* ── Fallback message for non-modeled decisions ─────────────── */}
      {(modelingDecision === 'no-impact' || modelingDecision === 'cannot-model') && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 text-center">
          <p className="text-sm text-amber-800" style={{ fontWeight: 500 }}>
            {modelingDecision === 'no-impact'
              ? 'This event has been marked as having no modeling impact. No CAT model output is available.'
              : 'No CAT model is available for this peril / region. Loss estimates will be based on underwriter judgment only.'}
          </p>
        </div>
      )}
    </div>
  );
}
