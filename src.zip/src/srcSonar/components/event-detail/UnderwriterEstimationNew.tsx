import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useParams } from 'react-router';
import {
  Download, Upload, ChevronDown, ChevronRight, Save, Send, X,
  CheckCircle2, MessageSquare, Building2, FileText,
  Check, Square, CheckSquare, XSquare, Cpu, AlertTriangle,
  Clock, UserCheck, XCircle, Lock, Eye, Calendar, Maximize2, Minimize2,
} from 'lucide-react';
import { mockEvents } from '../../lib/mockData';
import { ContractMetadata } from './ContractCapture';
import { chileEarthquakeContracts } from '../../lib/chileEarthquakeContracts';
import * as XLSX from 'xlsx';
import { toast } from 'sonner@2.0.3';
import { useRole } from '../../lib/roleContext';
import { useWorkflow } from '../../lib/workflowContext';
import { useCurrency } from '../../lib/currencyContext';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef,
  type MRT_ColumnFiltersState,
} from 'material-react-table';
import {
  BU_HIERARCHY, BU_NAME_MAP,
  PRODUCT_NODE_TO_NAME,
  findBUNode, collectBUIds, collectLeafBUs, resolveTeam, isProductSelection,
  type BUNode,
} from '../../lib/buHierarchy';
import { useUWPortfolio } from '../../lib/uwPortfolioContext';

// ─── EditableCell ─────────────────────────────────────────────────────────────
function EditableCell({
  value: externalValue, onChange, disabled, className, placeholder,
}: {
  value: string; onChange: (v: string) => void; disabled: boolean; className: string; placeholder?: string;
}) {
  const [localValue, setLocalValue] = useState(externalValue);
  const editingRef = useRef(false);
  useEffect(() => { if (!editingRef.current) setLocalValue(externalValue); }, [externalValue]);
  return (
    <input type="text" value={localValue}
      onChange={(e) => { editingRef.current = true; setLocalValue(e.target.value); }}
      onFocus={() => { editingRef.current = true; }}
      onBlur={() => { editingRef.current = false; if (localValue !== externalValue) onChange(localValue); }}
      disabled={disabled} className={className} placeholder={placeholder} />
  );
}

// ─── Contract Estimate Interface ──────────────────────────────────────────────
interface ContractEstimate extends ContractMetadata {
  team: string; teamName: string; impacted: boolean; modelImpacted: boolean;
  uwEstimateLow: string; uwEstimateMed: string; uwEstimateHigh: string;
  modelingLow: string; modelingMed: string; modelingHigh: string;
  ibnrCode: string; product: string; mainRisk: string; notes: string; fxRate: string; originalCurrency: string;
  premium: string; everestLimit: string; everestOccurrenceLimit: string;
  ripPercent: string; // editable: '100%' for XL, '' for others — user-overridable
  estimateVersion: number; estimateAsOf: string;
}

// ─── Estimate Snapshot (version history per contract) ─────────────────────────
interface EstimateSnapshot {
  id: string; contractNumber: string; version: number; asOfDate: string;
  savedAt: string; savedBy: string;
  uwEstimateLow: string; uwEstimateMed: string; uwEstimateHigh: string;
  notes: string;
}

// ─── Impact Assessment Entry ───────────────────────���──────────────────────────
interface ImpactEntry {
  id: string; buId: string; notes: string; expectations: string; exposureAsOf: string;
  estimateLow: string; estimateBest: string; estimateHigh: string;
  attachments: { name: string; type: string; size: string }[];
  savedAt: string; savedBy: string; sentToManagement: boolean; sentAt?: string;
}

// ─── Impact Row Data (per-BU inline editing) ─────────────────────────────────
interface ImpactRowData {
  low: string; best: string; high: string;
  notes: string; expectations: string; exposureAsOf: string;
}

// ─── Impact MRT Row (for MRT-based impact table) ─────────────────────────────
interface ImpactMRTRow {
  id: string; segment: string; hasExposure: string;
  reportVersion: number; asOfDate: string;
  uwTotalLow: number; uwTotalBest: number; uwTotalHigh: number;
  overrideLow: string; overrideBest: string; overrideHigh: string;
  notes: string; expectations: string; savedReports: number;
  rowType: 'current' | 'saved';
  tracked: boolean;
  contractCount: number;
  parentBuId?: string;
  savedAt?: string;
  savedBy?: string;
  expReinstPremiums: number;
  netLoss: number;
}

// ─── Submission Status ────────────────────────────────────────────────────────
interface SubmissionStatus {
  buId: string; submittedBy: string; submittedAt: string; comment: string;
  status: 'draft' | 'pending-approval' | 'approved' | 'rejected';
  approvedBy?: string; approvedAt?: string; rejectedBy?: string; rejectedAt?: string; rejectionReason?: string;
  version?: number;
}

// ─── Submission Version (created on each Submit click) ────────────────────────
interface SubmissionVersion {
  id: string;
  version: number;
  buId: string;
  submittedBy: string;
  submittedAt: string;
  comment: string;
  impactDecisions: Record<string, 'yes' | 'no' | null>;
  segments: {
    buId: string; segment: string; hasExposure: string;
    low: string; best: string; high: string;
    notes: string; expectations: string;
  }[];
  totals: { low: number; best: number; high: number };
  contractCount: number;
  impactedCount: number;
}

// ─── Sub-Product Interfaces ───────────────────────────────────────────────────
interface SubProductRow {
  id: string;
  name: string;
  low: string;
  best: string;
  high: string;
  notes: string;
}

interface SubProductData {
  buId: string;
  buName: string;
  segment: string;
  emoji: string;
  mode: 'sub-product';
  rows: SubProductRow[];
  submittedBy?: string;
  submittedAt?: string;
}

// ─── Sub-Product Name Combobox ────────────────────────────────────────────────
interface SubProductNameComboboxProps {
  value: string;
  catalog: string[];
  disabled?: boolean;
  onChange: (val: string) => void;
  onCommit: (val: string) => void;
}
function SubProductNameCombobox({ value, catalog, disabled, onChange, onCommit }: SubProductNameComboboxProps) {
  const [open, setOpen] = useState(false);
  const filtered = catalog.filter(n => n.toLowerCase().includes(value.toLowerCase()) && n !== value);
  const showNew = !!(value.trim() && !catalog.some(n => n.toLowerCase() === value.trim().toLowerCase()));
  return (
    <div className="relative">
      <input
        type="text"
        value={value}
        disabled={disabled}
        onChange={e => onChange(e.target.value)}
        onFocus={() => setOpen(true)}
        onBlur={() => { setTimeout(() => setOpen(false), 160); onCommit(value); }}
        onKeyDown={e => {
          if (e.key === 'Enter') { onCommit(value); setOpen(false); (e.target as HTMLInputElement).blur(); }
          if (e.key === 'Escape') setOpen(false);
        }}
        className="w-full bg-slate-50 border border-slate-200 rounded-sm px-2 py-1 text-[11px] text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-400 disabled:opacity-50"
        placeholder="Type or select sub-product…"
      />
      {open && (filtered.length > 0 || showNew) && (
        <div className="absolute z-50 top-full left-0 right-0 mt-0.5 bg-white border border-slate-200 rounded shadow-lg max-h-44 overflow-y-auto">
          {filtered.map(name => (
            <button
              key={name}
              type="button"
              onMouseDown={() => { onChange(name); onCommit(name); setOpen(false); }}
              className="w-full text-left px-2.5 py-1.5 text-[11px] text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
            >
              {name}
            </button>
          ))}
          {showNew && (
            <button
              type="button"
              onMouseDown={() => { onChange(value.trim()); onCommit(value.trim()); setOpen(false); }}
              className="w-full text-left px-2.5 py-1.5 text-[11px] text-blue-600 hover:bg-blue-50 border-t border-slate-100 transition-colors"
            >
              ＋ Save &ldquo;{value.trim()}&rdquo; as new sub-product
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const parseCurrency = (value?: string | number | null): number => {
  if (value == null || value === '' || value === '-' || value === '$0' || value === '$0.00M') return 0;
  const s = String(value).replace(/[$,€£]/g, '').trim();
  const n = parseFloat(s);
  if (isNaN(n)) return 0;
  if (String(value).includes('B')) return n * 1e9;
  if (String(value).includes('M')) return n * 1e6;
  if (String(value).includes('K')) return n * 1e3;
  return n;
};

const formatCurrency = (value: number): string => {
  if (!value || isNaN(value) || value === 0) return '$0.00M';
  const m = value / 1e6;
  if (Math.abs(m) >= 100) return `$${m.toFixed(1)}M`;
  if (Math.abs(m) >= 1) return `$${m.toFixed(2)}M`;
  return `$${m.toFixed(3)}M`;
};

const formatCurrencySymbol = (value: number, symbol: string): string => {
  if (!value || isNaN(value) || value === 0) return `${symbol}0.00M`;
  const m = value / 1e6;
  if (Math.abs(m) >= 100) return `${symbol}${m.toFixed(1)}M`;
  if (Math.abs(m) >= 1) return `${symbol}${m.toFixed(2)}M`;
  return `${symbol}${m.toFixed(3)}M`;
};

// ─── RIP% / Reinstatement helpers ────────────────────────────────────────────
const parsePercent = (value?: string | null): number => {
  if (!value || value.trim() === '' || value === '—') return 0;
  const n = parseFloat(value.replace('%', '').trim());
  return isNaN(n) ? 0 : n / 100;
};

// Exp. Reinst. Premiums = Premium × (UW Best / Our Limit) × RIP%
const calcExpReinstPremium = (e: { premium: string; uwEstimateMed: string; limit: string; ripPercent: string }): number => {
  const rip = parsePercent(e.ripPercent);
  if (rip === 0) return 0;
  const premium = parseCurrency(e.premium);
  const uwBest = parseCurrency(e.uwEstimateMed);
  const ourLimit = parseCurrency(e.limit);
  if (!premium || !ourLimit) return 0;
  return premium * (uwBest / ourLimit) * rip;
};

// ─── Display Currency Constants ───────────────────────────────────────────────
const DISPLAY_CURRENCIES = ['USD', 'GBP', 'EUR', 'CAD', 'ORIGINAL'] as const;
type DisplayCurrency = (typeof DISPLAY_CURRENCIES)[number];
const USD_TO_RATE: Record<string, number> = { USD: 1, GBP: 0.79, EUR: 0.92, CAD: 1.35 };
const CUR_SYMBOLS: Record<string, string> = { USD: '$', GBP: '£', EUR: '€', CAD: 'C$' };
const CUR_LABELS: Record<string, string> = { USD: 'USD ($)', GBP: 'GBP (£)', EUR: 'EUR (€)', CAD: 'CAD (C$)', ORIGINAL: 'Original Currency' };

const DATA_VERSION = '25.0'; // bumped: adds ripPercent, Exp. Reinst. Premiums, Net Loss
const allContracts: ContractMetadata[] = chileEarthquakeContracts;

// MRT Styles
const MRT_HEAD_CELL_SX = {
  py: '6px', px: '4px', backgroundColor: '#f8fafc', borderBottom: '2px solid #e2e8f0', verticalAlign: 'middle',
  '& .MuiTableSortLabel-root': { fontSize: '0.7rem', fontWeight: 600, color: '#475569', letterSpacing: '0.05em' },
};
const MRT_BODY_CELL_SX = { py: '4px', px: '4px', color: '#000000', verticalAlign: 'middle' };
const MRT_PAPER_SX = { width: '100%', overflow: 'hidden', boxShadow: 'none' };

// ─── IBNR Tag → Product Mapping ──────────────────────────────────────────────
const IBNR_TO_PRODUCT: Record<string, string> = {
  'EB_AH_CAT':'Accident & Health','EB_AHXS':'Accident & Health','EB_AH1ST$':'Accident & Health',
  'EB_AHSPAGG':'Accident & Health','EB_AHSPRSK':'Accident & Health','EB_BENMDPA':'Accident & Health',
  'EB_MEDSUPP':'Accident & Health','EB_AHPEX':'Accident & Health','EB_SDURMED':'Accident & Health',
  'EB_AHASL':'Accident & Health','EB_SPORTDI':'Accident & Health',
  'Z*_A&H_XL':'Accident & Health','Z*_A&H_PR':'Accident & Health',
  'A&H_PR':'Accident & Health','A&H_XL':'Accident & Health',
  'BM_A&H_XL':'Accident & Health','BM_A&H_PR':'Accident & Health',
  'JC_A&H_PR':'Accident & Health','JC_A&H_XS':'Accident & Health',
  'DU_AHXL':'Accident & Health','DU_AHPR':'Accident & Health',
  'ZU_AHXL':'Accident & Health','ZU_AHPR':'Accident & Health',
  'LN_AHXL':'Accident & Health','LN_AHPR':'Accident & Health',
  'LAB_A&H_XL':'Accident & Health','LAB_A&H_PR':'Accident & Health',
  'MEA_A&H_XL':'Accident & Health','MEA_A&H_PR':'Accident & Health',
  'A*_ALTRISK':'Alternative Risk','A*_RESDVAL':'Alternative Risk',
  'H*_IC_LMI':'Alternative Risk','L*_NON_REV':'Alternative Risk',
  'Z*_ALTRISK':'Alternative Risk','BR_ALTRISK':'Alternative Risk','BR_ANDES':'Alternative Risk',
  'NB_ALTRISK':'Alternative Risk','E*_ALTRISK':'Alternative Risk',
  'LB_AHULLXS':'Aviation','LB_AHULLPR':'Aviation','LB_ALIABXS':'Aviation','LB_ARETRXS':'Aviation',
  'LB_GENAVXS':'Aviation','LB_ALIABPR':'Aviation','LB_GENAVPR':'Aviation',
  'L*_FUNDXS':'Aviation','LB_PHXAVPR':'Aviation','LB_SATELT':'Aviation','LN_AVIPR':'Aviation',
  'LV_ALIABXS':'Aviation','LV_ALIABXC':'Aviation','LV_ALIABPR':'Aviation','LV_ALIABPC':'Aviation',
  'LV_AVCEDPR':'Aviation','LV_AVCEDXS':'Aviation','LV_AVRETRO':'Aviation','LV_AVRETRC':'Aviation',
  'LV_GENAVXS':'Aviation','LV_GENAVXC':'Aviation','LV_GENAVPR':'Aviation','LV_GENAVPC':'Aviation',
  'LV_SATELT':'Aviation','LV_SATELTC':'Aviation','WAR_XS':'Aviation','WAR_PR':'Aviation',
  'A*_CASCAT':'Casualty','A*_CQSHIGH':'Casualty','A*_CQSLOW':'Casualty','A*_CASWORK':'Casualty',
  'A*_FREE':'Casualty','A*_MUF':'Casualty','A*_CASWRKQ':'Casualty',
  'A*_CASCAT2':'Casualty','A*_FCASHI':'Casualty','A*_FCASLOW':'Casualty','A*_FMUFCAS':'Casualty',
  'A*_CASCAT5':'Casualty','A*_CASCATQ':'Casualty','A*_CQSCM':'Casualty','A*_CQSHIQ':'Casualty',
  'A*_AMTRUST':'Casualty','A*_CQSLOWQ':'Casualty',
  'A*_MMXCM':'Casualty','A*_MMXCMQ2':'Casualty','A*_MMXCM2':'Casualty',
  'A*_MMXOCC':'Casualty','A*_MMXOCC1':'Casualty',
  'A*_MLCATXS':'Casualty','A*_MLWRKQS':'Casualty','A*_MULTILN':'Casualty',
  'A*_ACE':'Casualty','A*_BROWARD':'Casualty','A*_CHUBD&O':'Casualty',
  'A*_CHUBUD':'Casualty','A*_CHUBUMB':'Casualty','A*_COMMUTE':'Casualty',
  'A*_FRNTIER':'Casualty','A*_FUNDED':'Casualty','A*_HBWIS':'Casualty',
  'A*_LONDONC':'Casualty','A*_LONDONW':'Casualty','A*_MIDLAND':'Casualty',
  'A*_PAULA':'Casualty','A*_SPECTRM':'Casualty','A*_STARLPT':'Casualty',
  'A*_STLOU2':'Casualty','A*_STLOUIS':'Casualty','A*_TRANCAS':'Casualty',
  'A*_WCRB':'Casualty','A*_LONDONQ':'Casualty','A*_FIRSTST':'Casualty',
  'A*_UTICA':'Casualty','H*_INTERCO':'Casualty','A*_ZURICH':'Casualty',
  'A*_PRFWKQ4':'Casualty','A*_PRFWRK4':'Casualty','A*_PRFWRK':'Casualty',
  'A*_MUF3':'Casualty','A*_UNEXPO':'Casualty','A*_CRDTEQ':'Casualty','A*_HIIG':'Casualty',
  'MB_FCAS_XS':'Casualty','MC_TCAS_XS':'Casualty','Z*_FCAS_XS':'Casualty','Z*_TCAS_XS':'Casualty',
  'MB_FCAS_PR':'Casualty','MC_TCAS_PR':'Casualty','Z*_FCAS_PR':'Casualty','Z*_TCAS_PR':'Casualty',
  'WAQS':'Casualty','WAQS_PR':'Casualty',
  'BR_CAS_CAT':'Casualty','BR_CAS_XS':'Casualty','BR_UNEXPO':'Casualty',
  'BR_PRO_XS':'Casualty','BR_CAS_PR':'Casualty','BR_CASPRXS':'Casualty','BR_CASPRUM':'Casualty',
  'BA_E&O_D&O':'Casualty','BS_E&O_D&O':'Casualty','UA_E&O_D&O':'Casualty',
  'B*_ANDES':'Casualty','BC_CAS_LOW':'Casualty','BC_CASHIGH':'Casualty',
  'BR_PRFL_PR':'Casualty','BR_PLPRXS':'Casualty','BR_PLPRUM':'Casualty',
  'NC_CASAF_H':'Casualty','NC_CASAF_L':'Casualty','NC_CASAFCM':'Casualty',
  'NC_FAC_CAS':'Casualty','NC_CLAIMMD':'Casualty','NC_MED_MAL':'Casualty',
  'NC_AUTOLIA':'Casualty','NC_UMB_XS':'Casualty','NC_GENLIAB':'Casualty','NC_E&O_D&O':'Casualty',
  'JA_CASAF_H':'Casualty','JA_CASAF_L':'Casualty','JA_CASAFCM':'Casualty',
  'JA_FAC_CAS':'Casualty','JA_CLAIMMD':'Casualty','JA_MED_MAL':'Casualty',
  'JA_AUTOLIA':'Casualty','JA_UMB_XS':'Casualty','JA_GENLIAB':'Casualty','JA_E&O_D&O':'Casualty',
  'JA_COMMUTE':'Casualty','JA_LAWYERS':'Casualty','JA_PROP_XS':'Casualty','JA_PRPXSAF':'Casualty',
  'DU_CASXL':'Casualty','DU_CASPR':'Casualty','ZU_CASXL':'Casualty','ZU_CASPR':'Casualty',
  'T*_CASAF_H':'Casualty','T*_CASAF_L':'Casualty','T*_CASAFCM':'Casualty','T*_CASAFME':'Casualty',
  'T*_CLAIMMD':'Casualty','T*_MED_MAL':'Casualty','T*_AON_FAC':'Casualty',
  'T*_AUTOLIA':'Casualty','T*_CASHIGH':'Casualty','T*_UMB_XS':'Casualty',
  'T*_CAS_LOW':'Casualty','T*_GENLIAB':'Casualty','T*_WORKCMP':'Casualty',
  'T*_AM_CYAN':'Casualty','T*_ARCH_CD':'Casualty','T*_COMMUTE':'Casualty',
  'T*_CROMWEL':'Casualty','T*_MISSION':'Casualty','T*_MUF_CAS':'Casualty',
  'T*_CAS_AF':'Casualty','T*_REZPRO':'Casualty','T*_STDFAST':'Casualty',
  'G*_COMMUTE':'Casualty',
  'R*_CASHIEX':'Casualty','R*_CASWORK':'Casualty','R*_CASWKQ2':'Casualty',
  'R*_CASWKQ5':'Casualty','R*_CASHIUN':'Casualty','R*_CASPRHI':'Casualty','R*_CASPRLO':'Casualty',
  'LF_CASAF_H':'Casualty','LF_CASAF_L':'Casualty','LF_CASAFCM':'Casualty',
  'LF_CLAIMMD':'Casualty','LF_MED_MAL':'Casualty','LF_AUTOLIA':'Casualty',
  'LF_UMB_XS':'Casualty','LF_GENLIAB':'Casualty','LF_WORKCMP':'Casualty','LF_E&O_D&O':'Casualty',
  'LN_CAS_RET':'Casualty','LN_CASXLBK':'Casualty','LN_CASXLEL':'Casualty',
  'LN_CASXLGL':'Casualty','LN_CASFLEX':'Casualty','LN_CASPR':'Casualty','LN_CASPRAI':'Casualty',
  'LN_CASXLPL':'Casualty','LN_CASPRPL':'Casualty','LN_STRUXL':'Casualty','LN_STRUPR':'Casualty',
  'LN_AVIXL':'Casualty','NB_TCAS_XS':'Casualty','NB_TCAS_PR':'Casualty',
  'NC_ALTRISK':'Casualty','NF_ALTRISK':'Casualty','JB_ALTRISK':'Casualty','KA_ALTRISK':'Casualty',
  'Z*_CASAF_H':'Casualty','Z*_CASAF_L':'Casualty','Z*_CASAFCM':'Casualty',
  'Z*_CLAIMMD':'Casualty','Z*_MED_MAL':'Casualty','Z*_AUTOLIA':'Casualty',
  'Z*_UMB_XS':'Casualty','Z*_GENLIAB':'Casualty','Z*_E&O_D&O':'Casualty',
  'JB_CASCAT':'Casualty','JB_FREE':'Casualty','JB_PROFWRK':'Casualty','JB_PROPXS':'Casualty',
  'JB_PROFCAT':'Casualty','JB_CQSHIGH':'Casualty','JB_CQSLOW':'Casualty',
  'JB_GAN':'Casualty','JB_LAQS':'Casualty','JB_MUF':'Casualty','JB_UNEXPO':'Casualty','JB_CASWORK':'Casualty',
  'KA_CRED_PR':'Casualty','KA_FID_XS':'Casualty','KA_FUNDXS':'Casualty',
  'KA_MISCCAS':'Casualty','KA_NON_REV':'Casualty','KB_FINGUAR':'Casualty',
  'KA_CRED_XS':'Casualty','KA_FID_PR':'Casualty',
  'E*_BERKLEY':'Casualty','E*_CQSLOW':'Casualty','E*_AMERSUR':'Casualty',
  'E*_CASCAT':'Casualty','E*_CASWORK':'Casualty','E*_AUTOQS':'Casualty',
  'E*_MUF':'Casualty','E*_UNEXPO':'Casualty','E*_POOLSPR':'Casualty',
  'E*_MLPRXS':'Property Risk','E*_FUNDED':'Property PR',
  'NB_COMMUTE':'Property PR','NB_FUNDXS':'Property PR','NB_POOLSPR':'Casualty',
  'G*_PROP_PR':'Property PR',
  'Z*_CROP_PR':'Crop','Z*_CROPHAI':'Crop','Z*_CROPXOL':'Crop',
  'EJ_CROPXOL':'Crop','EJ_CROP_PR':'Crop','JC_CROPHXS':'Crop','JC_CROPHPR':'Crop',
  'CYBER_XS':'Cyber','CYBER_PR':'Cyber',
  'OFS_NRG_PR':'Energy','ONS_NRG_PR':'Energy','RNW_NRG_PR':'Energy',
  'OFS_NRG_XS':'Energy','ONS_NRG_XS':'Energy','RNW_NRG_XS':'Energy',
  'E*_ONSEGPR':'Energy','E*_ONSEGXL':'Energy',
  'ENG_XS':'Engineering','ENG_PR':'Engineering','LN_ENGXL':'Engineering','LN_ENGPR':'Engineering',
  'FIN_PR':'Financial','FIN_XS':'Financial','SUR_XS':'Financial',
  'DU_FINXL':'Financial','DU_FINPR':'Financial','ZU_FINXL':'Financial','ZU_FINPR':'Financial',
  'LN_FINXL':'Financial','LN_FINPR':'Financial',
  'Z*_SUR_PR':'Financial','Z*_SUR_XL':'Financial',
  'NB_SUR_XS':'Financial','NB_SUR_PR':'Financial','NC_FAC_SUR':'Financial',
  'JB_FINGXS':'Financial','JB_SUREPR':'Financial','JB_SURXS':'Financial',
  'JB_FINXS':'Financial','JB_FINPR':'Financial',
  'BR_SRT_PR':'Financial','KA_SUR_XS':'Financial','KA_SUR_PR':'Financial',
  'MC_TMAR_PR':'Marine','Z*_TMAR_PR':'Marine','Z*_TMAR_XS':'Marine',
  'MAR_RETXS':'Marine','MAR_RETPR':'Marine','MAR_XS':'Marine','MAR_PR':'Marine',
  'DU_MARXL':'Marine','DU_MARPR':'Marine','ZU_MARXL':'Marine','ZU_MARPR':'Marine',
  'LN_MARXL':'Marine','LN_MARPR':'Marine',
  'MCARGPR':'Marine','MCARGXS':'Marine','MHULLPR':'Marine','MHULLXS':'Marine',
  'MP&IPR':'Marine','MP&IXS':'Marine',
  'LA_MALLPR':'Marine','LA_MALLXS':'Marine','LA_MHULLPR':'Marine','LA_MHULLXS':'Marine',
  'LA_MCARGPR':'Marine','LA_MCARGXS':'Marine','LA_MP&IPR':'Marine','LA_MP&IXS':'Marine',
  'LA_MRIGPR':'Marine','LA_MRIGXS':'Marine','LA_MRETPR':'Marine','LA_MRETXS':'Marine',
  'LA_MCAT_XS':'Marine','NB_TMAR_XS':'Marine','NB_TMAR_PR':'Marine','JC_MARPR':'Marine',
  'A*_MRTGAGE':'Mortgage','A*_MORTINS':'Mortgage',
  'BR_FIN_PR':'Mortgage','BR_INTL_MI':'Mortgage','BR_FIN_XL':'Mortgage',
  'BR_US_GSE':'Mortgage','BR_US_MI':'Mortgage',
  'Z*_MTRDMXL':'Motor','Z*_MTRDMPR':'Motor',
  'DU_AUTOXL':'Motor','DU_AUTOPR':'Motor','ZU_AUTOXL':'Motor','ZU_AUTOPR':'Motor',
  'LN_AUTOXLO':'Motor','LN_AUTOXLU':'Motor','LN_AUTOPR':'Motor',
  'PTS_CAT':'Parametric','PTS_CATAGG':'Parametric','PTS_XS':'Parametric',
  'PTS_RETRO':'Parametric','PTS_PR':'Parametric',
  'MC_TPHI_XS':'Property CAT','Z*_CATAGG':'Property CAT','Z*_RETRORG':'Property CAT',
  'Z*_TPHI_XS':'Property CAT',
  'BR_PROP_CA':'Property CAT','BR_PROP_RT':'Property CAT','BR_RETRAGG':'Property CAT',
  'DU_PROPCAT':'Property CAT','JC_PROPCAT':'Property CAT',
  'LN_PROPCAT':'Property CAT','NB_PROPCAT':'Property CAT',
  'E*_CATAGG':'Property CAT','E*_RETRAGG':'Property CAT',
  'E*_PCRETRO':'Property CAT','E*_PROPCAT':'Property CAT',
  'A*_PRFCAT':'Property CAT','A*_PRFCAT5':'Property CAT','A*_PRFCATA':'Property CAT',
  'MC_TPRP_PR':'Property PR','Z*_FPRP_PR':'Property PR','Z*_TPRP_PR':'Property PR',
  'Z*_PROPPRI':'Property PR','Z*_PRPRIAF':'Property PR','Z*_PRPPRAF':'Property PR',
  'NC_PRPRIAF':'Property PR','NC_PRPPRAF':'Property PR','NC_FPROPPR':'Property PR','NC_PROPPRI':'Property PR',
  'JA_PROP_PR':'Property PR','JA_PROPPRI':'Property PR','JA_PRPRIAF':'Property PR','JA_PRPPRAF':'Property PR',
  'DU_PROPPR':'Property PR','BR_PROP_PR':'Property PR',
  'B*_DRTPPR':'Property PR','B*_DRTPXS':'Property PR','B*_FACPPR':'Property PR','B*_FACPXS':'Property PR',
  '**_BC_CONT':'Property PR','BR_MULTILN':'Property PR',
  'LF_PRPRIAF':'Property PR','LF_PRPPRAF':'Property PR','LF_PROPPRF':'Property PR',
  'LF_PROPPRI':'Property PR','LF_PROP_PR':'Property PR',
  'LN_PROPPRF':'Property PR','LN_PROPPR':'Property PR','LN_PROPPRV':'Property PR','LN_GEARPR':'Property PR',
  'NB_TPROPPR':'Property PR','NB_FRONT':'Property PR','NB_AGG_DED':'Property PR',
  'JC_COMPXS':'Property PR','JC_FREE':'Property PR','JC_POOLSPR':'Property PR','JC_PROPPR':'Property PR',
  'E*_FREE':'Property PR','E*_NATCTYP':'Property PR','E*_NATCTYX':'Property PR',
  'E*_NATLCOL':'Property PR','E*_OLDM&A':'Property PR','E*_PERSPR':'Property PR',
  'E*_PROPPR':'Property PR','G*_PRPPRAF':'Property PR',
  'A*_PROPCAT':'Casualty','A*_PROPPR':'Casualty','A*_PROPXS':'Casualty',
  'MB_FPRP_XS':'Property Risk','MC_TPRP_XS':'Property Risk',
  'Z*_FPRP_XS':'Property Risk','Z*_TPRP_XS':'Property Risk',
  'BR_PROP_XS':'Property Risk','DU_PROPXL':'Property Risk',
  'JC_PROPXS':'Property Risk','LN_PROP_RT':'Property Risk','LN_PROPXL':'Property Risk',
  'NB_TPROPXS':'Property Risk',
  'NC_PRPXSAF':'Property Risk','NC_FPROPXS':'Property Risk',
  'LF_PRPXSAF':'Property Risk','LF_PROP_XS':'Property Risk',
  'G*_PROP_XS':'Property Risk','G*_FRNT_XS':'Property Risk','G*_PRPXSAF':'Property Risk',
  'E*_PROPXS':'Property Risk','E*_PROPXSA':'Property Risk','E*_PURPLE':'Property Risk',
  'BR_SRT_XS':'Casualty',
  'LN_PROPXLV':'PVT & Terror',
  'BR_REGEAR':'REGEAR',
};

function resolveProduct(ibnrCode: string): string {
  if (!ibnrCode || ibnrCode === 'UNKNOWN') return '—';
  return IBNR_TO_PRODUCT[ibnrCode] || '—';
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════
export function UnderwriterEstimationNew() {
  const { eventId } = useParams();
  const event = mockEvents.find(e => e.id === eventId);
  const { currentRole, userName } = useRole();
  const { getWorkflowStatus, setPhase, getAllowedPhases, getEventStatus, isEventLocked, lockEvent, unlockEvent, reopenEvent, completePhase4, closeEvent, archiveEvent } = useWorkflow();
  const { settings: currencySettings } = useCurrency();

  // ─── Portfolio Context (shared with nav sidebar) ──────────────────────
  const {
    selectedBU, setSelectedBU,
    publishPortfolioData,
  } = useUWPortfolio();

  // ─── Core State ───────────────────────────────────────────────────────
  const [estimates, setEstimates] = useState<ContractEstimate[]>([]);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnFilters, setColumnFilters] = useState<MRT_ColumnFiltersState>([]);
  const [buNoImpact, setBuNoImpact] = useState<Record<string, boolean>>({});
  const [displayCurrency, setDisplayCurrency] = useState<DisplayCurrency>('USD');
  const [estimateSnapshots, setEstimateSnapshots] = useState<Record<string, EstimateSnapshot[]>>({});
  const [snapshotModalContract, setSnapshotModalContract] = useState<string | null>(null);
  const [snapshotSort, setSnapshotSort] = useState<{ col: string; dir: 'asc' | 'desc' }>({ col: 'version', dir: 'desc' });
  const [phaseDropdownOpen, setPhaseDropdownOpen] = useState(false);

  // ─── Tab State: Impact Assessment vs UW Estimates ─────────────────────
  const [contentTab, setContentTab] = useState<'impact' | 'estimates' | 'subproduct'>('impact');
  const [tableExpanded, setTableExpanded] = useState(false);
  const [impactFilter, setImpactFilter] = useState<'all' | 'impacted' | 'not-impacted'>('all');

  // ─── Impact Assessment State ──────────────────────────────────────────
  const [buResponses, setBuResponses] = useState<Record<string, { response: 'yes' | 'no' | null; rationale: string }>>({});
  const [impactEntries, setImpactEntries] = useState<Record<string, ImpactEntry[]>>({});
  const [impactRowData, setImpactRowData] = useState<Record<string, ImpactRowData>>({});
  const [impactForm, setImpactForm] = useState({
    notes: '', expectations: '', exposureAsOf: new Date().toISOString().split('T')[0],
    estimateLow: '', estimateBest: '', estimateHigh: '',
    attachments: [] as { name: string; type: string; size: string }[],
  });
  const [editingEntryId, setEditingEntryId] = useState<string | null>(null);
  const impactFileRef = useRef<HTMLInputElement>(null);
  const [impactColumnFilters, setImpactColumnFilters] = useState<MRT_ColumnFiltersState>([]);
  const [impactGlobalSearch, setImpactGlobalSearch] = useState('');
  const [showImpactHistory, setShowImpactHistory] = useState<string | null>(null);
  const [impactHistorySort, setImpactHistorySort] = useState<{ col: string; dir: 'asc' | 'desc' }>({ col: 'version', dir: 'desc' });

  // ─── Sub-Product State ─────────────────────────────────────────────────
  const [subProductData, setSubProductData] = useState<SubProductData[]>([
    {
      buId: 'marine',
      buName: 'Marine',
      segment: 'Marine',
      emoji: '🚢',
      mode: 'sub-product',
      rows: [
        { id: '1', name: 'War on Land', low: '$0.40M', best: '$0.55M', high: '$0.70M', notes: 'Orphans accumulation pull — zone 2' },
        { id: '2', name: 'Cargo', low: '$0.50M', best: '$0.65M', high: '$0.80M', notes: 'Wes estimate — CIF basis' },
        { id: '3', name: 'Hull', low: '$0.30M', best: '$0.45M', high: '$0.55M', notes: 'Chilean port exposure — 3 vessels' },
        { id: '4', name: 'Terrorism / SRCC', low: '$0.30M', best: '$0.35M', high: '$0.45M', notes: 'Low confidence — awaiting broker confirmation' },
      ],
      submittedBy: 'Wes Martin',
      submittedAt: 'Mar 9',
    },
    {
      buId: 'financial',
      buName: 'Financial Lines',
      segment: 'Financial Lines',
      emoji: '💼',
      mode: 'sub-product',
      rows: [],
      submittedBy: undefined,
      submittedAt: undefined,
    },
  ]);

  // ─── Sub-Product Name Catalog (grows as users add new names) ───────────────
  const [subProductCatalog, setSubProductCatalog] = useState<Record<string, string[]>>({
    marine: ['War on Land', 'Cargo', 'Hull', 'Terrorism / SRCC'],
    financial: [],
  });

  const addToCatalog = (buId: string, name: string) => {
    if (!name.trim()) return;
    setSubProductCatalog(prev => {
      const existing = prev[buId] || [];
      if (existing.some(n => n.toLowerCase() === name.trim().toLowerCase())) return prev;
      return { ...prev, [buId]: [...existing, name.trim()] };
    });
  };

  const addSubProductRow = (buId: string) => {
    setSubProductData(prev => prev.map(sp => {
      if (sp.buId === buId) {
        const newRow: SubProductRow = {
          id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: '',
          low: '',
          best: '',
          high: '',
          notes: '',
        };
        return { ...sp, rows: [...sp.rows, newRow] };
      }
      return sp;
    }));
  };

  const deleteSubProductRow = (buId: string, rowId: string) => {
    setSubProductData(prev => prev.map(sp => {
      if (sp.buId === buId) {
        return { ...sp, rows: sp.rows.filter(r => r.id !== rowId) };
      }
      return sp;
    }));
  };

  const updateSubProductRow = (buId: string, rowId: string, field: keyof SubProductRow, value: string) => {
    setSubProductData(prev => prev.map(sp => {
      if (sp.buId === buId) {
        return {
          ...sp,
          rows: sp.rows.map(r => r.id === rowId ? { ...r, [field]: value } : r),
        };
      }
      return sp;
    }));
  };

  const calculateSubProductRollup = (rows: SubProductRow[]) => {
    const parseMoney = (val: string): number => {
      if (!val) return 0;
      const cleaned = val.replace(/[$,M]/g, '').trim();
      return parseFloat(cleaned) || 0;
    };

    const low = rows.reduce((sum, r) => sum + parseMoney(r.low), 0);
    const best = rows.reduce((sum, r) => sum + parseMoney(r.best), 0);
    const high = rows.reduce((sum, r) => sum + parseMoney(r.high), 0);

    return { low, best, high };
  };


  // ─── Impact Table Row Helpers ─────────────────────────────────────────
  // Determine if the current sidebar selection is a group/parent node (read-only aggregate view)
  const isGroupView = useMemo(() => {
    if (!selectedBU) return true; // "All Contracts" = aggregate → read-only
    const node = findBUNode(BU_HIERARCHY, selectedBU);
    if (!node) return false;
    return !!(node.children && node.children.length > 0); // parent nodes are group views
  }, [selectedBU]);

  // ─── Finance Lock (must be declared early — used in impactColumns useMemo) ──
  const eventLocked = isEventLocked(eventId || '');

  const getImpactTableRows = useMemo(() => {
    if (!selectedBU) {
      return collectLeafBUs(BU_HIERARCHY);
    }
    const node = findBUNode(BU_HIERARCHY, selectedBU);
    if (!node) return [];
    if (!node.children || node.children.length === 0) return [node];
    return collectLeafBUs([node]);
  }, [selectedBU]);

  const updateImpactRow = (buId: string, field: keyof ImpactRowData, value: string) => {
    setImpactRowData(prev => ({
      ...prev,
      [buId]: { ...(prev[buId] || { low: '', best: '', high: '', notes: '', expectations: '', exposureAsOf: new Date().toISOString().split('T')[0] }), [field]: value }
    }));
  };

  // ─── UW Totals per BU (auto-calculated from contracts table) ──────────
  const uwTotalsPerBU = useMemo(() => {
    const totals: Record<string, { low: number; best: number; high: number; expReinst: number; netLoss: number }> = {};
    estimates.forEach(e => {
      if (!totals[e.team]) totals[e.team] = { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
      if (e.impacted) {
        totals[e.team].low += parseCurrency(e.uwEstimateLow);
        totals[e.team].best += parseCurrency(e.uwEstimateMed);
        totals[e.team].high += parseCurrency(e.uwEstimateHigh);
        const er = calcExpReinstPremium(e);
        totals[e.team].expReinst += er;
        totals[e.team].netLoss += parseCurrency(e.uwEstimateMed) - er;
      }
    });
    return totals;
  }, [estimates]);

  // ─── Teams that actually have contracts (for filtering in aggregate view) ──
  const teamsWithContracts = useMemo(() => {
    const teams = new Set<string>();
    estimates.forEach(e => teams.add(e.team));
    return teams;
  }, [estimates]);

  // ─── Save Impact Row (confirms inline data is saved — only Submit creates the purple saved row) ──
  const saveImpactRow = useCallback((buId: string) => {
    toast.success(`Data saved for ${BU_NAME_MAP[buId] || buId}`);
  }, []);

  // ─── Track/Untrack state (must be declared before impactMRTData) ─────
  const [trackedBUs, setTrackedBUs] = useState<Set<string>>(() => {
    const leafIds = collectLeafBUs(BU_HIERARCHY).map(n => n.id);
    const withContracts = leafIds.filter(id => estimates.some(e => e.team === id));
    return new Set(withContracts);
  });

  // ─── Auto-tracking: track BUs when exposure=yes AND event is tracked ──
  useEffect(() => {
    if (event?.tracked) {
      setTrackedBUs(prev => {
        const next = new Set(prev);
        const leafIds = collectLeafBUs(BU_HIERARCHY).map(n => n.id);
        leafIds.forEach(buId => {
          // Auto-track if exposure response is 'yes'
          if (buResponses[buId]?.response === 'yes') {
            next.add(buId);
          }
        });
        return next;
      });
    }
  }, [event?.tracked, buResponses]);

  // ─── Impact MRT Data (latest version only per segment) ─────────────────
  const impactMRTData = useMemo<ImpactMRTRow[]>(() => {
    const rows: ImpactMRTRow[] = [];
    getImpactTableRows.forEach(row => {
      // In group/aggregate view, only show BUs that have contracts, submissions, or responses
      if (isGroupView) {
        const hasContracts = teamsWithContracts.has(row.id);
        const hasEntries = (impactEntries[row.id] || []).length > 0;
        const hasResponse = !!buResponses[row.id]?.response;
        const hasOverrides = !!(impactRowData[row.id]?.low || impactRowData[row.id]?.best || impactRowData[row.id]?.high);
        if (!hasContracts && !hasEntries && !hasResponse && !hasOverrides) return;
      }
      const totals = uwTotalsPerBU[row.id] || { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
      const entries = impactEntries[row.id] || [];
      const resp = buResponses[row.id];
      const rowD = impactRowData[row.id] || { low: '', best: '', high: '', notes: '', expectations: '', exposureAsOf: '' };
      const latestEntry = entries.length > 0 ? entries[entries.length - 1] : null;
      // Show current editable row per segment
      const hasContracts = estimates.some(e => e.team === row.id);
      const exposure = resp?.response === 'yes' ? 'Yes' : resp?.response === 'no' ? 'No' : hasContracts ? 'Yes' : 'Pending';
      rows.push({
        id: row.id, segment: row.name,
        hasExposure: exposure,
        reportVersion: Math.max(entries.length, 1),
        asOfDate: latestEntry ? latestEntry.savedAt : new Date().toISOString(),
        uwTotalLow: totals.low, uwTotalBest: totals.best, uwTotalHigh: totals.high,
        overrideLow: rowD.low || '',
        overrideBest: rowD.best || '',
        overrideHigh: rowD.high || '',
        notes: rowD.notes || '',
        expectations: rowD.expectations || '',
        savedReports: entries.length,
        rowType: 'current',
        tracked: trackedBUs.has(row.id),
        contractCount: estimates.filter(e => e.team === row.id).length,
        savedBy: userName || 'Current User',
        expReinstPremiums: totals.expReinst || 0,
        netLoss: totals.netLoss || 0,
      });
      // Show only the latest saved version below the current row (only after 2nd submission)
      if (entries.length > 1) {
        const latest = entries[entries.length - 1];
        rows.push({
          id: `${row.id}-saved-${entries.length}`,
          segment: row.name,
          hasExposure: exposure,
          reportVersion: entries.length,
          asOfDate: latest.savedAt,
          uwTotalLow: 0, uwTotalBest: 0, uwTotalHigh: 0,
          overrideLow: latest.estimateLow || '',
          overrideBest: latest.estimateBest || '',
          overrideHigh: latest.estimateHigh || '',
          notes: latest.notes || '',
          expectations: latest.expectations || '',
          savedReports: entries.length,
          rowType: 'saved',
          tracked: trackedBUs.has(row.id),
          contractCount: estimates.filter(e => e.team === row.id).length,
          parentBuId: row.id,
          savedAt: latest.savedAt,
          savedBy: latest.savedBy,
          expReinstPremiums: totals.expReinst || 0,
          netLoss: totals.netLoss || 0,
        });
      }
    });
    return rows;
  }, [getImpactTableRows, uwTotalsPerBU, impactEntries, buResponses, impactRowData, userName, isGroupView, teamsWithContracts, trackedBUs, estimates]);

  // ─── Exposure Response Handler (hoisted before impactColumns) ─────────
  const handleExposureResponse = (buId: string, response: 'yes' | 'no') => {
    setBuResponses(prev => ({ ...prev, [buId]: { response, rationale: prev[buId]?.rationale || '' } }));
    if (response === 'no') {
      // Inline markBUNoImpact logic to avoid TDZ
      const node = findBUNode(BU_HIERARCHY, buId);
      if (node) {
        const allIds = new Set(collectBUIds(node));
        setEstimates(prev => {
          const u = prev.map(e => allIds.has(e.team) ? { ...e, impacted: false } : e);
          sessionStorage.setItem(`uwEstimates-${eventId}`, JSON.stringify(u));
          return u;
        });
        setBuNoImpact(prev => ({ ...prev, [buId]: true }));
      }
      toast.success(`${BU_NAME_MAP[buId]} marked as No Exposure`);
    }
  };

  // ─── Impact MRT Columns ──────────────────────────────────────────────
  const impactColumns = useMemo<MRT_ColumnDef<ImpactMRTRow>[]>(() => [
    {
      accessorKey: 'segment', header: 'Segment', size: 200, enableColumnFilter: true, enableSorting: true,
      Header: () => (
        <div className="flex items-center gap-1.5">
          <Building2 className="w-3 h-3 text-blue-500" />
          <span className="text-[11px] font-semibold text-slate-600">BUSINESS UNIT</span>
        </div>
      ),
      Cell: ({ cell, row }) => {
        const exposure = row.original.hasExposure;
        const isSaved = row.original.rowType === 'saved';
        if (isSaved) {
          const d = row.original.savedAt ? new Date(row.original.savedAt) : null;
          return (
            <div className="flex items-center gap-2 pl-4">
              <div className="w-1 h-5 rounded-full shrink-0 bg-purple-300" />
              <div className="flex flex-col">
                <span className="text-[11px] text-purple-700 font-medium">v{row.original.reportVersion}</span>
                <span className="text-[9px] text-slate-400">{d ? d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''} · {row.original.savedBy || ''}</span>
              </div>
            </div>
          );
        }
        return (
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-6 rounded-full shrink-0 ${exposure === 'Yes' ? 'bg-green-400' : exposure === 'No' ? 'bg-red-300' : 'bg-slate-200'}`} />
            <div className="flex flex-col">
              <span className="text-[12px] font-medium text-blue-700 truncate cursor-pointer hover:underline" title={`Go to ${cell.getValue<string>()}`} onClick={() => { setSelectedBU(row.original.id); setContentTab('estimates'); }}>{cell.getValue<string>()}</span>
              
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: 'hasExposure', header: 'Has Exposure?', size: 140, enableColumnFilter: true, filterVariant: 'select',
      filterSelectOptions: ['Yes', 'No', 'Pending'],
      Header: () => (
        <div className="flex items-center gap-1">
          <AlertTriangle className="w-3 h-3 text-amber-500" />
          <span className="text-[11px] font-semibold text-slate-600">EXPOSURE?</span>
        </div>
      ),
      Cell: ({ row }) => {
        const buId = row.original.id;
        const val = row.original.hasExposure;
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        // Saved rows: just show a badge
        if (isSaved) {
          return <span className="text-[10px] text-slate-400 italic">—</span>;
        }
        // Group view or finance locked: show status badge (read-only)
        if (isGroupView || eventLocked) {
          return (
            <div className="flex items-center justify-center">
              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium ${val === 'Yes' ? 'bg-green-100 text-green-700' : val === 'No' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-400'}`}>
                {val === 'Yes' && <Check className="w-3 h-3" />}
                {val === 'No' && <X className="w-3 h-3" />}
                {val}
                {eventLocked && <Lock className="w-2.5 h-2.5 ml-0.5 opacity-50" />}
              </span>
            </div>
          );
        }
        const submittedCount = row.original.savedReports || 0;
        return (
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center justify-center gap-1.5">
              <button onClick={() => handleExposureResponse(buId, 'yes')}
                className={`flex items-center gap-1 px-3 py-1 rounded-md text-[11px] font-medium transition-all ${val === 'Yes' ? 'bg-green-600 text-white shadow-md ring-2 ring-green-300 ring-offset-1' : 'bg-slate-50 text-slate-400 border border-slate-200 hover:bg-green-50 hover:text-green-600 hover:border-green-300'}`}>
                {val === 'Yes' && <Check className="w-3 h-3" />}
                Yes
              </button>
              <button onClick={() => handleExposureResponse(buId, 'no')}
                className={`flex items-center gap-1 px-3 py-1 rounded-md text-[11px] font-medium transition-all ${val === 'No' ? 'bg-red-500 text-white shadow-md ring-2 ring-red-300 ring-offset-1' : 'bg-slate-50 text-slate-400 border border-slate-200 hover:bg-red-50 hover:text-red-600 hover:border-red-300'}`}>
                {val === 'No' && <X className="w-3 h-3" />}
                No
              </button>
            </div>
            {submittedCount > 0 && (
              <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200 font-medium">
                <Check className="w-2.5 h-2.5" /> Submitted
              </span>
            )}
          </div>
        );
      },
    },
    {
      accessorKey: 'tracked', header: 'Track', size: 90, enableColumnFilter: true, filterVariant: 'checkbox',
      enableSorting: true,
      Header: () => (
        <div className="flex items-center gap-1 justify-center">
          <Eye className="w-3 h-3 text-cyan-500" />
          <span className="text-[11px] font-semibold text-slate-600">TRACK</span>
        </div>
      ),
      Cell: ({ row }) => {
        const buId = row.original.id;
        const isSaved = row.original.rowType === 'saved';
        const isTracked = row.original.tracked;
        // Check if tracking is required (auto-tracked): event is tracked AND exposure is 'yes'
        const isAutoTracked = event?.tracked && buResponses[buId]?.response === 'yes';
        if (isSaved) return <span className="text-[10px] text-slate-300 italic">—</span>;
        return (
          <div className="flex items-center justify-center">
            <button
              onClick={() => {
                // Prevent untoggling if auto-tracked
                if (isAutoTracked) {
                  toast.info('This business unit is automatically tracked because exposure is "Yes" and the event is tracked');
                  return;
                }
                setTrackedBUs(prev => {
                  const next = new Set(prev);
                  if (next.has(buId)) next.delete(buId); else next.add(buId);
                  return next;
                });
              }}
              className={`relative inline-flex h-5 w-9 shrink-0 rounded-full border-2 transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:ring-offset-2 ${
                isAutoTracked
                  ? 'bg-amber-500 border-amber-500 cursor-not-allowed opacity-90'
                  : isTracked
                  ? 'bg-cyan-500 border-cyan-500 cursor-pointer'
                  : 'bg-slate-200 border-slate-200 cursor-pointer'
              }`}
              role="switch"
              aria-checked={isTracked}
              title={
                isAutoTracked 
                  ? 'Auto-tracked (exposure is Yes and event is tracked) — cannot be disabled' 
                  : isTracked 
                  ? 'Tracking — click to untrack' 
                  : 'Not tracking — click to track'
              }
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full shadow-sm ring-0 transition duration-200 ease-in-out ${
                  isTracked ? 'translate-x-4' : 'translate-x-0'
                } ${
                  isAutoTracked ? 'bg-white' : 'bg-white'
                }`}
              />
              {isAutoTracked && (
                <Lock className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 text-amber-700 pointer-events-none" />
              )}
            </button>
          </div>
        );
      },
    },
    {
      accessorKey: 'reportVersion', header: 'Report #', size: 70, enableColumnFilter: true, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-purple-600">REPORT #</span>,
      Cell: ({ row }) => {
        const v = row.original.reportVersion;
        const count = row.original.savedReports;
        return (
          <div className="flex items-center justify-center">
            <span className={`inline-flex items-center justify-center text-[11px] min-w-[28px] px-2 py-0.5 rounded-full font-medium ${count > 0 ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-400'}`}>
              {v}
            </span>
          </div>
        );
      },
    },
    {
      accessorKey: 'asOfDate', header: 'Last Updated', size: 130, enableColumnFilter: false, enableSorting: true,
      Header: () => (
        <div className="flex items-center gap-1">
          <Calendar className="w-3 h-3 text-slate-400" />
          <span className="text-[11px] font-semibold text-slate-600">LAST UPDATED</span>
        </div>
      ),
      Cell: ({ cell, row }) => {
        const val = cell.getValue<string>();
        const count = row.original.savedReports;
        if (!val || count === 0) return <span className="text-[11px] text-slate-300 italic">No reports yet</span>;
        const d = new Date(val);
        const estStr = d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'America/New_York' });
        return <span className="text-[11px] text-slate-700">{estStr} EST</span>;
      },
    },
    {
      accessorKey: 'savedBy', header: 'Submitted By', size: 130, enableColumnFilter: false, enableSorting: true,
      Header: () => (
        <div className="flex items-center gap-1">
          <UserCheck className="w-3 h-3 text-slate-400" />
          <span className="text-[11px] font-semibold text-slate-600">SUBMITTED BY</span>
        </div>
      ),
      Cell: ({ cell, row }: { cell: any; row: any }) => {
        const val = cell.getValue<string>() || row.original.savedBy;
        const isSaved = row.original.rowType === 'saved';
        if (!val) return <span className="text-[11px] text-slate-300 italic">—</span>;
        return <span className={`text-[11px] ${isSaved ? 'text-purple-600' : 'text-slate-700'}`}>{val}</span>;
      },
    },
    {
      accessorKey: 'uwTotalLow', header: 'UW Low', size: 120, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-blue-500">LOW</span>,
      Cell: ({ row }) => {
        const buId = row.original.id;
        const autoVal = row.original.uwTotalLow;
        const override = row.original.overrideLow;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        if (isNo) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        if (isReadOnly) {
          const display = override || (autoVal > 0 ? formatCurrency(autoVal) : '—');
          return <span className={`text-[12px] text-right block tabular-nums ${isSaved ? 'text-purple-600' : 'text-slate-600'}`}>{display}</span>;
        }
        return (
          <input
            type="text"
            value={override}
            onChange={(e) => updateImpactRow(buId, 'low', e.target.value)}
            placeholder={autoVal > 0 ? formatCurrency(autoVal) : '$0.00M'}
            className="w-full text-[12px] text-right tabular-nums bg-transparent border border-transparent hover:border-blue-200 focus:border-blue-400 focus:bg-white focus:shadow-sm rounded px-2 py-1 outline-none transition-all placeholder:text-blue-400/50"
          />
        );
      },
    },
    {
      accessorKey: 'uwTotalBest', header: 'UW Best', size: 120, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-blue-700">BEST</span>,
      Cell: ({ row }) => {
        const buId = row.original.id;
        const autoVal = row.original.uwTotalBest;
        const override = row.original.overrideBest;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        if (isNo) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        if (isReadOnly) {
          const display = override || (autoVal > 0 ? formatCurrency(autoVal) : '—');
          return <span className={`text-[12px] text-right block font-semibold tabular-nums ${isSaved ? 'text-purple-700' : 'text-slate-700'}`}>{display}</span>;
        }
        return (
          <input
            type="text"
            value={override}
            onChange={(e) => updateImpactRow(buId, 'best', e.target.value)}
            onBlur={() => {
              const raw = override.replace(/[^0-9.\-]/g, '');
              if (raw && !isNaN(Number(raw))) {
                const num = parseFloat(raw);
                updateImpactRow(buId, 'best', `$${num.toFixed(2)}M`);
              }
            }}
            placeholder={autoVal > 0 ? formatCurrency(autoVal) : '$0.00M'}
            className="w-full text-[12px] text-right font-semibold tabular-nums bg-transparent border border-transparent hover:border-blue-200 focus:border-blue-400 focus:bg-white focus:shadow-sm rounded px-2 py-1 outline-none transition-all placeholder:text-blue-600/50"
          />
        );
      },
    },
    {
      accessorKey: 'uwTotalHigh', header: 'UW High', size: 120, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-blue-500">HIGH</span>,
      Cell: ({ row }) => {
        const buId = row.original.id;
        const autoVal = row.original.uwTotalHigh;
        const override = row.original.overrideHigh;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        if (isNo) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        if (isReadOnly) {
          const display = override || (autoVal > 0 ? formatCurrency(autoVal) : '—');
          return <span className={`text-[12px] text-right block tabular-nums ${isSaved ? 'text-purple-600' : 'text-slate-600'}`}>{display}</span>;
        }
        return (
          <input
            type="text"
            value={override}
            onChange={(e) => updateImpactRow(buId, 'high', e.target.value)}
            placeholder={autoVal > 0 ? formatCurrency(autoVal) : '$0.00M'}
            className="w-full text-[12px] text-right tabular-nums bg-transparent border border-transparent hover:border-blue-200 focus:border-blue-400 focus:bg-white focus:shadow-sm rounded px-2 py-1 outline-none transition-all placeholder:text-blue-400/50"
          />
        );
      },
    },
    {
      accessorKey: 'expReinstPremiums', header: 'Exp. Reinst. Premiums', size: 130, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-orange-600">EXP. REINST. PREM.</span>,
      Cell: ({ row }) => {
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        if (isNo) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        const val = row.original.expReinstPremiums;
        if (!val || val === 0) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        return <span className={`text-[12px] text-right block tabular-nums ${isSaved ? 'text-orange-400' : 'text-orange-700'}`}>{formatCurrency(val)}</span>;
      },
    },
    {
      accessorKey: 'netLoss', header: 'Net Loss', size: 120, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[11px] font-semibold text-purple-600">NET LOSS</span>,
      Cell: ({ row }) => {
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        if (isNo) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        const val = row.original.netLoss;
        if (!val || val === 0) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        return <span className={`text-[12px] text-right block font-semibold tabular-nums ${isSaved ? 'text-purple-400' : 'text-purple-700'}`}>{formatCurrency(val)}</span>;
      },
    },
    {
      accessorKey: 'notes', header: 'Notes', size: 400, enableColumnFilter: true, enableSorting: false,
      Header: () => (
        <div className="flex items-center gap-1">
          <MessageSquare className="w-3 h-3 text-slate-400" />
          <span className="text-[11px] font-semibold text-slate-600">NOTES</span>
        </div>
      ),
      Cell: ({ row }) => {
        const buId = row.original.id;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        if (isSaved || isReadOnly) {
          return <span className={`text-[11px] ${isSaved ? 'text-purple-600 italic' : 'text-slate-600'}`}>{row.original.notes || '—'}</span>;
        }
        return (
          <textarea
            value={row.original.notes}
            onChange={(e) => { updateImpactRow(buId, 'notes', e.target.value); e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px'; }}
            onFocus={(e) => { e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px'; }}
            disabled={isNo}
            rows={1}
            placeholder={isNo ? '' : 'Click to add notes...'}
            className="w-full text-[11px] bg-white/50 border border-slate-100 hover:border-blue-200 focus:border-blue-400 focus:bg-white focus:shadow-sm rounded-md px-2.5 py-1.5 outline-none disabled:opacity-20 disabled:cursor-not-allowed disabled:bg-transparent disabled:border-transparent transition-all placeholder:text-slate-300 placeholder:italic resize-none overflow-hidden"
            style={{ minHeight: '28px' }}
          />
        );
      },
    },
    {
      accessorKey: 'expectations', header: 'Expectations', size: 400, enableColumnFilter: true, enableSorting: false,
      Header: () => (
        <div className="flex items-center gap-1">
          <Eye className="w-3 h-3 text-slate-400" />
          <span className="text-[11px] font-semibold text-slate-600">EXPECTATIONS</span>
        </div>
      ),
      Cell: ({ row }) => {
        const buId = row.original.id;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        const isReadOnly = isSaved || isGroupView || eventLocked;
        if (isSaved || isReadOnly) {
          return <span className={`text-[11px] ${isSaved ? 'text-purple-600 italic' : 'text-slate-600'}`}>{row.original.expectations || '—'}</span>;
        }
        return (
          <textarea
            value={row.original.expectations}
            onChange={(e) => { updateImpactRow(buId, 'expectations', e.target.value); e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px'; }}
            onFocus={(e) => { e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px'; }}
            disabled={isNo}
            rows={1}
            placeholder={isNo ? '' : 'Click to add expectations...'}
            className="w-full text-[11px] bg-white/50 border border-slate-100 hover:border-blue-200 focus:border-blue-400 focus:bg-white focus:shadow-sm rounded-md px-2.5 py-1.5 outline-none disabled:opacity-20 disabled:cursor-not-allowed disabled:bg-transparent disabled:border-transparent transition-all placeholder:text-slate-300 placeholder:italic resize-none overflow-hidden"
            style={{ minHeight: '28px' }}
          />
        );
      },
    },
    {
      id: 'impactActions', header: 'Actions', size: 150, enableColumnFilter: false, enableSorting: false,
      Header: () => <span className="text-[11px] font-semibold text-slate-600">ACTIONS</span>,
      Cell: ({ row }) => {
        const buId = row.original.id;
        const count = row.original.savedReports;
        const isNo = row.original.hasExposure === 'No';
        const isSaved = row.original.rowType === 'saved';
        if (isNo) return <span className="text-[10px] text-slate-300 italic">N/A</span>;
        // Saved rows: show timestamp only
        if (isSaved) {
          const d = row.original.savedAt ? new Date(row.original.savedAt) : null;
          return (
            <span className="text-[10px] text-purple-400 italic">
              {d ? d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Saved'}
            </span>
          );
        }
        // Group view or finance locked: read-only, no action buttons
        if (isGroupView || eventLocked) {
          return (
            <div className="flex items-center gap-1.5">
              <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 bg-slate-100 text-slate-500 border border-slate-200 rounded-md">
                <Lock className="w-3 h-3" /> {eventLocked ? 'Locked' : 'View Only'}
              </span>
              {count > 0 && (
                <button
                  onClick={() => setShowImpactHistory(buId)}
                  title={`View ${count} saved report(s)`}
                  className="flex items-center gap-1 text-[11px] px-2 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded-md hover:bg-purple-100 hover:shadow-sm transition-all"
                >
                  <Clock className="w-3 h-3" /> {count}
                </button>
              )}
            </div>
          );
        }
        return (
          <div className="flex items-center gap-1.5">
            
            {count > 0 ? (
              <button
                onClick={() => setShowImpactHistory(buId)}
                title={`View ${count} saved report(s)`}
                className="flex items-center gap-1 text-[11px] px-2 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded-md hover:bg-purple-100 hover:shadow-sm transition-all"
              >
                <Clock className="w-3 h-3" /> {count} report{count !== 1 ? 's' : ''}
              </button>
            ) : (
              <span className="text-[10px] text-slate-300 italic">No history</span>
            )}
          </div>
        );
      },
    },
  ], [updateImpactRow, saveImpactRow, isGroupView, eventLocked]);

  // ─── Impact MRT Table Instance ────────────────────────────────────────
  const impactTable = useMaterialReactTable({
    columns: impactColumns, data: impactMRTData,
    enableColumnFilters: true, enableGlobalFilter: false, enablePagination: false,
    enableRowVirtualization: false, enableStickyHeader: true, enableDensityToggle: false,
    enableFullScreenToggle: false, enableHiding: true, enableColumnActions: false, enableToolbarInternalActions: false,
    enableColumnResizing: true, enableSorting: true, columnFilterDisplayMode: 'popover',
    enableColumnPinning: true, enableTopToolbar: false,
    initialState: {
      density: 'comfortable', showColumnFilters: false,
      columnPinning: { left: ['segment', 'hasExposure'] },
    },
    state: { columnFilters: impactColumnFilters },
    onColumnFiltersChange: setImpactColumnFilters,
    muiTableHeadCellProps: { sx: MRT_HEAD_CELL_SX },
    muiTableBodyCellProps: { sx: { ...MRT_BODY_CELL_SX, verticalAlign: 'top', whiteSpace: 'normal', wordBreak: 'break-word' } },
    muiTablePaperProps: { sx: { ...MRT_PAPER_SX, boxShadow: 'none' } },
    muiTableContainerProps: { sx: { maxHeight: 'calc(100vh - 300px)', overflow: 'auto' } },
    getRowId: (row) => row.id,
    muiTableBodyRowProps: ({ row }) => {
      const isSaved = row.original.rowType === 'saved';
      const isNoExposure = row.original.hasExposure === 'No';
      const isYesExposure = row.original.hasExposure === 'Yes';
      if (isNoExposure) {
        return { sx: { opacity: 0.45, backgroundColor: '#f8fafc !important', '&:hover': { opacity: 0.65, backgroundColor: '#f1f5f9 !important' } } };
      }
      if (isSaved) {
        return { sx: { backgroundColor: '#faf5ff !important', borderLeft: '3px solid #c084fc', '&:hover': { backgroundColor: '#f3e8ff !important' } } };
      }
      if (isYesExposure) {
        return { sx: { backgroundColor: '#f0fdf4 !important', borderLeft: '3px solid #22c55e', '&:hover': { backgroundColor: '#dcfce7 !important' } } };
      }
      if (isGroupView) {
        return { sx: { backgroundColor: '#f8fafc !important', '&:hover': { backgroundColor: '#f1f5f9 !important' } } };
      }
      return { sx: { '&:hover': { backgroundColor: '#eff6ff !important' } } };
    },
    renderTopToolbarCustomActions: () => null,
  });

  // ─── Upload Modal State ───────────────────────────────────────────────
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadDragActive, setUploadDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadPreview, setUploadPreview] = useState<any[] | null>(null);
  const [uploadComment, setUploadComment] = useState('');
  const uploadFileRef = useRef<HTMLInputElement>(null);

  // ─── Import Validation State ──────────────────────────────────────────
  const [importValidationErrors, setImportValidationErrors] = useState<Record<string, { unmatchedContract: string; rowData: Record<string, any> }>>({});
  const [importedContracts, setImportedContracts] = useState<Set<string>>(new Set());

  // ─── Submission / Approval State ──────────────────────────────────────
  const [teamSubmissions, setTeamSubmissions] = useState<Record<string, SubmissionStatus>>({});
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [submitComment, setSubmitComment] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectingBU, setRejectingBU] = useState<string | null>(null);
  const [submissionVersions, setSubmissionVersions] = useState<Record<string, SubmissionVersion[]>>({});
  const [showSubmissionSummary, setShowSubmissionSummary] = useState<SubmissionVersion | null>(null);
  const [showVersionHistory, setShowVersionHistory] = useState(false);

  // ─── FX & IBNR helpers ────────────────────────────────────────────────
  const fxRateMap: Record<string, string> = {
    'USD': '1.00', 'EUR': '0.92', 'GBP': '0.79', 'CLP': '950.00',
    'BRL': '5.15', 'JPY': '149.50', 'CAD': '1.35', 'MXN': '17.15',
  };
  const teamRiskMap: Record<string, string> = {
    'latam-fac': 'Chile', 'latam-brazil-treaty': 'Chile', 'singapore-treaty': 'Taiwan',
    'dublin': 'Worldwide', 'zurich': 'Worldwide', 'treaty-property': 'United States',
    'bermuda-treaty': 'Worldwide', 'fac-property': 'United States',
    'fac-casualty': 'United States', 'canada-fac': 'Canada', 'london-fac': 'Turkey',
    'singapore-fac': 'Japan', 'aviation': 'Worldwide', 'marine': 'Worldwide', 'mortgage': 'United States',
  };
  const ibnrMap: Record<string, string> = {
    'LAF - Property': 'NC_PROPPRI', 'LAF - Casualty': 'NC_E&O_D&O',
    'LAF - Marine': 'LA_MCARGPR', 'LAF - Engineering': 'ENG_PR',
    'LAT - Property Cat': 'NC_PROPCAT', 'LAT - Property Pro': 'NC_PROP_PR', 'LAT - Property Excess': 'NC_PROP_XS',
    'LAT - Marine': 'LA_MHULLPR', 'LAT - Parametric': 'PTS_CAT', 'LAT - A&H': 'EB_AH_CAT',
    'DU - Marine': 'DU_MARXL', 'DU - Engineering': 'ENG_XS', 'DU - Aviation': 'LB_GENAVXS', 'DU - A&H': 'DU_AHXL',
    'ZU - Marine': 'ZU_MARXL', 'ZU - Parametric': 'PTS_XS', 'ZU - Engineering': 'ENG_XS', 'ZU - Aviation': 'LV_GENAVXS', 'ZU - A&H': 'ZU_AHXL',
    'LN - Marine': 'LN_MARXL', 'LN - Engineering': 'LN_ENGPR', 'LN - Parametric': 'PTS_PR', 'LN - Aviation': 'LN_AVIPR', 'LN - A&H': 'LN_AHXL',
    'BM - Marine': 'MAR_XS', 'BM - Engineering': 'ENG_PR', 'BM - US Mortgage': 'BR_US_MI', 'BM - Aviation': 'LB_GENAVPR', 'BM - A&H': 'BM_A&H_XL',
    'TP - Marine': 'MAR_RETXS', 'TP - Property': 'E*_PROPCAT', 'TP - Parametric': 'PTS_RETRO', 'TP - A&H': 'A&H_XL',
    'AS - Property': 'Z*_TPHI_XS', 'AS - Marine': 'Z*_TMAR_PR', 'AS - Aviation': 'LB_GENAVXS',
    'BM -': 'BR_MULTILN',
    'FP -': 'G*_PROP_XS', 'FC - Cyber': 'CYBER_PR', 'FC - Specialty': 'UA_E&O_D&O',
    'FC - Casualty': 'T*_GENLIAB', 'CF - Casualty': 'JA_AUTOLIA', 'CF - Property': 'JA_PROP_PR',
    'LF - Marine': 'LF_PROPPRI', 'LF -': 'LF_PROPPRI',
    'ASF -': 'Z*_FPRP_XS', 'LV -': 'LV_AVRETRO',
    'LN -': 'LN_ENGPR',
  };
  function resolveIBNR(rl: string): string {
    for (const k of Object.keys(ibnrMap).sort((a, b) => b.length - a.length)) { if (rl.startsWith(k)) return ibnrMap[k]; }
    return 'UNKNOWN';
  }

  // ─── Initialize estimates ─────────────────────────────────────────────
  useEffect(() => {
    try {
      const sv = sessionStorage.getItem(`uwEstimates-version-${eventId}`);
      const se = sessionStorage.getItem(`uwEstimates-${eventId}`);
      if (sv === DATA_VERSION && se) { const l = JSON.parse(se); if (Array.isArray(l) && l.length === allContracts.length) { setEstimates(l); return; } }
    } catch { /* reinit */ }

    const initial: ContractEstimate[] = allContracts.map((contract) => {
      let team = resolveTeam(contract.reportingLevel);
      const ibnrCode = resolveIBNR(contract.reportingLevel);
      const product = resolveProduct(ibnrCode);
      // Marine & Aviation are profit centers — override team to their own BU
      if (product === 'Marine') team = 'marine';
      else if (product === 'Aviation') team = 'aviation';
      const teamName = BU_NAME_MAP[team] || team;
      const originalCurrency = contract.currency || 'USD';
      const fxRate = fxRateMap[originalCurrency] || '1.00';
      const mainRisk = teamRiskMap[team] || 'Worldwide';
      // Modeled products: Property CAT, Property PR, Property Risk, Engineering, Parametric, some Marine
      const modeledProducts = ['Property CAT', 'Property PR', 'Property Risk', 'Engineering', 'Parametric'];
      const isFullyModeled = modeledProducts.includes(product);
      // ~60% of Marine contracts are modeled (deterministic by contract number hash)
      const isMarineModeled = product === 'Marine' && (contract.contractNumber || '').split('').reduce((s: number, c: string) => s + c.charCodeAt(0), 0) % 5 !== 0;
      const modelImpacted = isFullyModeled || isMarineModeled;
      const baseVal = parseCurrency(contract.limit) * (parseFloat(contract.everestLine || '1') / 100) * 0.05;
      const v = 0.25;
      const uwLow = modelImpacted ? baseVal * (1 - v) : 0;
      const uwMed = modelImpacted ? baseVal : 0;
      const uwHigh = modelImpacted ? baseVal * (1 + v) : 0;
      const mv = 0.95 + Math.random() * 0.1;
      const mMed = modelImpacted ? baseVal * mv : 0;
      const grossLimit = parseCurrency(contract.limit);
      const sharePercent = parseFloat(contract.everestLine || '0') / 100;
      const everestLimitVal = grossLimit * sharePercent;
      const premiumVal = everestLimitVal * (0.01 + Math.random() * 0.04); // 1-5% of Everest limit
      return {
        ...contract, team, teamName, impacted: modelImpacted, modelImpacted,
        limit: formatCurrency(grossLimit),
        deductible: formatCurrency(parseCurrency(contract.deductible)),
        uwEstimateLow: uwMed > 0 ? formatCurrency(uwLow) : '', uwEstimateMed: uwMed > 0 ? formatCurrency(uwMed) : '',
        uwEstimateHigh: uwMed > 0 ? formatCurrency(uwHigh) : '',
        modelingLow: modelImpacted ? formatCurrency(mMed * 0.75) : '-',
        modelingMed: modelImpacted ? formatCurrency(mMed) : '-',
        modelingHigh: modelImpacted ? formatCurrency(mMed * 1.25) : '-',
        ibnrCode, product, mainRisk, notes: '', fxRate, originalCurrency,
        premium: premiumVal > 0 ? formatCurrency(premiumVal) : '$0.00M',
        everestLimit: everestLimitVal > 0 ? formatCurrency(everestLimitVal) : '$0.00M',
        everestOccurrenceLimit: everestLimitVal > 0 ? formatCurrency(everestLimitVal * (0.6 + Math.random() * 0.4)) : '$0.00M',
        // RIP%: 100% for XL (some randomly left blank to simulate real data); blank for non-XL
        ripPercent: contract.programType === 'XL'
          ? (Math.random() > 0.15 ? '100%' : '')  // ~85% of XL get 100%, rest left blank
          : '',
        estimateVersion: 1, estimateAsOf: new Date().toISOString(),
      };
    });
    setEstimates(initial);
    sessionStorage.setItem(`uwEstimates-${eventId}`, JSON.stringify(initial));
    sessionStorage.setItem(`uwEstimates-version-${eventId}`, DATA_VERSION);

    // Auto-seed buResponses: BUs with at least one modeled contract default to 'yes'
    const modeledBUs = new Set<string>();
    initial.forEach(e => { if (e.modelImpacted) modeledBUs.add(e.team); });
    const autoResponses: Record<string, { response: 'yes' | 'no' | null; rationale: string }> = {};
    modeledBUs.forEach(buId => { autoResponses[buId] = { response: 'yes', rationale: 'Auto-set: modeled contracts detected' }; });
    setBuResponses(autoResponses);

    // Auto-seed trackedBUs: BUs with at least one contract are tracked by default
    const busWithContracts = new Set<string>();
    initial.forEach(e => busWithContracts.add(e.team));
    setTrackedBUs(busWithContracts);
  }, [eventId]);

  // ─── Persist ──────────────────────────────────────────────────────────
  const persistEstimates = useCallback((updated: ContractEstimate[]) => {
    sessionStorage.setItem(`uwEstimates-${eventId}`, JSON.stringify(updated));
  }, [eventId]);

  // ─── Impact checkbox ────────────────────────��─────────────────────────
  const toggleImpact = useCallback((cn: string) => {
    setEstimates(prev => { const u = prev.map(e => e.contractNumber === cn ? { ...e, impacted: !e.impacted } : e); persistEstimates(u); return u; });
  }, [persistEstimates]);

  // ─── Update field ─────────────────────────────────────────────────────
  const updateField = useCallback((cn: string, field: keyof ContractEstimate, value: string) => {
    setEstimates(prev => { const u = prev.map(e => e.contractNumber === cn ? { ...e, [field]: value } : e); persistEstimates(u); return u; });
  }, [persistEstimates]);

  // ─── Save Estimate Snapshot ────────────────────────────────────────────
  const saveEstimateSnapshot = useCallback((cn: string) => {
    const est = estimates.find(e => e.contractNumber === cn);
    if (!est) return;
    const currentVersion = est.estimateVersion;
    const snapshot: EstimateSnapshot = {
      id: `${cn}-v${currentVersion}-${Date.now()}`,
      contractNumber: cn, version: currentVersion,
      asOfDate: new Date().toISOString(),
      savedAt: new Date().toISOString(),
      savedBy: userName || 'Current User',
      uwEstimateLow: est.uwEstimateLow, uwEstimateMed: est.uwEstimateMed,
      uwEstimateHigh: est.uwEstimateHigh, notes: est.notes,
    };
    setEstimateSnapshots(prev => ({
      ...prev,
      [cn]: [...(prev[cn] || []), snapshot],
    }));
    // Increment version and update asOf on the live estimate
    setEstimates(prev => {
      const u = prev.map(e => e.contractNumber === cn ? { ...e, estimateVersion: currentVersion + 1, estimateAsOf: new Date().toISOString() } : e);
      persistEstimates(u); return u;
    });
    toast.success(`Snapshot v${currentVersion} saved for ${est.cedant || cn}`);
  }, [estimates, persistEstimates, userName]);

  const handleBlurField = useCallback((cn: string, field: keyof ContractEstimate, value: string) => {
    let num = parseCurrency(value);
    // Reverse-convert from display currency back to USD for storage
    if (displayCurrency !== 'USD' && displayCurrency !== 'ORIGINAL') {
      const rate = USD_TO_RATE[displayCurrency] || 1;
      if (rate > 0) num = num / rate;
    }
    updateField(cn, field, num > 0 ? formatCurrency(num) : value);
  }, [updateField, displayCurrency]);

  // ─── Filter by BU ─────────────────────────────────────────────────────
  const isProductBUSelected = isProductSelection(selectedBU);

  const filteredEstimates = useMemo(() => {
    if (!selectedBU) return estimates;
    if (isProductBUSelected) {
      // Product node selected → filter by product name, show ONLY matching contracts
      if (selectedBU === 'product') {
        // Parent "Product" node → show all contracts that have a recognized product
        const allProductNames = new Set(Object.values(PRODUCT_NODE_TO_NAME));
        return estimates.filter(e => allProductNames.has(e.product));
      }
      const productName = PRODUCT_NODE_TO_NAME[selectedBU];
      return productName ? estimates.filter(e => e.product === productName) : estimates;
    }
    const node = findBUNode(BU_HIERARCHY, selectedBU);
    if (!node) return estimates;
    const allIds = new Set(collectBUIds(node));
    return estimates.filter(e => allIds.has(e.team));
  }, [estimates, selectedBU, isProductBUSelected]);

  // Determine which product name(s) are "native" for the selected Product node
  // When 'marine' is selected → native = contracts with product === 'Marine'
  // When 'product' (parent) is selected → ALL product names are native
  const nativeProductNames = useMemo(() => {
    if (!isProductBUSelected || !selectedBU) return new Set<string>();
    if (selectedBU === 'product') {
      // Parent "Product" node → all product names are native
      return new Set(Object.values(PRODUCT_NODE_TO_NAME));
    }
    const productName = PRODUCT_NODE_TO_NAME[selectedBU];
    return productName ? new Set([productName]) : new Set<string>();
  }, [selectedBU, isProductBUSelected]);

  // Helper: is this contract "foreign" in the Product view? (belongs to another product)
  const isProductForeign = useCallback((estimate: ContractEstimate): boolean => {
    if (!isProductBUSelected) return false;
    return !nativeProductNames.has(estimate.product);
  }, [isProductBUSelected, nativeProductNames]);

  // ─── Currency Conversion ──────────────────────────────────────────────
  const convertCurrencyValue = useCallback((usdFormatted: string, origCur: string, origFx: string): string => {
    if (displayCurrency === 'USD') return usdFormatted;
    const val = parseCurrency(usdFormatted);
    if (val === 0 || usdFormatted === '-' || usdFormatted === '') return usdFormatted;
    if (displayCurrency === 'ORIGINAL') {
      const rate = parseFloat(origFx) || 1;
      return formatCurrencySymbol(val * rate, CUR_SYMBOLS[origCur] || '$');
    }
    const rate = USD_TO_RATE[displayCurrency] || 1;
    return formatCurrencySymbol(val * rate, CUR_SYMBOLS[displayCurrency]);
  }, [displayCurrency]);

  const displayEstimates = useMemo(() => {
    if (displayCurrency === 'USD') return filteredEstimates;
    return filteredEstimates.map(e => {
      const cv = (v: string) => convertCurrencyValue(v, e.originalCurrency, e.fxRate);
      const fxDisplay = displayCurrency === 'ORIGINAL'
        ? e.fxRate
        : (USD_TO_RATE[displayCurrency] || 1).toFixed(4);
      return {
        ...e,
        limit: cv(e.limit),
        everestLimit: cv(e.everestLimit),
        everestOccurrenceLimit: cv(e.everestOccurrenceLimit),
        deductible: cv(e.deductible),
        premium: cv(e.premium),
        uwEstimateLow: cv(e.uwEstimateLow),
        uwEstimateMed: cv(e.uwEstimateMed),
        uwEstimateHigh: cv(e.uwEstimateHigh),
        modelingLow: cv(e.modelingLow),
        modelingMed: cv(e.modelingMed),
        modelingHigh: cv(e.modelingHigh),
        fxRate: fxDisplay,
        originalCurrency: displayCurrency === 'ORIGINAL' ? e.originalCurrency : displayCurrency,
      };
    });
  }, [filteredEstimates, displayCurrency, convertCurrencyValue]);

  // ─── Apply Impact Filter ───────────────────────────────────────────────
  const impactFilteredEstimates = useMemo(() => {
    if (impactFilter === 'all') return displayEstimates;
    if (impactFilter === 'impacted') return displayEstimates.filter(e => e.impacted);
    return displayEstimates.filter(e => !e.impacted);
  }, [displayEstimates, impactFilter]);

  // ─── Select All / Deselect All ────────────────────────────────────────
  const selectAllVisible = useCallback(() => {
    const ids = new Set(filteredEstimates.map(e => e.contractNumber));
    setEstimates(prev => { const u = prev.map(e => ids.has(e.contractNumber) ? { ...e, impacted: true } : e); persistEstimates(u); return u; });
    toast.success(`Marked ${ids.size} contracts as impacted`);
  }, [filteredEstimates, persistEstimates]);

  const deselectAllVisible = useCallback(() => {
    const ids = new Set(filteredEstimates.map(e => e.contractNumber));
    setEstimates(prev => { const u = prev.map(e => ids.has(e.contractNumber) ? { ...e, impacted: false } : e); persistEstimates(u); return u; });
    toast.success(`Cleared impact on ${ids.size} contracts`);
  }, [filteredEstimates, persistEstimates]);

  // ─── BU-level No Impact ───────────────────────────────────────────────
  const markBUNoImpact = useCallback((buId: string) => {
    const node = findBUNode(BU_HIERARCHY, buId); if (!node) return;
    const allIds = new Set(collectBUIds(node));
    setEstimates(prev => { const u = prev.map(e => allIds.has(e.team) ? { ...e, impacted: false } : e); persistEstimates(u); return u; });
    setBuNoImpact(prev => ({ ...prev, [buId]: true }));
    toast.success(`Marked all contracts under "${BU_NAME_MAP[buId] || buId}" as Not Impacted`);
  }, [persistEstimates]);

  // ─── Contract counts ──────────────────────────────────────────────────
  const { contractCounts, impactedCounts } = useMemo(() => {
    const counts: Record<string, number> = {};
    const imp: Record<string, number> = {};
    estimates.forEach(e => { counts[e.team] = (counts[e.team] || 0) + 1; if (e.impacted) imp[e.team] = (imp[e.team] || 0) + 1; });
    // Product children: count by product name (handles cross-BU products like A&H)
    const productCounts: Record<string, number> = {};
    const productImp: Record<string, number> = {};
    estimates.forEach(e => {
      if (e.product && e.product !== '—') {
        productCounts[e.product] = (productCounts[e.product] || 0) + 1;
        if (e.impacted) productImp[e.product] = (productImp[e.product] || 0) + 1;
      }
    });
    // Override Product node counts with product-based counts
    Object.entries(PRODUCT_NODE_TO_NAME).forEach(([nodeId, productName]) => {
      counts[nodeId] = productCounts[productName] || 0;
      imp[nodeId] = productImp[productName] || 0;
    });
    function rollup(node: BUNode): { t: number; i: number } {
      let t = counts[node.id] || 0, i = imp[node.id] || 0;
      if (node.children) node.children.forEach(c => { const s = rollup(c); t += s.t; i += s.i; });
      counts[node.id] = t; imp[node.id] = i; return { t, i };
    }
    // Rollup non-Product hierarchy normally
    BU_HIERARCHY.filter(n => n.id !== 'product').forEach(n => rollup(n));
    // For Product parent, sum up children (already set by product-based counts)
    const productNode = BU_HIERARCHY.find(n => n.id === 'product');
    if (productNode) rollup(productNode);
    return { contractCounts: counts, impactedCounts: imp };
  }, [estimates]);

  // ─── BU submission statuses for tree icons ────────────────────────────
  const buStatuses = useMemo(() => {
    const s: Record<string, string> = {};
    Object.entries(teamSubmissions).forEach(([k, v]) => { s[k] = v.status; });
    return s;
  }, [teamSubmissions]);

  // ─── Summary stats ────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const vis = filteredEstimates;
    const impacted = vis.filter(e => e.impacted);
    return {
      total: vis.length,
      impactedCount: impacted.length,
      modelImpactedCount: vis.filter(e => e.modelImpacted).length,
      totalUWLow: impacted.reduce((s, e) => s + parseCurrency(e.uwEstimateLow), 0),
      totalUWMed: impacted.reduce((s, e) => s + parseCurrency(e.uwEstimateMed), 0),
      totalUWHigh: impacted.reduce((s, e) => s + parseCurrency(e.uwEstimateHigh), 0),
      totalExpReinst: impacted.reduce((s, e) => s + calcExpReinstPremium(e), 0),
      totalNetLoss: impacted.reduce((s, e) => s + (parseCurrency(e.uwEstimateMed) - calcExpReinstPremium(e)), 0),
    };
  }, [filteredEstimates]);

  // ─── Publish portfolio data to nav sidebar context ────────────────────
  useEffect(() => {
    publishPortfolioData({
      contractCounts,
      impactedCounts,
      buStatuses,
      portfolioStats: {
        total: stats.total,
        impactedCount: stats.impactedCount,
        totalUWMed: stats.totalUWMed,
      },
      displayCurrency,
      totalEstimatesCount: estimates.length,
    });
  }, [contractCounts, impactedCounts, buStatuses, stats, displayCurrency, estimates.length, publishPortfolioData]);

  // ─── Impact Assessment handlers ───────────────────────────────────────
  const currentBUName = selectedBU ? (BU_NAME_MAP[selectedBU] || selectedBU) : '';
  const currentResponse = selectedBU ? buResponses[selectedBU] : null;
  const currentEntries = selectedBU ? (impactEntries[selectedBU] || []) : [];

  const saveImpactEntry = () => {
    if (!selectedBU) return;
    const entry: ImpactEntry = {
      id: editingEntryId || Date.now().toString(), buId: selectedBU,
      notes: impactForm.notes, expectations: impactForm.expectations,
      exposureAsOf: impactForm.exposureAsOf,
      estimateLow: impactForm.estimateLow, estimateBest: impactForm.estimateBest, estimateHigh: impactForm.estimateHigh,
      attachments: impactForm.attachments, savedAt: new Date().toISOString(),
      savedBy: userName || 'Current User', sentToManagement: false,
    };
    setImpactEntries(prev => {
      const list = prev[selectedBU] || [];
      if (editingEntryId) {
        return { ...prev, [selectedBU]: list.map(e => e.id === editingEntryId ? entry : e) };
      }
      return { ...prev, [selectedBU]: [...list, entry] };
    });
    setImpactForm({ notes: '', expectations: '', exposureAsOf: new Date().toISOString().split('T')[0], estimateLow: '', estimateBest: '', estimateHigh: '', attachments: [] });
    setEditingEntryId(null);
    toast.success(editingEntryId ? 'Entry updated' : 'Risk details saved');
  };

  const sendEntryToManagement = (entryId: string) => {
    if (!selectedBU) return;
    setImpactEntries(prev => ({
      ...prev,
      [selectedBU]: (prev[selectedBU] || []).map(e => e.id === entryId ? { ...e, sentToManagement: true, sentAt: new Date().toISOString() } : e)
    }));
    toast.success('Sent to management');
  };

  const handleImpactFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newAttachments = Array.from(files).map(f => ({
      name: f.name, type: f.type || 'unknown',
      size: f.size > 1048576 ? `${(f.size / 1048576).toFixed(1)} MB` : `${(f.size / 1024).toFixed(1)} KB`,
    }));
    setImpactForm(prev => ({ ...prev, attachments: [...prev.attachments, ...newAttachments] }));
  };

  // ─── Excel Upload handlers ────────────────────────────────────────────
  const handleUploadFile = (file: File) => {
    setUploadedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
        if (json.length > 1) {
          const headers = json[0] as string[];
          const rows = json.slice(1, 11).map(row => {
            const obj: Record<string, any> = {};
            headers.forEach((h, i) => { obj[h] = row[i]; });
            return obj;
          });
          setUploadPreview(rows);
        }
      } catch { toast.error('Failed to parse Excel file'); }
    };
    reader.readAsArrayBuffer(file);
  };

  const processUpload = () => {
    if (!uploadedFile) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(ws) as any[];
        let matched = 0;
        let unmatched = 0;
        const newErrors: Record<string, { unmatchedContract: string; rowData: Record<string, any> }> = {};
        const newImported = new Set<string>();
        setEstimates(prev => {
          const updated = [...prev];
          json.forEach(row => {
            const cn = String(row['Contract #'] || row['ContractNumber'] || row['contract_number'] || row['Revised Contract #'] || '').trim();
            if (!cn) return;
            const idx = updated.findIndex(e => e.contractNumber === cn);
            if (idx >= 0) {
              matched++;
              newImported.add(cn);
              const low = row['UW Low'] || row['uwEstimateLow']; if (low) updated[idx] = { ...updated[idx], uwEstimateLow: String(low) };
              const med = row['UW Best'] || row['uwEstimateMed']; if (med) updated[idx] = { ...updated[idx], uwEstimateMed: String(med) };
              const high = row['UW High'] || row['uwEstimateHigh']; if (high) updated[idx] = { ...updated[idx], uwEstimateHigh: String(high) };
              const notes = row['Notes'] || row['notes']; if (notes) updated[idx] = { ...updated[idx], notes: String(notes) };
              if (low || med || high) updated[idx] = { ...updated[idx], impacted: true };

              // ─── RDM Validation: check Revised Contract # vs Contract # ───
              const revisedCN = String(row['Revised Contract #'] || row['RevisedContractNumber'] || '').trim();
              if (revisedCN && revisedCN !== cn) {
                // Revised contract number doesn't match — flag as validation error
                const revisedIdx = updated.findIndex(e => e.contractNumber === revisedCN);
                if (revisedIdx < 0) {
                  newErrors[cn] = { unmatchedContract: revisedCN, rowData: row };
                }
              }
            } else {
              unmatched++;
              newErrors[cn] = { unmatchedContract: cn, rowData: row };
            }
          });
          persistEstimates(updated);
          return updated;
        });
        setImportValidationErrors(newErrors);
        setImportedContracts(newImported);
        const errorCount = Object.keys(newErrors).length;
        if (errorCount > 0) {
          toast.error(`${errorCount} contract(s) did not match — highlighted in red`);
        }
        toast.success(`Imported ${matched} matched, ${unmatched} unmatched of ${json.length} rows`);
        setShowUploadModal(false);
        setUploadedFile(null);
        setUploadPreview(null);
        setUploadComment('');
      } catch { toast.error('Failed to process upload'); }
    };
    reader.readAsArrayBuffer(uploadedFile);
  };

  // ─── Submission handlers ──────────────────────────────────────────────
  const handleSubmit = () => {
    if (!selectedBU) { toast.error('Select a business unit first'); return; }
    setShowSubmitModal(true);
  };

  const confirmSubmit = () => {
    if (!selectedBU) return;
    // Build version snapshot of all impact data for this BU
    const leafBUs = getImpactTableRows;
    const prevVersions = submissionVersions[selectedBU] || [];
    const versionNum = prevVersions.length + 1;
    const segments = leafBUs.map(leaf => {
      const resp = buResponses[leaf.id];
      const rowD = impactRowData[leaf.id] || { low: '', best: '', high: '', notes: '', expectations: '', exposureAsOf: '' };
      const totals = uwTotalsPerBU[leaf.id] || { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
      return {
        buId: leaf.id, segment: leaf.name,
        hasExposure: resp?.response === 'yes' ? 'Yes' : resp?.response === 'no' ? 'No' : 'Pending',
        low: rowD.low || (totals.low > 0 ? formatCurrency(totals.low) : ''),
        best: rowD.best || (totals.best > 0 ? formatCurrency(totals.best) : ''),
        high: rowD.high || (totals.high > 0 ? formatCurrency(totals.high) : ''),
        notes: rowD.notes, expectations: rowD.expectations,
      };
    });
    const impactDecisions: Record<string, 'yes' | 'no' | null> = {};
    leafBUs.forEach(leaf => { impactDecisions[leaf.id] = buResponses[leaf.id]?.response || null; });
    const totalLow = segments.reduce((s, seg) => s + parseCurrency(seg.low), 0);
    const totalBest = segments.reduce((s, seg) => s + parseCurrency(seg.best), 0);
    const totalHigh = segments.reduce((s, seg) => s + parseCurrency(seg.high), 0);

    const version: SubmissionVersion = {
      id: `${selectedBU}-v${versionNum}-${Date.now()}`,
      version: versionNum, buId: selectedBU,
      submittedBy: userName || 'Current User',
      submittedAt: new Date().toISOString(),
      comment: submitComment,
      impactDecisions, segments,
      totals: { low: totalLow, best: totalBest, high: totalHigh },
      contractCount: stats.total,
      impactedCount: stats.impactedCount,
    };

    setSubmissionVersions(prev => ({
      ...prev,
      [selectedBU]: [...(prev[selectedBU] || []), version],
    }));

    // Also save an impact entry for each leaf BU so the purple saved row appears in the table
    leafBUs.forEach(leaf => {
      const rowD = impactRowData[leaf.id] || { low: '', best: '', high: '', notes: '', expectations: '', exposureAsOf: '' };
      const tots = uwTotalsPerBU[leaf.id] || { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
      const entry: ImpactEntry = {
        id: `submit-${Date.now()}-${leaf.id}`, buId: leaf.id,
        notes: rowD.notes || '', expectations: rowD.expectations || '',
        exposureAsOf: rowD.exposureAsOf || new Date().toISOString().split('T')[0],
        estimateLow: rowD.low || (tots.low > 0 ? formatCurrency(tots.low) : ''),
        estimateBest: rowD.best || (tots.best > 0 ? formatCurrency(tots.best) : ''),
        estimateHigh: rowD.high || (tots.high > 0 ? formatCurrency(tots.high) : ''),
        attachments: [], savedAt: new Date().toISOString(), savedBy: userName || 'Current User', sentToManagement: true,
      };
      setImpactEntries(prev => ({ ...prev, [leaf.id]: [...(prev[leaf.id] || []), entry] }));
    });

    // Update submission status (does NOT lock — UW can keep editing & resubmitting)
    const submission: SubmissionStatus = {
      buId: selectedBU, submittedBy: userName || 'Current User',
      submittedAt: new Date().toISOString(), comment: submitComment, status: 'pending-approval',
      version: versionNum,
    };
    setTeamSubmissions(prev => ({ ...prev, [selectedBU]: submission }));
    setShowSubmitModal(false);
    setSubmitComment('');
    toast.success(`Version ${versionNum} submitted for ${currentBUName}`);
  };

  const handleApprove = (buId: string) => {
    setTeamSubmissions(prev => ({
      ...prev,
      [buId]: { ...prev[buId], status: 'approved', approvedBy: userName || 'Manager', approvedAt: new Date().toISOString() },
    }));
    toast.success(`${BU_NAME_MAP[buId]} estimates approved`);
  };

  const handleReject = (buId: string) => {
    setRejectingBU(buId);
    setShowRejectModal(true);
  };

  const confirmReject = () => {
    if (!rejectingBU) return;
    setTeamSubmissions(prev => ({
      ...prev,
      [rejectingBU]: { ...prev[rejectingBU], status: 'rejected', rejectedBy: userName || 'Manager', rejectedAt: new Date().toISOString(), rejectionReason: rejectReason },
    }));
    setShowRejectModal(false);
    setRejectReason('');
    toast.success(`${BU_NAME_MAP[rejectingBU]} estimates rejected`);
    setRejectingBU(null);
  };

  // Finance lock = global read-only; UW submissions do NOT lock editing
  const isTeamLocked = eventLocked;
  const currentSubmission = selectedBU ? teamSubmissions[selectedBU] : null;
  const currentVersionCount = selectedBU ? (submissionVersions[selectedBU] || []).length : 0;

  // ─── MRT Column Definitions ───────────────────────────────────────────
  const columns = useMemo<MRT_ColumnDef<ContractEstimate>[]>(() => [
    // ── Impact & Model flags (pinned left) ──
    {
      accessorKey: 'impacted', header: 'Impact', size: 44, enableColumnFilter: true, filterVariant: 'checkbox', enableSorting: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">IMPACT</span>,
      Cell: ({ row }) => {
        const isForeign = isProductForeign(row.original);
        const disabled = isTeamLocked || isForeign || isGroupView;
        return (
          <button className={`flex items-center justify-center w-full ${(isForeign || isGroupView) ? 'opacity-50 pointer-events-none' : ''}`} onClick={() => !disabled && toggleImpact(row.original.contractNumber)}>
            {row.original.impacted ? <CheckSquare className="w-4 h-4 text-green-600" /> : <Square className={`w-4 h-4 ${disabled ? 'text-slate-200' : 'text-slate-300 hover:text-slate-500'}`} />}
          </button>
        );
      },
    },
    {
      accessorKey: 'modelImpacted', header: 'Modeled', size: 56, enableColumnFilter: true, filterVariant: 'checkbox', enableSorting: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">MODEL</span>,
      Cell: ({ row }) => row.original.modelImpacted ? (
        <div className="flex items-center justify-center">
          <span className="inline-flex items-center gap-0.5 text-[10px] bg-green-50 text-green-700 border border-green-200 px-1.5 py-0.5 rounded"><Cpu className="w-3 h-3" /> Yes</span>
        </div>
      ) : <div className="flex items-center justify-center"><span className="text-[10px] text-slate-400">—</span></div>,
    },
    {
      accessorKey: 'teamName', header: 'Business Unit', size: 150, enableColumnFilter: true, enableGrouping: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">BUSINESS UNIT</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'product', header: 'Product', size: 120, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">PRODUCT</span>,
      Cell: ({ cell }) => {
        const v = cell.getValue<string>();
        const colorMap: Record<string, string> = {
          'Property CAT': 'bg-red-50 text-red-700 border-red-200',
          'Property PR': 'bg-orange-50 text-orange-700 border-orange-200',
          'Property Risk': 'bg-amber-50 text-amber-700 border-amber-200',
          'Casualty': 'bg-blue-50 text-blue-700 border-blue-200',
          'Marine': 'bg-cyan-50 text-cyan-700 border-cyan-200',
          'Aviation': 'bg-sky-50 text-sky-700 border-sky-200',
          'Cyber': 'bg-purple-50 text-purple-700 border-purple-200',
          'Financial': 'bg-emerald-50 text-emerald-700 border-emerald-200',
          'Mortgage': 'bg-teal-50 text-teal-700 border-teal-200',
          'Engineering': 'bg-indigo-50 text-indigo-700 border-indigo-200',
          'Energy': 'bg-yellow-50 text-yellow-700 border-yellow-200',
          'Parametric': 'bg-pink-50 text-pink-700 border-pink-200',
          'Accident & Health': 'bg-rose-50 text-rose-700 border-rose-200',
          'Alternative Risk': 'bg-slate-50 text-slate-600 border-slate-200',
          'Motor': 'bg-lime-50 text-lime-700 border-lime-200',
          'Crop': 'bg-green-50 text-green-700 border-green-200',
          'PVT & Terror': 'bg-gray-100 text-gray-700 border-gray-300',
          'REGEAR': 'bg-violet-50 text-violet-700 border-violet-200',
        };
        const cls = colorMap[v] || 'bg-slate-50 text-slate-500 border-slate-200';
        return v && v !== '—'
          ? <span className={`text-[10px] px-1.5 py-0.5 rounded border ${cls}`}>{v}</span>
          : <span className="text-[10px] text-slate-400">—</span>;
      },
    },
    // ── Contract identification ──
    {
      accessorKey: 'cedant', header: 'Cedant', size: 190, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">CEDANT</span>,
      Cell: ({ cell }) => <span className="text-[11px] truncate block max-w-[180px]" title={cell.getValue<string>()}>{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'broker', header: 'Broker', size: 140, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">BROKER</span>,
      Cell: ({ cell }) => <span className="text-[11px] truncate block max-w-[130px]" title={cell.getValue<string>()}>{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'contractName', header: 'Name', size: 220, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">NAME</span>,
      Cell: ({ cell }) => <span className="text-[11px] truncate block max-w-[210px]" title={cell.getValue<string>()}>{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'contractNumber', header: 'Contract #', size: 150, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">CONTRACT #</span>,
      Cell: ({ cell }) => <span className="text-[11px] font-mono text-blue-700">{cell.getValue<string>()}</span>,
    },
    // ── Dates ──
    {
      accessorKey: 'effectiveDate', header: 'Eff. Date', size: 90, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">EFFECTIVE DATE</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>() || '—'}</span>,
    },
    {
      accessorKey: 'expiryDate', header: 'Exp. Date', size: 90, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">EXPIRY DATE</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>() || '—'}</span>,
    },
    // ── Currency & FX ──
    {
      accessorKey: 'originalCurrency', header: 'Currency', size: 65, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">CURRENCY</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>() || 'USD'}</span>,
    },
    {
      accessorKey: 'fxRate', header: 'FX Rate', size: 60, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">FX RATE</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>() || '1.00'}</span>,
    },
    // ── Limits & Structure ──
    {
      accessorKey: 'limit', header: '100% Limit', size: 110, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">100% LIMIT</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'everestLine', header: 'Share', size: 70, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">SHARE</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'everestLimit', header: 'Everest Limit', size: 110, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">EVEREST LIMIT</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'everestOccurrenceLimit', header: 'Everest Occurrence Limit', size: 140, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">EVEREST OCC. LIMIT</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'deductible', header: 'Attachment', size: 100, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">ATTACHMENT</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    // ── Reinsurance terms ──
    {
      accessorKey: 'programType', header: 'Contract Type', size: 65, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">CONTRACT TYPE</span>,
      Cell: ({ cell }) => {
        const v = cell.getValue<string>();
        const c: Record<string, string> = { QS: 'bg-indigo-50 text-indigo-700 border-indigo-200', XL: 'bg-amber-50 text-amber-700 border-amber-200' };
        return <span className={`text-[10px] px-1.5 py-0.5 rounded border ${c[v] || 'bg-slate-50 text-slate-700 border-slate-200'}`}>{v}</span>;
      },
    },
    {
      accessorKey: 'premium', header: 'Premium', size: 95, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">PREMIUM</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'reinstatementTerms', header: 'Reinstatement', size: 100, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">REINSTATEMENT</span>,
      Cell: ({ cell, row }) => {
        const raw = cell.getValue<string>();
        const programType = row.original.programType;
        
        // For XL contracts, show numeric values or "free"
        if (programType === 'XL') {
          const value = raw ? raw.toString().trim() : '';
          if (value.toLowerCase() === 'free' || value.toLowerCase() === 'n/a') {
            return <span className="text-[11px] text-center block text-slate-400">free</span>;
          }
          // Check if it's a simple number (1, 2, 5, etc.)
          const num = parseFloat(value);
          if (!isNaN(num)) {
            return <span className="text-[11px] text-center block font-medium">{Math.round(num)}</span>;
          }
        }
        
        // For non-XL contracts or invalid values, show empty
        return <span className="text-[11px] text-center block text-slate-400">—</span>;
      },
    },
    {
      id: 'ripPercent',
      accessorFn: (row) => row.ripPercent,
      header: 'RIP%', size: 68, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-amber-600">RIP%</span>,
      Cell: ({ row }) => {
        const isForeign = isProductForeign(row.original);
        const disabled = isTeamLocked || isForeign || isGroupView;
        // Non-XL with no value set: show dash (but still editable if clicked)
        if (row.original.programType !== 'XL' && !row.original.ripPercent) {
          return (
            <EditableCell value={row.original.ripPercent}
              onChange={(v) => updateField(row.original.contractNumber, 'ripPercent', v)}
              disabled={disabled}
              className="w-full text-[11px] text-center rounded px-1.5 py-0.5 outline-none bg-transparent border border-transparent hover:border-slate-200 focus:border-amber-300 focus:bg-amber-50/40 disabled:opacity-40"
              placeholder="—" />
          );
        }
        return (
          <EditableCell value={row.original.ripPercent}
            onChange={(v) => updateField(row.original.contractNumber, 'ripPercent', v)}
            disabled={disabled}
            className={`w-full text-[11px] text-center rounded px-1.5 py-0.5 outline-none ${(isForeign || isGroupView) ? 'bg-slate-100 border border-slate-200 text-slate-400 italic' : 'bg-amber-50/60 border border-amber-200 focus:ring-1 focus:ring-amber-400 disabled:opacity-50'}`}
            placeholder="e.g. 100%" />
        );
      },
    },
    // ── UW Estimates (blue) ──
    {
      accessorKey: 'uwEstimateLow', header: 'UW Low', size: 100, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-blue-600">UW LOW</span>,
      Cell: ({ row }) => {
        const isForeign = isProductForeign(row.original);
        const disabled = isTeamLocked || isForeign || isGroupView;
        return <div className={isForeign ? 'pointer-events-none' : ''}><EditableCell value={row.original.uwEstimateLow} onChange={(v) => handleBlurField(row.original.contractNumber, 'uwEstimateLow', v)}
          disabled={disabled} className={`w-full text-[11px] text-right rounded px-1.5 py-0.5 outline-none ${(isForeign || isGroupView) ? 'bg-slate-100 border border-slate-200 text-slate-400 italic' : 'bg-blue-50/40 border border-blue-100 focus:ring-1 focus:ring-blue-400 disabled:opacity-50'}`} placeholder="$0" /></div>;
      },
    },
    {
      accessorKey: 'uwEstimateMed', header: 'UW Best', size: 100, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-blue-700">UW BEST</span>,
      Cell: ({ row }) => {
        const isForeign = isProductForeign(row.original);
        const disabled = isTeamLocked || isForeign || isGroupView;
        return <div className={isForeign ? 'pointer-events-none' : ''}><EditableCell value={row.original.uwEstimateMed} onChange={(v) => handleBlurField(row.original.contractNumber, 'uwEstimateMed', v)}
          disabled={disabled} className={`w-full text-[11px] text-right rounded px-1.5 py-0.5 outline-none ${(isForeign || isGroupView) ? 'bg-slate-100 border border-slate-200 text-slate-400 italic' : 'bg-blue-50/60 border border-blue-200 font-semibold focus:ring-1 focus:ring-blue-400 disabled:opacity-50'}`} placeholder="$0" /></div>;
      },
    },
    {
      accessorKey: 'uwEstimateHigh', header: 'UW High', size: 100, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-blue-600">UW HIGH</span>,
      Cell: ({ row }) => {
        const isForeign = isProductForeign(row.original);
        const disabled = isTeamLocked || isForeign || isGroupView;
        return <div className={isForeign ? 'pointer-events-none' : ''}><EditableCell value={row.original.uwEstimateHigh} onChange={(v) => handleBlurField(row.original.contractNumber, 'uwEstimateHigh', v)}
          disabled={disabled} className={`w-full text-[11px] text-right rounded px-1.5 py-0.5 outline-none ${(isForeign || isGroupView) ? 'bg-slate-100 border border-slate-200 text-slate-400 italic' : 'bg-blue-50/40 border border-blue-100 focus:ring-1 focus:ring-blue-400 disabled:opacity-50'}`} placeholder="$0" /></div>;
      },
    },
    {
      id: 'expReinstPremiums',
      accessorFn: (row) => calcExpReinstPremium(row),
      header: 'Exp. Reinst. Premiums', size: 128, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-orange-600">EXP. REINST. PREM.</span>,
      Cell: ({ row }) => {
        const val = calcExpReinstPremium(row.original);
        if (val === 0) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        return <span className="text-[11px] text-right block text-orange-700">{formatCurrency(val)}</span>;
      },
    },
    {
      id: 'netLoss',
      accessorFn: (row) => parseCurrency(row.uwEstimateMed) - calcExpReinstPremium(row),
      header: 'Net Loss', size: 110, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-purple-600">NET LOSS</span>,
      Cell: ({ row }) => {
        const uwBest = parseCurrency(row.original.uwEstimateMed);
        if (uwBest === 0) return <span className="text-[11px] text-slate-300 text-right block">—</span>;
        const netLoss = uwBest - calcExpReinstPremium(row.original);
        return <span className="text-[11px] text-right block text-purple-700 font-semibold">{formatCurrency(netLoss)}</span>;
      },
    },
    // ── Display currency indicator ──
    {
      id: 'curUSD', header: 'Display Currency', size: 55, enableColumnFilter: false, enableSorting: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">{displayCurrency === 'ORIGINAL' ? 'ORIG' : displayCurrency}</span>,
      Cell: ({ row }) => <span className="text-[10px] text-slate-400">{displayCurrency === 'ORIGINAL' ? row.original.originalCurrency : displayCurrency}</span>,
    },
    // ── Modeled estimates (green) ──
    {
      accessorKey: 'modelingLow', header: 'Model Low', size: 90, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-emerald-600">MODEL LOW</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block text-emerald-700">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'modelingMed', header: 'Model Best', size: 90, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-emerald-700">MODEL BEST</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block text-emerald-800 font-semibold">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'modelingHigh', header: 'Model High', size: 90, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-emerald-600">MODEL HIGH</span>,
      Cell: ({ cell }) => <span className="text-[11px] text-right block text-emerald-700">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'mainRisk', header: 'Main Risk', size: 100, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">MAIN RISK</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'reportingLevel', header: 'Reporting Level', size: 140, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">REPORTING LEVEL</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>()}</span>,
    },
    {
      accessorKey: 'ibnrCode', header: 'IBNR Tag', size: 110, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">IBNR TAG</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>()}</span>,
    },
    // ── UW & Notes (last) ──
    {
      accessorKey: 'uwName', header: 'Underwriter', size: 130, enableColumnFilter: true,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">UNDERWRITER</span>,
      Cell: ({ cell }) => <span className="text-[11px]">{cell.getValue<string>() || '—'}</span>,
    },
    {
      accessorKey: 'notes', header: 'Notes', size: 150, enableColumnFilter: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">NOTES</span>,
      Cell: ({ row }) => <EditableCell value={row.original.notes} onChange={(v) => updateField(row.original.contractNumber, 'notes', v)}
        disabled={isTeamLocked || isGroupView} className={`w-full text-[11px] bg-transparent border border-transparent ${isGroupView ? 'text-slate-400 italic' : 'hover:border-slate-200 focus:border-blue-300'} rounded px-1 py-0.5 outline-none disabled:opacity-50`} placeholder={isGroupView ? '' : 'Add note...'} />,
    },
    // ── Version & Snapshot columns ──
    {
      accessorKey: 'estimateVersion', header: '#', size: 48, enableColumnFilter: true, enableSorting: true,
      Header: () => <span className="text-[10px] font-semibold text-purple-600">#</span>,
      Cell: ({ row }) => {
        const v = row.original.estimateVersion;
        const snapCount = (estimateSnapshots[row.original.contractNumber] || []).length;
        return (
          <div className="flex items-center justify-center">
            <span className={`inline-flex items-center justify-center text-[10px] px-1.5 py-0.5 rounded ${snapCount > 0 ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-slate-50 text-slate-500 border border-slate-200'}`}>
              v{v}
            </span>
          </div>
        );
      },
    },
    {
      accessorKey: 'estimateAsOf', header: 'As Of', size: 100, enableColumnFilter: false, enableSorting: true,
      Header: () => <span className="text-[10px] font-semibold text-purple-600">AS OF</span>,
      Cell: ({ cell }) => {
        const val = cell.getValue<string>();
        if (!val) return <span className="text-[10px] text-slate-400">—</span>;
        const d = new Date(val);
        return <span className="text-[10px] text-slate-600">{d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} {d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>;
      },
    },
    {
      id: 'snapshotActions', header: 'Actions', size: 110, enableColumnFilter: false, enableSorting: false,
      Header: () => <span className="text-[10px] font-semibold text-slate-500">ACTIONS</span>,
      Cell: ({ row }) => {
        const cn = row.original.contractNumber;
        const snapCount = (estimateSnapshots[cn] || []).length;
        return (
          <div className="flex items-center gap-1">
            <button
              onClick={() => !isTeamLocked && !isGroupView && saveEstimateSnapshot(cn)}
              disabled={isTeamLocked || isGroupView}
              title={isGroupView ? 'Select a leaf segment to edit' : 'Save snapshot of current estimates'}
              className="flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded hover:bg-blue-100 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Save className="w-3 h-3" /> Save
            </button>
            {snapCount > 0 && (
              <button
                onClick={() => setSnapshotModalContract(cn)}
                title={`View ${snapCount} snapshot(s)`}
                className="flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded hover:bg-purple-100 transition-colors"
              >
                <Clock className="w-3 h-3" /> {snapCount}
              </button>
            )}
          </div>
        );
      },
    },
  ], [toggleImpact, handleBlurField, updateField, isTeamLocked, isGroupView, displayCurrency, estimateSnapshots, saveEstimateSnapshot]);

  // ─── MRT Table ────────────────────────────────────────────────────────
  const table = useMaterialReactTable({
    columns, data: impactFilteredEstimates,
    enableColumnFilters: true, enableGlobalFilter: false, enablePagination: false,
    enableRowVirtualization: false, enableStickyHeader: true, enableDensityToggle: false,
    enableFullScreenToggle: false, enableHiding: true, enableColumnActions: false, enableToolbarInternalActions: false,
    enableColumnResizing: true, enableSorting: true, columnFilterDisplayMode: 'popover',
    enableColumnPinning: true,
    initialState: {
      density: 'compact', showColumnFilters: false,
      columnPinning: { left: ['impacted', 'modelImpacted', 'teamName', 'product', 'cedant'] },
    },
    state: { columnFilters },
    onColumnFiltersChange: setColumnFilters,
    muiTableHeadCellProps: { sx: MRT_HEAD_CELL_SX }, muiTableBodyCellProps: { sx: MRT_BODY_CELL_SX },
    muiTablePaperProps: { sx: { ...MRT_PAPER_SX, boxShadow: 'none' } },
    muiTableContainerProps: { sx: { maxHeight: 'calc(100vh - 300px)', overflow: 'auto' } },
    getRowId: (row) => row.contractNumber,
    muiTableBodyRowProps: ({ row }) => {
      const cn = row.original.contractNumber;
      const hasError = importValidationErrors[cn];
      const isNotImpacted = !row.original.impacted;
      return {
        sx: hasError ? {
          backgroundColor: '#fef2f2 !important',
          borderLeft: '3px solid #ef4444',
          '&:hover': { backgroundColor: '#fee2e2 !important' },
        } : isNotImpacted ? {
          backgroundColor: '#fefce8 !important',
          '&:hover': { backgroundColor: '#fef9c3 !important' },
        } : {},
      };
    },
    renderTopToolbarCustomActions: () => (
      <div className="flex items-center gap-2 flex-wrap">
        {/* Impact Filter */}
        <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg p-0.5">
          <button
            onClick={() => setImpactFilter('all')}
            className={`text-[11px] px-2.5 py-1 rounded transition-colors ${impactFilter === 'all' ? 'bg-white text-slate-900 font-medium shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            All
          </button>
          <button
            onClick={() => setImpactFilter('impacted')}
            className={`text-[11px] px-2.5 py-1 rounded transition-colors ${impactFilter === 'impacted' ? 'bg-white text-slate-900 font-medium shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            Impacted
          </button>
          <button
            onClick={() => setImpactFilter('not-impacted')}
            className={`text-[11px] px-2.5 py-1 rounded transition-colors ${impactFilter === 'not-impacted' ? 'bg-white text-slate-900 font-medium shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            Not Impacted
          </button>
        </div>
        <div className="h-4 w-px bg-slate-200" />
        {isGroupView && (
          <span className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full">
            <Lock className="w-3 h-3" /> View Only — select a leaf segment to edit
          </span>
        )}
        {!isGroupView && (
          <>
            <button onClick={selectAllVisible} className="flex items-center gap-1 text-[11px] px-2.5 py-1.5 bg-green-50 text-green-700 border border-green-200 rounded hover:bg-green-100 transition-colors">
              <CheckSquare className="w-3.5 h-3.5" /> Select All
            </button>
            <button onClick={deselectAllVisible} className="flex items-center gap-1 text-[11px] px-2.5 py-1.5 bg-slate-50 text-slate-600 border border-slate-200 rounded hover:bg-slate-100 transition-colors">
              <XSquare className="w-3.5 h-3.5" /> Deselect All
            </button>
          </>
        )}
        {selectedBU && !isGroupView && (
          null
        )}
        <div className="h-4 w-px bg-slate-200 mx-1" />
        {!isGroupView && <button onClick={() => setShowUploadModal(true)} className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm">
          <Upload className="w-3.5 h-3.5" /> Import
        </button>}
        <button onClick={() => {
          const wb = XLSX.utils.book_new();

          // ── Sheet 1: Contract-level estimates ──────────────────────────
          const wsData = filteredEstimates.map(e => {
            const expReinst = calcExpReinstPremium(e);
            const uwBest   = parseCurrency(e.uwEstimateMed);
            const netLoss  = uwBest - expReinst;
            return {
              'Contract #': e.contractNumber,
              'Contract Name': e.contractName,
              'Cedant': e.cedant,
              'Business Unit': e.teamName,
              'Impacted': e.impacted ? 'Yes' : 'No',
              'Model Impacted': e.modelImpacted ? 'Yes' : 'No',
              'Program Type': e.programType,
              'Limit (Our Limit)': e.limit,
              'Signed Line': e.everestLine,
              'Premium': e.premium,
              'Reinstatement Terms': e.reinstatementTerms,
              'RIP%': e.ripPercent || '',
              'UW Low': e.uwEstimateLow,
              'UW Best': e.uwEstimateMed,
              'UW High': e.uwEstimateHigh,
              'Exp. Reinst. Premiums': expReinst > 0 ? formatCurrency(expReinst) : '',
              'Net Loss': uwBest > 0 ? formatCurrency(netLoss) : '',
              'Model Low': e.modelingLow,
              'Model Best': e.modelingMed,
              'Model High': e.modelingHigh,
              'Underwriter': e.uwName || '',
              'Notes': e.notes,
            };
          });
          const ws = XLSX.utils.json_to_sheet(wsData);
          ws['!cols'] = [
            { wch: 22 }, { wch: 36 }, { wch: 36 }, { wch: 24 },
            { wch: 9 },  { wch: 14 }, { wch: 12 }, { wch: 16 },
            { wch: 12 }, { wch: 14 }, { wch: 20 }, { wch: 8 },
            { wch: 13 }, { wch: 13 }, { wch: 13 }, { wch: 22 },
            { wch: 14 }, { wch: 13 }, { wch: 13 }, { wch: 13 },
            { wch: 20 }, { wch: 40 },
          ];
          XLSX.utils.book_append_sheet(wb, ws, 'UW Estimates');

          // ── Sheet 2: Summary by Business Unit ─────────────────────────
          const buSummaryMap: Record<string, {
            buName: string; contracts: number; impacted: number;
            uwLow: number; uwBest: number; uwHigh: number;
            premium: number; expReinst: number; netLoss: number;
          }> = {};
          filteredEstimates.forEach(e => {
            if (!buSummaryMap[e.team]) {
              buSummaryMap[e.team] = {
                buName: e.teamName, contracts: 0, impacted: 0,
                uwLow: 0, uwBest: 0, uwHigh: 0, premium: 0, expReinst: 0, netLoss: 0,
              };
            }
            const bu = buSummaryMap[e.team];
            bu.contracts++;
            if (e.impacted) {
              bu.impacted++;
              const er = calcExpReinstPremium(e);
              const ub = parseCurrency(e.uwEstimateMed);
              bu.uwLow   += parseCurrency(e.uwEstimateLow);
              bu.uwBest  += ub;
              bu.uwHigh  += parseCurrency(e.uwEstimateHigh);
              bu.premium += parseCurrency(e.premium);
              bu.expReinst += er;
              bu.netLoss   += ub - er;
            }
          });

          const summaryData: Record<string, string | number>[] = Object.values(buSummaryMap).map(bu => ({
            'Business Unit': bu.buName,
            'Contracts': bu.contracts,
            'Impacted': bu.impacted,
            'Premium': bu.premium > 0 ? formatCurrency(bu.premium) : '',
            'UW Low':  bu.uwLow  > 0 ? formatCurrency(bu.uwLow)  : '',
            'UW Best': bu.uwBest > 0 ? formatCurrency(bu.uwBest) : '',
            'UW High': bu.uwHigh > 0 ? formatCurrency(bu.uwHigh) : '',
            'Exp. Reinst. Premiums': bu.expReinst > 0 ? formatCurrency(bu.expReinst) : '',
            'Net Loss': bu.netLoss  > 0 ? formatCurrency(bu.netLoss)  : '',
          }));

          const allImpacted = filteredEstimates.filter(e => e.impacted);
          const grandExpReinst = allImpacted.reduce((s, e) => s + calcExpReinstPremium(e), 0);
          const grandUWBest    = allImpacted.reduce((s, e) => s + parseCurrency(e.uwEstimateMed), 0);
          summaryData.push({
            'Business Unit': 'TOTAL',
            'Contracts': filteredEstimates.length,
            'Impacted': allImpacted.length,
            'Premium': formatCurrency(allImpacted.reduce((s, e) => s + parseCurrency(e.premium), 0)),
            'UW Low':  formatCurrency(allImpacted.reduce((s, e) => s + parseCurrency(e.uwEstimateLow), 0)),
            'UW Best': formatCurrency(grandUWBest),
            'UW High': formatCurrency(allImpacted.reduce((s, e) => s + parseCurrency(e.uwEstimateHigh), 0)),
            'Exp. Reinst. Premiums': grandExpReinst > 0 ? formatCurrency(grandExpReinst) : '',
            'Net Loss': grandUWBest > 0 ? formatCurrency(grandUWBest - grandExpReinst) : '',
          });

          const wsSummary = XLSX.utils.json_to_sheet(summaryData);
          wsSummary['!cols'] = [
            { wch: 28 }, { wch: 11 }, { wch: 11 }, { wch: 14 },
            { wch: 13 }, { wch: 13 }, { wch: 13 }, { wch: 22 }, { wch: 14 },
          ];
          XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary by BU');

          XLSX.writeFile(wb, `SONAR_UW_Estimation_${event?.eventName || eventId}_${new Date().toISOString().split('T')[0]}.xlsx`);
          toast.success('Excel exported — 2 sheets: UW Estimates + Summary by BU');
        }} className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm">
          <Download className="w-3.5 h-3.5" /> Export
        </button>
        <div className="h-4 w-px bg-slate-200 mx-1" />
        {/* Currency display selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider">Display:</span>
          <select
            value={displayCurrency}
            onChange={(e) => setDisplayCurrency(e.target.value as DisplayCurrency)}
            className="text-[11px] px-2 py-1.5 bg-white border border-slate-200 rounded hover:border-blue-300 focus:ring-1 focus:ring-blue-400 outline-none cursor-pointer"
          >
            {DISPLAY_CURRENCIES.map(c => (
              <option key={c} value={c}>{CUR_LABELS[c]}</option>
            ))}
          </select>
          {displayCurrency !== 'USD' && (
            <span className="text-[10px] px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded">
              {displayCurrency === 'ORIGINAL' ? 'Orig' : `1 USD = ${(USD_TO_RATE[displayCurrency] || 1).toFixed(2)} ${displayCurrency}`}
            </span>
          )}
        </div>
        <div className="h-4 w-px bg-slate-200 mx-1" />
        <button onClick={() => setTableExpanded(!tableExpanded)} className="flex items-center gap-1 text-[11px] px-2.5 py-1.5 bg-slate-700 text-white rounded hover:bg-slate-800 transition-colors">
          {tableExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          {tableExpanded ? 'Collapse' : 'Expand'}
        </button>
      </div>
    ),
  });

  // ─── Render ────────────────────────────────────────────────────────��──
  if (!event) return <div className="flex items-center justify-center h-64"><p className="text-slate-500">Event not found</p></div>;

  const phaseBadgeColors: Record<string, string> = {
    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Reopened': 'bg-red-50 text-red-700 border-red-200',
  };
  const phaseDisplayLabels: Record<string, string> = {
    'Event Creation': 'Event Creation', 'Monitoring': 'Monitoring',
    'Estimation & Approval': 'UW Estimation', 'Finance Review': 'Finance Review',
    'Reporting & Close': 'Reporting & Close', 'Reopened': 'Reopened',
  };
  const dropdownOptionColors: Record<string, string> = {
    'Monitoring': 'text-cyan-700', 'Estimation & Approval': 'text-amber-700',
    'Finance Review': 'text-blue-700', 'Reporting & Close': 'text-emerald-700',
    'Complete Phase 4': 'text-emerald-700', 'Close Event': 'text-emerald-800',
    'Close Archived': 'text-slate-600', 'Reopened': 'text-red-700',
  };
  const currentPhase = getWorkflowStatus(eventId || '').currentPhase;
  const allowedTransitions = getAllowedPhases(eventId || '');
  const eventStatus = getEventStatus(eventId || '');
  const statusBadge: Record<string, string> = {
    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
    'Reopened': 'bg-red-50 text-red-700 border-red-300',
  };

  return (
    <div className="flex flex-col min-h-0" style={{ minHeight: 'calc(100vh - 56px)' }}>
      {/* ─── EVENT BANNER (same as Overview, with module name) ─────── */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-40">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event.eventName}</h1>
                <h1 className="text-slate-600">- UW Estimation</h1>

                {/* Phase Dropdown */}
                <div className="relative flex items-center gap-1.5">
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Phase:</span>
                  <button
                    onClick={() => setPhaseDropdownOpen(!phaseDropdownOpen)}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border cursor-pointer hover:ring-2 hover:ring-blue-200 transition-all ${phaseBadgeColors[currentPhase] || 'bg-slate-100 text-slate-600 border-slate-200'}`}
                  >
                    {phaseDisplayLabels[currentPhase] || currentPhase}
                    <ChevronDown className="w-3 h-3 opacity-60" />
                  </button>
                  {phaseDropdownOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setPhaseDropdownOpen(false)} />
                      <div className="absolute top-full left-0 mt-1 z-50 bg-white border border-slate-200 rounded-lg shadow-lg py-1 min-w-[260px]">
                        <div className="px-3 py-1.5 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100">Allowed Transitions</div>
                        {allowedTransitions.filter(t => t.allowed).length === 0 ? (
                          <>
                            {allowedTransitions.filter(t => !t.allowed).map((t) => (
                              <div key={t.phase} className="w-full text-left px-3 py-2 text-xs flex items-center justify-between gap-2 opacity-50 cursor-not-allowed">
                                <span className="flex flex-col">
                                  <span className="font-medium text-slate-400 flex items-center gap-1"><Lock className="w-3 h-3" />{phaseDisplayLabels[t.phase] || t.phase}</span>
                                  {t.reason && <span className="text-[10px] text-slate-400">{t.reason}</span>}
                                </span>
                                {t.ruleId && <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>}
                              </div>
                            ))}
                            {allowedTransitions.filter(t => !t.allowed).length === 0 && (
                              <div className="px-3 py-2 text-xs text-slate-400 italic">No transitions available</div>
                            )}
                          </>
                        ) : (
                          <>
                            {allowedTransitions.filter(t => t.allowed).map((t) => (
                              <button key={t.phase} onClick={() => {
                                if (t.phase === 'Complete Phase 4') completePhase4(eventId || '');
                                else if (t.phase === 'Close Event') closeEvent(eventId || '');
                                else if (t.phase === 'Close Archived') archiveEvent(eventId || '');
                                else if (t.phase === 'Reopened') reopenEvent(eventId || '');
                                else setPhase(eventId || '', t.phase as any);
                                setPhaseDropdownOpen(false);
                                toast.success(t.phase === 'Reopened' ? 'Event reopened — restarted at Monitoring' : `Phase updated to ${t.phase}`);
                              }} className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition-colors flex items-center justify-between gap-2">
                                <span className="flex flex-col">
                                  <span className={`font-medium ${dropdownOptionColors[t.phase] || 'text-slate-700'}`}>{phaseDisplayLabels[t.phase] || t.phase}</span>
                                  {t.reason && <span className="text-[10px] text-slate-400">{t.reason}</span>}
                                </span>
                                {t.ruleId && <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>}
                              </button>
                            ))}
                            {allowedTransitions.filter(t => !t.allowed).map((t) => (
                              <div key={t.phase} className="w-full text-left px-3 py-2 text-xs flex items-center justify-between gap-2 opacity-50 cursor-not-allowed border-t border-slate-100">
                                <span className="flex flex-col">
                                  <span className="font-medium text-slate-400 flex items-center gap-1"><Lock className="w-3 h-3" />{phaseDisplayLabels[t.phase] || t.phase}</span>
                                  {t.reason && <span className="text-[10px] text-slate-400">{t.reason}</span>}
                                </span>
                                {t.ruleId && <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>}
                              </div>
                            ))}
                          </>
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Status Badge + Lock */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-400 uppercase tracking-wider">Status:</span>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[eventStatus] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>{eventStatus}</span>
                  {eventLocked && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-red-50 text-red-700 border border-red-200">
                      <Lock className="w-3 h-3" />
                      {currentPhase === 'Finance Review' ? 'Finance Review Lock' : currentPhase === 'Reporting & Close' ? 'Reporting & Close Lock' : 'Locked'}
                    </span>
                  )}
                  {(currentRole === 'finance' || currentRole === 'management') && eventLocked && (
                    <button
                      onClick={() => {
                        unlockEvent(eventId || '');
                        if (currentPhase === 'Finance Review') {
                          setPhase(eventId || '', 'Estimation & Approval');
                          toast.success('Event unlocked — returned to Estimation & Approval');
                        } else if (currentPhase === 'Reporting & Close') {
                          setPhase(eventId || '', 'Finance Review');
                          toast.success('Event unlocked — returned to Finance Review');
                        } else {
                          toast.success('Event manually unlocked');
                        }
                      }}
                      className="p-1 rounded hover:bg-red-50 transition-colors"
                      title="Unlock event (Finance/Management only)"
                    >
                      <XCircle className="w-3.5 h-3.5 text-red-500" />
                    </button>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Type of Everest Event:</span>
                  <span className="text-slate-900">{event.everestEventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Type:</span>
                  <span className="text-slate-900">{event.eventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Sub-Type:</span>
                  <span className="text-slate-900">{event.eventSubType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── MAIN CONTENT ──────────────────────────────────────────── */}
      <div className="flex flex-1">
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        {/* Toolbar header */}
        <div className="border-b border-slate-200 bg-white px-4 py-0 flex items-stretch gap-0 min-h-[48px]">

          {/* PORTFOLIO SUMMARY */}
          <div className="flex flex-col justify-center pr-4 border-r border-slate-200 mr-3 py-2 shrink-0">
            <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Portfolio Summary</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-[15px] font-bold text-slate-800 tabular-nums">{stats.impactedCount}/{stats.total}</span>
              <span className="text-[11px] text-slate-400">Impacted</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-[13px] font-semibold text-blue-600 tabular-nums">{formatCurrency(stats.totalUWMed)}</span>
              <span className="text-[11px] text-slate-400">Best Est.</span>
            </div>
          </div>

          {/* Stats columns */}
          <div className="flex items-stretch gap-0 flex-1">

            {/* CONTRACTS */}
            

            {/* GROSS LOW */}
            <div className="flex flex-col justify-center items-start px-3 border-r border-slate-200 py-2 shrink-0">
              <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Gross Low</span>
              <span className="text-[14px] font-semibold text-slate-600 tabular-nums">{formatCurrency(stats.totalUWLow)}</span>
            </div>

            {/* GROSS BEST */}
            <div className="flex flex-col justify-center items-start px-3 border-r border-slate-200 py-2 shrink-0">
              <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Gross Best</span>
              <span className="text-[14px] font-semibold text-blue-700 tabular-nums">{formatCurrency(stats.totalUWMed)}</span>
            </div>

            {/* GROSS HIGH */}
            <div className="flex flex-col justify-center items-start px-3 border-r border-slate-200 py-2 shrink-0">
              <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Gross High</span>
              <span className="text-[14px] font-semibold text-slate-600 tabular-nums">{formatCurrency(stats.totalUWHigh)}</span>
            </div>

            {/* EXP REINST (conditional) */}
            {stats.totalExpReinst > 0 && (
              <div className="flex flex-col justify-center items-start px-3 border-r border-slate-200 py-2 shrink-0">
                <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Exp. Reinst.</span>
                <span className="text-[14px] font-semibold text-orange-600 tabular-nums">{formatCurrency(stats.totalExpReinst)}</span>
              </div>
            )}

            {/* NET LOSS */}
            {stats.totalNetLoss > 0 && (
              <div className="flex flex-col justify-center items-start px-3 border-r border-slate-200 py-2 shrink-0">
                <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase mb-0.5">Net Loss</span>
                <span className="text-[14px] font-semibold text-purple-700 tabular-nums">{formatCurrency(stats.totalNetLoss)}</span>
              </div>
            )}
          </div>

          {/* Not Reviewed warning + progress bar */}
          {(() => {
            const notReviewedCount = filteredEstimates.filter(e => e.impacted && !parseCurrency(e.uwEstimateMed)).length;
            const reviewedCount = stats.impactedCount - notReviewedCount;
            const pct = stats.impactedCount > 0 ? (reviewedCount / stats.impactedCount) * 100 : 0;
            return notReviewedCount > 0 ? (
              <div className="flex items-center gap-3 px-3 border-r border-slate-200 py-2 shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-amber-500 text-[12px]">△</span>
                  <span className="text-[11px] text-amber-700">{notReviewedCount} contracts not reviewed</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-24 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-[11px] text-slate-400 tabular-nums">{reviewedCount}/{stats.impactedCount}</span>
                </div>
              </div>
            ) : null;
          })()}

          {/* Save / Submit */}
          <div className="flex items-center gap-1.5 pl-3 py-2 shrink-0">
            {eventLocked ? (
              <span className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded">
                <Lock className="w-3.5 h-3.5" /> {currentPhase === 'Finance Review' ? 'Finance Review — Read Only' : currentPhase === 'Reporting & Close' ? 'Reporting & Close — Read Only' : 'Locked'}
              </span>
            ) : (
              <>
                <button onClick={() => { persistEstimates(estimates); toast.success('Draft saved'); }}
                  disabled={isGroupView}
                  className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-white text-slate-700 border border-slate-300 rounded hover:bg-slate-50 transition-colors disabled:opacity-50">
                  <Save className="w-3.5 h-3.5" /> Save Draft
                </button>
                {selectedBU && (
                  <button onClick={handleSubmit}
                    disabled={isGroupView}
                    className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50">
                    <Send className="w-3.5 h-3.5" /> Submit {currentVersionCount > 0 ? `(v${currentVersionCount + 1})` : ''}
                  </button>
                )}
              </>
            )}
            {currentSubmission?.status === 'pending-approval' && (currentRole === 'Business Unit Lead' || currentRole === 'Admin') && (
              <>
                <button onClick={() => handleApprove(selectedBU!)} className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-green-600 text-white rounded hover:bg-green-700 transition-colors shadow-sm">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                </button>
                <button onClick={() => handleReject(selectedBU!)} className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 rounded hover:bg-red-100 transition-colors">
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </button>
              </>
            )}
          </div>
        </div>

        {/* Finance Lock Banner */}
        {eventLocked && (
          <div className="px-4 py-2.5 border-b bg-red-50 border-red-200 flex items-center gap-2 text-[11px] text-red-800">
            <Lock className="w-3.5 h-3.5 text-red-600" />
            <span className="font-semibold">{currentPhase === 'Finance Review' ? 'Finance Review Lock Active' : currentPhase === 'Reporting & Close' ? 'Reporting & Close Lock Active' : 'Lock Applied'}</span>
            <span className="text-red-600">
              {currentPhase === 'Finance Review'
                ? '— Event is in Finance Review. All UW Estimation and Cat Modeling modules are read-only until Finance completes review.'
                : currentPhase === 'Reporting & Close'
                ? '— Event is in Reporting & Close. All UW Estimation and Cat Modeling modules are read-only.'
                : '— All UW Estimation and Cat Modeling modules are read-only.'}
            </span>
            {(currentRole === 'finance' || currentRole === 'management') && (
              <button
                onClick={() => {
                  unlockEvent(eventId || '');
                  if (currentPhase === 'Finance Review') {
                    setPhase(eventId || '', 'Estimation & Approval');
                    toast.success('Event unlocked — returned to Estimation & Approval');
                  } else if (currentPhase === 'Reporting & Close') {
                    setPhase(eventId || '', 'Finance Review');
                    toast.success('Event unlocked — returned to Finance Review');
                  } else {
                    toast.success('Event manually unlocked');
                  }
                }}
                className="ml-auto flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium bg-white text-red-700 border border-red-300 rounded hover:bg-red-100 transition-colors"
              >
                <XCircle className="w-3 h-3" /> Unlock
              </button>
            )}
          </div>
        )}



        {/* Tab bar: Impact Assessment / UW Estimates */}
        <div className="border-b border-slate-200 px-4 flex items-center gap-0">
          <button onClick={() => setContentTab('impact')}
            className={`px-4 py-2.5 text-[13px] font-medium border-b-2 transition-colors ${contentTab === 'impact' ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            <span className="flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> Portfolio Exposure</span>
          </button>
          <button onClick={() => setContentTab('estimates')}
            className={`px-4 py-2.5 text-[13px] font-medium border-b-2 transition-colors ${contentTab === 'estimates' ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            <span className="flex items-center gap-1.5"><FileText className="w-4 h-4" /> Impacted Contracts</span>
          </button>
          <button onClick={() => setContentTab('subproduct')}
            className={`px-4 py-2.5 text-[13px] font-medium border-b-2 transition-colors ${contentTab === 'subproduct' ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            <span className="flex items-center gap-1.5"><Building2 className="w-4 h-4" /> Sub-Product Estimation</span>
          </button>
        </div>

        {/* Tab content */}
        <div className={`flex-1 ${contentTab === 'estimates' ? 'overflow-hidden flex flex-col' : 'overflow-auto'}`}>
          {contentTab === 'impact' ? (() => {
            // Filter to only relevant BUs (those with contracts, submissions, or responses) in aggregate view
            const relevantRows = isGroupView
              ? getImpactTableRows.filter(r => teamsWithContracts.has(r.id) || (impactEntries[r.id] || []).length > 0 || !!buResponses[r.id]?.response || !!(impactRowData[r.id]?.low || impactRowData[r.id]?.best || impactRowData[r.id]?.high))
              : getImpactTableRows;
            const totalSegments = relevantRows.length;
            const respondedCount = relevantRows.filter(r => buResponses[r.id]?.response).length;
            const yesCount = relevantRows.filter(r => buResponses[r.id]?.response === 'yes').length;
            const noCount = relevantRows.filter(r => buResponses[r.id]?.response === 'no').length;
            const pendingCount = totalSegments - respondedCount;
            const totalLow = relevantRows.reduce((s, r) => {
              const ov = impactRowData[r.id]?.low;
              return s + (ov ? parseCurrency(ov) : (uwTotalsPerBU[r.id]?.low || 0));
            }, 0);
            const totalBest = relevantRows.reduce((s, r) => {
              const ov = impactRowData[r.id]?.best;
              return s + (ov ? parseCurrency(ov) : (uwTotalsPerBU[r.id]?.best || 0));
            }, 0);
            const totalHigh = relevantRows.reduce((s, r) => {
              const ov = impactRowData[r.id]?.high;
              return s + (ov ? parseCurrency(ov) : (uwTotalsPerBU[r.id]?.high || 0));
            }, 0);
            return (
            <div className="px-4 pt-2 pb-3 h-full flex flex-col gap-1.5">
              {/* Spreadsheet Table — MRT */}
              <div className="flex-1 overflow-auto bg-white">
                <MaterialReactTable table={impactTable} />
              </div>

              {/* Summary Footer */}
              
            </div>
            );
          })()
          : contentTab === 'estimates' ? (
            /* ─── UW ESTIMATES TAB ──────────────────────────────────── */
            tableExpanded ? (
              /* Expanded: render placeholder, table is in the portal below */
              <div className="flex-1 flex items-center justify-center py-12 text-slate-400 text-[12px]">
                <Maximize2 className="w-5 h-5 mr-2" /> Table is expanded to full screen. <button onClick={() => setTableExpanded(false)} className="ml-2 underline text-blue-600 hover:text-blue-800">Collapse</button>
              </div>
            ) : (
              <div className="px-2 py-1">
                <MaterialReactTable table={table} />
                {/* Import Validation Summary */}
                {Object.keys(importValidationErrors).length > 0 && (
                  <div className="mt-1 px-3 py-2 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                    <div className="flex-1">
                      <span className="text-[11px] font-semibold text-red-700">
                        {Object.keys(importValidationErrors).length} Import Validation Error{Object.keys(importValidationErrors).length !== 1 ? 's' : ''}
                      </span>
                      <span className="text-[10px] text-red-600 ml-2">
                        Revised Contract Numbers do not match existing records. Rows highlighted in red.
                      </span>
                    </div>
                    <button onClick={() => { setImportValidationErrors({}); setImportedContracts(new Set()); }}
                      className="text-[10px] px-2 py-1 bg-white text-red-600 border border-red-200 rounded hover:bg-red-50 transition-colors">
                      <X className="w-3 h-3 inline mr-0.5" /> Dismiss
                    </button>
                  </div>
                )}
              </div>
            )
          ) : (
            /* ─── SUB-PRODUCT ESTIMATION TAB ──────────────────────────── */
            <div className="px-6 py-6 overflow-y-auto">
              {/* Info Banner */}
              <div className="mb-3.5 bg-[#f0f0ff] border border-[#c7d2fe] rounded-[5px] px-3.5 py-2.5">
                <p className="text-[11px] text-[#4338ca] leading-relaxed">
                  ⊞ Sub-Product mode is active. Totals entered here roll up automatically to the Portfolio Exposure view. Contract list review is still required on the Impacted Contracts tab.
                </p>
              </div>

              {/* Sub-Product Cards */}
              {(() => {
                // Get or create sub-product cards based on selected BU
                let cardsToShow: SubProductData[] = [];
                
                if (isGroupView) {
                  // In group view, show all BUs that have data
                  cardsToShow = subProductData.filter(sp => sp.rows.length > 0);
                } else {
                  // For specific BU, find or create card
                  const existing = subProductData.find(sp => sp.buId === selectedBU);
                  if (existing) {
                    cardsToShow = [existing];
                  } else if (selectedBU) {
                    // Create a temporary card for this BU
                    const buNode = findBUNode(BU_HIERARCHY, selectedBU);
                    const buName = buNode ? (PRODUCT_NODE_TO_NAME[selectedBU] || BU_NAME_MAP[selectedBU] || buNode.name) : selectedBU;
                    cardsToShow = [{
                      buId: selectedBU,
                      buName: buName,
                      segment: buName,
                      emoji: '📊',
                      mode: 'sub-product' as const,
                      rows: [],
                      submittedBy: undefined,
                      submittedAt: undefined,
                    }];
                  }
                }

                if (cardsToShow.length === 0 && isGroupView) {
                  return (
                    <div className="flex items-center justify-center py-12">
                      <div className="text-center">
                        <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                        <h3 className="text-[14px] font-semibold text-slate-700 mb-2">No Sub-Product Data</h3>
                        <p className="text-[12px] text-slate-500 max-w-md">
                          Select a business unit to start adding sub-product estimates.
                        </p>
                      </div>
                    </div>
                  );
                }

                return cardsToShow.map(sp => {
                const rollup = calculateSubProductRollup(sp.rows);
                const hasData = sp.rows.some(r => r.low || r.best || r.high);

                return (
                  <div key={sp.buId} className="mb-3.5 bg-white border border-slate-200 rounded-md overflow-hidden">
                    {/* Card Header */}
                    <div className="bg-slate-50 border-b border-slate-200 px-3.5 py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[13px] font-bold text-[#1e3a5f] flex items-center gap-1.5">
                          <span>{sp.emoji}</span>
                          <span>{sp.segment}</span>
                        </span>
                        <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-[10px] font-semibold rounded">
                          Sub-Product Mode
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-slate-600 font-mono">
                          Rollup → Low: <span className="font-bold text-green-600">${rollup.low.toFixed(2)}M</span> Best: <span className="font-bold text-amber-600">${rollup.best.toFixed(2)}M</span> High: <span className="font-bold text-slate-700">${rollup.high.toFixed(2)}M</span>
                        </span>
                        {sp.submittedBy && sp.submittedAt && (
                          <span className="text-[11px] text-slate-500">
                            {sp.submittedBy} · {sp.submittedAt}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Column Headers */}
                    <div className="bg-slate-50 border-b border-slate-200 px-3.5 py-1.5 grid grid-cols-[1.2fr_90px_90px_90px_1fr_60px] gap-2 items-center">
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider">Sub-Product</span>
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider text-right">Low</span>
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider text-right">Best</span>
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider text-right">High</span>
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider">Notes / Source</span>
                      <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider text-center"></span>
                    </div>

                    {/* Data Rows */}
                    {sp.rows.map(row => (
                      <div key={row.id} className="px-3.5 py-1.5 grid grid-cols-[1.2fr_90px_90px_90px_1fr_60px] gap-2 items-center border-b border-slate-100">
                        <SubProductNameCombobox
                          value={row.name}
                          catalog={subProductCatalog[sp.buId] || []}
                          disabled={eventLocked}
                          onChange={(val) => updateSubProductRow(sp.buId, row.id, 'name', val)}
                          onCommit={(val) => addToCatalog(sp.buId, val)}
                        />
                        <input
                          type="text"
                          value={row.low}
                          onChange={(e) => updateSubProductRow(sp.buId, row.id, 'low', e.target.value)}
                          disabled={eventLocked}
                          className="bg-slate-50 border border-slate-200 rounded-sm px-2 py-1 text-[11px] text-green-600 font-bold font-mono text-right focus:outline-none focus:ring-1 focus:ring-blue-400 disabled:opacity-50"
                          placeholder="$0.00M"
                        />
                        <input
                          type="text"
                          value={row.best}
                          onChange={(e) => updateSubProductRow(sp.buId, row.id, 'best', e.target.value)}
                          disabled={eventLocked}
                          className="bg-slate-50 border border-slate-200 rounded-sm px-2 py-1 text-[11px] text-amber-600 font-bold font-mono text-right focus:outline-none focus:ring-1 focus:ring-blue-400 disabled:opacity-50"
                          placeholder="$0.00M"
                        />
                        <input
                          type="text"
                          value={row.high}
                          onChange={(e) => updateSubProductRow(sp.buId, row.id, 'high', e.target.value)}
                          disabled={eventLocked}
                          className="bg-slate-50 border border-slate-200 rounded-sm px-2 py-1 text-[11px] text-slate-700 font-bold font-mono text-right focus:outline-none focus:ring-1 focus:ring-blue-400 disabled:opacity-50"
                          placeholder="$0.00M"
                        />
                        <input
                          type="text"
                          value={row.notes}
                          onChange={(e) => updateSubProductRow(sp.buId, row.id, 'notes', e.target.value)}
                          disabled={eventLocked}
                          className="bg-slate-50 border border-slate-200 rounded-sm px-2 py-1 text-[11px] text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-400 disabled:opacity-50"
                          placeholder="Notes or source"
                        />
                        <button
                          onClick={() => deleteSubProductRow(sp.buId, row.id)}
                          disabled={eventLocked}
                          className="text-slate-400 hover:text-red-600 transition-colors disabled:opacity-30 text-center"
                          title="Delete row"
                        >
                          🗑
                        </button>
                      </div>
                    ))}

                    {/* Add Sub-Product Button */}
                    <button
                      onClick={() => {
                        const newRow: SubProductRow = {
                          id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                          name: '', low: '', best: '', high: '', notes: '',
                        };
                        setSubProductData(prev => {
                          const exists = prev.some(s => s.buId === sp.buId);
                          if (exists) {
                            return prev.map(s => s.buId === sp.buId
                              ? { ...s, rows: [...s.rows, newRow] }
                              : s
                            );
                          }
                          // BU card was temporary (not yet in state) — persist it now with the new row
                          return [...prev, { ...sp, rows: [newRow] }];
                        });
                      }}
                      disabled={eventLocked}
                      className="w-full bg-slate-50 border-t border-slate-200 px-3.5 py-2 text-[11px] text-slate-600 hover:text-blue-600 text-left transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      ＋ Add Sub-Product
                    </button>

                    {/* Auto-Rollup Bar */}
                    {hasData ? (
                      <div className="bg-sky-50 border-t border-sky-200 px-3.5 py-2 flex items-center justify-between">
                        <span className="text-[9px] font-bold text-sky-700 uppercase tracking-wider">
                          AUTO-ROLLUP TO PORTFOLIO VIEW
                        </span>
                        <div className="flex items-center gap-3 text-[12px] font-bold font-mono">
                          <span className="text-green-600">Low ${rollup.low.toFixed(2)}M</span>
                          <span className="text-amber-600">Best ${rollup.best.toFixed(2)}M</span>
                          <span className="text-slate-700">High ${rollup.high.toFixed(2)}M</span>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-red-50 border-t border-red-200 px-3.5 py-2 flex items-center justify-between">
                        <span className="text-[9px] font-bold text-red-600 uppercase tracking-wider">
                          PENDING — NO DATA ENTERED
                        </span>
                        <div className="flex items-center gap-3 text-[12px] font-bold font-mono text-slate-400">
                          <span>—</span>
                          <span>—</span>
                          <span>—</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              });
              })()}
            </div>
          )}
        </div>
      </div>
      </div>

      {/* ═══ EXPANDED TABLE OVERLAY ══════════════════════════════════════ */}
      {tableExpanded && contentTab === 'estimates' && (
        <div className="fixed inset-0 z-50 bg-white flex flex-col">
          {/* Expanded header bar */}
          <div className="shrink-0 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white px-4 py-2 flex items-center gap-3">
            <FileText className="w-4 h-4 text-blue-600" />
            <span className="text-[12px] font-semibold text-slate-800">UW Estimation — Expanded View</span>
            {selectedBU && (<><ChevronRight className="w-3 h-3 text-slate-400" /><span className="text-[12px] text-blue-600 font-medium">{currentBUName}</span></>)}
            <span className="text-[10px] text-slate-400 ml-2">{impactFilteredEstimates.length} contracts</span>
            <div className="flex-1" />
            <div className="flex items-center gap-1.5 mr-3">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider">Currency:</span>
              <select
                value={displayCurrency}
                onChange={(e) => setDisplayCurrency(e.target.value as DisplayCurrency)}
                className="text-[11px] px-2 py-1 bg-white border border-slate-200 rounded hover:border-blue-300 focus:ring-1 focus:ring-blue-400 outline-none cursor-pointer"
              >
                {DISPLAY_CURRENCIES.map(c => (
                  <option key={c} value={c}>{CUR_LABELS[c]}</option>
                ))}
              </select>
              {displayCurrency !== 'USD' && (
                <span className="text-[10px] px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded">
                  {displayCurrency === 'ORIGINAL' ? 'Orig' : `1 USD = ${(USD_TO_RATE[displayCurrency] || 1).toFixed(2)} ${displayCurrency}`}
                </span>
              )}
            </div>
            <button onClick={() => setTableExpanded(false)} className="flex items-center gap-1 text-[11px] px-3 py-1.5 bg-slate-700 text-white rounded hover:bg-slate-800 transition-colors">
              <Minimize2 className="w-3.5 h-3.5" /> Collapse
            </button>
          </div>
          {/* Expanded table — scrolls with overflow */}
          <div className="flex-1 overflow-auto px-2 py-1">
            <MaterialReactTable table={table} />
          </div>
        </div>
      )}

      {/* ═══ UPLOAD MODAL ═══════════════════════════════════════════════ */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowUploadModal(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-[600px] max-h-[80vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Upload className="w-4 h-4 text-blue-600" />
                <h2 className="text-[14px] font-semibold text-slate-800">Import UW Estimates</h2>
              </div>
              <button onClick={() => { setShowUploadModal(false); setUploadedFile(null); setUploadPreview(null); }} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
            </div>

            <div className="p-5">
              {!uploadedFile ? (
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${uploadDragActive ? 'border-blue-400 bg-blue-50' : 'border-slate-200 hover:border-blue-300'}`}
                  onDragOver={(e) => { e.preventDefault(); setUploadDragActive(true); }}
                  onDragLeave={() => setUploadDragActive(false)}
                  onDrop={(e) => { e.preventDefault(); setUploadDragActive(false); if (e.dataTransfer.files[0]) handleUploadFile(e.dataTransfer.files[0]); }}
                >
                  <Upload className="w-8 h-8 text-slate-400 mx-auto mb-3" />
                  <p className="text-[13px] text-slate-600 mb-1">Drag & drop your Excel file here</p>
                  <p className="text-[11px] text-slate-400 mb-3">Supports .xlsx, .xls, .csv</p>
                  <button onClick={() => uploadFileRef.current?.click()}
                    className="text-[11px] px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                    Browse Files
                  </button>
                  <input ref={uploadFileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden"
                    onChange={(e) => { if (e.target.files?.[0]) handleUploadFile(e.target.files[0]); }} />
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-lg px-4 py-3 mb-4">
                    <FileText className="w-5 h-5 text-green-600" />
                    <div className="flex-1">
                      <p className="text-[12px] font-medium text-green-800">{uploadedFile.name}</p>
                      <p className="text-[10px] text-green-600">{(uploadedFile.size / 1024).toFixed(1)} KB</p>
                    </div>
                    <button onClick={() => { setUploadedFile(null); setUploadPreview(null); }}
                      className="text-green-600 hover:text-green-800"><X className="w-4 h-4" /></button>
                  </div>

                  {uploadPreview && (
                    <div className="mb-4">
                      <p className="text-[11px] font-semibold text-slate-700 mb-2">Preview (first {uploadPreview.length} rows)</p>
                      <div className="border border-slate-200 rounded overflow-x-auto max-h-48">
                        <table className="w-full text-[10px]">
                          <thead>
                            <tr className="bg-slate-50">{Object.keys(uploadPreview[0] || {}).slice(0, 6).map(h => <th key={h} className="px-2 py-1.5 text-left font-semibold text-slate-600 border-b">{h}</th>)}</tr>
                          </thead>
                          <tbody>
                            {uploadPreview.map((row, i) => (
                              <tr key={i} className="border-b border-slate-100">{Object.values(row).slice(0, 6).map((v: any, j) => <td key={j} className="px-2 py-1 text-slate-600 truncate max-w-[120px]">{String(v ?? '')}</td>)}</tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div className="mb-4">
                    <label className="block text-[11px] text-slate-500 mb-1">Upload Comment (optional)</label>
                    <textarea value={uploadComment} onChange={(e) => setUploadComment(e.target.value)} rows={2}
                      placeholder="Add context for this upload..."
                      className="w-full text-[12px] border border-slate-200 rounded px-3 py-2 outline-none focus:ring-1 focus:ring-blue-300 resize-none" />
                  </div>

                  <div className="flex items-center gap-2">
                    <button onClick={processUpload}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm">
                      <Upload className="w-3.5 h-3.5" /> Import & Apply
                    </button>
                    <button onClick={() => { setShowUploadModal(false); setUploadedFile(null); setUploadPreview(null); }}
                      className="text-[11px] px-3 py-2 text-slate-500 hover:text-slate-700">Cancel</button>
                  </div>

                  <div className="mt-4 bg-slate-50 border border-slate-200 rounded p-3">
                    <p className="text-[10px] font-semibold text-slate-600 mb-1">Expected columns:</p>
                    <p className="text-[10px] text-slate-500">Contract # | UW Low | UW Best | UW High | Notes</p>
                    <p className="text-[10px] text-slate-400 mt-1">Contracts matching by contract number will have their estimates updated. Unmatched rows are skipped.</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══ SUBMIT MODAL ═══════════════════════════════════════════════ */}
      {showSubmitModal && (() => {
        const leafBUs = getImpactTableRows;
        const previewSegments = leafBUs.map(leaf => {
          const resp = buResponses[leaf.id];
          const rowD = impactRowData[leaf.id] || { low: '', best: '', high: '', notes: '', expectations: '', exposureAsOf: '' };
          const totals = uwTotalsPerBU[leaf.id] || { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
          return {
            segment: leaf.name,
            hasExposure: resp?.response === 'yes' ? 'Yes' : resp?.response === 'no' ? 'No' : 'Pending',
            low: rowD.low || (totals.low > 0 ? formatCurrency(totals.low) : '—'),
            best: rowD.best || (totals.best > 0 ? formatCurrency(totals.best) : '—'),
            high: rowD.high || (totals.high > 0 ? formatCurrency(totals.high) : '—'),
            notes: rowD.notes || '—', expectations: rowD.expectations || '—',
          };
        });
        return (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowSubmitModal(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-[720px] max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-200 shrink-0">
              <div className="flex items-center justify-between">
                <h2 className="text-[14px] font-semibold text-slate-800 flex items-center gap-2">
                  <Send className="w-4 h-4 text-blue-600" /> Submit Estimates — {currentBUName}
                </h2>
                <span className="text-[10px] px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-full">
                  Version {currentVersionCount + 1}
                </span>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-5">
              {/* Summary Stats Cards */}
              <div className="grid grid-cols-5 gap-3 mb-5">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 border border-blue-200 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-blue-500 mb-0.5">Contracts</div>
                  <div className="text-[18px] font-semibold text-blue-800">{stats.total}</div>
                </div>
                <div className="bg-gradient-to-br from-green-50 to-green-100/50 border border-green-200 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-green-500 mb-0.5">Impacted</div>
                  <div className="text-[18px] font-semibold text-green-800">{stats.impactedCount}</div>
                </div>
                <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/50 border border-indigo-200 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-indigo-500 mb-0.5">Gross Best <span className="text-[8px]">({displayCurrency})</span></div>
                  <div className="text-[16px] font-semibold text-indigo-800">{formatCurrency(stats.totalUWMed)}</div>
                </div>
                <div className="bg-gradient-to-br from-orange-50 to-orange-100/50 border border-orange-200 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-orange-500 mb-0.5">Exp. Reinst. Prem. <span className="text-[8px]">({displayCurrency})</span></div>
                  <div className="text-[16px] font-semibold text-orange-800">{stats.totalExpReinst > 0 ? formatCurrency(stats.totalExpReinst) : '—'}</div>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-purple-100/50 border border-purple-200 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-purple-500 mb-0.5">Net Loss <span className="text-[8px]">({displayCurrency})</span></div>
                  <div className="text-[16px] font-semibold text-purple-800">{stats.totalNetLoss > 0 ? formatCurrency(stats.totalNetLoss) : '—'}</div>
                </div>
              </div>

              {/* Impact Decision Preview */}
              <div className="mb-5">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider">Impact Assessment Summary</h3>
                  
                </div>
                <div className="border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                  <table className="w-full text-[11px]">
                    <thead>
                      <tr className="bg-slate-100/80 border-b border-slate-200">
                        <th className="px-3 py-2 text-left text-[10px] font-semibold text-slate-500">Segment</th>
                        <th className="px-2 py-2 text-center text-[10px] font-semibold text-slate-500 w-16">Impact</th>
                        <th className="px-2 py-2 text-right text-[10px] font-semibold text-slate-500 w-24">Low</th>
                        <th className="px-2 py-2 text-right text-[10px] font-semibold text-slate-500 w-24">Best</th>
                        <th className="px-2 py-2 text-right text-[10px] font-semibold text-slate-500 w-24">High</th>
                        <th className="px-2 py-2 text-left text-[10px] font-semibold text-slate-500">Notes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {previewSegments.map((seg, idx) => (
                        <tr key={idx} className={`border-b border-slate-100 transition-colors ${seg.hasExposure === 'Yes' ? 'bg-green-50/40' : seg.hasExposure === 'No' ? 'bg-slate-50/50 opacity-40' : 'bg-white'}`}>
                          <td className="px-3 py-2 text-slate-700">{seg.segment}</td>
                          <td className="px-2 py-2 text-center">
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium ${
                              seg.hasExposure === 'Yes' ? 'bg-green-100 text-green-700' :
                              seg.hasExposure === 'No' ? 'bg-red-100 text-red-600' :
                              'bg-slate-100 text-slate-400'
                            }`}>{seg.hasExposure}</span>
                          </td>
                          <td className="px-2 py-2 text-right font-mono text-blue-700">{seg.low}</td>
                          <td className="px-2 py-2 text-right font-mono font-semibold text-blue-800">{seg.best}</td>
                          <td className="px-2 py-2 text-right font-mono text-blue-700">{seg.high}</td>
                          <td className="px-2 py-2 text-slate-500 truncate max-w-[140px]" title={seg.notes}>{seg.notes}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Submission Comment */}
              <label className="block text-[11px] font-medium text-slate-600 mb-1.5">Submission Comment <span className="text-slate-400 font-normal">(optional)</span></label>
              <textarea value={submitComment} onChange={(e) => setSubmitComment(e.target.value)} rows={3}
                placeholder="Add context, assumptions, or notes for the reviewer..."
                className="w-full text-[12px] border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300 resize-none bg-slate-50/50" />
            </div>
            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center gap-2 justify-between shrink-0">
              <span className="text-[10px] text-slate-400">This creates version {currentVersionCount + 1}. You can submit more updates before Finance locks the event.</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setShowSubmitModal(false)} className="text-[11px] px-3 py-2 text-slate-500 hover:text-slate-700">Cancel</button>
                <button onClick={confirmSubmit}
                  className="flex items-center gap-1.5 text-[11px] px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors shadow-sm">
                  <Send className="w-3.5 h-3.5" /> Submit v{currentVersionCount + 1}
                </button>
              </div>
            </div>
          </div>
        </div>
        );
      })()}

      {/* ═══ REJECT MODAL ═══════════════════════════════════════════════ */}
      {showRejectModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowRejectModal(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-[440px]" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-[14px] font-semibold text-red-700 flex items-center gap-2">
                <XCircle className="w-4 h-4" /> Reject — {rejectingBU ? BU_NAME_MAP[rejectingBU] : ''}
              </h2>
            </div>
            <div className="p-5">
              <label className="block text-[11px] text-slate-500 mb-1">Reason for rejection</label>
              <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} rows={3}
                placeholder="Explain why the estimates are being sent back..."
                className="w-full text-[12px] border border-slate-200 rounded px-3 py-2 outline-none focus:ring-1 focus:ring-red-300 resize-none mb-4" />
              <div className="flex items-center gap-2 justify-end">
                <button onClick={() => { setShowRejectModal(false); setRejectingBU(null); }} className="text-[11px] px-3 py-2 text-slate-500">Cancel</button>
                <button onClick={confirmReject} disabled={!rejectReason.trim()}
                  className="flex items-center gap-1.5 text-[11px] px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors shadow-sm disabled:opacity-50">
                  <XCircle className="w-3.5 h-3.5" /> Reject Submission
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* ═══ SUBMISSION SUMMARY MODAL (shown after Submit) ═══════════════ */}
      {showSubmissionSummary && (() => {
        const sv = showSubmissionSummary;
        const yesCount = sv.segments.filter(s => s.hasExposure === 'Yes').length;
        const noCount = sv.segments.filter(s => s.hasExposure === 'No').length;
        const pendingCount = sv.segments.filter(s => s.hasExposure === 'Pending').length;
        return (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowSubmissionSummary(null)}>
            <div className="bg-white rounded-xl shadow-2xl w-[760px] max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="px-5 py-4 border-b border-slate-200 shrink-0 bg-gradient-to-r from-green-50 to-emerald-50">
                <div className="flex items-center justify-between">
                  <h2 className="text-[14px] font-semibold text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" /> Submission Confirmed — v{sv.version}
                  </h2>
                  <span className="text-[10px] px-2 py-0.5 bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-full">
                    {BU_NAME_MAP[sv.buId] || sv.buId}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-600 mt-1">
                  Submitted by {sv.submittedBy} on {new Date(sv.submittedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'America/New_York' })} EST
                </p>
              </div>
              <div className="flex-1 overflow-auto p-5">
              </div>
              <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
                <span className="text-[10px] text-slate-400">Version {sv.version} is now locked. You can submit a new version (v{sv.version + 1}) with updated data at any time.</span>
                <button onClick={() => setShowSubmissionSummary(null)}
                  className="text-[11px] px-4 py-2 bg-emerald-600 text-white rounded hover:bg-emerald-700 transition-colors shadow-sm">
                  Done
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ═══ VERSION HISTORY MODAL ═══════════════════════════════════════ */}
      {showVersionHistory && selectedBU && (() => {
        const versions = submissionVersions[selectedBU] || [];
        return (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowVersionHistory(false)}>
            <div className="bg-white rounded-xl shadow-2xl w-[820px] max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <h2 className="text-[14px] font-semibold text-slate-800">Submission History</h2>
                  <span className="text-[11px] text-slate-400">— {BU_NAME_MAP[selectedBU] || selectedBU}</span>
                  <span className="text-[10px] px-1.5 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded">{versions.length} version{versions.length !== 1 ? 's' : ''}</span>
                </div>
                <button onClick={() => setShowVersionHistory(false)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
              </div>
              <div className="flex-1 overflow-auto p-4">
                {versions.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-[12px]">No submissions yet. Click "Submit" to create the first version.</div>
                ) : (
                  <div className="space-y-3">
                    {[...versions].reverse().map(v => {
                      const yC = v.segments.filter(s => s.hasExposure === 'Yes').length;
                      const nC = v.segments.filter(s => s.hasExposure === 'No').length;
                      return (
                        <div key={v.id} className="border border-slate-200 rounded-lg overflow-hidden">
                          <div className="px-4 py-3 bg-slate-50 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="inline-flex items-center justify-center px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-100 text-purple-800 border border-purple-200">v{v.version}</span>
                              <div className="text-[11px]">
                                <span className="text-slate-600">by {v.submittedBy}</span>
                                <span className="text-slate-400 ml-2">{new Date(v.submittedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'America/New_York' })} EST</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 text-[10px]">
                              <span className="text-green-600">{yC} Yes</span>
                              <span className="text-red-500">{nC} No</span>
                              <span className="text-slate-400">{v.contractCount} contracts</span>
                            </div>
                          </div>
                          <div className="px-4 py-2 flex items-center gap-6 text-[11px] border-t border-slate-100">
                            <div><span className="text-slate-400">Low:</span> <span className="font-semibold text-blue-700">{formatCurrency(v.totals.low)}</span></div>
                            <div><span className="text-slate-400">Best:</span> <span className="font-semibold text-blue-800">{formatCurrency(v.totals.best)}</span></div>
                            <div><span className="text-slate-400">High:</span> <span className="font-semibold text-blue-700">{formatCurrency(v.totals.high)}</span></div>
                            {v.comment && <div className="ml-auto text-slate-400 truncate max-w-[200px]" title={v.comment}>"{v.comment}"</div>}
                          </div>
                          <details className="border-t border-slate-100">
                            <summary className="px-4 py-1.5 text-[10px] text-slate-400 cursor-pointer hover:text-slate-600 hover:bg-slate-50 transition-colors">
                              Show {v.segments.length} segments
                            </summary>
                            <div className="px-4 pb-2">
                              <table className="w-full text-[10px]">
                                <thead>
                                  <tr className="border-b border-slate-100">
                                    <th className="py-1 text-left text-slate-400">Segment</th>
                                    <th className="py-1 text-center text-slate-400 w-14">Impact</th>
                                    <th className="py-1 text-right text-slate-400 w-16">Low</th>
                                    <th className="py-1 text-right text-slate-400 w-16">Best</th>
                                    <th className="py-1 text-right text-slate-400 w-16">High</th>
                                    <th className="py-1 text-left text-slate-400">Notes</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {v.segments.map((seg, si) => (
                                    <tr key={si} className={`border-b border-slate-50 ${seg.hasExposure === 'Yes' ? 'bg-green-50/40' : ''}`}>
                                      <td className="py-1 text-slate-600">{seg.segment}</td>
                                      <td className="py-1 text-center">
                                        <span className={`px-1 py-0.5 rounded text-[9px] ${seg.hasExposure === 'Yes' ? 'bg-green-100 text-green-700' : seg.hasExposure === 'No' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-400'}`}>{seg.hasExposure}</span>
                                      </td>
                                      <td className="py-1 text-right text-blue-600">{seg.low || '—'}</td>
                                      <td className="py-1 text-right text-blue-700 font-medium">{seg.best || '—'}</td>
                                      <td className="py-1 text-right text-blue-600">{seg.high || '—'}</td>
                                      <td className="py-1 text-slate-400 truncate max-w-[120px]">{seg.notes || '—'}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </details>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
                <span className="text-[10px] text-slate-400">Each version captures the full impact assessment at submission time.</span>
                <button onClick={() => setShowVersionHistory(false)} className="text-[11px] px-3 py-1.5 bg-slate-700 text-white rounded hover:bg-slate-800 transition-colors">Close</button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ═══ SNAPSHOT HISTORY MODAL ═════════════════════════════════════ */}
      {snapshotModalContract && (() => {
        const cn = snapshotModalContract;
        const est = estimates.find(e => e.contractNumber === cn);
        const snaps = estimateSnapshots[cn] || [];
        // Add the current live estimate as "Latest (unsaved)" row
        const currentRow: EstimateSnapshot = {
          id: 'current', contractNumber: cn, version: est?.estimateVersion || 1,
          asOfDate: est?.estimateAsOf || new Date().toISOString(),
          savedAt: est?.estimateAsOf || new Date().toISOString(),
          savedBy: userName || 'Current User',
          uwEstimateLow: est?.uwEstimateLow || '', uwEstimateMed: est?.uwEstimateMed || '',
          uwEstimateHigh: est?.uwEstimateHigh || '', notes: est?.notes || '',
        };
        const allRows = [currentRow, ...snaps];
        // Sort
        const sorted = [...allRows].sort((a, b) => {
          const col = snapshotSort.col;
          let va: any, vb: any;
          if (col === 'version') { va = a.version; vb = b.version; }
          else if (col === 'asOfDate') { va = a.asOfDate; vb = b.asOfDate; }
          else if (col === 'savedBy') { va = a.savedBy; vb = b.savedBy; }
          else if (col === 'uwEstimateLow') { va = parseCurrency(a.uwEstimateLow); vb = parseCurrency(b.uwEstimateLow); }
          else if (col === 'uwEstimateMed') { va = parseCurrency(a.uwEstimateMed); vb = parseCurrency(b.uwEstimateMed); }
          else if (col === 'uwEstimateHigh') { va = parseCurrency(a.uwEstimateHigh); vb = parseCurrency(b.uwEstimateHigh); }
          else { va = a.version; vb = b.version; }
          if (va < vb) return snapshotSort.dir === 'asc' ? -1 : 1;
          if (va > vb) return snapshotSort.dir === 'asc' ? 1 : -1;
          return 0;
        });
        const toggleSort = (col: string) => {
          setSnapshotSort(prev => prev.col === col ? { col, dir: prev.dir === 'asc' ? 'desc' : 'asc' } : { col, dir: 'desc' });
        };
        const SortArrow = ({ col }: { col: string }) => (
          <span className="inline-flex flex-col ml-0.5 leading-none">
            <ChevronDown className={`w-2.5 h-2.5 rotate-180 ${snapshotSort.col === col && snapshotSort.dir === 'asc' ? 'text-blue-600' : 'text-slate-300'}`} />
            <ChevronDown className={`w-2.5 h-2.5 -mt-0.5 ${snapshotSort.col === col && snapshotSort.dir === 'desc' ? 'text-blue-600' : 'text-slate-300'}`} />
          </span>
        );
        return (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setSnapshotModalContract(null)}>
            <div className="bg-white rounded-xl shadow-2xl w-[780px] max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <h2 className="text-[14px] font-semibold text-slate-800">Estimate History</h2>
                  <span className="text-[11px] text-slate-400">— {est?.cedant || cn}</span>
                  <span className="text-[10px] px-1.5 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded">{snaps.length} snapshot{snaps.length !== 1 ? 's' : ''}</span>
                </div>
                <button onClick={() => setSnapshotModalContract(null)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
              </div>
              <div className="flex-1 overflow-auto p-4">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b-2 border-slate-200 bg-slate-50">
                      {[
                        { key: 'version', label: '#', w: 'w-12' },
                        { key: 'asOfDate', label: 'AS OF', w: 'w-36' },
                        { key: 'uwEstimateLow', label: 'UW LOW', w: 'w-20' },
                        { key: 'uwEstimateMed', label: 'UW BEST', w: 'w-20' },
                        { key: 'uwEstimateHigh', label: 'UW HIGH', w: 'w-20' },
                        { key: 'notes', label: 'NOTES', w: 'flex-1' },
                        { key: 'savedBy', label: 'SAVED BY', w: 'w-24' },
                      ].map(c => (
                        <th key={c.key} className={`${c.w} px-2 py-2 text-left font-semibold text-slate-500 cursor-pointer hover:text-blue-600 select-none`}
                          onClick={() => c.key !== 'notes' && toggleSort(c.key)}>
                          <span className="flex items-center gap-0.5">
                            {c.label}
                            {c.key !== 'notes' && <SortArrow col={c.key} />}
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.map((snap, idx) => {
                      const isCurrent = snap.id === 'current';
                      const d = new Date(snap.asOfDate);
                      return (
                        <tr key={snap.id} className={`border-b border-slate-100 ${isCurrent ? 'bg-blue-50/50' : idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'} hover:bg-blue-50/30 transition-colors`}>
                          <td className="px-2 py-2">
                            <span className={`inline-flex items-center justify-center px-1.5 py-0.5 rounded text-[10px] ${isCurrent ? 'bg-blue-100 text-blue-800 border border-blue-200' : 'bg-purple-50 text-purple-700 border border-purple-200'}`}>
                              {isCurrent ? `v${snap.version}*` : `v${snap.version}`}
                            </span>
                          </td>
                          <td className="px-2 py-2 text-slate-600">
                            {d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} {d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                          </td>
                          <td className="px-2 py-2 text-right text-blue-700">{snap.uwEstimateLow || '—'}</td>
                          <td className="px-2 py-2 text-right font-semibold text-blue-800">{snap.uwEstimateMed || '—'}</td>
                          <td className="px-2 py-2 text-right text-blue-700">{snap.uwEstimateHigh || '—'}</td>
                          <td className="px-2 py-2 text-slate-600 truncate max-w-[180px]" title={snap.notes}>{snap.notes || '—'}</td>
                          <td className="px-2 py-2 text-slate-500">
                            {isCurrent ? <span className="text-blue-600 font-medium">Live</span> : snap.savedBy}
                          </td>
                        </tr>
                      );
                    })}
                    {sorted.length === 0 && (
                      <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-400 text-[12px]">No snapshots yet. Click "Save" on the contract row to create a snapshot.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
                <span className="text-[10px] text-slate-400">* Current live estimate (unsaved). Click "Save" to snapshot before modifying.</span>
                <button onClick={() => setSnapshotModalContract(null)} className="text-[11px] px-3 py-1.5 bg-slate-700 text-white rounded hover:bg-slate-800 transition-colors">Close</button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ═══ IMPACT REPORT HISTORY MODAL ══════════════════════════════════ */}
      {showImpactHistory && (() => {
        const buId = showImpactHistory;
        const buName = BU_NAME_MAP[buId] || buId;
        const entries = impactEntries[buId] || [];
        const totals = uwTotalsPerBU[buId] || { low: 0, best: 0, high: 0, expReinst: 0, netLoss: 0 };
        const toggleHSort = (col: string) => {
          setImpactHistorySort(prev => prev.col === col ? { col, dir: prev.dir === 'asc' ? 'desc' : 'asc' } : { col, dir: 'desc' });
        };
        const HSortArrow = ({ col }: { col: string }) => (
          <span className="inline-flex flex-col ml-0.5 leading-none">
            <ChevronDown className={`w-2.5 h-2.5 rotate-180 ${impactHistorySort.col === col && impactHistorySort.dir === 'asc' ? 'text-blue-600' : 'text-slate-300'}`} />
            <ChevronDown className={`w-2.5 h-2.5 -mt-0.5 ${impactHistorySort.col === col && impactHistorySort.dir === 'desc' ? 'text-blue-600' : 'text-slate-300'}`} />
          </span>
        );
        const sorted = [...entries].sort((a, b) => {
          const col = impactHistorySort.col;
          let va: any, vb: any;
          if (col === 'version') { va = entries.indexOf(a); vb = entries.indexOf(b); }
          else if (col === 'savedAt') { va = a.savedAt; vb = b.savedAt; }
          else if (col === 'savedBy') { va = a.savedBy; vb = b.savedBy; }
          else if (col === 'estimateBest') { va = parseFloat(a.estimateBest) || 0; vb = parseFloat(b.estimateBest) || 0; }
          else { va = entries.indexOf(a); vb = entries.indexOf(b); }
          if (va < vb) return impactHistorySort.dir === 'asc' ? -1 : 1;
          if (va > vb) return impactHistorySort.dir === 'asc' ? 1 : -1;
          return 0;
        });
        return (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center" onClick={() => setShowImpactHistory(null)}>
            <div className="bg-white rounded-xl shadow-2xl w-[860px] max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <h2 className="text-[14px] font-semibold text-slate-800">Impact Reports History</h2>
                  <span className="text-[11px] text-slate-400">— {buName}</span>
                  <span className="text-[10px] px-1.5 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded">{entries.length} report{entries.length !== 1 ? 's' : ''}</span>
                </div>
                <button onClick={() => setShowImpactHistory(null)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
              </div>
              {/* Current UW Totals Banner */}
              <div className="px-5 py-2 bg-blue-50 border-b border-blue-200 flex items-center gap-6 text-[11px]">
                <span className="text-blue-500 font-medium">Current UW Totals:</span>
                <span className="text-blue-700">Low: <b>{formatCurrency(totals.low)}</b></span>
                <span className="text-blue-800">Best: <b>{formatCurrency(totals.best)}</b></span>
                <span className="text-blue-700">High: <b>{formatCurrency(totals.high)}</b></span>
              </div>
              <div className="flex-1 overflow-auto p-4">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b-2 border-slate-200 bg-slate-50">
                      {[
                        { key: 'version', label: '#', w: 'w-12' },
                        { key: 'savedAt', label: 'DATE', w: 'w-36' },
                        { key: 'estimateLow', label: 'LOW', w: 'w-20' },
                        { key: 'estimateBest', label: 'BEST', w: 'w-20' },
                        { key: 'estimateHigh', label: 'HIGH', w: 'w-20' },
                        { key: 'notes', label: 'NOTES', w: 'flex-1' },
                        { key: 'expectations', label: 'EXPECTATIONS', w: 'w-32' },
                        { key: 'savedBy', label: 'SAVED BY', w: 'w-24' },
                      ].map(c => (
                        <th key={c.key} className={`${c.w} px-2 py-2 text-left font-semibold text-slate-500 cursor-pointer hover:text-blue-600 select-none`}
                          onClick={() => !['notes', 'expectations'].includes(c.key) && toggleHSort(c.key)}>
                          <span className="flex items-center gap-0.5">
                            {c.label}
                            {!['notes', 'expectations'].includes(c.key) && <HSortArrow col={c.key} />}
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.map((entry, idx) => {
                      const d = new Date(entry.savedAt);
                      const vNum = entries.indexOf(entry) + 1;
                      return (
                        <tr key={entry.id} className={`border-b border-slate-100 ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'} hover:bg-blue-50/30 transition-colors`}>
                          <td className="px-2 py-2">
                            <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded text-[10px] bg-purple-50 text-purple-700 border border-purple-200">v{vNum}</span>
                          </td>
                          <td className="px-2 py-2 text-slate-600">
                            {d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} {d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                          </td>
                          <td className="px-2 py-2 text-right text-blue-700">{entry.estimateLow ? `$${entry.estimateLow}` : '—'}</td>
                          <td className="px-2 py-2 text-right font-semibold text-blue-800">{entry.estimateBest ? `$${entry.estimateBest}` : '—'}</td>
                          <td className="px-2 py-2 text-right text-blue-700">{entry.estimateHigh ? `$${entry.estimateHigh}` : '—'}</td>
                          <td className="px-2 py-2 text-slate-600 truncate max-w-[180px]" title={entry.notes}>{entry.notes || '—'}</td>
                          <td className="px-2 py-2 text-slate-600 truncate max-w-[120px]" title={entry.expectations}>{entry.expectations || '—'}</td>
                          <td className="px-2 py-2 text-slate-500">{entry.savedBy}</td>
                        </tr>
                      );
                    })}
                    {entries.length === 0 && (
                      <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400 text-[12px]">No reports saved yet. Click "+ Add" on the segment row to save the first report.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
                <span className="text-[10px] text-slate-400">Each report captures notes, expectations, and UW totals at the time of saving.</span>
                <button onClick={() => setShowImpactHistory(null)} className="text-[11px] px-3 py-1.5 bg-slate-700 text-white rounded hover:bg-slate-800 transition-colors">Close</button>
              </div>
            </div>
          </div>
        );
      })()}

    </div>
  );
}

export default UnderwriterEstimationNew;
