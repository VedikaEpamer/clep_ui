import { useState, useMemo, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Download, Upload, Building2, Lock, Unlock, Send, ChevronDown, Bell, Users, Check, X, MessageSquare, Clock } from 'lucide-react';
import { mockEvents } from '../../lib/mockData';
import { useWorkflow } from '../../lib/workflowContext';
import { ContractMetadata } from './ContractCapture';
import { chileEarthquakeContracts } from '../../lib/chileEarthquakeContracts';
import * as XLSX from 'xlsx';
import { toast } from 'sonner@2.0.3';

// Use Chile Earthquake historical contract data for EVT-2024-012
const mockContracts: ContractMetadata[] = chileEarthquakeContracts;

interface ContractEstimate extends ContractMetadata {
  catModelStatus: 'Listed' | 'Not Listed' | 'Pending';
  validationStatus?: 'valid' | 'not-in-rdm';
  impactStatus?: 'Impacted' | 'Not Impacted' | 'Excluded' | 'Manual' | 'Not in RDM';
  team?: string;
  effectDate?: string;
  signedShare?: string;
  dreamLimit?: string;
  limit100Pct?: string;
  attachPoint?: string;
  premium?: string;
  dreamReEQLoss?: string;
  reinstNumber?: string;
  reinstPremium?: string;
  uwEstimateLow: string;
  uwEstimateHigh: string;
  modelingLow: string;
  modelingHigh: string;
  netOfRI?: string;
  netOfMountLogan?: string;
  netOfOtherCessions?: string;
  finalNetNet?: string;
}

// Data version
const DATA_VERSION = '1.0';

// ── Reporting Level → Executive Area / Business Unit / IBNR Mapping ──
interface RLMapping {
  execArea: string;
  businessUnit: string;
  ibnrTag: string;
}

const RL_MAP: Record<string, RLMapping> = {
  // Facultative — International
  'LAF - Property Pro Rata Fac':   { execArea: 'Facultative', businessUnit: 'Latin America Fac', ibnrTag: 'NC_FPROPPR' },
  'LAF - Property Excess Fac':     { execArea: 'Facultative', businessUnit: 'Latin America Fac', ibnrTag: 'NC_FPROPXS' },
  'LAF - Casualty Excess':         { execArea: 'Facultative', businessUnit: 'Latin America Fac', ibnrTag: 'NC_E&O_D&O' },
  'LF - Property Pro Rata Fac':    { execArea: 'Facultative', businessUnit: 'London Fac', ibnrTag: 'LF_PROPPRI' },
  'LF - Property Excess Fac':      { execArea: 'Facultative', businessUnit: 'London Fac', ibnrTag: 'LF_PROP_XS' },
  'ASF - Property Excess Fac':     { execArea: 'Facultative', businessUnit: 'Singapore Fac', ibnrTag: 'Z*_FPRP_XS' },
  // Facultative — North America
  'FP - Property Excess':          { execArea: 'Facultative', businessUnit: 'NA Fac Property', ibnrTag: 'G*_PROP_XS' },
  'FC - Cyber Pro Rata':           { execArea: 'Facultative', businessUnit: 'NA Fac Casualty', ibnrTag: 'CYBER_PR' },
  'FC - Specialty':                { execArea: 'Facultative', businessUnit: 'NA Fac Casualty', ibnrTag: 'UA_E&O_D&O' },
  'FC - Casualty Occurrence':      { execArea: 'Facultative', businessUnit: 'NA Fac Casualty', ibnrTag: 'T*_GENLIAB' },
  'CF - Casualty Excess':          { execArea: 'Facultative', businessUnit: 'Canada Fac', ibnrTag: 'JA_AUTOLIA' },
  'CF - Property Pro Rata':        { execArea: 'Facultative', businessUnit: 'Canada Fac', ibnrTag: 'JA_PROP_PR' },
  // International Treaty
  'LAT - Property Cat':            { execArea: 'International Treaty', businessUnit: 'Latin America Treaty', ibnrTag: 'NC_PROPCAT' },
  'LAT - Property Pro Rata':       { execArea: 'International Treaty', businessUnit: 'Latin America Treaty', ibnrTag: 'NC_PROP_PR' },
  'LAT - Property Excess':         { execArea: 'International Treaty', businessUnit: 'Latin America Treaty', ibnrTag: 'NC_PROP_XS' },
  'AS - Property High Excess':     { execArea: 'International Treaty', businessUnit: 'Singapore Treaty', ibnrTag: 'Z*_TPHI_XS' },
  'DU - Marine Excess':            { execArea: 'International Treaty', businessUnit: 'Dublin / Zurich', ibnrTag: 'DU_MARXL' },
  // NA Treaty
  'TP - Property Catastrophe':     { execArea: 'NA Treaty', businessUnit: 'Treaty Property', ibnrTag: 'E*_PROPCAT' },
  'BM - Multiline':                { execArea: 'NA Treaty', businessUnit: 'Bermuda', ibnrTag: 'BR_MULTILN' },
  'BM - Property Cat':             { execArea: 'NA Treaty', businessUnit: 'Bermuda', ibnrTag: 'BR_PROP_CA' },
  // Product
  'LV - Aviation Retro':           { execArea: 'Product', businessUnit: 'Aviation', ibnrTag: 'LV_AVRETRO' },
  // Financial Lines
  'BM - US Mortgage Insurance':    { execArea: 'Financial Lines', businessUnit: 'Financial Lines', ibnrTag: 'BR_US_MI' },
};

const getMapping = (rl: string): RLMapping =>
  RL_MAP[rl] || { execArea: 'Other', businessUnit: 'Other', ibnrTag: 'UNKNOWN' };

export function FinanceEstimation() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const event = mockEvents.find(e => e.id === eventId);
  const { getWorkflowStatus, getEventStatus } = useWorkflow();

  const [estimates, setEstimates] = useState<ContractEstimate[]>([]);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeView, setActiveView] = useState<'flat' | 'team'>('flat');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCedant, setFilterCedant] = useState('');

  // ── Lock / Unlock workflow state ──
  const [lockStatus, setLockStatus] = useState<'unlocked' | 'locked' | 'submitted'>('unlocked');
  const [showSubmitPanel, setShowSubmitPanel] = useState(false);
  const [notifyTargets, setNotifyTargets] = useState<Set<string>>(new Set());
  const [submitNote, setSubmitNote] = useState('');
  const [showNotifyDropdown, setShowNotifyDropdown] = useState(false);
  const notifyDropdownRef = useRef<HTMLDivElement>(null);
  const [submissionLog, setSubmissionLog] = useState<Array<{
    timestamp: Date;
    action: string;
    targets: string[];
    note: string;
  }>>([]);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifyDropdownRef.current && !notifyDropdownRef.current.contains(e.target as Node)) {
        setShowNotifyDropdown(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Notification target options
  const NOTIFY_OPTIONS = [
    { id: 'cat_team', label: 'CAT Modeling Team', description: 'Request updated model runs', icon: '🔬' },
    { id: 'uw_contributors', label: 'UW Contributors', description: 'Request revised UW estimates', icon: '📋' },
    { id: 'bu_leads', label: 'Business Unit Leads', description: 'Notify for BU review & sign-off', icon: '👤' },
    { id: 'event_coordinator', label: 'Event Coordinator', description: 'Escalate to event coordinator', icon: '🎯' },
    { id: 'finance_final', label: 'Unlock for Final', description: 'Mark finance complete — no notification', icon: '✅' },
  ];

  const toggleNotifyTarget = (id: string) => {
    setNotifyTargets(prev => {
      const next = new Set(prev);
      if (id === 'finance_final') {
        // "Unlock for Final" is exclusive — clears all others
        if (next.has('finance_final')) {
          next.delete('finance_final');
        } else {
          next.clear();
          next.add('finance_final');
        }
      } else {
        // Selecting any team clears "finance_final"
        next.delete('finance_final');
        if (next.has(id)) {
          next.delete(id);
        } else {
          next.add(id);
        }
      }
      return next;
    });
  };

  const handleSubmitAction = () => {
    const targets = Array.from(notifyTargets);
    const isFinal = targets.includes('finance_final');
    const targetLabels = targets.map(t => NOTIFY_OPTIONS.find(o => o.id === t)?.label || t);

    setSubmissionLog(prev => [...prev, {
      timestamp: new Date(),
      action: isFinal ? 'Unlocked for Final' : 'Submitted & Notified',
      targets: targetLabels,
      note: submitNote,
    }]);

    if (isFinal) {
      setLockStatus('submitted');
      toast.success('Finance estimates unlocked for final. Event marked complete from Finance.');
    } else {
      setLockStatus('locked');
      toast.success(`Submitted. Notifications sent to: ${targetLabels.join(', ')}`);
    }

    setShowSubmitPanel(false);
    setNotifyTargets(new Set());
    setSubmitNote('');
  };

  // Initialize estimates from mock data
  useState(() => {
    const loadedEstimates: ContractEstimate[] = mockContracts.map((contract) => ({
      ...contract,
      catModelStatus: Math.random() > 0.3 ? 'Listed' : 'Not Listed',
      validationStatus: Math.random() > 0.1 ? 'valid' : 'not-in-rdm',
      impactStatus: 'Impacted' as const,
      uwEstimateLow: (Math.random() * 5000000 + 1000000).toFixed(2),
      uwEstimateHigh: (Math.random() * 8000000 + 3000000).toFixed(2),
      modelingLow: (Math.random() * 4500000 + 900000).toFixed(2),
      modelingHigh: (Math.random() * 7500000 + 2800000).toFixed(2),
      reinstPremium: (Math.random() * 200000 + 50000).toFixed(2),
    }));
    setEstimates(loadedEstimates);
  });

  // Helper functions
  const parseCurrency = (value: string | undefined): number => {
    if (!value) return 0;
    const cleaned = value.replace(/[$,]/g, '');
    return parseFloat(cleaned) || 0;
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const updateEstimateField = (contractNumber: string, field: string, value: any) => {
    setEstimates(prev => 
      prev.map(est => 
        est.contractNumber === contractNumber 
          ? { ...est, [field]: value }
          : est
      )
    );
  };

  // Filtered estimates
  const filteredEstimates = useMemo(() => {
    return estimates.filter(est => {
      if (searchTerm && !est.contractName.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !est.contractNumber.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !est.cedant.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }
      if (filterCedant && est.cedant !== filterCedant) {
        return false;
      }
      return true;
    });
  }, [estimates, searchTerm, filterCedant]);

  // Helper: compute totals for a set of contracts
  const computeGroupTotals = (contracts: ContractEstimate[]) => {
    return contracts.reduce((acc, c) => {
      const uwL = parseCurrency(c.uwEstimateLow);
      const uwH = parseCurrency(c.uwEstimateHigh);
      const uwM = (uwL + uwH) / 2;
      const mL = parseCurrency(c.modelingLow);
      const mH = parseCurrency(c.modelingHigh);
      const mM = (mL + mH) / 2;
      const nri = parseCurrency(c.netOfRI) || (uwM - parseCurrency(c.reinstPremium || '0'));
      const nml = parseCurrency(c.netOfMountLogan) || (nri * 0.95);
      const nf = parseCurrency(c.netOfOtherCessions) || (nml * 0.98);
      return {
        uwLow: acc.uwLow + uwL, uwMid: acc.uwMid + uwM, uwHigh: acc.uwHigh + uwH,
        modelLow: acc.modelLow + mL, modelMid: acc.modelMid + mM, modelHigh: acc.modelHigh + mH,
        netRI: acc.netRI + nri, netML: acc.netML + nml, netFinal: acc.netFinal + nf,
        count: acc.count + 1,
      };
    }, { uwLow: 0, uwMid: 0, uwHigh: 0, modelLow: 0, modelMid: 0, modelHigh: 0, netRI: 0, netML: 0, netFinal: 0, count: 0 });
  };

  // Build the hierarchy: Exec Area → Business Unit → Reporting Level → contracts
  const hierarchy = useMemo(() => {
    const execAreaOrder = ['Facultative', 'International Treaty', 'NA Treaty', 'Product', 'Financial Lines'];
    const map: Record<string, Record<string, Record<string, ContractEstimate[]>>> = {};

    filteredEstimates.forEach(est => {
      const m = getMapping(est.reportingLevel);
      if (!map[m.execArea]) map[m.execArea] = {};
      if (!map[m.execArea][m.businessUnit]) map[m.execArea][m.businessUnit] = {};
      if (!map[m.execArea][m.businessUnit][est.reportingLevel]) map[m.execArea][m.businessUnit][est.reportingLevel] = [];
      map[m.execArea][m.businessUnit][est.reportingLevel].push(est);
    });

    return execAreaOrder
      .filter(ea => map[ea])
      .map(ea => ({
        execArea: ea,
        businessUnits: Object.entries(map[ea]).map(([bu, rls]) => ({
          businessUnit: bu,
          reportingLevels: Object.entries(rls).map(([rl, contracts]) => ({
            reportingLevel: rl,
            ibnrTag: getMapping(rl).ibnrTag,
            contracts,
          })),
        })),
      }));
  }, [filteredEstimates]);

  // Export to Excel
  const handleExportExcel = () => {
    const exportData = filteredEstimates.map(est => {
      const uwAvg = (parseCurrency(est.uwEstimateLow) + parseCurrency(est.uwEstimateHigh)) / 2;
      const modelAvg = (parseCurrency(est.modelingLow) + parseCurrency(est.modelingHigh)) / 2;
      const netRI = parseCurrency(est.netOfRI) || (uwAvg - parseCurrency(est.reinstPremium || '0'));
      const netML = parseCurrency(est.netOfMountLogan) || (netRI * 0.95);
      const netFinal = parseCurrency(est.netOfOtherCessions) || (netML * 0.98);
      
      return {
        'Cedant': est.cedant,
        'Contract Name': est.contractName,
        'Contract Number': est.contractNumber,
        'UW Estimate': uwAvg,
        'Modeling Estimate': modelAvg,
        'Net of RI Premium': netRI,
        'Net of Mount Logan': netML,
        'Final Net-Net-Net': netFinal,
      };
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Finance Estimates');
    XLSX.writeFile(wb, `SONAR_Finance_Estimation_${event?.eventName || eventId}_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Finance estimates exported successfully');
  };

  // Render Flat View
  const renderFlatView = () => (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden w-full">
      <div className={isFullscreen ? "max-h-[calc(100vh-120px)] overflow-auto" : "max-h-[calc(100vh-400px)] overflow-auto"}>
        <table className="w-full table-auto">
          <thead className="sticky top-0 z-30 bg-slate-50 border-b border-slate-200">
            {/* Top header row with grouped column labels */}
            <tr>
                <th className="px-1 py-1 text-center text-xs text-slate-500" style={{ width: '32px', minWidth: '32px' }} rowSpan={2}>
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300"
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedRows(new Set(filteredEstimates.map(est => est.contractNumber)));
                      } else {
                        setSelectedRows(new Set());
                      }
                    }}
                    checked={selectedRows.size === filteredEstimates.length && filteredEstimates.length > 0}
                  />
                </th>
                <th className="px-1 py-1 text-left text-xs text-slate-500 uppercase" style={{ width: '90px' }} rowSpan={2}>Cedant</th>
                <th className="px-1 py-1 text-left text-xs text-slate-500 uppercase" style={{ width: '110px' }} rowSpan={2}>Name</th>
                <th className="px-1 py-1 text-left text-xs text-slate-500 uppercase" style={{ width: '70px' }} rowSpan={2}>Contr#</th>
                <th className="px-1 py-1 text-left text-xs text-slate-500 uppercase" style={{ width: '80px' }} rowSpan={2}>IBNR</th>
                <th className="px-1 py-1 text-left text-xs text-slate-500 uppercase" style={{ width: '130px' }} rowSpan={2}>Reporting Level</th>
                <th className="px-1 py-1 text-center text-xs font-semibold text-blue-700 uppercase border-l-2 border-blue-300" colSpan={3}>UW Estimate</th>
                
                <th className="px-1 py-1 text-center text-xs font-semibold text-purple-700 uppercase bg-purple-50 border-l-2 border-purple-400" colSpan={3}>Finance Net Calculations</th>
            </tr>
            {/* Sub-header row with Low/Mid/High */}
            <tr className="bg-slate-100">
                <th className="px-1 py-1 text-center text-xs text-blue-600 border-l-2 border-blue-300" style={{ width: '80px' }}>Low</th>
                <th className="px-1 py-1 text-center text-xs text-blue-700 bg-blue-50/50" style={{ width: '80px' }}>Mid</th>
                <th className="px-1 py-1 text-center text-xs text-blue-600" style={{ width: '80px' }}>High</th>
                
                
                
                <th className="px-1 py-1 text-center text-xs text-purple-600 bg-purple-50 border-l-2 border-purple-400" style={{ width: '100px' }}>Third Party Session</th>
                <th className="px-1 py-1 text-center text-xs text-purple-600 bg-purple-50" style={{ width: '100px' }}>Net Mt Logan</th>
                <th className="px-1 py-1 text-center text-xs text-purple-700 bg-purple-50" style={{ width: '100px' }}>Net-Net-Net</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 bg-white">
            {filteredEstimates.map((estimate, index) => {
              const uwLow = parseCurrency(estimate.uwEstimateLow);
              const uwHigh = parseCurrency(estimate.uwEstimateHigh);
              const uwMid = (uwLow + uwHigh) / 2;
              const modelLow = parseCurrency(estimate.modelingLow);
              const modelHigh = parseCurrency(estimate.modelingHigh);
              const modelMid = (modelLow + modelHigh) / 2;
              const netOfRI = parseCurrency(estimate.netOfRI) || (uwMid - parseCurrency(estimate.reinstPremium || '0'));
              const netOfMountLogan = parseCurrency(estimate.netOfMountLogan) || (netOfRI * 0.95);
              const finalNetNet = parseCurrency(estimate.netOfOtherCessions) || (netOfMountLogan * 0.98);
              const mapping = getMapping(estimate.reportingLevel);
              
              return (
                <tr 
                  key={`${estimate.contractNumber}-${index}`}
                  className="hover:bg-slate-50 transition-colors"
                >
                  <td className="px-1 py-1.5 text-center">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 rounded border-slate-300"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedRows(prev => new Set([...prev, estimate.contractNumber]));
                        } else {
                          setSelectedRows(prev => new Set([...prev].filter(num => num !== estimate.contractNumber)));
                        }
                      }}
                      checked={selectedRows.has(estimate.contractNumber)}
                    />
                  </td>
                  <td className="px-1 py-1.5 text-sm text-slate-900 break-words leading-tight" style={{ maxWidth: '90px', wordWrap: 'break-word', whiteSpace: 'normal' }}>{estimate.cedant}</td>
                  <td className="px-1 py-1.5 text-sm text-slate-900 break-words leading-tight" style={{ maxWidth: '110px', wordWrap: 'break-word', whiteSpace: 'normal' }}>{estimate.contractName}</td>
                  <td className="px-1 py-1.5 text-xs text-slate-900 truncate" title={estimate.contractNumber}>{estimate.contractNumber}</td>
                  <td className="px-1 py-1.5 text-xs text-orange-700 font-mono" title={mapping.ibnrTag}>{mapping.ibnrTag}</td>
                  <td className="px-1 py-1.5 text-xs text-slate-600 break-words leading-tight" style={{ maxWidth: '130px', whiteSpace: 'normal' }}>{estimate.reportingLevel}</td>
                  {/* UW columns */}
                  <td className="px-1 py-1.5 text-xs text-right text-blue-600 border-l-2 border-blue-300">{formatCurrency(uwLow)}</td>
                  <td className="px-1 py-1.5 text-xs text-right text-blue-700 bg-blue-50/30">{formatCurrency(uwMid)}</td>
                  <td className="px-1 py-1.5 text-xs text-right text-blue-600">{formatCurrency(uwHigh)}</td>
                  {/* Modeled columns */}
                  
                  
                  
                  {/* Purple finance columns */}
                  <td className="px-1 py-1.5 bg-purple-50 border-l-2 border-purple-400">
                    <input
                      type="text"
                      value={estimate.netOfRI || formatCurrency(netOfRI)}
                      onChange={(e) => updateEstimateField(estimate.contractNumber, 'netOfRI', e.target.value)}
                      className="w-full px-1.5 py-1 text-xs text-right text-purple-700 border border-purple-300 rounded focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500 bg-white"
                      placeholder="$0"
                    />
                  </td>
                  <td className="px-1 py-1.5 bg-purple-50">
                    <input
                      type="text"
                      value={estimate.netOfMountLogan || formatCurrency(netOfMountLogan)}
                      onChange={(e) => updateEstimateField(estimate.contractNumber, 'netOfMountLogan', e.target.value)}
                      className="w-full px-1.5 py-1 text-xs text-right text-purple-700 border border-purple-300 rounded focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500 bg-white"
                      placeholder="$0"
                    />
                  </td>
                  <td className="px-1 py-1.5 bg-purple-50">
                    <input
                      type="text"
                      value={estimate.netOfOtherCessions || formatCurrency(finalNetNet)}
                      onChange={(e) => updateEstimateField(estimate.contractNumber, 'netOfOtherCessions', e.target.value)}
                      className="w-full px-1.5 py-1 text-xs text-right text-purple-700 border border-purple-300 rounded focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500 bg-white font-bold"
                      placeholder="$0"
                    />
                  </td>
                </tr>
              );
            })}
            {/* Totals Row */}
            {(() => {
              const t = computeGroupTotals(filteredEstimates);
              return (
                <tr className="bg-slate-100 border-t-2 border-slate-300 font-semibold sticky bottom-0">
                  <td className="px-1 py-2 text-center"></td>
                  <td className="px-1 py-2 text-xs"></td>
                  <td className="px-1 py-2 text-xs text-slate-900">{t.count} cnt</td>
                  <td className="px-1 py-2 text-xs text-slate-900 font-bold">TOTAL</td>
                  <td className="px-1 py-2"></td>
                  <td className="px-1 py-2"></td>
                  <td className="px-1 py-2 text-xs text-right text-blue-600 font-bold border-l-2 border-blue-300">{formatCurrency(t.uwLow)}</td>
                  <td className="px-1 py-2 text-xs text-right text-blue-700 font-bold bg-blue-50/30">{formatCurrency(t.uwMid)}</td>
                  <td className="px-1 py-2 text-xs text-right text-blue-600 font-bold">{formatCurrency(t.uwHigh)}</td>
                  
                  
                  
                  <td className="px-1 py-2 text-xs text-right text-purple-700 font-bold bg-purple-50 border-l-2 border-purple-400">{formatCurrency(t.netRI)}</td>
                  <td className="px-1 py-2 text-xs text-right text-purple-700 font-bold bg-purple-50">{formatCurrency(t.netML)}</td>
                  <td className="px-1 py-2 text-xs text-right text-purple-700 font-bold bg-purple-50">{formatCurrency(t.netFinal)}</td>
                </tr>
              );
            })()}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Render Team View
  const renderTeamView = () => {
    const COL_COUNT = 13; // ExecArea + BU + RL + Cnt + 9 value cols

    const renderTotalsRow = (label: string, t: ReturnType<typeof computeGroupTotals>, className: string, colSpan = 3) => (
      <tr key={`totals-${label}`} className={className}>
        <td className="px-2 py-1.5 text-xs font-bold" colSpan={colSpan}>{label}</td>
        <td className="px-1 py-1.5 text-xs text-center">{t.count}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold border-l-2 border-blue-300">{formatCurrency(t.uwLow)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold bg-blue-50/50">{formatCurrency(t.uwMid)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold">{formatCurrency(t.uwHigh)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold border-l-2 border-emerald-300">{formatCurrency(t.modelLow)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold bg-emerald-50/50">{formatCurrency(t.modelMid)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold">{formatCurrency(t.modelHigh)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold bg-purple-50 border-l-2 border-purple-400">{formatCurrency(t.netRI)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold bg-purple-50">{formatCurrency(t.netML)}</td>
        <td className="px-1 py-1.5 text-xs text-right font-bold bg-purple-50">{formatCurrency(t.netFinal)}</td>
      </tr>
    );

    return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className={isFullscreen ? "max-h-[calc(100vh-120px)] overflow-auto" : "max-h-[calc(100vh-400px)] overflow-auto"}>
        <table className="w-full table-auto">
          <thead className="sticky top-0 z-30 bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-2 py-2 text-left text-xs font-semibold text-slate-700 uppercase" rowSpan={2} style={{ width: '130px' }}>Executive Area</th>
              <th className="px-1 py-2 text-left text-xs font-semibold text-slate-700 uppercase" rowSpan={2} style={{ width: '120px' }}>Business Unit</th>
              <th className="px-1 py-2 text-left text-xs font-semibold text-slate-700 uppercase" rowSpan={2} style={{ width: '160px' }}>Reporting Level</th>
              <th className="px-1 py-2 text-center text-xs font-semibold text-slate-700 uppercase" rowSpan={2} style={{ width: '40px' }}>Cnt</th>
              <th className="px-1 py-1 text-center text-xs font-semibold text-blue-700 uppercase border-l-2 border-blue-300" colSpan={3}>UW Estimate</th>
              <th className="px-1 py-1 text-center text-xs font-semibold text-emerald-700 uppercase border-l-2 border-emerald-300" colSpan={3}>Modeled</th>
              <th className="px-1 py-1 text-center text-xs font-semibold text-purple-700 uppercase bg-purple-50 border-l-2 border-purple-400" colSpan={3}>Finance Net</th>
            </tr>
            <tr className="bg-slate-100">
              <th className="px-1 py-1 text-center text-xs text-blue-600 border-l-2 border-blue-300">Low</th>
              <th className="px-1 py-1 text-center text-xs text-blue-700 bg-blue-50/50">Mid</th>
              <th className="px-1 py-1 text-center text-xs text-blue-600">High</th>
              <th className="px-1 py-1 text-center text-xs text-emerald-600 border-l-2 border-emerald-300">Low</th>
              <th className="px-1 py-1 text-center text-xs text-emerald-700 bg-emerald-50/50">Mid</th>
              <th className="px-1 py-1 text-center text-xs text-emerald-600">High</th>
              <th className="px-1 py-1 text-center text-xs text-purple-600 bg-purple-50 border-l-2 border-purple-400">Net of RI</th>
              <th className="px-1 py-1 text-center text-xs text-purple-600 bg-purple-50">Net Mt Logan</th>
              <th className="px-1 py-1 text-center text-xs text-purple-700 bg-purple-50">Net-Net-Net</th>
            </tr>
          </thead>
          <tbody className="bg-white">
            {hierarchy.flatMap((ea) => {
              const rows: React.ReactNode[] = [];
              const allEAContracts = ea.businessUnits.flatMap(bu => bu.reportingLevels.flatMap(rl => rl.contracts));
              const eaTotals = computeGroupTotals(allEAContracts);

              // Executive Area header
              rows.push(
                <tr key={`ea-${ea.execArea}`} className="bg-blue-600 border-t-2 border-blue-700">
                  <td className="px-2 py-2" colSpan={COL_COUNT}>
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-white" />
                      <span className="text-white font-semibold text-sm">{ea.execArea}</span>
                      <span className="text-blue-200 text-xs ml-2">({eaTotals.count} contracts)</span>
                    </div>
                  </td>
                </tr>
              );

              ea.businessUnits.forEach((bu) => {
                const allBUContracts = bu.reportingLevels.flatMap(rl => rl.contracts);
                const buTotals = computeGroupTotals(allBUContracts);

                // Business Unit header
                rows.push(
                  <tr key={`bu-${ea.execArea}-${bu.businessUnit}`} className="bg-blue-100 border-t border-blue-200">
                    <td className="px-2 py-1.5" colSpan={COL_COUNT}>
                      <span className="text-blue-800 font-semibold text-xs pl-4">{bu.businessUnit}</span>
                      <span className="text-blue-500 text-xs ml-2">({buTotals.count})</span>
                    </td>
                  </tr>
                );

                bu.reportingLevels.forEach((rl) => {
                  const rlTotals = computeGroupTotals(rl.contracts);

                  // Reporting Level row with totals
                  rows.push(
                    <tr key={`rl-${rl.reportingLevel}`} className="bg-slate-50 border-t border-slate-200 hover:bg-slate-100">
                      <td className="px-2 py-1.5 text-xs text-slate-500 pl-8"></td>
                      <td className="px-1 py-1.5 text-xs text-slate-500"></td>
                      <td className="px-1 py-1.5">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs text-slate-800">{rl.reportingLevel}</span>
                          <span className="px-1.5 py-0.5 text-[10px] font-mono bg-orange-100 text-orange-700 rounded">{rl.ibnrTag}</span>
                        </div>
                      </td>
                      <td className="px-1 py-1.5 text-xs text-center text-slate-700">{rlTotals.count}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-blue-600 border-l-2 border-blue-300">{formatCurrency(rlTotals.uwLow)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-blue-700 bg-blue-50/30">{formatCurrency(rlTotals.uwMid)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-blue-600">{formatCurrency(rlTotals.uwHigh)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-emerald-600 border-l-2 border-emerald-300">{formatCurrency(rlTotals.modelLow)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-emerald-700 bg-emerald-50/30">{formatCurrency(rlTotals.modelMid)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-emerald-600">{formatCurrency(rlTotals.modelHigh)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-purple-700 bg-purple-50 border-l-2 border-purple-400">{formatCurrency(rlTotals.netRI)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-purple-700 bg-purple-50">{formatCurrency(rlTotals.netML)}</td>
                      <td className="px-1 py-1.5 text-xs text-right text-purple-700 bg-purple-50">{formatCurrency(rlTotals.netFinal)}</td>
                    </tr>
                  );
                });

                // Business Unit subtotal
                rows.push(renderTotalsRow(
                  `${bu.businessUnit} Subtotal`,
                  buTotals,
                  'bg-blue-50 border-t border-b border-blue-200 text-blue-800',
                  3
                ));
              });

              // Executive Area subtotal
              rows.push(renderTotalsRow(
                `${ea.execArea} Total`,
                eaTotals,
                'bg-blue-200 border-t-2 border-b border-blue-300 text-blue-900',
                3
              ));

              return rows;
            })}
            {/* Grand Total */}
            {renderTotalsRow(
              'GRAND TOTAL',
              computeGroupTotals(filteredEstimates),
              'bg-slate-200 border-t-2 border-slate-400 text-slate-900 sticky bottom-0',
              3
            )}
          </tbody>
        </table>
      </div>
    </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-50 w-full overflow-y-auto overflow-x-hidden">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm w-full overflow-x-hidden">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event.eventName}</h1>
                <h1 className="text-slate-600">- Finance</h1>
                {(() => {
                  const phase = getWorkflowStatus(eventId || '').currentPhase;
                  const phaseBadge: Record<string, string> = {
                    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
                    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
                    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
                    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'Reopened': 'bg-red-50 text-red-700 border-red-200',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${phaseBadge[phase] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {phase}
                    </span>
                  );
                })()}
                {(() => {
                  const status = getEventStatus(eventId || '');
                  const statusBadge: Record<string, string> = {
                    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
                    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
                    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
                    'Reopened': 'bg-red-50 text-red-700 border-red-300',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {status}
                    </span>
                  );
                })()}
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Category:</span>
                  <span className="text-slate-900">{event.eventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Peril:</span>
                  <span className="text-slate-900">{event.peril}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Workflow Actions Section */}
      {!isFullscreen && (
        <div className="bg-white border-b border-slate-200 w-full overflow-x-hidden">
          <div className="px-8 py-6 w-full">

            {/* ── Lock Status + Submit Bar ── */}
            <div className="flex items-center justify-between mb-5 p-3 rounded-lg border border-slate-200 bg-slate-50">
              {/* Left: Status badge */}
              <div className="flex items-center gap-3">
                {lockStatus === 'unlocked' && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg">
                    <Unlock className="w-4 h-4 text-amber-600" />
                    <span className="text-sm text-amber-800">Editing — Finance In Progress</span>
                  </div>
                )}
                {lockStatus === 'locked' && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg">
                    <Lock className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-blue-800">Locked — Waiting on Other Teams</span>
                  </div>
                )}
                {lockStatus === 'submitted' && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-sm text-emerald-800">Finance Complete — Unlocked for Final</span>
                  </div>
                )}
                {submissionLog.length > 0 && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Last: {submissionLog[submissionLog.length - 1].action}</span>
                    <span className="text-slate-400">
                      {submissionLog[submissionLog.length - 1].timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}
              </div>

              {/* Right: Action buttons */}
              <div className="flex items-center gap-2">
                {lockStatus === 'locked' && (
                  <button
                    onClick={() => { setLockStatus('unlocked'); toast.success('Finance estimates re-opened for editing.'); }}
                    className="px-3 py-1.5 text-sm text-blue-700 bg-white border border-blue-300 rounded-lg hover:bg-blue-50 flex items-center gap-1.5 transition-colors"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    Re-open for Editing
                  </button>
                )}
                {lockStatus === 'submitted' && (
                  <button
                    onClick={() => { setLockStatus('unlocked'); toast.success('Finance re-opened. Final status cleared.'); }}
                    className="px-3 py-1.5 text-sm text-amber-700 bg-white border border-amber-300 rounded-lg hover:bg-amber-50 flex items-center gap-1.5 transition-colors"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    Revise Estimates
                  </button>
                )}
                <button
                  onClick={() => setShowSubmitPanel(!showSubmitPanel)}
                  className={`px-3 py-1.5 text-sm rounded-lg flex items-center gap-1.5 transition-colors ${
                    showSubmitPanel
                      ? 'bg-slate-200 text-slate-700'
                      : 'bg-purple-600 text-white hover:bg-purple-700'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  Submit & Route
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showSubmitPanel ? 'rotate-180' : ''}`} />
                </button>
              </div>
            </div>

            {/* ── Submit Panel (expandable) ── */}
            {showSubmitPanel && (
              <div className="mb-5 p-4 rounded-lg border-2 border-purple-200 bg-purple-50/50">
                <div className="flex items-start gap-6">

                  {/* Notify Target Dropdown */}
                  <div className="flex-1 max-w-sm" ref={notifyDropdownRef}>
                    <label className="block text-xs text-slate-600 mb-1.5">Notify / Route To</label>
                    <button
                      onClick={() => setShowNotifyDropdown(!showNotifyDropdown)}
                      className="w-full px-3 py-2 text-sm text-left bg-white border border-slate-300 rounded-lg hover:border-purple-400 flex items-center justify-between transition-colors"
                    >
                      <span className={notifyTargets.size > 0 ? 'text-slate-900' : 'text-slate-400'}>
                        {notifyTargets.size === 0
                          ? 'Select who needs the next action...'
                          : Array.from(notifyTargets).map(t => NOTIFY_OPTIONS.find(o => o.id === t)?.label).join(', ')
                        }
                      </span>
                      <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showNotifyDropdown ? 'rotate-180' : ''}`} />
                    </button>

                    {showNotifyDropdown && (
                      <div className="absolute z-50 mt-1 w-96 bg-white border border-slate-200 rounded-lg shadow-xl">
                        <div className="p-2">
                          <div className="text-[10px] text-slate-400 uppercase tracking-wider px-2 py-1">Notify a Team</div>
                          {NOTIFY_OPTIONS.filter(o => o.id !== 'finance_final').map(option => (
                            <button
                              key={option.id}
                              onClick={() => toggleNotifyTarget(option.id)}
                              className={`w-full px-3 py-2.5 text-left rounded-md flex items-center gap-3 transition-colors ${
                                notifyTargets.has(option.id) ? 'bg-purple-50 border border-purple-200' : 'hover:bg-slate-50'
                              }`}
                            >
                              <span className="text-lg flex-shrink-0">{option.icon}</span>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm text-slate-900">{option.label}</div>
                                <div className="text-xs text-slate-500">{option.description}</div>
                              </div>
                              {notifyTargets.has(option.id) && (
                                <Check className="w-4 h-4 text-purple-600 flex-shrink-0" />
                              )}
                            </button>
                          ))}
                          <div className="border-t border-slate-200 mt-1 pt-1">
                            <div className="text-[10px] text-slate-400 uppercase tracking-wider px-2 py-1">Or Complete</div>
                            {NOTIFY_OPTIONS.filter(o => o.id === 'finance_final').map(option => (
                              <button
                                key={option.id}
                                onClick={() => toggleNotifyTarget(option.id)}
                                className={`w-full px-3 py-2.5 text-left rounded-md flex items-center gap-3 transition-colors ${
                                  notifyTargets.has(option.id) ? 'bg-emerald-50 border border-emerald-200' : 'hover:bg-slate-50'
                                }`}
                              >
                                <span className="text-lg flex-shrink-0">{option.icon}</span>
                                <div className="flex-1 min-w-0">
                                  <div className="text-sm text-slate-900">{option.label}</div>
                                  <div className="text-xs text-slate-500">{option.description}</div>
                                </div>
                                {notifyTargets.has(option.id) && (
                                  <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                                )}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Note field */}
                  <div className="flex-1">
                    <label className="block text-xs text-slate-600 mb-1.5">Note (optional)</label>
                    <div className="flex items-start gap-2">
                      <div className="relative flex-1">
                        <MessageSquare className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
                        <input
                          type="text"
                          value={submitNote}
                          onChange={(e) => setSubmitNote(e.target.value)}
                          placeholder="e.g. Need updated EQ model for Chile treaty book..."
                          className="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500"
                        />
                      </div>
                      <button
                        onClick={handleSubmitAction}
                        disabled={notifyTargets.size === 0}
                        className={`px-4 py-2 text-sm rounded-lg flex items-center gap-1.5 transition-colors ${
                          notifyTargets.size === 0
                            ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            : notifyTargets.has('finance_final')
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-purple-600 text-white hover:bg-purple-700'
                        }`}
                      >
                        {notifyTargets.has('finance_final') ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            Unlock for Final
                          </>
                        ) : (
                          <>
                            <Send className="w-3.5 h-3.5" />
                            Submit & Notify
                          </>
                        )}
                      </button>
                      <button
                        onClick={() => { setShowSubmitPanel(false); setNotifyTargets(new Set()); setSubmitNote(''); }}
                        className="px-2 py-2 text-slate-400 hover:text-slate-600 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Selected targets summary */}
                {notifyTargets.size > 0 && !notifyTargets.has('finance_final') && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Bell className="w-3.5 h-3.5 text-purple-500" />
                    <span className="text-xs text-purple-700">Will notify:</span>
                    {Array.from(notifyTargets).map(t => {
                      const opt = NOTIFY_OPTIONS.find(o => o.id === t);
                      return (
                        <span key={t} className="inline-flex items-center gap-1 px-2 py-0.5 text-xs bg-purple-100 text-purple-800 rounded-full">
                          {opt?.icon} {opt?.label}
                          <button onClick={() => toggleNotifyTarget(t)} className="hover:text-purple-900">
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      );
                    })}
                  </div>
                )}

                {/* Submission history */}
                {submissionLog.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-purple-200">
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1.5">Submission History</div>
                    <div className="space-y-1 max-h-24 overflow-y-auto">
                      {[...submissionLog].reverse().map((log, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                          <span className="text-slate-400">{log.timestamp.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                          <span className="px-1.5 py-0.5 bg-slate-100 rounded text-slate-700">{log.action}</span>
                          {log.targets.length > 0 && log.targets[0] !== 'Unlock for Final' && (
                            <span className="text-slate-500">to {log.targets.join(', ')}</span>
                          )}
                          {log.note && <span className="text-slate-400 italic truncate max-w-48">"{log.note}"</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  Import
                  <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => {
                    const files = e.target.files;
                    if (files && files.length > 0) {
                      toast.success(`"${files[0].name}" imported successfully`);
                    }
                    e.target.value = '';
                  }} />
                </label>
                <button
                  onClick={handleExportExcel}
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export
                </button>
              </div>
            </div>

            {/* View Tabs */}
            <div className="flex items-center gap-1 border-b border-slate-200">
              
              <button
                onClick={() => setActiveView('flat')}
                className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                  activeView === 'flat'
                    ? 'text-blue-600 border-blue-600'
                    : 'text-slate-600 border-transparent hover:text-slate-900'
                }`}
              >
                Flat View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table Container */}
      <div className={isFullscreen ? "px-4 py-4 w-full overflow-x-hidden" : "px-8 py-6 w-full overflow-x-hidden"}>
        {activeView === 'team' ? renderTeamView() : renderFlatView()}
      </div>
    </div>
  );
}