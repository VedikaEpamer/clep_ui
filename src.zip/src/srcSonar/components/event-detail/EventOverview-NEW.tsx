import { useParams, useNavigate } from 'react-router';
import React, { useState, useEffect } from 'react';
import { Calendar, TrendingUp, CheckCircle2, AlertCircle, DollarSign, FileText, Activity, Clock, Users, Building2, Download, Mail, ArrowUp, ArrowDown, CheckCircle, XCircle, UserCheck, ArrowUpDown, ChevronDown, ChevronRight, X, Search, ExternalLink, Filter, Edit2, MapPin, Globe, Save, Send, MessageSquare, Crosshair, Lock, Unlock } from 'lucide-react';
import { mockEvents, mockAuditLog, phases } from '../../lib/mockData';
import { WorkflowTracker } from '../WorkflowTracker';
import { EventDetailsTab } from './EventDetailsTab';
import { MarketShare } from './MarketShare';
import { CATEstimationSummary } from './CATEstimationSummary';
import { useRole } from '../../lib/roleContext';
import { toast } from 'sonner@2.0.3';
import { useComments } from '../../lib/commentContext';
import { ExecutiveSummary } from './ExecutiveSummary';
import { ModelingTab } from './ModelingTab';
import { useWorkflow } from '../../lib/workflowContext';
import type { WorkflowPhase } from '../../lib/workflowContext';
import { downloadCSV } from '../../lib/exportUtils';

// Team slug to display name mapping
const teamDisplayNames: Record<string, string> = {
  // Facultative (International)
  'intl-fac': 'International Fac',
  'latam-fac': 'Latin America Fac',
  'london-fac': 'London Fac',
  'singapore-fac': 'Singapore Fac',
  // International Treaty
  'dublin-zurich': 'Dublin / Zurich',
  'latam-brazil-treaty': 'Latin America / Brazil Treaty',
  'london-treaty': 'London Treaty',
  'me-africa': 'ME / Africa',
  'singapore-treaty': 'Singapore Treaty',
  // Facultative (North America)
  'bermuda-fac': 'Bermuda Fac',
  'canada-fac': 'Canada Fac',
  'fac-casualty': 'FAC Casualty',
  'fac-property': 'FAC Property',
  // North America Treaty
  'bermuda-treaty': 'Bermuda Treaty',
  'canada-treaty': 'Canada Treaty',
  'treaty-casualty': 'Treaty Casualty',
  'treaty-property': 'Treaty Property',
  // Product
  'aviation': 'Aviation',
  'parametric': 'Parametric',
  'marine': 'Marine',
  'surety': 'Surety',
  // Functional teams
  'modeling': 'CAT Modeling',
  'finance': 'Finance',
};

// Mock UW Teams (no individual names — teams only)
const uwManagers = [
  { id: 'M001', name: 'US Property Team', bu: 'US Property' },
  { id: 'M002', name: 'USA Casualty Team', bu: 'USA Casualty' },
  { id: 'M003', name: 'Bermuda Team', bu: 'Bermuda' },
  { id: 'M004', name: 'Canada Team', bu: 'Canada' },
  { id: 'M005', name: 'LATAM Team', bu: 'LATAM' },
  { id: 'M006', name: 'Europe Team', bu: 'Europe' },
];

const uwContributors = [
  { id: 'C001', name: 'US Property Team', bu: 'US Property', manager: 'M001' },
  { id: 'C002', name: 'US Property Team', bu: 'US Property', manager: 'M001' },
  { id: 'C003', name: 'US Property Team', bu: 'US Property', manager: 'M001' },
  { id: 'C004', name: 'USA Casualty Team', bu: 'USA Casualty', manager: 'M002' },
  { id: 'C005', name: 'USA Casualty Team', bu: 'USA Casualty', manager: 'M002' },
  { id: 'C006', name: 'Bermuda Team', bu: 'Bermuda', manager: 'M003' },
  { id: 'C007', name: 'Bermuda Team', bu: 'Bermuda', manager: 'M003' },
];

// Unassigned contracts for assignment panel
const unassignedContracts = [
  { contractId: 'PROP-2024-0847', cedent: 'State Farm', bu: 'US Property', exposure: '$127M', count: 1 },
  { contractId: 'PROP-2024-0932', cedent: 'Liberty Mutual', bu: 'US Property', exposure: '$118M', count: 1 },
  { contractId: 'PROP-2024-0654', cedent: 'Allstate', bu: 'US Property', exposure: '$87M', count: 1 },
  { contractId: 'CAS-2024-1247', cedent: 'Travelers', bu: 'USA Casualty', exposure: '$94M', count: 1 },
  { contractId: 'CAS-2024-0888', cedent: 'Hartford', bu: 'USA Casualty', exposure: '$71M', count: 1 },
  { contractId: 'BERM-2024-0421', cedent: 'AIG', bu: 'Bermuda', exposure: '$82M', count: 1 },
];

// Mock contract data for expanded Business Unit rows
const contractsByBU: Record<string, any[]> = {
  'US Property': [
    { contractId: 'PROP-2024-0847', cedent: 'State Farm', exposure: '$127M', grossEst: '$12.4M', netEst: '$6.2M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0932', cedent: 'Liberty Mutual', exposure: '$118M', grossEst: '$11.2M', netEst: '$5.6M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0654', cedent: 'Allstate', exposure: '$87M', grossEst: '$8.1M', netEst: '$4.0M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-1089', cedent: 'Progressive', exposure: '$76M', grossEst: '$7.2M', netEst: '$3.6M', uw: 'US Property Team' },
  ],
  'USA Casualty': [
    { contractId: 'CAS-2024-1247', cedent: 'Travelers', exposure: '$94M', grossEst: '$8.8M', netEst: '$4.4M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-0888', cedent: 'Hartford', exposure: '$71M', grossEst: '$6.8M', netEst: '$3.4M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-0456', cedent: 'Chubb', exposure: '$54M', grossEst: '$5.1M', netEst: '$2.5M', uw: 'USA Casualty Team' },
  ],
  'Bermuda': [
    { contractId: 'BERM-2024-0421', cedent: 'AIG', exposure: '$82M', grossEst: '$7.9M', netEst: '$3.9M', uw: 'Bermuda Team' },
    { contractId: 'BERM-2024-0556', cedent: 'Chubb', exposure: '$64M', grossEst: '$6.1M', netEst: '$3.0M', uw: 'Bermuda Team' },
    { contractId: 'BERM-2024-0789', cedent: 'Zurich', exposure: '$59M', grossEst: '$5.6M', netEst: '$2.8M', uw: 'Bermuda Team' },
  ],
};

// Mock contract data grouped by Cedent
const contractsByCedent: Record<string, any[]> = {
  'State Farm': [
    { contractId: 'PROP-2024-0847', bu: 'US Property', exposure: '$127M', grossEst: '$12.4M', netEst: '$6.2M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-1156', bu: 'US Property', exposure: '$89M', grossEst: '$8.7M', netEst: '$4.3M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-1289', bu: 'Canada', exposure: '$68M', grossEst: '$6.3M', netEst: '$3.1M', uw: 'Canada Team' },
  ],
  'Liberty Mutual': [
    { contractId: 'PROP-2024-0932', bu: 'US Property', exposure: '$118M', grossEst: '$11.2M', netEst: '$5.6M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-1034', bu: 'US Property', exposure: '$94M', grossEst: '$8.9M', netEst: '$4.4M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0756', bu: 'Canada', exposure: '$55M', grossEst: '$5.0M', netEst: '$2.5M', uw: 'Canada Team' },
  ],
  'Travelers': [
    { contractId: 'CAS-2024-1247', bu: 'USA Casualty', exposure: '$94M', grossEst: '$8.8M', netEst: '$4.4M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-0983', bu: 'USA Casualty', exposure: '$82M', grossEst: '$7.8M', netEst: '$3.9M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-1124', bu: 'Bermuda', exposure: '$65M', grossEst: '$6.2M', netEst: '$3.1M', uw: 'Bermuda Team' },
  ],
  'Allstate': [
    { contractId: 'PROP-2024-0654', bu: 'US Property', exposure: '$87M', grossEst: '$8.1M', netEst: '$4.0M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0778', bu: 'US Property', exposure: '$71M', grossEst: '$6.7M', netEst: '$3.3M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0891', bu: 'Canada', exposure: '$40M', grossEst: '$4.1M', netEst: '$2.0M', uw: 'Canada Team' },
  ],
  'AIG': [
    { contractId: 'BERM-2024-0421', bu: 'Bermuda', exposure: '$82M', grossEst: '$7.9M', netEst: '$3.9M', uw: 'Bermuda Team' },
    { contractId: 'BERM-2024-0634', bu: 'Bermuda', exposure: '$69M', grossEst: '$6.5M', netEst: '$3.2M', uw: 'Bermuda Team' },
    { contractId: 'BERM-2024-0745', bu: 'London', exposure: '$36M', grossEst: '$3.2M', netEst: '$1.6M', uw: 'London Team' },
  ],
  'Progressive': [
    { contractId: 'PROP-2024-1089', bu: 'US Property', exposure: '$76M', grossEst: '$7.2M', netEst: '$3.6M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0923', bu: 'US Property', exposure: '$58M', grossEst: '$5.5M', netEst: '$2.7M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-1201', bu: 'Canada', exposure: '$38M', grossEst: '$3.5M', netEst: '$1.7M', uw: 'Canada Team' },
  ],
  'Hartford': [
    { contractId: 'CAS-2024-0888', bu: 'USA Casualty', exposure: '$71M', grossEst: '$6.8M', netEst: '$3.4M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-1056', bu: 'USA Casualty', exposure: '$55M', grossEst: '$5.2M', netEst: '$2.6M', uw: 'USA Casualty Team' },
    { contractId: 'CAS-2024-0745', bu: 'Bermuda', exposure: '$30M', grossEst: '$2.8M', netEst: '$1.4M', uw: 'Bermuda Team' },
  ],
  'Chubb': [
    { contractId: 'CAS-2024-0456', bu: 'USA Casualty', exposure: '$54M', grossEst: '$5.1M', netEst: '$2.5M', uw: 'USA Casualty Team' },
    { contractId: 'BERM-2024-0556', bu: 'Bermuda', exposure: '$64M', grossEst: '$6.1M', netEst: '$3.0M', uw: 'Bermuda Team' },
    { contractId: 'BERM-2024-0667', bu: 'London', exposure: '$25M', grossEst: '$2.3M', netEst: '$1.2M', uw: 'London Team' },
  ],
  'Nationwide': [
    { contractId: 'PROP-2024-0745', bu: 'US Property', exposure: '$68M', grossEst: '$6.4M', netEst: '$3.2M', uw: 'US Property Team' },
    { contractId: 'PROP-2024-0856', bu: 'Canada', exposure: '$47M', grossEst: '$4.4M', netEst: '$2.2M', uw: 'Canada Team' },
    { contractId: 'PROP-2024-0967', bu: 'US Property', exposure: '$23M', grossEst: '$2.3M', netEst: '$1.1M', uw: 'US Property Team' },
  ],
  'Zurich': [
    { contractId: 'BERM-2024-0789', bu: 'Bermuda', exposure: '$59M', grossEst: '$5.6M', netEst: '$2.8M', uw: 'Bermuda Team' },
    { contractId: 'PROP-2024-0923', bu: 'Europe', exposure: '$42M', grossEst: '$4.0M', netEst: '$2.0M', uw: 'Europe Team' },
    { contractId: 'BERM-2024-0821', bu: 'London', exposure: '$23M', grossEst: '$2.1M', netEst: '$1.0M', uw: 'London Team' },
  ],
};

export function EventOverview() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { currentRole, permissions } = useRole();
  const { getWorkflowStatus, getEventStatus, getAllowedPhases, setPhase, completePhase4, closeEvent, archiveEvent, reopenEvent, lockEvent, unlockEvent, isEventLocked } = useWorkflow();
  const [phaseDropdownOpen, setPhaseDropdownOpen] = useState(false);
  const [approvalRequest, setApprovalRequest] = useState<any>(null);
  const { addComment, getCommentsByEvent } = useComments();
  
  // Team Comments & Updates table data
  const [teamUpdates] = useState([
    {
      id: 1,
      name: 'Underwriting Team',
      date: '2024-12-02 14:30',
      column: 'Loss Estimate - High',
      comment: 'Updated loss estimate based on latest cedent feedback from Chilean treaty holders.'
    },
    {
      id: 2,
      name: 'Cat Modeling Team',
      date: '2024-12-02 11:15',
      column: 'Modeling - 100%',
      comment: 'AIR model results validated against historical events. 100% scenario reflects full exposure.'
    },
    {
      id: 3,
      name: 'Finance Team',
      date: '2024-12-01 16:45',
      column: 'Reinstatements - Low',
      comment: 'Adjusted reinstatement premium based on treaty layer analysis.'
    },
    {
      id: 4,
      name: 'LATAM Treaty Team',
      date: '2024-12-01 09:20',
      column: 'UW Ground Up - Latin America / Brazil Treaty',
      comment: 'Ground-up estimate from LATAM team incorporating direct cedent contact and policy limits review.'
    }
  ]);
  
  // Table state
  const [buSortConfig, setBuSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [dealsSortConfig, setDealsSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [companiesSortConfig, setCompaniesSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [expandedBUs, setExpandedBUs] = useState<Set<string>>(new Set());
  const [expandedCedents, setExpandedCedents] = useState<Set<string>>(new Set());
  const [sidePanelData, setSidePanelData] = useState<any>(null);
  const [buSearchTerm, setBuSearchTerm] = useState('');
  
  // Edit modal state
  const [showEditModal, setShowEditModal] = useState(false);
  const [editFormData, setEditFormData] = useState<any>(null);
  
  // Event details section state
  const [isEventDetailsExpanded, setIsEventDetailsExpanded] = useState(false);
  const [isEditingEventDetails, setIsEditingEventDetails] = useState(false);
  const [editedEventData, setEditedEventData] = useState<any>(null);
  
  // Tab navigation state
  const [activeTab, setActiveTab] = useState<'executive' | 'modeling' | 'summary' | 'details' | 'market'>('summary');

  
  // Add comment form state
  const [showAddComment, setShowAddComment] = useState(false);
  const [newCommentText, setNewCommentText] = useState('');
  const [newCommentTeam, setNewCommentTeam] = useState('latam-brazil-treaty');
  

  
  // Comments table state
  const [commentSortConfig, setCommentSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);

  const [commentFilterRole, setCommentFilterRole] = useState<string>('all');
  const [commentFilterBU, setCommentFilterBU] = useState<string>('all');
  const [showCommentRoleFilter, setShowCommentRoleFilter] = useState(false);
  const [showCommentBUFilter, setShowCommentBUFilter] = useState(false);
  
  const event = mockEvents.find(e => e.id === eventId);

  useEffect(() => {
    const pendingApprovals = JSON.parse(sessionStorage.getItem('pendingApprovals') || '[]');
    const request = pendingApprovals.find((a: any) => a.eventId === eventId && a.status === 'pending-management-review');
    if (request) {
      setApprovalRequest(request);
    }
  }, [eventId]);



  const handleApprove = () => {
    const pendingApprovals = JSON.parse(sessionStorage.getItem('pendingApprovals') || '[]');
    const updatedApprovals = pendingApprovals.map((a: any) => 
      a.eventId === eventId ? { ...a, status: 'approved', approvedAt: new Date().toISOString(), approvedBy: 'Management' } : a
    );
    sessionStorage.setItem('pendingApprovals', JSON.stringify(updatedApprovals));
    
    const notifications = [
      {
        id: `finance-${eventId}-${Date.now()}`,
        eventId,
        eventName: event?.eventName,
        recipient: 'Finance Team',
        type: 'approval-notification',
        message: 'Management has approved UW estimates. Please review for final processing.',
        createdAt: new Date().toISOString(),
        read: false
      },
      {
        id: `cat-${eventId}-${Date.now()}`,
        eventId,
        eventName: event?.eventName,
        recipient: 'CAT Modeling Team',
        type: 'approval-notification',
        message: 'Management has approved UW estimates. Please revise your modeling numbers.',
        createdAt: new Date().toISOString(),
        read: false
      }
    ];
    
    const existingNotifications = JSON.parse(sessionStorage.getItem('notifications') || '[]');
    sessionStorage.setItem('notifications', JSON.stringify([...existingNotifications, ...notifications]));
    
    setApprovalRequest(null);
    toast.success('Estimates Approved', {
      description: 'Notifications sent to Finance & CAT Modeling teams.'
    });
  };

  const handleRequestChanges = () => {
    const pendingApprovals = JSON.parse(sessionStorage.getItem('pendingApprovals') || '[]');
    const updatedApprovals = pendingApprovals.map((a: any) => 
      a.eventId === eventId ? { ...a, status: 'changes-requested', reviewedAt: new Date().toISOString(), reviewedBy: 'Management' } : a
    );
    sessionStorage.setItem('pendingApprovals', JSON.stringify(updatedApprovals));
    
    setApprovalRequest(null);
    alert('Changes requested. The underwriter will be notified to revise their estimates.');
  };

  // Close comment filter dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutsideFilters = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.comment-role-filter')) setShowCommentRoleFilter(false);
      if (!target.closest('.comment-bu-filter')) setShowCommentBUFilter(false);
    };
    document.addEventListener('mousedown', handleClickOutsideFilters);
    return () => document.removeEventListener('mousedown', handleClickOutsideFilters);
  }, []);

  // Unified comment rows: merge dynamic context comments + static teamUpdates
  const unifiedComments = React.useMemo(() => {
    const dynamicRows = (eventId ? getCommentsByEvent(eventId) : []).map((c) => ({
      uid: `ctx-${c.id}`,
      author: c.author,
      role: c.authorRole,
      businessUnit: teamDisplayNames[c.team] || c.team,
      comment: c.text,
      date: new Date(c.timestamp),
      source: 'dynamic' as const,
    }));
    const staticRows = teamUpdates.map((u) => ({
      uid: `static-${u.id}`,
      author: u.name,
      role: 'Underwriter',
      businessUnit: u.column,
      comment: u.comment,
      date: new Date(u.date),
      source: 'static' as const,
    }));
    return [...dynamicRows, ...staticRows];
  }, [eventId, getCommentsByEvent, teamUpdates]);

  // Unique values for filter dropdowns
  const uniqueRoles = React.useMemo(() => Array.from(new Set(unifiedComments.map(c => c.role))).sort(), [unifiedComments]);
  const uniqueBUs = React.useMemo(() => Array.from(new Set(unifiedComments.map(c => c.businessUnit))).sort(), [unifiedComments]);

  // Filtered + sorted comments
  const processedComments = React.useMemo(() => {
    let rows = [...unifiedComments];
    // Filter
    if (commentFilterRole !== 'all') rows = rows.filter(r => r.role === commentFilterRole);
    if (commentFilterBU !== 'all') rows = rows.filter(r => r.businessUnit === commentFilterBU);
    // Sort
    if (commentSortConfig) {
      rows.sort((a, b) => {
        let valA: any, valB: any;
        switch (commentSortConfig.key) {
          case 'author': valA = a.author.toLowerCase(); valB = b.author.toLowerCase(); break;
          case 'role': valA = a.role.toLowerCase(); valB = b.role.toLowerCase(); break;
          case 'businessUnit': valA = a.businessUnit.toLowerCase(); valB = b.businessUnit.toLowerCase(); break;
          case 'date': valA = a.date.getTime(); valB = b.date.getTime(); break;
          default: return 0;
        }
        if (valA < valB) return commentSortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return commentSortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return rows;
  }, [unifiedComments, commentFilterRole, commentFilterBU, commentSortConfig]);

  const handleCommentSort = (key: string) => {
    setCommentSortConfig(prev => {
      if (prev?.key === key) {
        if (prev.direction === 'asc') return { key, direction: 'desc' };
        return null; // third click clears
      }
      return { key, direction: 'asc' };
    });
  };

  // Comment sort arrow component (Excel-style, matching app pattern)
  const CommentSortArrow = ({ column }: { column: string }) => {
    const isActive = commentSortConfig?.key === column;
    if (!isActive) {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-400"><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-400"><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
        </div>
      );
    }
    if (commentSortConfig?.direction === 'asc') {
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-blue-600"><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
          <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-300"><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
        </div>
      );
    }
    return (
      <div className="flex flex-col items-center gap-0.5">
        <svg width="12" height="6" viewBox="0 0 10 5" className="text-gray-300"><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
        <svg width="12" height="6" viewBox="0 0 10 5" className="text-blue-600"><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
      </div>
    );
  };

  if (!event) return <div className="p-8">Event not found</div>;

  const currentPhaseIndex = event.phase;
  const currentPhase = phases[currentPhaseIndex];
  const hasContracts = event.contracts > 0;

  // Executive KPIs - Different for Chile earthquake (realistic 2010 Maule numbers)
  const isChileEventKPI = event.id === 'EVT-2024-012';
  const executiveKPIs = isChileEventKPI ? [
    { label: 'Total Market Loss', value: hasContracts ? '$8B - $10B' : '$0', sublabel: hasContracts ? 'Total insured market loss' : 'No contracts loaded', icon: Globe, color: '#3b82f6' },
    { label: 'UW Gross Estimate', value: hasContracts ? '$339M' : '$0', sublabel: hasContracts ? '~4% market share' : 'Pending contract load', icon: TrendingUp, color: '#ef4444' },
    { label: 'UW Net Estimate', value: hasContracts ? '$300M' : '$0', sublabel: hasContracts ? 'After retro coverage (88%)' : 'Pending contract load', icon: Activity, color: '#8b5cf6' },
    { label: 'Model Estimate', value: hasContracts ? '$305M' : '$0', sublabel: hasContracts ? 'CAT model projection' : 'Pending contract load', icon: DollarSign, color: '#10b981' },
    { label: 'Contracts Affected', value: event.contracts.toLocaleString(), sublabel: hasContracts ? `${event.progress}% estimated` : 'Awaiting contract upload', icon: FileText, color: '#f59e0b', change: hasContracts ? '+12%' : null },
    { label: 'Underwriters Assigned', value: hasContracts ? '56' : '0', sublabel: hasContracts ? 'Across 8 teams' : 'Not assigned', icon: Users, color: '#ec4899' }
  ] : [
    { label: 'Total Gross Exposure', value: hasContracts ? '$2.4B' : '$0', sublabel: hasContracts ? 'Across all contracts' : 'No contracts loaded', icon: DollarSign, color: '#3b82f6' },
    { label: 'Market Est. Gross Loss', value: hasContracts ? '$185M' : '$0', sublabel: hasContracts ? 'Initial estimate' : 'Pending contract load', icon: TrendingUp, color: '#ef4444' },
    { label: 'Net Loss Estimate', value: hasContracts ? '$92M' : '$0', sublabel: hasContracts ? 'After retrocession' : 'Pending contract load', icon: Activity, color: '#8b5cf6' },
    { label: 'Contracts Affected', value: event.contracts.toLocaleString(), sublabel: hasContracts ? `${event.progress}% estimated` : 'Awaiting contract upload', icon: FileText, color: '#10b981', change: hasContracts ? '+8%' : null },
    { label: 'Business Units', value: hasContracts ? '12' : '0', sublabel: hasContracts ? '8 completed' : 'Not assigned', icon: Building2, color: '#f59e0b' },
    { label: 'Underwriters Assigned', value: hasContracts ? '47' : '0', sublabel: hasContracts ? '42 submitted' : 'Not assigned', icon: Users, color: '#ec4899' }
  ];

  const getActiveTask = () => {
    const phase = event.phase;
    
    if (phase === 0) {
      return {
        phase: currentPhase?.name || 'Event Creation',
        assignedTo: 'Event Coordinator',
        assignees: ['Event Creator'],
        dueDate: event.updatedAt,
        task: 'Complete event creation and publish event',
        status: 'In Draft',
        completion: 0
      };
    }
    
    if (phase === 1) {
      return {
        phase: currentPhase.name,
        assignedTo: 'Group UW, Finance, Cat Modeling, Claims',
        assignees: ['Monitoring Teams'],
        dueDate: '2024-12-05',
        task: 'Awareness only — event recorded, monitoring exposure but underwriting estimation not yet required',
        status: 'Monitoring',
        completion: 15
      };
    }
    
    if (phase === 2) {
      if (currentRole === 'Cat Modeling') {
        return {
          phase: currentPhase.name,
          assignedTo: 'Cat Modeling Team',
          assignees: ['Cat Modeling Team'],
          dueDate: '2024-12-08',
          task: 'Complete vendor model runs and upload loss estimates for assigned contracts',
          status: 'In Progress',
          completion: 65
        };
      } else if (currentRole === 'Underwriter') {
        return {
          phase: currentPhase.name,
          assignedTo: 'Underwriting Team',
          assignees: ['Underwriting Team'],
          dueDate: '2024-12-08',
          task: 'Complete UW loss estimates for your assigned contracts',
          status: 'In Progress',
          completion: 85
        };
      } else {
        return {
          phase: currentPhase.name,
          assignedTo: 'Cat Modeling & UW Teams',
          assignees: ['Cat Modeling Team', 'Underwriting Team'],
          dueDate: '2024-12-08',
          task: 'Complete Cat Modeling runs and UW loss estimates, then approve for finance review',
          status: 'In Progress',
          completion: 70
        };
      }
    }
    
    if (phase === 3) {
      return {
        phase: currentPhase.name,
        assignedTo: 'Finance Team',
        assignees: ['Finance Team'],
        dueDate: '2024-12-10',
        task: 'Review and validate UW estimates and modeling results before reporting',
        status: 'Pending Review',
        completion: 90
      };
    }
    
    if (phase === 4) {
      return {
        phase: currentPhase.name,
        assignedTo: 'Finance & Operations',
        assignees: ['Finance Team', 'Operations Team'],
        dueDate: '2024-12-15',
        task: 'Generate final reports, monitor claims development, and close event',
        status: 'Reporting',
        completion: 100
      };
    }
    
    return {
      phase: currentPhase?.name || 'Close Monitor',
      assignedTo: 'All Teams',
      assignees: ['Event Closed'],
      dueDate: event.updatedAt,
      task: 'Event completed and archived',
      status: 'Close Monitor',
      completion: 100
    };
  };
  
  const nextTask = getActiveTask();

  // Conditional data based on event type - Chile earthquake has realistic industry numbers
  const isChileEvent = event.id === 'EVT-2024-012';

  let marketEstimates = hasContracts ? (isChileEvent ? [
    // Chile Earthquake — real BU names (4-department structure)
    { bu: 'Latin America / Brazil Treaty', exposure: 4200, grossEst: 145, netEst: 122, uwCount: 342, status: 'Complete', manager: 'LATAM Treaty Team' },
    { bu: 'Latin America Fac', exposure: 2800, grossEst: 82, netEst: 70, uwCount: 218, status: 'Complete', manager: 'LATAM Fac Team' },
    { bu: 'Marine', exposure: 1450, grossEst: 48, netEst: 40, uwCount: 156, status: 'Complete', manager: 'Marine Team' },
    { bu: 'London Treaty', exposure: 1280, grossEst: 38, netEst: 32, uwCount: 124, status: 'Complete', manager: 'London Treaty Team' },
    { bu: 'Dublin / Zurich', exposure: 890, grossEst: 22, netEst: 19, uwCount: 187, status: 'In Progress', manager: 'Dublin / Zurich Team' },
    { bu: 'Treaty Property', exposure: 520, grossEst: 8, netEst: 7, uwCount: 102, status: 'Complete', manager: 'Treaty Property Team' },
    { bu: 'Bermuda Treaty', exposure: 420, grossEst: 6, netEst: 6, uwCount: 72, status: 'Complete', manager: 'Bermuda Treaty Team' },
    { bu: 'London Fac', exposure: 315, grossEst: 5, netEst: 4, uwCount: 46, status: 'Complete', manager: 'London Fac Team' }
  ] : [
    { bu: 'Treaty Property', exposure: 842, grossEst: 68, netEst: 34, uwCount: 12, status: 'Complete', manager: 'Treaty Property Team' },
    { bu: 'Treaty Casualty', exposure: 456, grossEst: 22, netEst: 11, uwCount: 8, status: 'Complete', manager: 'Treaty Casualty Team' },
    { bu: 'Bermuda Fac', exposure: 385, grossEst: 31, netEst: 15, uwCount: 6, status: 'Complete', manager: 'Bermuda Fac Team' },
    { bu: 'Canada Fac', exposure: 245, grossEst: 18, netEst: 9, uwCount: 5, status: 'Complete', manager: 'Canada Fac Team' },
    { bu: 'Latin America Fac', exposure: 198, grossEst: 14, netEst: 7, uwCount: 4, status: 'In Progress', manager: 'LATAM Fac Team' },
    { bu: 'London Fac', exposure: 142, grossEst: 9, netEst: 4.5, uwCount: 3, status: 'In Progress', manager: 'London Fac Team' },
    { bu: 'London Treaty', exposure: 89, grossEst: 5, netEst: 2.5, uwCount: 4, status: 'Pending', manager: 'London Treaty Team' },
    { bu: 'FAC Property', exposure: 43, grossEst: 18, netEst: 9, uwCount: 5, status: 'Complete', manager: 'FAC Property Team' }
  ]) : [];

  let top10Deals = hasContracts ? (isChileEvent ? [
    // Chile Earthquake - Major LATAM property CAT XL treaties
    { contractId: 'LATAM-2024-0847', cedent: 'Compañía de Seguros', exposure: 285, grossEst: 24.8, netEst: 19.8, limit: 300, attachment: 50 },
    { contractId: 'LATAM-2024-0932', cedent: 'Mapfre Chile', exposure: 248, grossEst: 21.4, netEst: 17.1, limit: 400, attachment: 75 },
    { contractId: 'INTL-2024-1247', cedent: 'Liberty Seguros', exposure: 215, grossEst: 18.6, netEst: 14.9, limit: 250, attachment: 40 },
    { contractId: 'LATAM-2024-0654', cedent: 'HDI Seguros', exposure: 198, grossEst: 16.8, netEst: 13.4, limit: 225, attachment: 35 },
    { contractId: 'FAC-2024-0421', cedent: 'RSA Chile', exposure: 187, grossEst: 15.2, netEst: 12.2, limit: 500, attachment: 100 },
    { contractId: 'LATAM-2024-1089', cedent: 'BCI Seguros', exposure: 176, grossEst: 14.6, netEst: 11.7, limit: 200, attachment: 30 },
    { contractId: 'MAR-2024-0888', cedent: 'Chile Seguros', exposure: 164, grossEst: 13.8, netEst: 11.0, limit: 300, attachment: 50 },
    { contractId: 'LATAM-2024-0745', cedent: 'Consorcio Nacional', exposure: 152, grossEst: 12.4, netEst: 9.9, limit: 175, attachment: 25 },
    { contractId: 'ENG-2024-0556', cedent: 'Sura Chile', exposure: 143, grossEst: 11.8, netEst: 9.4, limit: 400, attachment: 60 },
    { contractId: 'LATAM-2024-0923', cedent: 'MetLife Chile', exposure: 138, grossEst: 11.2, netEst: 9.0, limit: 225, attachment: 40 }
  ] : [
    { contractId: 'PROP-2024-0847', cedent: 'State Farm', exposure: 127, grossEst: 12.4, netEst: 6.2, limit: 150, attachment: 25 },
    { contractId: 'PROP-2024-0932', cedent: 'Liberty Mutual', exposure: 118, grossEst: 11.2, netEst: 5.6, limit: 200, attachment: 50 },
    { contractId: 'CAS-2024-1247', cedent: 'Travelers', exposure: 94, grossEst: 8.8, netEst: 4.4, limit: 100, attachment: 10 },
    { contractId: 'PROP-2024-0654', cedent: 'Allstate', exposure: 87, grossEst: 8.1, netEst: 4.0, limit: 125, attachment: 20 },
    { contractId: 'BERM-2024-0421', cedent: 'AIG', exposure: 82, grossEst: 7.9, netEst: 3.9, limit: 250, attachment: 75 },
    { contractId: 'PROP-2024-1089', cedent: 'Progressive', exposure: 76, grossEst: 7.2, netEst: 3.6, limit: 100, attachment: 15 },
    { contractId: 'CAS-2024-0888', cedent: 'Hartford', exposure: 71, grossEst: 6.8, netEst: 3.4, limit: 150, attachment: 30 },
    { contractId: 'PROP-2024-0745', cedent: 'Nationwide', exposure: 68, grossEst: 6.4, netEst: 3.2, limit: 100, attachment: 10 },
    { contractId: 'BERM-2024-0556', cedent: 'Chubb', exposure: 64, grossEst: 6.1, netEst: 3.0, limit: 200, attachment: 40 },
    { contractId: 'PROP-2024-0923', cedent: 'Zurich', exposure: 59, grossEst: 5.6, netEst: 2.8, limit: 125, attachment: 25 }
  ]) : [];

  let top10Companies = hasContracts ? (isChileEvent ? [
    // Chile Earthquake - Major Chilean insurers and regional players
    { cedent: 'Compañía de Seguros', contractCount: 64, totalExposure: 486, grossEst: 42.8, netEst: 34.2, percentOfTotal: '12.2%' },
    { cedent: 'Mapfre Chile', contractCount: 58, totalExposure: 445, grossEst: 38.6, netEst: 30.9, percentOfTotal: '11.0%' },
    { cedent: 'Liberty Seguros', contractCount: 52, totalExposure: 412, grossEst: 34.2, netEst: 27.4, percentOfTotal: '9.8%' },
    { cedent: 'HDI Seguros', contractCount: 48, totalExposure: 378, grossEst: 31.4, netEst: 25.1, percentOfTotal: '9.0%' },
    { cedent: 'RSA Chile', contractCount: 42, totalExposure: 342, grossEst: 28.2, netEst: 22.6, percentOfTotal: '8.1%' },
    { cedent: 'BCI Seguros', contractCount: 46, totalExposure: 324, grossEst: 26.8, netEst: 21.4, percentOfTotal: '7.7%' },
    { cedent: 'Chile Seguros', contractCount: 38, totalExposure: 298, grossEst: 24.2, netEst: 19.4, percentOfTotal: '6.9%' },
    { cedent: 'Consorcio Nacional', contractCount: 35, totalExposure: 276, grossEst: 22.4, netEst: 17.9, percentOfTotal: '6.4%' },
    { cedent: 'Sura Chile', contractCount: 32, totalExposure: 254, grossEst: 20.8, netEst: 16.6, percentOfTotal: '5.9%' },
    { cedent: 'MetLife Chile', contractCount: 28, totalExposure: 235, grossEst: 19.2, netEst: 15.4, percentOfTotal: '5.5%' }
  ] : [
    { cedent: 'State Farm', contractCount: 23, totalExposure: 284, grossEst: 27.4, netEst: 13.7, percentOfTotal: '11.8%' },
    { cedent: 'Liberty Mutual', contractCount: 19, totalExposure: 267, grossEst: 25.1, netEst: 12.5, percentOfTotal: '11.1%' },
    { cedent: 'Travelers', contractCount: 18, totalExposure: 241, grossEst: 22.8, netEst: 11.4, percentOfTotal: '10.0%' },
    { cedent: 'Allstate', contractCount: 16, totalExposure: 198, grossEst: 18.9, netEst: 9.4, percentOfTotal: '8.2%' },
    { cedent: 'AIG', contractCount: 14, totalExposure: 187, grossEst: 17.6, netEst: 8.8, percentOfTotal: '7.8%' },
    { cedent: 'Progressive', contractCount: 15, totalExposure: 172, grossEst: 16.2, netEst: 8.1, percentOfTotal: '7.2%' },
    { cedent: 'Hartford', contractCount: 12, totalExposure: 156, grossEst: 14.8, netEst: 7.4, percentOfTotal: '6.5%' },
    { cedent: 'Chubb', contractCount: 11, totalExposure: 143, grossEst: 13.5, netEst: 6.7, percentOfTotal: '6.0%' },
    { cedent: 'Nationwide', contractCount: 13, totalExposure: 138, grossEst: 13.1, netEst: 6.5, percentOfTotal: '5.8%' },
    { cedent: 'Zurich', contractCount: 10, totalExposure: 124, grossEst: 11.7, netEst: 5.8, percentOfTotal: '5.2%' }
  ]) : [];

  const sortData = (data: any[], key: string, direction: 'asc' | 'desc') => {
    return [...data].sort((a, b) => {
      const aVal = a[key];
      const bVal = b[key];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return direction === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return direction === 'asc' 
        ? String(aVal).localeCompare(String(bVal)) 
        : String(bVal).localeCompare(String(aVal));
    });
  };

  const handleSort = (table: 'bu' | 'deals' | 'companies', key: string) => {
    const configs = { bu: buSortConfig, deals: dealsSortConfig, companies: companiesSortConfig };
    const setters = { bu: setBuSortConfig, deals: setDealsSortConfig, companies: setCompaniesSortConfig };
    
    const currentConfig = configs[table];
    let direction: 'asc' | 'desc' = 'asc';
    
    if (currentConfig?.key === key) {
      direction = currentConfig.direction === 'asc' ? 'desc' : 'asc';
    }
    
    setters[table]({ key, direction });
  };

  if (buSortConfig) {
    marketEstimates = sortData(marketEstimates, buSortConfig.key, buSortConfig.direction);
  }
  if (dealsSortConfig) {
    top10Deals = sortData(top10Deals, dealsSortConfig.key, dealsSortConfig.direction);
  }
  if (companiesSortConfig) {
    top10Companies = sortData(top10Companies, companiesSortConfig.key, companiesSortConfig.direction);
  }

  const filteredBUs = marketEstimates.filter(bu => 
    bu.bu.toLowerCase().includes(buSearchTerm.toLowerCase()) ||
    bu.status.toLowerCase().includes(buSearchTerm.toLowerCase())
  );

  const toggleBUExpansion = (bu: string) => {
    const newExpanded = new Set(expandedBUs);
    if (newExpanded.has(bu)) {
      newExpanded.delete(bu);
    } else {
      newExpanded.add(bu);
    }
    setExpandedBUs(newExpanded);
  };

  const toggleCedentExpansion = (cedent: string) => {
    const newExpanded = new Set(expandedCedents);
    if (newExpanded.has(cedent)) {
      newExpanded.delete(cedent);
    } else {
      newExpanded.add(cedent);
    }
    setExpandedCedents(newExpanded);
  };

  const SortableHeader = ({ label, sortKey, currentConfig, onSort }: any) => {
    const isActive = currentConfig?.key === sortKey;
    const direction = isActive ? currentConfig.direction : null;
    
    return (
      <th 
        className="px-5 py-4 text-right uppercase tracking-wider cursor-pointer hover:bg-blue-50/50 transition-colors text-xs"
        onClick={() => onSort(sortKey)}
      >
        <div className="flex items-center justify-end gap-2">
          <span className="text-slate-700">{label}</span>
          <div className="flex flex-col items-center -space-y-1">
            <svg width="12" height="6" viewBox="0 0 10 5" className={direction === 'asc' ? 'text-blue-600' : 'text-gray-400'}>
              <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
            </svg>
            <svg width="12" height="6" viewBox="0 0 10 5" className={direction === 'desc' ? 'text-blue-600' : 'text-gray-400'}>
              <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
            </svg>
          </div>
        </div>
      </th>
    );
  };

  const formatCurrency = (num: number) => {
    if (num >= 1000) return `$${(num / 1000).toFixed(1)}B`;
    return `$${num}M`;
  };

  const handleDownloadSummary = () => {
    const headers = ['Metric', 'Value'];
    const totalGross = isChileEvent ? 350 : 185;
    const rows: (string | number)[][] = [
      ['Event', event?.eventName || ''],
      ['Total Gross Loss ($M)', totalGross],
      ['Total Net Loss ($M)', isChileEvent ? 318 : 92],
      ['Business Units', filteredBUs.length],
      ['Phase', getWorkflowStatus(eventId || '').currentPhase],
    ];
    filteredBUs.forEach(bu => {
      rows.push([`BU: ${bu.bu} - Gross ($M)`, bu.grossEst]);
      rows.push([`BU: ${bu.bu} - Net ($M)`, bu.netEst]);
    });
    downloadCSV(headers, rows, `SONAR_Executive_Summary_${event?.eventName || 'Event'}`);
    toast.success('Executive summary exported to CSV');
  };

  const handleEmailSummary = () => {
    toast.success('Executive summary emailed to CEO, CFO, and CRO offices');
  };

  const handleExportTable = (tableName: string) => {
    if (tableName === 'Business Unit Performance') {
      const headers = ['Business Unit', 'Total Loss ($M)', 'Net Loss ($M)', 'Contracts', '% of Total', 'Status'];
      const totalGross = isChileEvent ? 350 : 185;
      const rows = filteredBUs.map(bu => [bu.bu, bu.grossEst, bu.netEst, bu.uwCount, `${((bu.grossEst / totalGross) * 100).toFixed(1)}%`, bu.status]);
      downloadCSV(headers, rows, `SONAR_Event_Overview_Business_Unit_Performance_${event?.eventName || 'Event'}`);
    } else if (tableName === 'Top 10 Contracts') {
      const headers = ['#', 'Contract', 'Cedent', 'Est. Loss ($M)', 'Limit Util. %'];
      const rows = top10Deals.map((d, i) => [i + 1, d.contractId, d.cedent, d.grossEst, `${((d.grossEst / d.limit) * 100).toFixed(1)}%`]);
      downloadCSV(headers, rows, `SONAR_Event_Overview_Top10_Contracts_${event?.eventName || 'Event'}`);
    } else if (tableName === 'Top 10 Cedants') {
      const headers = ['#', 'Cedant', 'Total Loss ($M)', 'Contracts', '% of Total'];
      const totalGross = isChileEvent ? 350 : 185;
      const rows = top10Companies.map((c, i) => [i + 1, c.company, c.grossEst, c.contracts, `${((c.grossEst / totalGross) * 100).toFixed(1)}%`]);
      downloadCSV(headers, rows, `SONAR_Event_Overview_Top10_Cedants_${event?.eventName || 'Event'}`);
    }
    toast.success(`${tableName} exported to CSV`);
  };

  const handleSaveDraft = () => {
    toast.success('Draft saved successfully');
  };

  const [estimatesLocked, setEstimatesLocked] = useState(false);

  const handleLockEstimates = () => {
    setEstimatesLocked(prev => {
      const next = !prev;
      toast.success(next ? 'Estimates locked — management notified with final figures' : 'Estimates unlocked — editing re-enabled');
      return next;
    });
  };

  const handleDownload = () => {
    const headers = ['Business Unit', 'Total Loss ($M)', 'Net Loss ($M)', 'Contracts', 'Status'];
    const rows = filteredBUs.map(bu => [bu.bu, bu.grossEst, bu.netEst, bu.uwCount, bu.status]);
    downloadCSV(headers, rows, `SONAR_CAT_Estimation_Summary_${event?.eventName || 'Event'}`);
    toast.success('CSV export downloaded');
  };

  return (
    <div className="min-h-screen bg-slate-50">
      
      {/* Executive Header */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-40">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event.eventName}</h1>
                <h1 className="text-slate-600">- Overview</h1>

                {/* Phase - Editable Dropdown */}
                {(() => {
                  const currentPhase = getWorkflowStatus(eventId || '').currentPhase;
                  const allowedTransitions = getAllowedPhases(eventId || '');
                  const phaseBadgeColors: Record<string, string> = {
                    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
                    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
                    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
                    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'Reopened': 'bg-red-50 text-red-700 border-red-200',
                  };
                  const phaseDisplayLabels: Record<string, string> = {
                    'Event Creation': 'Event Creation',
                    'Monitoring': 'Monitoring',
                    'Estimation & Approval': 'UW Estimation',
                    'Finance Review': 'Finance Review',
                    'Reporting & Close': 'Reporting & Close',
                    'Reopened': 'Reopened',
                  };
                  const dropdownOptionColors: Record<string, string> = {
                    'Monitoring': 'text-cyan-700',
                    'Estimation & Approval': 'text-amber-700',
                    'Finance Review': 'text-blue-700',
                    'Reporting & Close': 'text-emerald-700',
                    'Complete Phase 4': 'text-emerald-700',
                    'Close Event': 'text-emerald-800',
                    'Close Archived': 'text-slate-600',
                    'Reopened': 'text-red-700',
                  };
                  return (
                    <div className="relative flex items-center gap-1.5">
                      <span className="text-xs text-slate-400 uppercase tracking-wider">Phase:</span>
                      <button
                        onClick={() => setPhaseDropdownOpen(!phaseDropdownOpen)}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border cursor-pointer hover:ring-2 hover:ring-blue-200 transition-all ${phaseBadgeColors[currentPhase] || 'bg-slate-100 text-slate-600 border-slate-200'}`}
                      >
                        {phaseDisplayLabels[currentPhase] || currentPhase}
                        <ChevronDown className="w-3 h-3 opacity-60" />
                      </button>
                      {phaseDropdownOpen && (
                        <>
                          <div className="fixed inset-0 z-40" onClick={() => setPhaseDropdownOpen(false)} />
                          <div className="absolute top-full left-0 mt-1 z-50 bg-white border border-slate-200 rounded-lg shadow-lg py-1 min-w-[260px]">
                            <div className="px-3 py-1.5 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100">
                              Allowed Transitions
                            </div>
                            {allowedTransitions.filter(t => t.allowed).length === 0 ? (
                              <>
                                {allowedTransitions.filter(t => !t.allowed).map((t) => (
                                  <div
                                    key={t.phase}
                                    className="w-full text-left px-3 py-2 text-xs flex items-center justify-between gap-2 opacity-50 cursor-not-allowed"
                                  >
                                    <span className="flex flex-col">
                                      <span className="font-medium text-slate-400 flex items-center gap-1">
                                        <Lock className="w-3 h-3" />
                                        {phaseDisplayLabels[t.phase] || t.phase}
                                      </span>
                                      {t.reason && (
                                        <span className="text-[10px] text-slate-400">{t.reason}</span>
                                      )}
                                    </span>
                                    {t.ruleId && (
                                      <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>
                                    )}
                                  </div>
                                ))}
                                {allowedTransitions.filter(t => !t.allowed).length === 0 && (
                                  <div className="px-3 py-2 text-xs text-slate-400 italic">No transitions available</div>
                                )}
                              </>
                            ) : (
                              <>
                                {allowedTransitions.filter(t => t.allowed).map((t) => (
                                  <button
                                    key={t.phase}
                                    onClick={() => {
                                      if (t.phase === 'Complete Phase 4') {
                                        completePhase4(eventId || '');
                                      } else if (t.phase === 'Close Event') {
                                        closeEvent(eventId || '');
                                      } else if (t.phase === 'Close Archived') {
                                        archiveEvent(eventId || '');
                                      } else if (t.phase === 'Reopened') {
                                        reopenEvent(eventId || '');
                                      } else {
                                        setPhase(eventId || '', t.phase as any);
                                      }
                                      setPhaseDropdownOpen(false);
                                      toast.success(t.phase === 'Reopened' ? 'Event reopened — restarted at Monitoring' : `Phase updated to ${t.phase}`);
                                    }}
                                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition-colors flex items-center justify-between gap-2"
                                  >
                                    <span className="flex flex-col">
                                      <span className={`font-medium ${dropdownOptionColors[t.phase] || 'text-slate-700'}`}>
                                        {phaseDisplayLabels[t.phase] || t.phase}
                                      </span>
                                      {t.reason && (
                                        <span className="text-[10px] text-slate-400">{t.reason}</span>
                                      )}
                                    </span>
                                    {t.ruleId && (
                                      <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>
                                    )}
                                  </button>
                                ))}
                                {allowedTransitions.filter(t => !t.allowed).map((t) => (
                                  <div
                                    key={t.phase}
                                    className="w-full text-left px-3 py-2 text-xs flex items-center justify-between gap-2 opacity-50 cursor-not-allowed border-t border-slate-100"
                                  >
                                    <span className="flex flex-col">
                                      <span className="font-medium text-slate-400 flex items-center gap-1">
                                        <Lock className="w-3 h-3" />
                                        {phaseDisplayLabels[t.phase] || t.phase}
                                      </span>
                                      {t.reason && (
                                        <span className="text-[10px] text-slate-400">{t.reason}</span>
                                      )}
                                    </span>
                                    {t.ruleId && (
                                      <span className="text-[10px] text-slate-300 font-mono">{t.ruleId}</span>
                                    )}
                                  </div>
                                ))}
                              </>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  );
                })()}

                {/* Status - Read Only Label + Badge with Lock/Unlock */}
                {(() => {
                  const status = getEventStatus(eventId || '');
                  const locked = isEventLocked(eventId || '');
                  const statusBadge: Record<string, string> = {
                    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
                    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
                    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
                    'Reopened': 'bg-red-50 text-red-700 border-red-300',
                  };
                  
                  const handleLockToggle = () => {
                    if (locked) {
                      unlockEvent(eventId || '');
                      // When unlocked, move to Reporting & Close
                      setPhase(eventId || '', 'Reporting & Close');
                      toast.success('Event unlocked and moved to Reporting & Close');
                    } else {
                      lockEvent(eventId || '');
                      toast.success('Event locked - UW Estimation and Cat Modeling frozen');
                    }
                  };
                  
                  return (
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-slate-400 uppercase tracking-wider">Status:</span>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                        {status}
                      </span>
                      {/* Lock/Unlock Button */}
                      <button
                        onClick={handleLockToggle}
                        className="p-1 rounded hover:bg-slate-100 transition-colors"
                        title={locked ? 'Unlock event (moves to Reporting & Close)' : 'Lock event (freezes UW Estimation & Cat Modeling)'}
                      >
                        {locked ? (
                          <Lock className="w-4 h-4 text-red-600" />
                        ) : (
                          null
                        )}
                      </button>
                    </div>
                  );
                })()}
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Type of Everest Event:</span>
                  <span className="text-slate-900">{event.everestEventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Type:</span>
                  <span className="text-slate-900">{event.eventType || '—'}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Sub-Type:</span>
                  <span className="text-slate-900">{event.eventSubType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Management Approval Banner */}
      {approvalRequest && (
        <div className="px-10 pt-6">
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-5 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <div className="text-amber-900">Approval Required</div>
                <div className="text-sm text-amber-700 mt-0.5">
                  {approvalRequest.submittedBy} • {approvalRequest.totalUWEstimate} • {approvalRequest.totalContracts} contracts
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleRequestChanges}
                className="px-5 py-2 bg-white border border-amber-300 text-amber-900 hover:bg-amber-50 transition-all rounded-lg"
              >
                Request Changes
              </button>
              <button
                onClick={handleApprove}
                className="px-5 py-2 text-white hover:opacity-90 transition-all rounded-lg shadow-sm"
                style={{ backgroundColor: '#0052FF' }}
              >
                Approve Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <div className="bg-white border-b border-slate-200 sticky top-[88px] z-30">
        <div className="px-10 flex items-center justify-between">
          <div className="flex items-center">
            {/* Executive Summary tab removed — out of initial scope */}

            

            <button
              onClick={() => setActiveTab('summary')}
              className={`px-6 py-4 text-sm uppercase tracking-wider transition-all border-b-2 flex items-center gap-2 ${
                activeTab === 'summary' 
                  ? 'text-slate-900 border-blue-600' 
                  : 'text-slate-500 border-transparent hover:text-slate-700 hover:border-slate-300'
              }`}
              style={activeTab === 'summary' ? { borderColor: '#0052FF' } : {}}
            >
              Net Waterfall
            </button>

            <button
              onClick={() => setActiveTab('details')}
              className={`px-6 py-4 text-sm uppercase tracking-wider transition-all border-b-2 ${
                activeTab === 'details' 
                  ? 'text-slate-900 border-blue-600' 
                  : 'text-slate-500 border-transparent hover:text-slate-700 hover:border-slate-300'
              }`}
              style={activeTab === 'details' ? { borderColor: '#0052FF' } : {}}
            >
              Event Details
            </button>


          </div>

        </div>
      </div>

      <div className={activeTab === 'marketshare' || activeTab === 'summary' || activeTab === 'executive' || activeTab === 'modeling' ? '' : 'px-10 py-8'}>
        {activeTab === 'executive' ? (
          <ExecutiveSummary
            event={event}
            marketEstimates={marketEstimates}
            top10Deals={top10Deals}
            top10Companies={top10Companies}
            hasContracts={hasContracts}
          />
        ) : activeTab === 'details' ? (
          <EventDetailsTab 
            event={event} 
            canEdit={permissions.canEditEventMetadata} 
            isEditing={isEditingEventDetails}
            setIsEditing={setIsEditingEventDetails}
          />
        ) : activeTab === 'modeling' ? (
          <ModelingTab eventName={event?.eventName || event?.name} />
        ) : activeTab === 'marketshare' ? (
          <MarketShare eventName={event.name} />
        ) : activeTab === 'summary' ? (
          <div className="px-4 lg:px-10 py-8 space-y-8">
            <CATEstimationSummary 
              event={event}
              onSaveDraft={handleSaveDraft}
              onLockEstimates={handleLockEstimates}
              isLocked={estimatesLocked}
              onDownload={handleDownload}
            />
            
            {/* Team Comments & Updates */}
            
          </div>
        ) : (
          <div className="px-10 py-8 space-y-8">
            {/* Executive KPIs */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="grid grid-cols-6 divide-x divide-slate-200">
                {executiveKPIs.map((kpi, index) => {
                  const Icon = kpi.icon;
                  return (
                    <div key={kpi.label} className="px-6 py-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center">
                          <Icon className="w-5 h-5 text-slate-600" />
                        </div>
                        {kpi.change && (
                          <div className="flex items-center gap-1 px-2 py-0.5 rounded text-xs bg-emerald-50 text-emerald-700">
                            <ArrowUp className="w-3 h-3" />
                            {kpi.change}
                          </div>
                        )}
                      </div>
                      <div className="space-y-1">
                        <div className="text-slate-900 text-2xl">
                          {kpi.value}
                        </div>
                        <div className="text-xs uppercase tracking-wider text-slate-600">
                          {kpi.label}
                        </div>
                        <div className="text-xs text-slate-500">
                          {kpi.sublabel}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

        {/* Workflow Progress Bar */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
          <div className="px-8 py-5">
            <div className="flex items-center justify-between gap-8 mb-4">
              {/* Phase Info */}
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <div>
                  <div className="text-xs text-slate-500">Current Phase</div>
                  <div className="text-sm text-slate-900">Phase {event.phase} • {currentPhase.name}</div>
                </div>
              </div>

              {/* Assigned Team */}
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg">
                <UserCheck className="w-4 h-4 text-slate-500" />
                <span className="text-sm text-slate-700">{nextTask.assignedTo}</span>
              </div>

              {/* Task Description */}
              <div className="flex-1 px-4">
                <div className="text-xs text-slate-500 mb-1">Action Required</div>
                <div className="text-sm text-slate-900">{nextTask.task}</div>
              </div>

              {/* Due Date */}
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg">
                <Clock className="w-4 h-4 text-slate-500" />
                <span className="text-sm text-slate-700">
                  Due {new Date(nextTask.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              </div>

              {/* Status Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-700">
                {nextTask.status}
              </div>

              {/* Progress */}
              <div className="text-right min-w-[70px]">
                <div className="text-xs text-slate-500 mb-1">Progress</div>
                <div className="text-sm text-slate-900">{nextTask.completion}%</div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="flex gap-1.5">
              {phases.map((phase, index) => {
                const isCompleted = index < currentPhaseIndex;
                const isCurrent = index === currentPhaseIndex;
                return (
                  <div key={phase.id} className="flex-1">
                    <div className={`h-1 rounded-full transition-all ${
                      isCompleted ? 'bg-emerald-500' : isCurrent ? 'bg-amber-500' : 'bg-slate-200'
                    }`} />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Business Unit Performance Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-gradient-to-r from-slate-50 to-white px-8 py-5 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E6EFFF' }}>
                <Building2 className="w-5 h-5" style={{ color: '#0052FF' }} />
              </div>
              <h3 className="text-slate-900 uppercase tracking-wider text-sm">Business Unit Summary</h3>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search business units..."
                  value={buSearchTerm}
                  onChange={(e) => setBuSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 rounded-lg border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:border-transparent text-sm"
                  style={{ focusRing: '2px solid #0052FF' }}
                />
              </div>
              <button
                onClick={() => handleExportTable('Business Unit Performance')}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            </div>
          </div>
          
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-slate-50 to-white border-b border-slate-200">
                <th 
                  className="px-8 py-4 text-left uppercase tracking-wider cursor-pointer hover:bg-blue-50/50 transition-colors text-xs"
                  onClick={() => handleSort('bu', 'bu')}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-slate-700">Business Unit</span>
                    <div className="flex flex-col items-center -space-y-1">
                      <svg width="12" height="6" viewBox="0 0 10 5" className={buSortConfig?.key === 'bu' && buSortConfig.direction === 'asc' ? 'text-blue-600' : buSortConfig?.key === 'bu' ? 'text-gray-300' : 'text-gray-400'}>
                        <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
                      </svg>
                      <svg width="12" height="6" viewBox="0 0 10 5" className={buSortConfig?.key === 'bu' && buSortConfig.direction === 'desc' ? 'text-blue-600' : buSortConfig?.key === 'bu' ? 'text-gray-300' : 'text-gray-400'}>
                        <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
                      </svg>
                    </div>
                  </div>
                </th>
                <SortableHeader label="Total Loss" sortKey="grossEst" currentConfig={buSortConfig} onSort={(key: string) => handleSort('bu', key)} />
                <SortableHeader label="Net Loss" sortKey="netEst" currentConfig={buSortConfig} onSort={(key: string) => handleSort('bu', key)} />
                <SortableHeader label="Contracts" sortKey="uwCount" currentConfig={buSortConfig} onSort={(key: string) => handleSort('bu', key)} />
                <th className="px-5 py-4 text-center uppercase tracking-wider text-xs text-slate-700">% of Total</th>
                <th className="px-5 py-4 text-center uppercase tracking-wider text-xs text-slate-700">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBUs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-8 py-20 text-center">
                    <Building2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <div className="text-slate-400 uppercase tracking-wider text-sm">No Business Units Found</div>
                  </td>
                </tr>
              ) : filteredBUs.map((bu, idx) => {
                const totalGross = isChileEvent ? 350 : 185;
                const percentOfTotal = ((bu.grossEst / totalGross) * 100).toFixed(1);
                
                return (
                  <tr key={bu.bu} className={`hover:bg-blue-50/30 transition-colors ${idx % 2 === 1 ? 'bg-slate-50/40' : 'bg-white'}`}>
                    <td className="px-8 py-4">
                      <span className="text-slate-900">{bu.bu}</span>
                    </td>
                    <td className="px-5 py-4 text-right text-slate-900">{formatCurrency(bu.grossEst)}</td>
                    <td className="px-5 py-4 text-right text-slate-900">{formatCurrency(bu.netEst)}</td>
                    <td className="px-5 py-4 text-center text-slate-900">
                      {bu.uwCount}
                    </td>
                    <td className="px-5 py-4 text-center text-slate-700">{percentOfTotal}%</td>
                    <td className="px-5 py-4 text-center">
                      {bu.status === 'Complete' ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs text-emerald-700 bg-emerald-50 rounded-full border border-emerald-200">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          Complete
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs bg-blue-50 rounded-full border border-blue-200" style={{ color: '#0052FF' }}>
                          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#0052FF' }} />
                          In Progress
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-gradient-to-r from-slate-800 to-slate-700 text-white">
                <td className="px-8 py-4 uppercase tracking-wider text-sm">Total</td>
                <td className="px-5 py-4 text-right">{isChileEvent ? '$350M' : '$185M'}</td>
                <td className="px-5 py-4 text-right">{isChileEvent ? '$318M' : '$92M'}</td>
                <td className="px-5 py-4 text-center">{isChileEvent ? '1,247' : '47'}</td>
                <td className="px-5 py-4 text-center">100%</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Critical Tables Grid */}
        <div className="grid grid-cols-2 gap-8">
          {/* Top Contracts */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-violet-50 to-purple-50 px-6 py-4 border-b border-violet-200 flex items-center justify-between">
              <h3 className="text-violet-700 uppercase tracking-wider text-sm flex items-center gap-2">
                <div className="w-1 h-6 bg-violet-600 rounded-full" />
                Top 10 Contracts by Loss
              </h3>
              <button
                onClick={() => handleExportTable('Top 10 Contracts')}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            </div>
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-slate-50 to-white border-b border-slate-200">
                  <th className="px-4 py-3 text-left uppercase tracking-wider text-xs text-slate-700">#</th>
                  <th className="px-4 py-3 text-left uppercase tracking-wider text-xs text-slate-700">Contract</th>
                  <th className="px-4 py-3 text-left uppercase tracking-wider text-xs text-slate-700">Cedent</th>
                  <th 
                    className="px-4 py-3 text-right uppercase tracking-wider text-xs text-slate-700 cursor-pointer hover:bg-blue-50/50"
                    onClick={() => handleSort('deals', 'grossEst')}
                  >
                    <div className="flex items-center justify-end gap-2">
                      <span>Est. Loss</span>
                      <div className="flex flex-col items-center -space-y-1">
                        <svg width="12" height="6" viewBox="0 0 10 5" className={dealsSortConfig?.key === 'grossEst' && dealsSortConfig.direction === 'asc' ? 'text-blue-600' : dealsSortConfig?.key === 'grossEst' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
                        </svg>
                        <svg width="12" height="6" viewBox="0 0 10 5" className={dealsSortConfig?.key === 'grossEst' && dealsSortConfig.direction === 'desc' ? 'text-blue-600' : dealsSortConfig?.key === 'grossEst' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
                        </svg>
                      </div>
                    </div>
                  </th>
                  <th className="px-4 py-3 text-right uppercase tracking-wider text-xs text-slate-700">
                    Limit Util.
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {top10Deals.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-16 text-center">
                      <FileText className="w-14 h-14 text-slate-300 mx-auto mb-3" />
                      <div className="text-slate-400 text-sm">No Contracts Available</div>
                    </td>
                  </tr>
                ) : top10Deals.map((deal, index) => {
                  const utilizationPct = ((deal.grossEst / deal.limit) * 100).toFixed(1);
                  const isAttached = deal.grossEst > deal.attachment;
                  
                  return (
                    <tr 
                      key={deal.contractId}
                      className="hover:bg-violet-50/30 transition-colors cursor-pointer"
                      onClick={() => setSidePanelData({ type: 'deal', data: deal })}
                    >
                      <td className="px-4 py-3.5">
                        <div className={`w-7 h-7 flex items-center justify-center rounded text-xs ${
                          index < 3 ? 'bg-violet-600 text-white' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {index + 1}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-900 text-sm">{deal.contractId}</td>
                      <td className="px-4 py-3.5 text-slate-600 text-sm">{deal.cedent}</td>
                      <td className="px-4 py-3.5 text-right text-slate-900 text-sm">{formatCurrency(deal.grossEst)}</td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="flex flex-col items-end gap-1">
                          <span className="text-slate-900 text-sm">{utilizationPct}%</span>
                          {isAttached ? (
                            <span className="px-2 py-0.5 bg-violet-50 text-violet-700 border border-violet-200 rounded text-xs">Attached</span>
                          ) : (
                            <span className="px-2 py-0.5 bg-slate-50 text-slate-600 border border-slate-200 rounded text-xs">Working</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Top Cedants */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 px-6 py-4 border-b border-blue-200 flex items-center justify-between">
              <h3 className="uppercase tracking-wider text-sm flex items-center gap-2" style={{ color: '#0052FF' }}>
                <div className="w-1 h-6 rounded-full" style={{ backgroundColor: '#0052FF' }} />
                Top 10 Cedants by Loss
              </h3>
              <button
                onClick={() => handleExportTable('Top 10 Cedants')}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            </div>
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-slate-50 to-white border-b border-slate-200">
                  <th className="w-10"></th>
                  <th className="px-4 py-3 text-left uppercase tracking-wider text-xs text-slate-700">Cedant</th>
                  <th 
                    className="px-4 py-3 text-right uppercase tracking-wider text-xs text-slate-700 cursor-pointer hover:bg-blue-50/50"
                    onClick={() => handleSort('companies', 'grossEst')}
                  >
                    <div className="flex items-center justify-end gap-2">
                      <span>Total Loss</span>
                      <div className="flex flex-col items-center -space-y-1">
                        <svg width="12" height="6" viewBox="0 0 10 5" className={companiesSortConfig?.key === 'grossEst' && companiesSortConfig.direction === 'asc' ? 'text-blue-600' : companiesSortConfig?.key === 'grossEst' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
                        </svg>
                        <svg width="12" height="6" viewBox="0 0 10 5" className={companiesSortConfig?.key === 'grossEst' && companiesSortConfig.direction === 'desc' ? 'text-blue-600' : companiesSortConfig?.key === 'grossEst' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
                        </svg>
                      </div>
                    </div>
                  </th>
                  <th className="px-4 py-3 text-right uppercase tracking-wider text-xs text-slate-700">
                    % of Total
                  </th>
                  <th 
                    className="px-4 py-3 text-center uppercase tracking-wider text-xs text-slate-700 cursor-pointer hover:bg-blue-50/50"
                    onClick={() => handleSort('companies', 'contractCount')}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <span>Contracts</span>
                      <div className="flex flex-col items-center -space-y-1">
                        <svg width="12" height="6" viewBox="0 0 10 5" className={companiesSortConfig?.key === 'contractCount' && companiesSortConfig.direction === 'asc' ? 'text-blue-600' : companiesSortConfig?.key === 'contractCount' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 0 L9 5 L1 5 Z" fill="currentColor" />
                        </svg>
                        <svg width="12" height="6" viewBox="0 0 10 5" className={companiesSortConfig?.key === 'contractCount' && companiesSortConfig.direction === 'desc' ? 'text-blue-600' : companiesSortConfig?.key === 'contractCount' ? 'text-gray-300' : 'text-gray-400'}>
                          <path d="M5 5 L9 0 L1 0 Z" fill="currentColor" />
                        </svg>
                      </div>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {top10Companies.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-16 text-center">
                      <Building2 className="w-14 h-14 text-slate-300 mx-auto mb-3" />
                      <div className="text-slate-400 text-sm">No Cedents Available</div>
                    </td>
                  </tr>
                ) : top10Companies.flatMap((company) => {
                  const isExpanded = expandedCedents.has(company.cedent);
                  const hasContracts = contractsByCedent[company.cedent];
                  
                  const cedentRows: React.ReactNode[] = [
                    <tr key={company.cedent} className="hover:bg-blue-50/30 transition-colors">
                      <td className="px-4 py-3.5">
                        {hasContracts && (
                          <button
                            onClick={() => toggleCedentExpansion(company.cedent)}
                            className="p-1 hover:bg-slate-100 rounded transition-colors"
                          >
                            {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-600" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                          </button>
                        )}
                      </td>
                      <td 
                        className="px-4 py-3.5 text-slate-900 cursor-pointer text-sm"
                        onClick={() => hasContracts && toggleCedentExpansion(company.cedent)}
                      >
                        {company.cedent}
                      </td>
                      <td className="px-4 py-3.5 text-right text-slate-900 text-sm">{formatCurrency(company.grossEst)}</td>
                      <td className="px-4 py-3.5 text-right text-slate-700 text-sm">{company.percentOfTotal}</td>
                      <td className="px-4 py-3.5 text-center text-slate-900 text-sm">
                        {company.contractCount}
                      </td>
                    </tr>
                  ];
                  if (isExpanded && hasContracts) {
                    cedentRows.push(
                      <tr key={`${company.cedent}-detail`} className="bg-slate-50">
                        <td colSpan={5} className="px-12 py-4">
                          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
                            <div className="space-y-2">
                              {contractsByCedent[company.cedent].map((contract: any) => (
                                <div 
                                  key={contract.contractId}
                                  className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer text-sm border border-slate-200"
                                  onClick={() => setSidePanelData({ type: 'contract', data: contract })}
                                >
                                  <span className="text-slate-900">{contract.contractId}</span>
                                  <span className="px-2 py-1 bg-blue-50 rounded text-xs border border-blue-200" style={{ color: '#0052FF' }}>{contract.bu}</span>
                                  <span className="text-slate-700">{contract.exposure}</span>
                                  <span className="text-slate-900">{contract.grossEst}</span>
                                  <span className="text-slate-600">{contract.uw}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  }
                  return cedentRows;
                })}
              </tbody>
            </table>
          </div>
        </div>
          </div>
        )}
      </div>

      {/* Side Panel */}
      {sidePanelData && (
        <div className="fixed inset-0 bg-black/40 z-50" onClick={() => setSidePanelData(null)}>
          <div 
            className="absolute right-0 top-0 bottom-0 w-[500px] bg-white shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 flex items-center justify-between sticky top-0 z-10 bg-gradient-to-r from-slate-800 to-slate-700 border-b border-slate-600">
              <div className="text-white">
                <div className="uppercase tracking-wider text-xs opacity-70 mb-1">Detail View</div>
                <div className="text-lg">
                  {sidePanelData.type === 'deal' && sidePanelData.data.contractId}
                  {sidePanelData.type === 'contract' && sidePanelData.data.contractId}
                  {sidePanelData.type === 'company' && sidePanelData.data.cedent}
                </div>
              </div>
              <button
                onClick={() => setSidePanelData(null)}
                className="text-white p-2 rounded-lg hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-8 space-y-8">
              {sidePanelData.type === 'deal' && (
                <>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <div className="uppercase tracking-wider mb-2 text-xs text-slate-500">Contract ID</div>
                      <div className="text-sm text-slate-900">{sidePanelData.data.contractId}</div>
                    </div>
                    <div>
                      <div className="uppercase tracking-wider mb-2 text-xs text-slate-500">Cedent</div>
                      <div className="text-sm text-slate-900">{sidePanelData.data.cedent}</div>
                    </div>
                  </div>

                  <div className="border-t border-slate-200 pt-6">
                    <div className="text-slate-900 uppercase tracking-wider mb-4 text-sm">Financial Metrics</div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <div className="uppercase text-slate-500 mb-2 text-xs">Exposure</div>
                        <div className="text-2xl text-slate-900">{formatCurrency(sidePanelData.data.exposure)}</div>
                      </div>
                      <div className="bg-red-50 p-4 rounded-xl border border-red-200">
                        <div className="uppercase text-red-700 mb-2 text-xs">Gross Estimate</div>
                        <div className="text-2xl text-red-700">{formatCurrency(sidePanelData.data.grossEst)}</div>
                      </div>
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <div className="uppercase text-blue-700 mb-2 text-xs">Net Estimate</div>
                        <div className="text-2xl text-blue-700">{formatCurrency(sidePanelData.data.netEst)}</div>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <div className="uppercase text-slate-500 mb-2 text-xs">Loss Ratio</div>
                        <div className="text-2xl text-slate-900">
                          {((sidePanelData.data.grossEst / sidePanelData.data.exposure) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {sidePanelData.type === 'contract' && (
                <>
                  <div>
                    <div className="uppercase tracking-wider mb-2 text-xs text-slate-500">Contract ID</div>
                    <div className="text-sm text-slate-900">{sidePanelData.data.contractId}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <div className="uppercase tracking-wider mb-2 text-xs text-slate-500">Cedent</div>
                      <div className="text-sm text-slate-900">{sidePanelData.data.cedent}</div>
                    </div>
                    <div>
                      <div className="uppercase tracking-wider mb-2 text-xs text-slate-500">Underwriter</div>
                      <div className="text-sm text-slate-900">{sidePanelData.data.uw}</div>
                    </div>
                  </div>

                  <div className="border-t border-slate-200 pt-6">
                    <div className="text-slate-900 uppercase tracking-wider mb-4 text-sm">Estimates</div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <div className="uppercase text-slate-500 mb-2 text-xs">Exposure</div>
                        <div className="text-lg text-slate-900">{sidePanelData.data.exposure}</div>
                      </div>
                      <div className="bg-red-50 p-4 rounded-xl border border-red-200">
                        <div className="uppercase text-red-700 mb-2 text-xs">Gross</div>
                        <div className="text-lg text-red-700">{sidePanelData.data.grossEst}</div>
                      </div>
                      <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <div className="uppercase text-blue-700 mb-2 text-xs">Net</div>
                        <div className="text-lg text-blue-700">{sidePanelData.data.netEst}</div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
