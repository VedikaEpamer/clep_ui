import { useState } from 'react';
import { X, Search, AlertCircle, CheckCircle, Building2, DollarSign, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AddContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (contract: any) => void;
}

export function AddContractModal({ isOpen, onClose, onAdd }: AddContractModalProps) {
  const [contractNumber, setContractNumber] = useState('');
  const [rdmResult, setRdmResult] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [showManualAdd, setShowManualAdd] = useState(false);
  const [reasonCode, setReasonCode] = useState('');
  const [comment, setComment] = useState('');

  if (!isOpen) return null;

  // Mock RDM validation (replace with actual RDM API call)
  const handleValidateRDM = async () => {
    if (!contractNumber.trim()) {
      toast.error('Please enter a contract number');
      return;
    }

    setIsValidating(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock: 70% found in RDM, 30% not found
    const foundInRDM = Math.random() > 0.3;
    
    if (foundInRDM) {
      setRdmResult({
        found: true,
        contractNumber,
        cedant: 'Compañía de Seguros Mock',
        structure: 'Quota Share',
        currency: 'CLP',
        limit: 'CLP 500,000,000',
        attachment: 'CLP 0',
        profitCenter: 'LATAM',
        broker: 'Aon',
        effectDate: '2024-01-01'
      });
      toast.success('Contract found in RDM');
    } else {
      setRdmResult({ found: false });
      setShowManualAdd(true);
      toast.warning('Contract not found in RDM - Manual entry required');
    }
    
    setIsValidating(false);
  };

  const handleAdd = () => {
    if (rdmResult?.found) {
      // Add contract with RDM data
      onAdd({
        contractNumber,
        ...rdmResult,
        rosterStatus: 'Included',
        inRoster: 'included',
        validationStatus: 'valid',
        addedManually: false
      });
      toast.success('Contract added successfully');
      handleClose();
    } else if (showManualAdd) {
      // Validate manual entry
      if (!reasonCode) {
        toast.error('Reason Code is required for manual entries');
        return;
      }
      if (!comment.trim()) {
        toast.error('Comment is required for manual entries');
        return;
      }
      
      // Add contract without RDM data
      onAdd({
        contractNumber,
        cedant: 'Manual Entry - See Comments',
        structure: 'Unknown',
        rosterStatus: 'Manual Added / Not in RDM',
        inRoster: 'manual-added',
        validationStatus: 'not-in-rdm',
        addedManually: true,
        exclusionReason: reasonCode,
        exclusionComment: comment
      });
      toast.success('Contract added manually');
      handleClose();
    } else {
      toast.error('Please validate the contract number first');
    }
  };

  const handleClose = () => {
    setContractNumber('');
    setRdmResult(null);
    setShowManualAdd(false);
    setReasonCode('');
    setComment('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">Add Contract to Roster</h2>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Contract Number Input */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Contract Number <span className="text-red-600">*</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={contractNumber}
                onChange={(e) => setContractNumber(e.target.value.toUpperCase())}
                placeholder="e.g., TR123456"
                className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isValidating || rdmResult?.found}
              />
              <button
                onClick={handleValidateRDM}
                disabled={isValidating || !contractNumber.trim() || rdmResult?.found}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed flex items-center gap-2 transition-all"
              >
                <Search className={`w-4 h-4 ${isValidating ? 'animate-spin' : ''}`} />
                {isValidating ? 'Validating...' : 'Validate in RDM'}
              </button>
            </div>
          </div>

          {/* RDM Validation Result - Found */}
          {rdmResult?.found && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="font-medium text-green-900 mb-3">Contract Found in RDM</div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-green-700 mb-1">Cedant</div>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium text-green-900">{rdmResult.cedant}</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-700 mb-1">Structure</div>
                      <div className="text-sm font-medium text-green-900">{rdmResult.structure}</div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-700 mb-1">Currency</div>
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium text-green-900">{rdmResult.currency}</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-700 mb-1">Limit</div>
                      <div className="text-sm font-medium text-green-900">{rdmResult.limit}</div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-700 mb-1">Profit Center</div>
                      <div className="text-sm font-medium text-green-900">{rdmResult.profitCenter}</div>
                    </div>
                    
                    <div>
                      <div className="text-xs text-green-700 mb-1">Effective Date</div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium text-green-900">{rdmResult.effectDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* RDM Validation Result - Not Found */}
          {showManualAdd && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="font-medium text-amber-900 mb-1">Contract Not Found in RDM</div>
                  <div className="text-sm text-amber-700">
                    You can still add this contract manually, but you must provide a reason and comment.
                  </div>
                </div>
              </div>

              {/* Reason Code */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Reason Code <span className="text-red-600">*</span>
                </label>
                <select
                  value={reasonCode}
                  onChange={(e) => setReasonCode(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select reason...</option>
                  <option value="not-in-rdm">Not in RDM</option>
                  <option value="new-contract">New Contract (Pending RDM Entry)</option>
                  <option value="manual-override">Manual Override / Special Case</option>
                  <option value="acquisition">Recent Acquisition</option>
                  <option value="reinsured-program">Reinsured Program</option>
                </select>
              </div>

              {/* Comment */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Comment <span className="text-red-600">*</span>
                </label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Explain why this contract is being added manually..."
                  rows={3}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleAdd}
            disabled={!rdmResult && !showManualAdd}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-all"
          >
            Add Contract
          </button>
        </div>
      </div>
    </div>
  );
}
