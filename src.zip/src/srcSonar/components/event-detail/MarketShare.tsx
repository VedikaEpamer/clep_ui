import { Building2, TrendingUp, AlertCircle } from 'lucide-react';

interface MarketShareProps {
  eventName: string;
}

export function MarketShare({ eventName }: MarketShareProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-50 px-8 py-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-2xl font-semibold text-slate-900">Market Share Analysis</h2>
          <p className="text-sm text-slate-600 mt-1">
            Competitive positioning and market share breakdown for {eventName}
          </p>
        </div>

        {/* Coming Soon Placeholder */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-12 text-center">
          <Building2 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 mb-2">Market Share Analysis</h3>
          <p className="text-slate-600 max-w-md mx-auto">
            Detailed market share breakdown, competitive positioning, and reinsurer comparisons will be available here.
          </p>
          <div className="mt-6 flex items-center justify-center gap-4">
            <div className="text-center">
              <p className="text-sm text-slate-500">Dream Re Market Share</p>
              <p className="text-2xl font-semibold text-blue-600 mt-1">15.3%</p>
            </div>
            <div className="w-px h-12 bg-slate-200"></div>
            <div className="text-center">
              <p className="text-sm text-slate-500">Industry Total</p>
              <p className="text-2xl font-semibold text-slate-900 mt-1">$2.4B</p>
            </div>
            <div className="w-px h-12 bg-slate-200"></div>
            <div className="text-center">
              <p className="text-sm text-slate-500">Rank</p>
              <p className="text-2xl font-semibold text-emerald-600 mt-1">#4</p>
            </div>
          </div>
        </div>

        {/* Top Competitors Preview */}
        <div className="mt-6 grid grid-cols-3 gap-4">
          {[
            { name: 'Munich Re', share: '18.7%', trend: 'up' },
            { name: 'Swiss Re', share: '16.9%', trend: 'down' },
            { name: 'Hannover Re', share: '15.8%', trend: 'up' },
          ].map((competitor) => (
            <div key={competitor.name} className="bg-white rounded-lg border border-slate-200 p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-slate-900">{competitor.name}</h4>
                {competitor.trend === 'up' ? (
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                ) : (
                  <TrendingUp className="w-4 h-4 text-red-600 rotate-180" />
                )}
              </div>
              <p className="text-2xl font-semibold text-blue-600">{competitor.share}</p>
              <p className="text-xs text-slate-500 mt-1">Market Share</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
