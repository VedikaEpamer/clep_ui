import { useState, useMemo, useRef, useEffect, Fragment } from 'react';
import { useParams } from 'react-router';
import { mockEvents } from '../../lib/mockData';
import { useWorkflow } from '../../lib/workflowContext';
import { useEventData, BACKEND_CAT_CODES } from '../../lib/eventDataContext';
import { downloadCSV } from '../../lib/exportUtils';
import { toast } from 'sonner@2.0.3';
import { DollarSign, TrendingUp, TrendingDown, FileText, Percent, Filter, Download, Search, Tag, X } from 'lucide-react';

// ─── MOCK DATA ─────────────────────────────────────────────────────────
const claimsData = [
  {
    executiveArea: 'North America', bu: 'US Property', contractNumber: 'RE-2024-12345',
    cedant: 'State Farm', uwyYear: 2024, reportingLevel: 'NA US Property', ibnrTag: 'PROP_CAT_XL',
    estimatedLoss: 12400000, totalIncurredClaims: 11800000, totalPaid: 9200000,
    csr: 1850000, judgementACR: 750000, cedantIBNR: 1200000, variance: -600000,
    lastFinancialUpdate: '2025-02-28', estimatedLossNetNet: 8680000, totalIncurredNetNet: 8260000, varianceNetNet: -420000,
  },
  {
    executiveArea: 'North America', bu: 'US Property', contractNumber: 'RE-2024-12346',
    cedant: 'Liberty Mutual', uwyYear: 2024, reportingLevel: 'NA US Property', ibnrTag: 'PROP_CAT_XL',
    estimatedLoss: 11200000, totalIncurredClaims: 12100000, totalPaid: 8900000,
    csr: 2100000, judgementACR: 1100000, cedantIBNR: 950000, variance: 900000,
    lastFinancialUpdate: '2025-03-01', estimatedLossNetNet: 7840000, totalIncurredNetNet: 8470000, varianceNetNet: 630000,
  },
  {
    executiveArea: 'North America', bu: 'US Property', contractNumber: 'RE-2024-12347',
    cedant: 'Allstate', uwyYear: 2023, reportingLevel: 'NA US Property', ibnrTag: 'PROP_RISK_XL',
    estimatedLoss: 8100000, totalIncurredClaims: 7900000, totalPaid: 6500000,
    csr: 950000, judgementACR: 450000, cedantIBNR: 680000, variance: -200000,
    lastFinancialUpdate: '2025-02-15', estimatedLossNetNet: 5670000, totalIncurredNetNet: 5530000, varianceNetNet: -140000,
  },
  {
    executiveArea: 'North America', bu: 'USA Casualty', contractNumber: 'CAS-2024-1247',
    cedant: 'Travelers', uwyYear: 2024, reportingLevel: 'NA US Casualty', ibnrTag: 'CAS_XL',
    estimatedLoss: 8800000, totalIncurredClaims: 9500000, totalPaid: 7100000,
    csr: 1600000, judgementACR: 800000, cedantIBNR: 1100000, variance: 700000,
    lastFinancialUpdate: '2025-03-02', estimatedLossNetNet: 6160000, totalIncurredNetNet: 6650000, varianceNetNet: 490000,
  },
  {
    executiveArea: 'North America', bu: 'USA Casualty', contractNumber: 'CAS-2024-0888',
    cedant: 'Hartford', uwyYear: 2024, reportingLevel: 'NA US Casualty', ibnrTag: 'CAS_XL',
    estimatedLoss: 6800000, totalIncurredClaims: 6650000, totalPaid: 5200000,
    csr: 980000, judgementACR: 470000, cedantIBNR: 520000, variance: -150000,
    lastFinancialUpdate: '2025-02-20', estimatedLossNetNet: 4760000, totalIncurredNetNet: 4655000, varianceNetNet: -105000,
  },
  {
    executiveArea: 'Bermuda', bu: 'Bermuda Property', contractNumber: 'BERM-2024-0421',
    cedant: 'AIG', uwyYear: 2024, reportingLevel: 'BM Property', ibnrTag: 'PROP_BM_XL',
    estimatedLoss: 7900000, totalIncurredClaims: 8200000, totalPaid: 6100000,
    csr: 1400000, judgementACR: 700000, cedantIBNR: 850000, variance: 300000,
    lastFinancialUpdate: '2025-02-25', estimatedLossNetNet: 5530000, totalIncurredNetNet: 5740000, varianceNetNet: 210000,
  },
  {
    executiveArea: 'North America', bu: 'US Property', contractNumber: 'PROP-2024-1089',
    cedant: 'Progressive', uwyYear: 2023, reportingLevel: 'NA US Property', ibnrTag: 'PROP_RISK_XL',
    estimatedLoss: 7200000, totalIncurredClaims: 6900000, totalPaid: 5800000,
    csr: 750000, judgementACR: 350000, cedantIBNR: 480000, variance: -300000,
    lastFinancialUpdate: '2025-02-10', estimatedLossNetNet: 5040000, totalIncurredNetNet: 4830000, varianceNetNet: -210000,
  },
  {
    executiveArea: 'Bermuda', bu: 'Bermuda Casualty', contractNumber: 'BERM-2024-0556',
    cedant: 'Chubb', uwyYear: 2024, reportingLevel: 'BM Casualty', ibnrTag: 'CAS_BM_XL',
    estimatedLoss: 6100000, totalIncurredClaims: 6400000, totalPaid: 4800000,
    csr: 1050000, judgementACR: 550000, cedantIBNR: 720000, variance: 300000,
    lastFinancialUpdate: '2025-03-01', estimatedLossNetNet: 4270000, totalIncurredNetNet: 4480000, varianceNetNet: 210000,
  },
];

type ClaimRow = typeof claimsData[number];

// ─── HELPERS ───────────────────────────────────────────────────────────
const fmt = (v: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(v);

const fmtPct = (v: number) => `${v > 0 ? '+' : ''}${v.toFixed(1)}%`;

function safeMatch(value: unknown, filter: string): boolean {
  if (!filter) return true;
  return String(value ?? '').toLowerCase().includes(filter.toLowerCase());
}

// ─── GROUP HEADER ROW ───────────────────────────────────────────────────
function GroupHeaderRow({ colSpan, groupKey, count }: {
  colSpan: number; groupKey: string; count: number;
}) {
  return (
    <tr className="bg-indigo-50 border-b border-indigo-100">
      <td colSpan={colSpan} className="py-2 px-4">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-indigo-800">{groupKey}</span>
          <span className="text-[10px] text-indigo-500 ml-1">
            ({count} contract{count !== 1 ? 's' : ''})
          </span>
        </div>
      </td>
    </tr>
  );
}

// ─── COMPONENT ─────────────────────────────────────────────────────────
export function ClaimsEstimation() {
  const { eventId } = useParams();
  const event = mockEvents.find(e => e.id === eventId);
  const { getWorkflowStatus, getEventStatus } = useWorkflow();
  const { getCatCode, setCatCode: setSharedCatCode } = useEventData();

  const [activeView, setActiveView] = useState<'gross' | 'netnet'>('gross');
  const [groupBy, setGroupBy] = useState<'none' | 'bu'>('none');
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [filters, setFilters] = useState({
    executiveArea: '', bu: '', contractNumber: '', cedant: '', uwyYear: '', reportingLevel: '', ibnrTag: '',
  });
  const [openFilter, setOpenFilter] = useState<string | null>(null);
  const [catCodeOpen, setCatCodeOpen] = useState(false);
  const [catCodeSearch, setCatCodeSearch] = useState('');
  const catCodeRef = useRef<HTMLDivElement>(null);
  const catCodeInputRef = useRef<HTMLInputElement>(null);

  // Last refreshed date for data
  const lastRefreshedDate = new Date().toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (catCodeRef.current && !catCodeRef.current.contains(e.target as Node)) {
        setCatCodeOpen(false); setCatCodeSearch('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const catCode = getCatCode(eventId || '');

  const filteredCatCodes = BACKEND_CAT_CODES.filter(c =>
    c.label.toLowerCase().includes(catCodeSearch.toLowerCase()) ||
    c.code.toLowerCase().includes(catCodeSearch.toLowerCase())
  );

  const handleCatCodeChange = (code: string) => {
    setSharedCatCode(eventId || '', code);
    setCatCodeOpen(false); setCatCodeSearch('');
    toast.success(code ? `CAT Code updated to ${code}` : 'CAT Code cleared');
  };

  const handleFilterChange = (col: string, value: string) => setFilters(prev => ({ ...prev, [col]: value }));

  const uniqueExecAreas = useMemo(() => Array.from(new Set(claimsData.map(c => c.executiveArea))).sort(), []);
  const uniqueBUs = useMemo(() => Array.from(new Set(claimsData.map(c => c.bu))).sort(), []);
  const uniqueYears = useMemo(() => Array.from(new Set(claimsData.map(c => c.uwyYear))).sort(), []);

  const filteredData = useMemo(() => claimsData.filter(row =>
    safeMatch(row.executiveArea, filters.executiveArea) &&
    safeMatch(row.bu, filters.bu) &&
    safeMatch(row.contractNumber, filters.contractNumber) &&
    safeMatch(row.cedant, filters.cedant) &&
    safeMatch(row.uwyYear, filters.uwyYear) &&
    safeMatch(row.reportingLevel, filters.reportingLevel) &&
    safeMatch(row.ibnrTag, filters.ibnrTag)
  ), [filters]);

  const getGroupKey = (row: ClaimRow) => {
    if (groupBy === 'bu') return row.bu;
    return '';
  };

  const sortedData = useMemo(() => {
    let base = [...filteredData];
    if (groupBy !== 'none') {
      base.sort((a, b) => {
        const ak = getGroupKey(a); const bk = getGroupKey(b);
        return ak < bk ? -1 : ak > bk ? 1 : 0;
      });
    }
    if (!sortConfig) return base;
    return base.sort((a, b) => {
      const av = a[sortConfig.key as keyof ClaimRow];
      const bv = b[sortConfig.key as keyof ClaimRow];
      if (av < bv) return sortConfig.direction === 'asc' ? -1 : 1;
      if (av > bv) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortConfig, groupBy]);

  const totals = useMemo(() => {
    const eg = filteredData.reduce((s, r) => s + r.estimatedLoss, 0);
    const ig = filteredData.reduce((s, r) => s + r.totalIncurredClaims, 0);
    const pg = filteredData.reduce((s, r) => s + r.totalPaid, 0);
    const cg = filteredData.reduce((s, r) => s + r.csr, 0);
    const ag = filteredData.reduce((s, r) => s + r.judgementACR, 0);
    const bg = filteredData.reduce((s, r) => s + r.cedantIBNR, 0);
    const vg = ig - eg; const vpg = eg > 0 ? (vg / eg) * 100 : 0;
    const ppg = ig > 0 ? (pg / ig) * 100 : 0;
    const en = filteredData.reduce((s, r) => s + r.estimatedLossNetNet, 0);
    const inn = filteredData.reduce((s, r) => s + r.totalIncurredNetNet, 0);
    const vn = inn - en; const vpn = en > 0 ? (vn / en) * 100 : 0;
    const ppn = inn > 0 ? (pg / inn) * 100 : 0;
    return {
      gross: { estimated: eg, incurred: ig, paid: pg, csr: cg, acr: ag, ibnr: bg, variance: vg, variancePct: vpg, pctPaid: ppg },
      netnet: { estimated: en, incurred: inn, variance: vn, variancePct: vpn, pctPaid: ppn },
    };
  }, [filteredData]);

  const handleSort = (key: string) => {
    setSortConfig(cur => {
      if (cur?.key === key) return cur.direction === 'asc' ? { key, direction: 'desc' } : null;
      return { key, direction: 'asc' };
    });
  };

  const SortIcon = ({ col }: { col: string }) => {
    const active = sortConfig?.key === col;
    const asc = active && sortConfig?.direction === 'asc';
    const desc = active && sortConfig?.direction === 'desc';
    return (
      <div className="flex flex-col items-center gap-0.5">
        <svg width="12" height="6" viewBox="0 0 10 5" className={asc ? 'text-blue-600' : 'text-gray-300'}><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
        <svg width="12" height="6" viewBox="0 0 10 5" className={desc ? 'text-blue-600' : 'text-gray-300'}><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
      </div>
    );
  };

  const eventHeading = event
    ? `${event.eventName.toUpperCase()} ${event.lossDate ? new Date(event.lossDate).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '.') : ''} (${event.id.replace('EVT-', '')})`
    : '';

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const FilterBtn = ({ col, label, type, options }: { col: string; label: string; type: 'text' | 'select'; options?: (string | number)[] }) => (
    <button onClick={(e) => { e.stopPropagation(); setOpenFilter(openFilter === col ? null : col); }} className="relative">
      <Filter className={`w-3.5 h-3.5 cursor-pointer ${filters[col as keyof typeof filters] ? 'text-blue-600' : 'text-gray-400'}`} />
      {openFilter === col && (
        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 min-w-[180px]" onClick={e => e.stopPropagation()}>
          {type === 'select' ? (
            <select value={filters[col as keyof typeof filters]} onChange={e => handleFilterChange(col, e.target.value)}
              className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500">
              <option value="">All</option>
              {options?.map(o => <option key={String(o)} value={String(o)}>{String(o)}</option>)}
            </select>
          ) : (
            <input type="text" placeholder={`Filter ${label}...`} value={filters[col as keyof typeof filters]}
              onChange={e => handleFilterChange(col, e.target.value)}
              className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500" />
          )}
        </div>
      )}
    </button>
  );

  const curEstimated = activeView === 'gross' ? totals.gross.estimated : totals.netnet.estimated;
  const curIncurred = activeView === 'gross' ? totals.gross.incurred : totals.netnet.incurred;
  const curVariance = activeView === 'gross' ? totals.gross.variance : totals.netnet.variance;
  const curVariancePct = activeView === 'gross' ? totals.gross.variancePct : totals.netnet.variancePct;
  const curPctPaid = activeView === 'gross' ? totals.gross.pctPaid : totals.netnet.pctPaid;

  // Build grouped display rows — count per group for the header badge
  const groupCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    if (groupBy !== 'none') sortedData.forEach(r => { const k = getGroupKey(r); counts[k] = (counts[k] || 0) + 1; });
    return counts;
  }, [sortedData, groupBy]);

  const TH = ({ children, col, align = 'left', center = false }: { children: React.ReactNode; col: string; align?: string; center?: boolean }) => (
    <th className={`text-${center ? 'center' : align} py-3.5 px-4 text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100`} onClick={() => handleSort(col)}>
      <div className={`flex items-center ${center ? 'justify-center' : align === 'right' ? 'justify-end' : ''} gap-2 whitespace-nowrap`}>
        {children}
        <SortIcon col={col} />
      </div>
    </th>
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ─── Page Header ─────────────────────────────────────────────── */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event?.eventName}</h1>
                <h1 className="text-slate-600">- Claims</h1>
                {(() => {
                  const phase = getWorkflowStatus(eventId || '').currentPhase;
                  const phaseBadge: Record<string, string> = {
                    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
                    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
                    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
                    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'Reopened': 'bg-red-50 text-red-700 border-red-200',
                  };
                  const phaseLabels: Record<string, string> = {
                    'Estimation & Approval': 'UW Estimation',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${phaseBadge[phase] || 'bg-slate-100 text-slate-700 border-slate-200'}`}>
                      {phaseLabels[phase] || phase}
                    </span>
                  );
                })()}
                {(() => {
                  const status = getEventStatus(eventId || '');
                  const statusBadge: Record<string, string> = {
                    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
                    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
                    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
                    'Reopened': 'bg-red-50 text-red-700 border-red-300',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {status}
                    </span>
                  );
                })()}
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600 flex-wrap">
                <div className="flex items-center gap-2"><span className="text-slate-500">Event ID:</span><span style={{ color: '#0052FF' }}>{event?.id}</span></div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2"><span className="text-slate-500">Type of Everest Event:</span><span className="text-slate-900">{event?.everestEventType}</span></div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2"><span className="text-slate-500">Event Type:</span><span className="text-slate-900">{event?.eventType}</span></div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2"><span className="text-slate-500">Event Sub-Type:</span><span className="text-slate-900">{event?.eventSubType}</span></div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2"><span className="text-slate-500">Region:</span><span className="text-slate-900">{event?.region}</span></div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2"><span className="text-slate-500">Loss Date:</span><span className="text-slate-900">{event?.lossDate ? new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Body ────────────────────────────────────────────────────── */}
      <div className="px-10 py-8">
        {/* Title + View Toggle */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h2 className="text-slate-900">Claims Estimated vs Actual</h2>
              <span className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-medium rounded-full uppercase tracking-wider">Read Only</span>
              {activeFilterCount > 0 && (
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                  {activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''} active
                </span>
              )}
            </div>
            
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                const isGross = activeView === 'gross';
                const headers = isGross
                  ? ['Executive Area', 'BU', 'Contract #', 'Cedant', 'UWY', 'Reporting Level', 'IBNR Tag', 'Est. Loss', 'Total Incurred', 'Total Paid', 'CSR', 'Judgement/ACR', 'Cedant IBNR', 'Variance', 'Last Update']
                  : ['Executive Area', 'BU', 'Contract #', 'Cedant', 'UWY', 'Reporting Level', 'IBNR Tag', 'Est. Loss (NN)', 'Total Incurred (NN)', 'Variance (NN)', 'Last Update'];
                const rows = sortedData.map(r => isGross
                  ? [r.executiveArea, r.bu, r.contractNumber, r.cedant, r.uwyYear, r.reportingLevel, r.ibnrTag, r.estimatedLoss, r.totalIncurredClaims, r.totalPaid, r.csr, r.judgementACR, r.cedantIBNR, r.variance, r.lastFinancialUpdate]
                  : [r.executiveArea, r.bu, r.contractNumber, r.cedant, r.uwyYear, r.reportingLevel, r.ibnrTag, r.estimatedLossNetNet, r.totalIncurredNetNet, r.varianceNetNet, r.lastFinancialUpdate]
                );
                downloadCSV(headers, rows, `SONAR_Claims_${event?.eventName || eventId}_${isGross ? 'Gross' : 'NetNet'}`);
                toast.success('Claims table exported to CSV');
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" /> Export
            </button>
            <div className="flex items-center bg-slate-100 rounded-lg p-1 gap-0.5">
              <button onClick={() => setActiveView('gross')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeView === 'gross' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Gross</button>
              <button onClick={() => setActiveView('netnet')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${activeView === 'netnet' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Net-Net</button>
            </div>
          </div>
        </div>

        {/* Basis label + CAT Code */}
        <div className="mb-4 flex items-center gap-3 flex-wrap">
          
          <div className="relative" ref={catCodeRef}>
            
            {catCodeOpen && (
              <div className="absolute top-full left-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-50 w-96 flex flex-col max-h-72">
                <div className="p-2 border-b border-slate-100 flex items-center gap-2 px-3">
                  <Search className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <input ref={catCodeInputRef} type="text" placeholder="Search CAT codes..." value={catCodeSearch}
                    onChange={(e) => setCatCodeSearch(e.target.value)} onClick={(e) => e.stopPropagation()}
                    className="flex-1 text-xs py-1 focus:outline-none text-slate-700 placeholder-slate-400" />
                  {catCodeSearch && <button onClick={() => setCatCodeSearch('')} className="text-slate-400 hover:text-slate-600"><X className="w-3 h-3" /></button>}
                </div>
                <div className="px-3 py-1.5 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100 bg-slate-50">
                  CAT Code — Headline Loss Code <span className="normal-case">(Optional)</span>
                </div>
                <div className="overflow-y-auto flex-1">
                  {filteredCatCodes.length === 0 ? (
                    <div className="px-3 py-4 text-xs text-slate-400 text-center">No matching CAT codes</div>
                  ) : (
                    <>
                      {catCode && <div className="px-3 py-2 text-xs cursor-pointer text-slate-400 hover:bg-red-50 hover:text-red-600 border-b border-slate-100 flex items-center gap-2" onClick={() => handleCatCodeChange('')}><X className="w-3 h-3" /> Clear selection</div>}
                      {filteredCatCodes.map((cat) => (
                        <div key={cat.code} className={`px-3 py-2 text-xs cursor-pointer transition-colors ${cat.code === catCode ? 'bg-amber-50 text-amber-700 font-medium' : 'text-slate-700 hover:bg-slate-50'}`} onClick={() => handleCatCodeChange(cat.code)}>
                          <span className="font-medium">{cat.code}</span>
                          <span className="text-slate-500 ml-1">{cat.label.replace(cat.code, '').replace(' — ', '')}</span>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ─── KPI Cards ────────────────────────────────────────────── */}
        <div className={`grid gap-4 mb-8 ${activeView === 'gross' ? 'grid-cols-7' : 'grid-cols-4'}`}>
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center"><DollarSign className="w-5 h-5 text-blue-600" /></div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">Total Best Estimate</div>
            </div>
            <div className="text-xl text-slate-900">{fmt(curEstimated)}</div>
            <div className="text-[11px] text-slate-400 mt-1">{filteredData.length} contract{filteredData.length !== 1 ? 's' : ''}</div>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-lg bg-indigo-50 flex items-center justify-center"><DollarSign className="w-5 h-5 text-indigo-600" /></div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">Total Incurred Claims</div>
            </div>
            <div className="text-xl text-slate-900">{fmt(curIncurred)}</div>
          </div>
          
          {/* Additional KPI Cards (Gross View Only) - shown before Variance and % Paid */}
          {activeView === 'gross' && (
            <>
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center"><DollarSign className="w-5 h-5 text-purple-600" /></div>
                  <div className="text-xs text-slate-500 uppercase tracking-wider">Total Paid</div>
                </div>
                <div className="text-xl text-slate-900">{fmt(totals.gross.paid)}</div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-orange-50 flex items-center justify-center"><DollarSign className="w-5 h-5 text-orange-600" /></div>
                  <div className="text-xs text-slate-500 uppercase tracking-wider">Total CSR</div>
                </div>
                <div className="text-xl text-slate-900">{fmt(totals.gross.csr)}</div>
              </div>
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-teal-50 flex items-center justify-center"><DollarSign className="w-5 h-5 text-teal-600" /></div>
                  <div className="text-xs text-slate-500 uppercase tracking-wider">Total ACR</div>
                </div>
                <div className="text-xl text-slate-900">{fmt(totals.gross.acr)}</div>
              </div>
            </>
          )}

          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-2.5 mb-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${curVariance > 0 ? 'bg-red-50' : 'bg-emerald-50'}`}>
                {curVariance > 0 ? <TrendingUp className="w-5 h-5 text-red-600" /> : <TrendingDown className="w-5 h-5 text-emerald-600" />}
              </div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">Variance</div>
            </div>
            <div className={`text-xl ${curVariance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{curVariance > 0 ? '+' : ''}{fmt(curVariance)}</div>
            <div className={`text-[11px] mt-1 ${curVariance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{fmtPct(curVariancePct)} {curVariance > 0 ? 'over' : 'under'} estimate</div>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-lg bg-cyan-50 flex items-center justify-center"><Percent className="w-5 h-5 text-cyan-600" /></div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">% Paid</div>
            </div>
            <div className="text-xl text-slate-900">{curPctPaid.toFixed(1)}%</div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
              <div className="bg-cyan-500 h-1.5 rounded-full transition-all" style={{ width: `${Math.min(curPctPaid, 100)}%` }} />
            </div>
          </div>
        </div>

        {!activeView || activeView === 'netnet' ? <div className="mb-8" /> : null}

        {/* Active filters */}
        {activeFilterCount > 0 && (
          <div className="flex items-center gap-3 mb-4 px-1 flex-wrap">
            <span className="text-xs text-slate-500">Active filters:</span>
            {Object.entries(filters).filter(([, v]) => v).map(([k, v]) => (
              <span key={k} className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full border border-blue-200">
                {k === 'executiveArea' ? 'Exec Area' : k === 'bu' ? 'BU' : k === 'contractNumber' ? 'Contract' : k === 'cedant' ? 'Cedant' : k === 'uwyYear' ? 'UWY' : k === 'reportingLevel' ? 'Reporting Level' : 'IBNR Tag'}: {v}
                <button onClick={() => handleFilterChange(k, '')} className="ml-0.5 hover:text-blue-900">&times;</button>
              </span>
            ))}
            <button onClick={() => setFilters({ executiveArea: '', bu: '', contractNumber: '', cedant: '', uwyYear: '', reportingLevel: '', ibnrTag: '' })} className="text-xs text-red-600 hover:text-red-800 underline">Clear all</button>
          </div>
        )}

        {/* ─── Group by bar ─────────────────────────────────────────── */}
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Group by:</span>
            </div>
            {([ 
              { key: 'none', label: 'None' },
              { key: 'bu', label: 'Business Unit' },
            ] as const).map(opt => (
              <button key={opt.key} onClick={() => setGroupBy(opt.key)}
                className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${groupBy === opt.key ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300 hover:text-indigo-600'}`}>
                {opt.label}
              </button>
            ))}
          </div>
          <div className="text-xs text-slate-500">
            Last Refreshed: <span className="font-medium text-slate-700">{lastRefreshedDate}</span>
          </div>
        </div>

        {/* ─── GROSS TABLE ───────────────────────────────────────────── */}
        {activeView === 'gross' && (
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <TH col="executiveArea">Executive Area <FilterBtn col="executiveArea" label="Exec Area" type="select" options={uniqueExecAreas} /></TH>
                    <TH col="bu">Business Unit <FilterBtn col="bu" label="BU" type="select" options={uniqueBUs} /></TH>
                    <TH col="contractNumber">Contract # <FilterBtn col="contractNumber" label="Contract" type="text" /></TH>
                    <TH col="cedant">Cedant <FilterBtn col="cedant" label="Cedant" type="text" /></TH>
                    <TH col="uwyYear" center>UWY Year <FilterBtn col="uwyYear" label="Year" type="select" options={uniqueYears} /></TH>
                    <TH col="reportingLevel">Reporting Level <FilterBtn col="reportingLevel" label="Reporting Level" type="text" /></TH>
                    <TH col="ibnrTag">IBNR Tag <FilterBtn col="ibnrTag" label="IBNR Tag" type="text" /></TH>
                    <TH col="estimatedLoss" align="right">Best Estimate</TH>
                    <TH col="totalIncurredClaims" align="right">Total Incurred Claims</TH>
                    <TH col="totalPaid" align="right"><span className="text-center leading-tight">Total Paid<br /><span className="text-[10px] text-slate-500 normal-case tracking-normal">Indem + Exp - Recovery</span></span></TH>
                    <TH col="csr" align="right">CSR</TH>
                    <TH col="judgementACR" align="right">Judgement ACR</TH>
                    <TH col="cedantIBNR" align="right">Cedant IBNR</TH>
                    <TH col="variance" align="right">Variance</TH>
                    <TH col="lastFinancialUpdate">Last Financial Update</TH>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    let lastKey = '';
                    return sortedData.map((row, i) => {
                      const pct = row.estimatedLoss > 0 ? (row.variance / row.estimatedLoss) * 100 : 0;
                      const gk = groupBy !== 'none' ? getGroupKey(row) : '';
                      const isNew = groupBy !== 'none' && gk !== lastKey;
                      if (isNew) lastKey = gk;
                      return (
                        <Fragment key={row.contractNumber}>
                          {isNew && <GroupHeaderRow colSpan={15} groupKey={gk} count={groupCounts[gk] || 0} />}
                          <tr className={`border-b border-slate-100 hover:bg-slate-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.executiveArea}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.bu}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900">{row.contractNumber}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.cedant}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700 text-center">{row.uwyYear}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.reportingLevel}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.ibnrTag}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900 text-right">{fmt(row.estimatedLoss)}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900 text-right">{fmt(row.totalIncurredClaims)}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900 text-right">{fmt(row.totalPaid)}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700 text-right">{fmt(row.csr)}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700 text-right">{fmt(row.judgementACR)}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700 text-right">{fmt(row.cedantIBNR)}</td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <span className={`text-sm font-medium ${row.variance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{row.variance > 0 ? '+' : ''}{fmt(row.variance)}</span>
                                <span className={`text-[10px] ${row.variance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>({fmtPct(pct)})</span>
                              </div>
                            </td>
                            <td className="py-3.5 px-4 text-sm text-slate-600">{new Date(row.lastFinancialUpdate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                          </tr>
                        </Fragment>
                      );
                    });
                  })()}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 border-t-2 border-slate-300">
                    <td colSpan={7} className="py-3.5 px-4 text-sm font-semibold text-slate-900">Total ({filteredData.length} contracts)</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.estimated)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.incurred)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.paid)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.csr)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.acr)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.gross.ibnr)}</td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <span className={`text-sm font-semibold ${totals.gross.variance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{totals.gross.variance > 0 ? '+' : ''}{fmt(totals.gross.variance)}</span>
                        <span className={`text-[10px] ${totals.gross.variance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>({fmtPct(totals.gross.variancePct)})</span>
                      </div>
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}

        {/* ─── NET-NET TABLE ─────────────────────────────────────────── */}
        {activeView === 'netnet' && (
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <TH col="executiveArea">Executive Area <FilterBtn col="executiveArea" label="Exec Area" type="select" options={uniqueExecAreas} /></TH>
                    <TH col="bu">Business Unit <FilterBtn col="bu" label="BU" type="select" options={uniqueBUs} /></TH>
                    <TH col="contractNumber">Contract # <FilterBtn col="contractNumber" label="Contract" type="text" /></TH>
                    <TH col="cedant">Cedant <FilterBtn col="cedant" label="Cedant" type="text" /></TH>
                    <TH col="uwyYear" center>UWY Year <FilterBtn col="uwyYear" label="Year" type="select" options={uniqueYears} /></TH>
                    <TH col="reportingLevel">Reporting Level <FilterBtn col="reportingLevel" label="Reporting Level" type="text" /></TH>
                    <TH col="ibnrTag">IBNR Tag <FilterBtn col="ibnrTag" label="IBNR Tag" type="text" /></TH>
                    <TH col="totalIncurredNetNet" align="right"><span className="text-center leading-tight">Total Incurred Claims<br /><span className="text-[10px] text-slate-500 normal-case tracking-normal">Net - Net</span></span></TH>
                    <TH col="estimatedLossNetNet" align="right"><span className="text-center leading-tight">Best Estimate<br /><span className="text-[10px] text-slate-500 normal-case tracking-normal">Net - Net</span></span></TH>
                    <TH col="varianceNetNet" align="right">Variance</TH>
                    <TH col="lastFinancialUpdate">Last Financial Update</TH>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    let lastKey = '';
                    return sortedData.map((row, i) => {
                      const pct = row.estimatedLossNetNet > 0 ? (row.varianceNetNet / row.estimatedLossNetNet) * 100 : 0;
                      const gk = groupBy !== 'none' ? getGroupKey(row) : '';
                      const isNew = groupBy !== 'none' && gk !== lastKey;
                      if (isNew) lastKey = gk;
                      return (
                        <Fragment key={row.contractNumber}>
                          {isNew && <GroupHeaderRow colSpan={11} groupKey={gk} count={groupCounts[gk] || 0} />}
                          <tr className={`border-b border-slate-100 hover:bg-slate-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.executiveArea}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.bu}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900">{row.contractNumber}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.cedant}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700 text-center">{row.uwyYear}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.reportingLevel}</td>
                            <td className="py-3.5 px-4 text-sm text-slate-700">{row.ibnrTag}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900 text-right">{fmt(row.totalIncurredNetNet)}</td>
                            <td className="py-3.5 px-4 text-sm font-medium text-slate-900 text-right">{fmt(row.estimatedLossNetNet)}</td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <span className={`text-sm font-medium ${row.varianceNetNet > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{row.varianceNetNet > 0 ? '+' : ''}{fmt(row.varianceNetNet)}</span>
                                <span className={`text-[10px] ${row.varianceNetNet > 0 ? 'text-red-500' : 'text-emerald-500'}`}>({fmtPct(pct)})</span>
                              </div>
                            </td>
                            <td className="py-3.5 px-4 text-sm text-slate-600">{new Date(row.lastFinancialUpdate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                          </tr>
                        </Fragment>
                      );
                    });
                  })()}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 border-t-2 border-slate-300">
                    <td colSpan={7} className="py-3.5 px-4 text-sm font-semibold text-slate-900">Total ({filteredData.length} contracts)</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.netnet.incurred)}</td>
                    <td className="py-3.5 px-4 text-right text-sm font-semibold text-slate-900">{fmt(totals.netnet.estimated)}</td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <span className={`text-sm font-semibold ${totals.netnet.variance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{totals.netnet.variance > 0 ? '+' : ''}{fmt(totals.netnet.variance)}</span>
                        <span className={`text-[10px] ${totals.netnet.variance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>({fmtPct(totals.netnet.variancePct)})</span>
                      </div>
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}