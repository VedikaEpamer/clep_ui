import { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Lock } from 'lucide-react';

// ─── Impact Status values ─────────────────────────────────────────────────────
export type ImpactStatusValue =
  | 'Impacted'
  | 'Not Impacted'
  | 'Excluded'
  | 'Manual'
  | 'Not in RDM';

export type ImpactStatusEditability = 'editable' | 'locked';
export type ImpactStatusDensity = 'compact' | 'regular';

// ─── Style map per value ──────────────────────────────────────────────────────
const STATUS_STYLES: Record<ImpactStatusValue, { bg: string; text: string; dot: string; border: string; hoverBg: string }> = {
  'Impacted':      { bg: 'bg-green-50',  text: 'text-green-700',  dot: 'bg-green-500',  border: 'border-green-200',  hoverBg: 'hover:bg-green-100' },
  'Not Impacted':  { bg: 'bg-slate-50',  text: 'text-slate-600',  dot: 'bg-slate-400',  border: 'border-slate-200',  hoverBg: 'hover:bg-slate-100' },
  'Excluded':      { bg: 'bg-orange-50', text: 'text-orange-700', dot: 'bg-orange-500', border: 'border-orange-200', hoverBg: 'hover:bg-orange-100' },
  'Manual':        { bg: 'bg-blue-50',   text: 'text-blue-700',   dot: 'bg-blue-500',   border: 'border-blue-200',   hoverBg: 'hover:bg-blue-100' },
  'Not in RDM':    { bg: 'bg-red-50',    text: 'text-red-700',    dot: 'bg-red-500',    border: 'border-red-200',     hoverBg: 'hover:bg-red-100' },
};

const ALL_OPTIONS: ImpactStatusValue[] = [
  'Impacted',
  'Not Impacted',
  'Excluded',
  'Manual',
  'Not in RDM',
];

// ─── Business‑rule helpers ────────────────────────────────────────────────────
/**
 * Derive the impact status and editability from contract data.
 * The dropdown is ALWAYS editable — users can override at any time.
 *
 * Defaulting rules (initial + when estimate values change):
 *
 *   1. Any Low/Best/High > 0                → "Impacted"
 *      Applies even to contracts not in RDM or manually added.
 *
 *   2. User has explicitly set a status via
 *      the dropdown (impactStatus stored)   → respect that choice
 *      Only checked when no value is > 0 (rule 1 always wins).
 *
 *   3. Contract not in RDM (no positive values) → "Not in RDM"
 *
 *   4. Manually added to roster (no est.)   → "Manual"
 *
 *   5. All Low/Best/High = 0                → "Not Impacted"
 *
 *   6. All Low/Best/High blank              → "Excluded"
 *
 *   7. Fallback                             → "Not Impacted"
 */
export function deriveImpactStatus(contract: {
  validationStatus?: string;
  rosterStatus?: string;
  uwEstimateLow?: string | number;
  uwEstimateMed?: string | number;
  uwEstimateHigh?: string | number;
  impactStatus?: string;
}): { value: ImpactStatusValue; editability: ImpactStatusEditability } {
  // Helper to parse a currency-ish string to a number
  const parse = (v?: string | number): number => {
    if (v == null || v === '' || v === '-') return 0;
    if (v === '$0' || v === '0') return 0;
    const s = String(v).replace(/[$,€£]/g, '').trim();
    const n = parseFloat(s);
    if (isNaN(n)) return 0;
    if (String(v).includes('B')) return n * 1_000_000_000;
    if (String(v).includes('M')) return n * 1_000_000;
    if (String(v).includes('K')) return n * 1_000;
    return n;
  };

  // Helper to check if a value is truly blank (empty / undefined / just a dash)
  const isBlank = (v?: string | number): boolean =>
    v == null || v === '' || v === '-';

  const low = parse(contract.uwEstimateLow);
  const med = parse(contract.uwEstimateMed);
  const high = parse(contract.uwEstimateHigh);

  const anyPositive = low > 0 || med > 0 || high > 0;
  const allBlank = isBlank(contract.uwEstimateLow) && isBlank(contract.uwEstimateMed) && isBlank(contract.uwEstimateHigh);

  // Rule 1 – Any estimate value > 0 → Impacted (overrides everything, including Not in RDM)
  if (anyPositive) {
    return { value: 'Impacted', editability: 'editable' };
  }

  // Rule 2 – User has explicitly set a status via the dropdown → respect it
  //          (only when no value is positive, i.e. rule 1 didn't fire)
  const manual = contract.impactStatus as ImpactStatusValue | undefined;
  if (manual && ALL_OPTIONS.includes(manual)) {
    return { value: manual, editability: 'editable' };
  }

  // Rule 3 – Contract not in RDM (no positive values, no manual override)
  if (contract.validationStatus === 'not-in-rdm') {
    return { value: 'Not in RDM', editability: 'editable' };
  }

  // Rule 4 – Manually added to roster, no estimates yet → Manual
  if (contract.rosterStatus === 'Manual Added') {
    return { value: 'Manual', editability: 'editable' };
  }

  // Rule 5 – All values are explicitly zero (not blank) → Not Impacted
  if (!allBlank) {
    return { value: 'Not Impacted', editability: 'editable' };
  }

  // Rule 6 – All values are blank → Excluded
  if (allBlank) {
    return { value: 'Excluded', editability: 'editable' };
  }

  // Rule 7 – Fallback
  return { value: 'Not Impacted', editability: 'editable' };
}

// ─── Component Props ──────────────────────────────────────────────────────────
export interface ImpactStatusCellProps {
  /** Current value; undefined renders the placeholder state. */
  value?: ImpactStatusValue;
  /** Override editability. When omitted the component is editable. */
  editability?: ImpactStatusEditability;
  /** Row density – compact (default for table cells) or regular. */
  density?: ImpactStatusDensity;
  /** Whether the parent row / team is submitted (disables interaction). */
  disabled?: boolean;
  /** Called when the user selects a new value. */
  onChange?: (value: ImpactStatusValue) => void;
}

// ─── Component ────────────────────────────────────────────────────────────────
export function ImpactStatusCell({
  value,
  editability = 'editable',
  density = 'compact',
  disabled = false,
  onChange,
}: ImpactStatusCellProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number; width: number } | null>(null);

  const isLocked = editability === 'locked' || disabled;
  const style = value ? STATUS_STYLES[value] : null;

  // Compact vs regular sizing
  const py = density === 'compact' ? 'py-0.5' : 'py-1.5';
  const px = density === 'compact' ? 'px-1.5' : 'px-2.5';
  const textSize = density === 'compact' ? 'text-xs' : 'text-sm';
  const dotSize = density === 'compact' ? 'w-1.5 h-1.5' : 'w-2 h-2';
  const iconSize = density === 'compact' ? 14 : 16;

  // Position the dropdown menu using a portal
  const positionMenu = () => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const spaceBelow = window.innerHeight - rect.bottom;
    const menuHeight = 190; // approximate
    const top = spaceBelow > menuHeight ? rect.bottom + 2 : rect.top - menuHeight - 2;
    setMenuPos({ top, left: rect.left, width: Math.max(rect.width, 140) });
  };

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;
    const handleClick = (e: MouseEvent) => {
      if (
        menuRef.current && !menuRef.current.contains(e.target as Node) &&
        triggerRef.current && !triggerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  // ── Locked state ──────────────────────────────────────────────────────────
  if (isLocked && value) {
    return (
      <div
        className={`inline-flex items-center gap-1.5 ${px} ${py} ${textSize} rounded ${style!.bg} ${style!.text} font-semibold select-none max-w-full`}
        title={`${value} (locked)`}
      >
        <span className={`shrink-0 rounded-full ${dotSize} ${style!.dot}`} />
        <span className="truncate">{value}</span>
        <Lock size={density === 'compact' ? 10 : 12} className="shrink-0 opacity-50" />
      </div>
    );
  }

  // ── Editable trigger ──────────────────────────────────────────────────────
  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => {
          if (isLocked) return;
          positionMenu();
          setIsOpen(prev => !prev);
        }}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        disabled={isLocked}
        className={[
          'inline-flex items-center gap-1.5 rounded border transition-colors w-full max-w-full',
          px, py, textSize, 'font-semibold',
          isLocked
            ? 'cursor-not-allowed opacity-50 bg-slate-100 border-slate-200 text-slate-400'
            : value
              ? `${style!.bg} ${style!.border} ${style!.text} ${style!.hoverBg} cursor-pointer`
              : 'bg-white border-slate-300 text-slate-400 hover:border-slate-400 cursor-pointer',
          isFocused && !isLocked ? 'ring-1 ring-blue-500 border-blue-500' : '',
          isOpen ? 'ring-1 ring-blue-500 border-blue-500' : '',
        ].join(' ')}
      >
        {value ? (
          <>
            <span className={`shrink-0 rounded-full ${dotSize} ${style!.dot}`} />
            <span className="truncate flex-1 text-left">{value}</span>
          </>
        ) : (
          <span className="truncate flex-1 text-left">Select...</span>
        )}
        <ChevronDown
          size={iconSize}
          className={`shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {/* ── Dropdown overlay (portal) ────────────────────────────────────── */}
      {isOpen && menuPos && createPortal(
        <div
          ref={menuRef}
          className="fixed z-[200] bg-white rounded-lg border border-slate-200 shadow-lg py-1 overflow-hidden"
          style={{ top: menuPos.top, left: menuPos.left, width: menuPos.width, minWidth: 140 }}
        >
          {ALL_OPTIONS.map((opt) => {
            const s = STATUS_STYLES[opt];
            const isSelected = opt === value;
            return (
              <button
                key={opt}
                type="button"
                onClick={() => {
                  onChange?.(opt);
                  setIsOpen(false);
                }}
                className={[
                  'flex items-center gap-2 w-full px-3 py-1.5 text-xs font-medium transition-colors text-left',
                  isSelected
                    ? `${s.bg} ${s.text}`
                    : `text-slate-700 hover:bg-slate-50`,
                ].join(' ')}
              >
                <span className={`shrink-0 rounded-full w-2 h-2 ${s.dot}`} />
                <span className="flex-1">{opt}</span>
                {isSelected && (
                  <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.75.75 0 0 1 1.06-1.06L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z" />
                  </svg>
                )}
              </button>
            );
          })}

          {/* ── Business rules footnote ─────────────────────────────────── */}
          <div className="border-t border-slate-100 mt-1 px-3 py-2">
            <p className="text-[10px] text-slate-400 leading-tight">
              Auto-defaults: Any Low/Best/High &gt; 0 = Impacted · All zero = Not Impacted · All blank = Excluded · Always editable via dropdown
            </p>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}