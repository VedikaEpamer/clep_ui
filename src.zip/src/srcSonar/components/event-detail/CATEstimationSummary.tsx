import { useState } from 'react';
import { ChevronDown, ChevronRight, AlertCircle, Paperclip, Info, X, MessageSquarePlus, DollarSign, FileText, Users, CheckCircle2, Save, Lock, Unlock, Download, MessageSquare } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

// Constants used for cascading deductions (hoisted for use in initial state)
const LOGAN_RETENTION = 0.85;
const EXTERNAL_RECOV_RATE = 0.92;

// Pure helper — derive all 5 column groups from 4 base values
function deriveRowDataStatic(grossLow: number, grossHigh: number, reinstLow: number, reinstHigh: number) {
  const netLoganLow = grossLow * LOGAN_RETENTION;
  const netLoganHigh = grossHigh * LOGAN_RETENTION;
  const netLoganExtLow = netLoganLow * EXTERNAL_RECOV_RATE;
  const netLoganExtHigh = netLoganHigh * EXTERNAL_RECOV_RATE;
  const netLossLow = netLoganExtLow - reinstLow;
  const netLossHigh = netLoganExtHigh - reinstHigh;
  return {
    gross: { low: grossLow, med: (grossLow + grossHigh) / 2, high: grossHigh },
    netLogan: { low: netLoganLow, med: (netLoganLow + netLoganHigh) / 2, high: netLoganHigh },
    netLoganExt: { low: netLoganExtLow, med: (netLoganExtLow + netLoganExtHigh) / 2, high: netLoganExtHigh },
    reinst: { low: reinstLow, med: (reinstLow + reinstHigh) / 2, high: reinstHigh },
    netLoss: { low: netLossLow, med: (netLossLow + netLossHigh) / 2, high: netLossHigh },
  };
}

interface CATEstimationSummaryProps {
  event: any;
  onSaveDraft?: () => void;
  onLockEstimates?: () => void;
  isLocked?: boolean;
  onDownload?: () => void;
  onAddComment?: () => void;
}

interface EstimationRow {
  method: string;
  lossLow: number;
  lossBest: number;
  lossHigh: number;
  reinstatementLow: number;
  reinstatementBest: number;
  reinstatementHigh: number;
  isSubtotal?: boolean;
  isEditable?: boolean;
  indent?: number;
}

export function CATEstimationSummary({ 
  event, 
  onSaveDraft, 
  onLockEstimates, 
  isLocked = false,
  onDownload,
  onAddComment
}: CATEstimationSummaryProps) {
  // Summary data — pre-populate from event creation form, fallback to defaults
  const eventGrossLow = event?.consensusGrossLow ?? event?.industryEstimateLow ?? 8000;
  const eventGrossHigh = event?.consensusGrossHigh ?? event?.industryEstimateHigh ?? 10000;
  const eventReinstLow = event?.consensusReinstLow ?? event?.industryReinstatementLow ?? 0;
  const eventReinstHigh = event?.consensusReinstHigh ?? event?.industryReinstatementHigh ?? 0;

  // Derive initial 15-cell values from the 4 base inputs using cascading deductions
  const initDerived = deriveRowDataStatic(eventGrossLow, eventGrossHigh, eventReinstLow, eventReinstHigh);

  const [consensus, setConsensus] = useState({
    grossLow: initDerived.gross.low,
    grossBest: initDerived.gross.med,
    grossHigh: initDerived.gross.high,
    netLoganLow: initDerived.netLogan.low,
    netLoganBest: initDerived.netLogan.med,
    netLoganHigh: initDerived.netLogan.high,
    netLoganExtLow: initDerived.netLoganExt.low,
    netLoganExtBest: initDerived.netLoganExt.med,
    netLoganExtHigh: initDerived.netLoganExt.high,
    reinstLow: initDerived.reinst.low,
    reinstBest: initDerived.reinst.med,
    reinstHigh: initDerived.reinst.high,
    netLossLow: initDerived.netLoss.low,
    netLossBest: initDerived.netLoss.med,
    netLossHigh: initDerived.netLoss.high,
  });

  const [editingConsensusCell, setEditingConsensusCell] = useState<string | null>(null);
  const [editingConsensusValue, setEditingConsensusValue] = useState('');

  // Everest Market Share % — independent per-column percentages (Low/Best/High), start empty
  const [marketSharePcts, setMarketSharePcts] = useState<{ low: string; best: string; high: string }>({ low: '', best: '', high: '' });
  const getMarketShareNum = (key: 'low' | 'best' | 'high') => { const n = parseFloat(marketSharePcts[key]); return isNaN(n) ? 0 : n; };

  // Keep summaryData in sync for RE Market Share calculation
  const [summaryData, setSummaryData] = useState({
    industryLossLow: eventGrossLow,
    industryLossHigh: eventGrossHigh,
    industryReinstatementLow: eventReinstLow,
    industryReinstatementHigh: eventReinstHigh,
    marketSharePercent: 3.2,
  });

  // RE Market Share is calculated: Total Modeling / Industry Estimate
  const calcReMarketShare = () => {
    const industryData = deriveRowData(summaryData.industryLossLow, summaryData.industryLossHigh, summaryData.industryReinstatementLow, summaryData.industryReinstatementHigh);
    const modelingData = calcTotalModeling();
    const modelingDerived = deriveRowData(modelingData.lossLow, modelingData.lossHigh, modelingData.reinstLow, modelingData.reinstHigh);

    const pct = (num: number, den: number) => den !== 0 ? (num / den) * 100 : 0;

    return {
      gross: {
        low: pct(modelingDerived.gross.low, industryData.gross.low),
        med: pct(modelingDerived.gross.med, industryData.gross.med),
        high: pct(modelingDerived.gross.high, industryData.gross.high),
      },
      netLogan: {
        low: pct(modelingDerived.netLogan.low, industryData.netLogan.low),
        med: pct(modelingDerived.netLogan.med, industryData.netLogan.med),
        high: pct(modelingDerived.netLogan.high, industryData.netLogan.high),
      },
      netLoganExt: {
        low: pct(modelingDerived.netLoganExt.low, industryData.netLoganExt.low),
        med: pct(modelingDerived.netLoganExt.med, industryData.netLoganExt.med),
        high: pct(modelingDerived.netLoganExt.high, industryData.netLoganExt.high),
      },
      reinst: {
        low: pct(modelingDerived.reinst.low, industryData.reinst.low),
        med: pct(modelingDerived.reinst.med, industryData.reinst.med),
        high: pct(modelingDerived.reinst.high, industryData.reinst.high),
      },
      netLoss: {
        low: pct(modelingDerived.netLoss.low, industryData.netLoss.low),
        med: pct(modelingDerived.netLoss.med, industryData.netLoss.med),
        high: pct(modelingDerived.netLoss.high, industryData.netLoss.high),
      },
    };
  };

  // Header weights for each method (portfolio weights)
  const [methodWeights] = useState({
    marketShareLow: 6.1,
    marketShareHigh: 3.2,
    airModelLow: 6.1,
    airModelHigh: 3.2,
    uwGroundUpLow: 6.1,
    uwGroundUpHigh: 3.2,
  });

  // Methods data
  const calcMarketShareLoss = () => {
    const ms = calcReMarketShare();
    return {
      lossLow: summaryData.industryLossLow * (ms.gross.low / 100),
      lossHigh: summaryData.industryLossHigh * (ms.gross.high / 100),
    };
  };

  const [marketShare, setMarketShare] = useState({
    reinstatementLow: 0,
    reinstatementHigh: 0,
  });

  const [modelingEstimates, setModelingEstimates] = useState({
    // Facultative (International)
    latinAmericaFac: { lossLow: 42, lossHigh: 68, reinstatementLow: 1.5, reinstatementHigh: 2.5 },
    londonFac: { lossLow: 5, lossHigh: 8, reinstatementLow: 0.3, reinstatementHigh: 0.5 },
    singaporeFac: { lossLow: 0.8, lossHigh: 1.5, reinstatementLow: 0, reinstatementHigh: 0 },
    // International Treaty
    dublinZurich: { lossLow: 3.5, lossHigh: 5.5, reinstatementLow: 0.4, reinstatementHigh: 0.6 },
    latamBrazilTreaty: { lossLow: 120, lossHigh: 175, reinstatementLow: 4.5, reinstatementHigh: 6.5 },
    londonTreaty: { lossLow: 9, lossHigh: 10, reinstatementLow: 1.2, reinstatementHigh: 1.2 },
    meAfrica: { lossLow: 0.5, lossHigh: 1.5, reinstatementLow: 0, reinstatementHigh: 0 },
    singaporeTreaty: { lossLow: 1.2, lossHigh: 2, reinstatementLow: 0.1, reinstatementHigh: 0.1 },
    // Facultative (North America)
    bermudaFac: { lossLow: 3, lossHigh: 5, reinstatementLow: 0.2, reinstatementHigh: 0.3 },
    canadaFac: { lossLow: 0.5, lossHigh: 1, reinstatementLow: 0, reinstatementHigh: 0 },
    facCasualty: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    facProperty: { lossLow: 2, lossHigh: 3.5, reinstatementLow: 0.1, reinstatementHigh: 0.2 },
    // North America Treaty
    bermudaTreaty: { lossLow: 5, lossHigh: 8, reinstatementLow: 0.3, reinstatementHigh: 0.5 },
    canadaTreaty: { lossLow: 0.5, lossHigh: 1, reinstatementLow: 0, reinstatementHigh: 0 },
    treatyCasualty: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    treatyProperty: { lossLow: 15, lossHigh: 20, reinstatementLow: 2.5, reinstatementHigh: 2.5 },
    // Product
    aviation: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    parametric: { lossLow: 1.5, lossHigh: 3, reinstatementLow: 0, reinstatementHigh: 0 },
    marine: { lossLow: 2.5, lossHigh: 4.5, reinstatementLow: 0.2, reinstatementHigh: 0.3 },
    // Financial Lines
    financial: { lossLow: 0.8, lossHigh: 1.2, reinstatementLow: 0, reinstatementHigh: 0 },
    mortgage: { lossLow: 0.3, lossHigh: 0.5, reinstatementLow: 0, reinstatementHigh: 0 },
    // Insurance
    insuranceDiv: { lossLow: 1.0, lossHigh: 1.8, reinstatementLow: 0.1, reinstatementHigh: 0.2 },
    lloyds: { lossLow: 2.0, lossHigh: 3.5, reinstatementLow: 0.2, reinstatementHigh: 0.3 },
  });

  const [uwEstimates, setUwEstimates] = useState({
    // Facultative (International)
    latinAmericaFac: { lossLow: 50, lossHigh: 78, reinstatementLow: 0, reinstatementHigh: 0 },
    londonFac: { lossLow: 6, lossHigh: 9, reinstatementLow: 0, reinstatementHigh: 0 },
    singaporeFac: { lossLow: 1, lossHigh: 2, reinstatementLow: 0, reinstatementHigh: 0 },
    // International Treaty
    dublinZurich: { lossLow: 4, lossHigh: 6, reinstatementLow: 0, reinstatementHigh: 0 },
    latamBrazilTreaty: { lossLow: 145, lossHigh: 210, reinstatementLow: 0, reinstatementHigh: 0 },
    londonTreaty: { lossLow: 11.25, lossHigh: 11.85, reinstatementLow: 0, reinstatementHigh: 0 },
    meAfrica: { lossLow: 1, lossHigh: 3, reinstatementLow: 0, reinstatementHigh: 0 },
    singaporeTreaty: { lossLow: 1.5, lossHigh: 2.5, reinstatementLow: 0, reinstatementHigh: 0 },
    // Facultative (North America)
    bermudaFac: { lossLow: 3.5, lossHigh: 5.5, reinstatementLow: 0, reinstatementHigh: 0 },
    canadaFac: { lossLow: 0.5, lossHigh: 1.2, reinstatementLow: 0, reinstatementHigh: 0 },
    facCasualty: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    facProperty: { lossLow: 2.2, lossHigh: 4, reinstatementLow: 0, reinstatementHigh: 0 },
    // North America Treaty
    bermudaTreaty: { lossLow: 6.2, lossHigh: 10.2, reinstatementLow: 0, reinstatementHigh: 0 },
    canadaTreaty: { lossLow: 0.5, lossHigh: 1, reinstatementLow: 0, reinstatementHigh: 0 },
    treatyCasualty: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    treatyProperty: { lossLow: 18, lossHigh: 24.3, reinstatementLow: 0, reinstatementHigh: 0 },
    // Product
    aviation: { lossLow: 0, lossHigh: 0, reinstatementLow: 0, reinstatementHigh: 0 },
    parametric: { lossLow: 2, lossHigh: 3.5, reinstatementLow: 0, reinstatementHigh: 0 },
    marine: { lossLow: 3, lossHigh: 5, reinstatementLow: 0, reinstatementHigh: 0 },
    // Financial Lines
    financial: { lossLow: 1.0, lossHigh: 1.5, reinstatementLow: 0, reinstatementHigh: 0 },
    mortgage: { lossLow: 0.4, lossHigh: 0.6, reinstatementLow: 0, reinstatementHigh: 0 },
    // Insurance
    insuranceDiv: { lossLow: 1.2, lossHigh: 2.0, reinstatementLow: 0, reinstatementHigh: 0 },
    lloyds: { lossLow: 2.5, lossHigh: 4.0, reinstatementLow: 0, reinstatementHigh: 0 },
  });

  // Standalone "Other" section — negative adjustments (Gross & Net of Logan = 0)
  const [otherEstimates] = useState({
    afCessionsRecovery: { lossLow: -4.0, lossHigh: -6.0, reinstatementLow: -0.5, reinstatementHigh: -0.7 },
    catBondRecovery: { lossLow: -2.2, lossHigh: -3.0, reinstatementLow: -0.3, reinstatementHigh: -0.4 },
    eiRecovery: { lossLow: -2.5, lossHigh: -3.5, reinstatementLow: -0.2, reinstatementHigh: -0.3 },
  });

  // Everest Estimated values (editable numeric values)
  const [everestEstimated, setEverestEstimated] = useState({
    grossLow: 0, grossBest: 0, grossHigh: 0,
    netLoganLow: 0, netLoganBest: 0, netLoganHigh: 0,
    netLoganExtLow: 0, netLoganExtBest: 0, netLoganExtHigh: 0,
    reinstLow: 0, reinstBest: 0, reinstHigh: 0,
    netLossLow: 0, netLossBest: 0, netLossHigh: 0,
  });

  const [editingEverestEstimatedCell, setEditingEverestEstimatedCell] = useState<string | null>(null);
  const [editingEverestEstimatedValue, setEditingEverestEstimatedValue] = useState('');

  const [notes, setNotes] = useState({
    marketShare: 'Based on Dream Re\'s historical market share in Chilean property/earthquake reinsurance (3.2%). Applied to industry loss estimates of $10-12B.',
    air: 'AIR Touchstone model run completed 3 days post-event. 100% exposure reflects full portfolio; 60% reflects preliminary validation discount based on initial claims activity being lower than modeled.',
    underwriters: 'Ground-up estimates from regional underwriting teams based on treaty exposure cards, known policy limits, and direct cedent contact. International Dept subtotal reflects Latin America, South Africa, and Intl FAC offices. Total UW estimate aggregates all regional inputs.',
  });

  // Comments and files for each method
  const [methodComments, setMethodComments] = useState<{
    marketShare: Array<{ text: string; author: string; date: string; files?: string[] }>;
    air: Array<{ text: string; author: string; date: string; files?: string[] }>;
    underwriters: Array<{ text: string; author: string; date: string; files?: string[] }>;
  }>({
    marketShare: [
      {
        text: 'Market share at lower loss ranges (sub $5B industry) is closer to 6%, while at higher loss ranges ($10B+) it trends toward 3.2% due to limit participation and attachment points. LATAM department confirms this based on historical treaty structures.',
        author: 'Business Unit - LATAM',
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toLocaleString(),
      }
    ],
    air: [
      {
        text: 'AIR provided 5 event sets that were considered closely correlated to the Chile EQ loss. Several issues with the AIR data resulted in actuarial modeling reducing the AIR estimates by 60%. AIR uses average construction codes for Chile in Cat Trader but per underwriting premium was based on higher construction codes. When running Cat Trader vs Classic, this has historically shown a 60% overstatement factor in Cat Trader.',
        author: 'Cat Modeler',
        date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toLocaleString(),
      }
    ],
    underwriters: [],
  });

  const [newComment, setNewComment] = useState({
    marketShare: '',
    air: '',
    underwriters: '',
  });

  const [attachedFiles, setAttachedFiles] = useState<{
    marketShare: string[];
    air: string[];
    underwriters: string[];
  }>({
    marketShare: [],
    air: [],
    underwriters: [],
  });

  // Collapse states
  const [expandedSections, setExpandedSections] = useState({
    marketShare: false,
    air: false,
    uwGroundUp: false,
    modeling: false,
    // UW 6 departments
    uwIntlFac: false,
    uwIntlTreaty: false,
    uwNaFac: false,
    uwNaTreaty: false,
    uwSpecialty: false,
    uwFinancialLines: false,
    uwInsurance: false,
    uwOther: false,
    // Modeling 7 departments (including Other)
    modelingIntlFac: false,
    modelingIntlTreaty: false,
    modelingNaFac: false,
    modelingNaTreaty: false,
    modelingSpecialty: false,
    modelingFinancialLines: false,
    modelingInsurance: false,
    modelingRecoveries: false,
  });

  // Calculate totals
  const calcNetPreTax = (lossLow: number, lossHigh: number, reinstLow: number, reinstHigh: number) => {
    return {
      netLow: lossLow - reinstLow,
      netHigh: lossHigh - reinstHigh,
    };
  };

  // Helper to sum a group of estimate keys
  const sumEstimates = (src: typeof uwEstimates, keys: (keyof typeof uwEstimates)[]) =>
    keys.reduce((a, k) => ({ lossLow: a.lossLow + src[k].lossLow, lossHigh: a.lossHigh + src[k].lossHigh, reinstLow: a.reinstLow + src[k].reinstatementLow, reinstHigh: a.reinstHigh + src[k].reinstatementHigh }), { lossLow: 0, lossHigh: 0, reinstLow: 0, reinstHigh: 0 });

  const INTL_FAC_KEYS: (keyof typeof uwEstimates)[] = ['latinAmericaFac', 'londonFac', 'singaporeFac'];
  const INTL_TREATY_KEYS: (keyof typeof uwEstimates)[] = ['dublinZurich', 'latamBrazilTreaty', 'londonTreaty', 'meAfrica', 'singaporeTreaty'];
  const NA_FAC_KEYS: (keyof typeof uwEstimates)[] = ['bermudaFac', 'canadaFac', 'facCasualty', 'facProperty'];
  const NA_TREATY_KEYS: (keyof typeof uwEstimates)[] = ['bermudaTreaty', 'canadaTreaty', 'treatyCasualty', 'treatyProperty'];
  const SPECIALTY_KEYS: (keyof typeof uwEstimates)[] = ['aviation', 'parametric', 'marine'];
  const FINANCIAL_LINES_KEYS: (keyof typeof uwEstimates)[] = ['financial', 'mortgage'];
  const INSURANCE_KEYS: (keyof typeof uwEstimates)[] = ['insuranceDiv', 'lloyds'];

  // BU label map for display
  const BU_LABELS: Record<string, string> = {
    bermudaTreaty: 'Bermuda Treaty', londonTreaty: 'London Treaty', singaporeTreaty: 'Singapore Treaty',
    meAfrica: 'ME / Africa', lloyds: "Lloyd's", latamBrazilTreaty: 'Latin America / Brazil Treaty',
    treatyProperty: 'Treaty Property', facProperty: 'FAC Property', dublinZurich: 'Dublin / Zurich',
    canadaTreaty: 'Canada Treaty', insuranceDiv: 'Insurance', marine: 'Marine', parametric: 'Parametric',
    latinAmericaFac: 'Latin America Fac', londonFac: 'London Fac', singaporeFac: 'Singapore Fac',
    bermudaFac: 'Bermuda Fac', canadaFac: 'Canada Fac', facCasualty: 'FAC Casualty',
    treatyCasualty: 'Treaty Casualty', financial: 'Financial', mortgage: 'Mortgage', aviation: 'Aviation',
  };

  // UW 7-department subtotals
  const calcUwIntlFac = () => sumEstimates(uwEstimates, INTL_FAC_KEYS);
  const calcUwIntlTreaty = () => sumEstimates(uwEstimates, INTL_TREATY_KEYS);
  const calcUwNaFac = () => sumEstimates(uwEstimates, NA_FAC_KEYS);
  const calcUwNaTreaty = () => sumEstimates(uwEstimates, NA_TREATY_KEYS);
  const calcUwSpecialty = () => sumEstimates(uwEstimates, SPECIALTY_KEYS);
  const calcUwFinancialLines = () => sumEstimates(uwEstimates, FINANCIAL_LINES_KEYS);
  const calcUwInsurance = () => sumEstimates(uwEstimates, INSURANCE_KEYS);

  const calcTotalUW = () => {
    const a = calcUwIntlFac(), b = calcUwIntlTreaty(), c = calcUwNaFac(), d = calcUwNaTreaty(), e = calcUwSpecialty(), f = calcUwFinancialLines(), g = calcUwInsurance();
    return { lossLow: a.lossLow + b.lossLow + c.lossLow + d.lossLow + e.lossLow + f.lossLow + g.lossLow, lossHigh: a.lossHigh + b.lossHigh + c.lossHigh + d.lossHigh + e.lossHigh + f.lossHigh + g.lossHigh, reinstLow: a.reinstLow + b.reinstLow + c.reinstLow + d.reinstLow + e.reinstLow + f.reinstLow + g.reinstLow, reinstHigh: a.reinstHigh + b.reinstHigh + c.reinstHigh + d.reinstHigh + e.reinstHigh + f.reinstHigh + g.reinstHigh };
  };

  // Modeling 7-department subtotals
  const calcModelingIntlFac = () => sumEstimates(modelingEstimates, INTL_FAC_KEYS);
  const calcModelingIntlTreaty = () => sumEstimates(modelingEstimates, INTL_TREATY_KEYS);
  const calcModelingNaFac = () => sumEstimates(modelingEstimates, NA_FAC_KEYS);
  const calcModelingNaTreaty = () => sumEstimates(modelingEstimates, NA_TREATY_KEYS);
  const calcModelingSpecialty = () => sumEstimates(modelingEstimates, SPECIALTY_KEYS);
  const calcModelingFinancialLines = () => sumEstimates(modelingEstimates, FINANCIAL_LINES_KEYS);
  const calcModelingInsurance = () => sumEstimates(modelingEstimates, INSURANCE_KEYS);

  // Sub-group definitions for Modeling and UW sections (after calc functions to avoid TDZ)
  const MODELING_GROUPS = [
    { name: 'International Treaty', keys: INTL_TREATY_KEYS, toggleKey: 'modelingIntlTreaty' as const, calc: calcModelingIntlTreaty, color: 'purple' },
    { name: 'NA Treaty', keys: NA_TREATY_KEYS, toggleKey: 'modelingNaTreaty' as const, calc: calcModelingNaTreaty, color: 'purple' },
    { name: 'International Fac', keys: INTL_FAC_KEYS, toggleKey: 'modelingIntlFac' as const, calc: calcModelingIntlFac, color: 'purple' },
    { name: 'NA Fac', keys: NA_FAC_KEYS, toggleKey: 'modelingNaFac' as const, calc: calcModelingNaFac, color: 'purple' },
    { name: 'Specialty', keys: SPECIALTY_KEYS, toggleKey: 'modelingSpecialty' as const, calc: calcModelingSpecialty, color: 'purple' },
    { name: 'Financial Lines', keys: FINANCIAL_LINES_KEYS, toggleKey: 'modelingFinancialLines' as const, calc: calcModelingFinancialLines, color: 'purple' },
    { name: 'Insurance', keys: INSURANCE_KEYS, toggleKey: 'modelingInsurance' as const, calc: calcModelingInsurance, color: 'purple' },
  ];

  const UW_GROUPS = [
    { name: 'International Treaty', keys: INTL_TREATY_KEYS, toggleKey: 'uwIntlTreaty' as const, calc: calcUwIntlTreaty, color: 'emerald' },
    { name: 'NA Treaty', keys: NA_TREATY_KEYS, toggleKey: 'uwNaTreaty' as const, calc: calcUwNaTreaty, color: 'emerald' },
    { name: 'International Fac', keys: INTL_FAC_KEYS, toggleKey: 'uwIntlFac' as const, calc: calcUwIntlFac, color: 'emerald' },
    { name: 'NA Fac', keys: NA_FAC_KEYS, toggleKey: 'uwNaFac' as const, calc: calcUwNaFac, color: 'emerald' },
    { name: 'Specialty', keys: SPECIALTY_KEYS, toggleKey: 'uwSpecialty' as const, calc: calcUwSpecialty, color: 'emerald' },
    { name: 'Financial Lines', keys: FINANCIAL_LINES_KEYS, toggleKey: 'uwFinancialLines' as const, calc: calcUwFinancialLines, color: 'emerald' },
    { name: 'Insurance', keys: INSURANCE_KEYS, toggleKey: 'uwInsurance' as const, calc: calcUwInsurance, color: 'emerald' },
  ];

  // Recovery items total (AF Cessions, Cat Bond, EI Recovery — negative adjustments, now part of Modeling)
  const calcOtherTotal = () => {
    const keys = ['afCessionsRecovery', 'catBondRecovery', 'eiRecovery'] as const;
    return keys.reduce((a, k) => ({
      lossLow: a.lossLow + otherEstimates[k].lossLow,
      lossHigh: a.lossHigh + otherEstimates[k].lossHigh,
      reinstLow: a.reinstLow + otherEstimates[k].reinstatementLow,
      reinstHigh: a.reinstHigh + otherEstimates[k].reinstatementHigh,
    }), { lossLow: 0, lossHigh: 0, reinstLow: 0, reinstHigh: 0 });
  };

  const calcTotalModeling = () => {
    const a = calcModelingIntlFac(), b = calcModelingIntlTreaty(), c = calcModelingNaFac(), d = calcModelingNaTreaty(), e = calcModelingSpecialty(), f = calcModelingFinancialLines(), g = calcModelingInsurance();
    const h = calcOtherTotal(); // Recoveries included in Modeling total
    return { lossLow: a.lossLow + b.lossLow + c.lossLow + d.lossLow + e.lossLow + f.lossLow + g.lossLow + h.lossLow, lossHigh: a.lossHigh + b.lossHigh + c.lossHigh + d.lossHigh + e.lossHigh + f.lossHigh + g.lossHigh + h.lossHigh, reinstLow: a.reinstLow + b.reinstLow + c.reinstLow + d.reinstLow + e.reinstLow + f.reinstLow + g.reinstLow + h.reinstLow, reinstHigh: a.reinstHigh + b.reinstHigh + c.reinstHigh + d.reinstHigh + e.reinstHigh + f.reinstHigh + g.reinstHigh + h.reinstHigh };
  };

  const calcAverageLowHigh = () => {
    // Method 1: Everest Market Share (Consensus Gross × independent per-column %)
    const msVals = {
      lossLow: consensus.grossLow * (getMarketShareNum('low') / 100),
      lossBest: consensus.grossBest * (getMarketShareNum('best') / 100),
      lossHigh: consensus.grossHigh * (getMarketShareNum('high') / 100),
    };

    // Method 2: Modeling (office-level totals)
    const totalModeling = calcTotalModeling();
    const modelingBest = (totalModeling.lossLow + totalModeling.lossHigh) / 2;
    const modelVals = {
      lossLow: totalModeling.lossLow,
      lossBest: modelingBest,
      lossHigh: totalModeling.lossHigh,
    };

    // Method 3: UW Ground Up Estimates (Gross only)
    const totalUW = calcTotalUW();
    const uwVals = {
      lossLow: totalUW.lossLow,
      lossBest: (totalUW.lossLow + totalUW.lossHigh) / 2,
      lossHigh: totalUW.lossHigh,
    };

    // Header-weighted calculation (only Gross Loss — Net/Reinst not available for UW & MS)
    // Only include methods with non-zero values in the weighted average
    
    // Low column uses Low weights
    let weightedLossLow = 0;
    let totalWeightLow = 0;
    if (msVals.lossLow > 0) {
      weightedLossLow += msVals.lossLow * methodWeights.marketShareLow;
      totalWeightLow += methodWeights.marketShareLow;
    }
    if (modelVals.lossLow > 0) {
      weightedLossLow += modelVals.lossLow * methodWeights.airModelLow;
      totalWeightLow += methodWeights.airModelLow;
    }
    if (uwVals.lossLow > 0) {
      weightedLossLow += uwVals.lossLow * methodWeights.uwGroundUpLow;
      totalWeightLow += methodWeights.uwGroundUpLow;
    }

    // Best column uses average of Low/High weights
    const msBestW = (methodWeights.marketShareLow + methodWeights.marketShareHigh) / 2;
    const modelBestW = (methodWeights.airModelLow + methodWeights.airModelHigh) / 2;
    const uwBestW = (methodWeights.uwGroundUpLow + methodWeights.uwGroundUpHigh) / 2;
    let weightedLossBest = 0;
    let totalWeightBest = 0;
    if (msVals.lossBest > 0) {
      weightedLossBest += msVals.lossBest * msBestW;
      totalWeightBest += msBestW;
    }
    if (modelVals.lossBest > 0) {
      weightedLossBest += modelVals.lossBest * modelBestW;
      totalWeightBest += modelBestW;
    }
    if (uwVals.lossBest > 0) {
      weightedLossBest += uwVals.lossBest * uwBestW;
      totalWeightBest += uwBestW;
    }

    // High column uses High weights
    let weightedLossHigh = 0;
    let totalWeightHigh = 0;
    if (msVals.lossHigh > 0) {
      weightedLossHigh += msVals.lossHigh * methodWeights.marketShareHigh;
      totalWeightHigh += methodWeights.marketShareHigh;
    }
    if (modelVals.lossHigh > 0) {
      weightedLossHigh += modelVals.lossHigh * methodWeights.airModelHigh;
      totalWeightHigh += methodWeights.airModelHigh;
    }
    if (uwVals.lossHigh > 0) {
      weightedLossHigh += uwVals.lossHigh * methodWeights.uwGroundUpHigh;
      totalWeightHigh += methodWeights.uwGroundUpHigh;
    }

    return {
      lossLow: totalWeightLow > 0 ? weightedLossLow / totalWeightLow : 0,
      lossBest: totalWeightBest > 0 ? weightedLossBest / totalWeightBest : 0,
      lossHigh: totalWeightHigh > 0 ? weightedLossHigh / totalWeightHigh : 0,
    };
  };

  const summaryNetPreTax = calcNetPreTax(
    summaryData.industryLossLow * (summaryData.marketSharePercent / 100),
    summaryData.industryLossHigh * (summaryData.marketSharePercent / 100),
    summaryData.industryReinstatementLow * (summaryData.marketSharePercent / 100),
    summaryData.industryReinstatementHigh * (summaryData.marketSharePercent / 100)
  );

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections({ ...expandedSections, [section]: !expandedSections[section] });
  };

  const formatCurrency = (value: number) => {
    if (value < 0) {
      return `-$${Math.abs(value).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}M`;
    }
    return `$${value.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}M`;
  };

  const formatCurrencyBillions = (value: number) => {
    return `$${(value / 1000).toFixed(1)}B`;
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  // Derive "Other" row data: Gross=0, Net of Logan=0, remaining columns use raw negative values
  const deriveOtherRowData = (netExtLow: number, netExtHigh: number, reinstLow: number, reinstHigh: number) => {
    const netLossLow = netExtLow - reinstLow;
    const netLossHigh = netExtHigh - reinstHigh;
    return {
      gross: null as { low: number; med: number; high: number } | null,
      netLogan: null as { low: number; med: number; high: number } | null,
      netLoganExt: { low: netExtLow, med: (netExtLow + netExtHigh) / 2, high: netExtHigh },
      reinst: { low: reinstLow, med: (reinstLow + reinstHigh) / 2, high: reinstHigh },
      netLoss: { low: netLossLow, med: (netLossLow + netLossHigh) / 2, high: netLossHigh },
    };
  };

  // Derive Gross-only row data: only Gross has values, all other columns blank (for UW Ground Up)
  const deriveGrossOnlyRowData = (grossLow: number, grossHigh: number) => {
    return {
      gross: { low: grossLow, med: (grossLow + grossHigh) / 2, high: grossHigh },
      netLogan: null as { low: number; med: number; high: number } | null,
      netLoganExt: null as { low: number; med: number; high: number } | null,
      reinst: null as { low: number; med: number; high: number } | null,
      netLoss: null as { low: number; med: number; high: number } | null,
    };
  };

  // Derive all 5 column groups from base data
  const deriveRowData = (grossLow: number, grossHigh: number, reinstLow: number, reinstHigh: number) => {
    const netLoganLow = grossLow * LOGAN_RETENTION;
    const netLoganHigh = grossHigh * LOGAN_RETENTION;
    const netLoganExtLow = netLoganLow * EXTERNAL_RECOV_RATE;
    const netLoganExtHigh = netLoganHigh * EXTERNAL_RECOV_RATE;
    const netLossLow = netLoganExtLow - reinstLow;
    const netLossHigh = netLoganExtHigh - reinstHigh;
    return {
      gross: { low: grossLow, med: (grossLow + grossHigh) / 2, high: grossHigh },
      netLogan: { low: netLoganLow, med: (netLoganLow + netLoganHigh) / 2, high: netLoganHigh },
      netLoganExt: { low: netLoganExtLow, med: (netLoganExtLow + netLoganExtHigh) / 2, high: netLoganExtHigh },
      reinst: { low: reinstLow, med: (reinstLow + reinstHigh) / 2, high: reinstHigh },
      netLoss: { low: netLossLow, med: (netLossLow + netLossHigh) / 2, high: netLossHigh },
    };
  };

  // Render 15 data cells for a row
  // zeroReinst: if true, Expected Reinstatement Premiums group (index 3) renders as "—"
  // null groups render as "—" in gray (used by Other rows for Gross & Net of Logan)
  // tooltipFormulas: optional array of tooltip formulas for each column group
  const renderDataCells = (
    d: { gross: { low: number; med: number; high: number } | null; netLogan: { low: number; med: number; high: number } | null; netLoganExt: { low: number; med: number; high: number } | null; reinst: { low: number; med: number; high: number } | null; netLoss: { low: number; med: number; high: number } | null },
    borderColor: string = 'border-gray-100',
    bold: boolean = false,
    zeroReinst: boolean = false,
    tooltipFormulas?: string[]
  ) => {
    const fw = bold ? 'font-semibold' : '';
    const groups = [d.gross, d.netLogan, d.netLoganExt, d.reinst, d.netLoss];
    const groupNames = ['Gross Loss', 'Net of Logan', 'Net of Logan & Ext. Recov.', 'Exp. Reinst. Premiums', 'Net Loss'];
    return groups.flatMap((g, i) => {
      const isReinst = i === 3;
      const isBlank = g === null;
      const displayVal = (v: number) => isBlank ? '—' : (isReinst && zeroReinst) ? '—' : formatCurrency(v);
      const blankOrReinst = isBlank || (isReinst && zeroReinst);
      const tooltip = tooltipFormulas && tooltipFormulas[i] ? tooltipFormulas[i] : '';
      return [
        <td key={`${i}-low`} className={`px-1 py-3 text-center text-xs ${fw} ${blankOrReinst ? 'text-gray-400' : 'text-gray-900'} border-l ${borderColor} truncate`} title={tooltip}>{displayVal(isBlank ? 0 : g.low)}</td>,
        <td key={`${i}-med`} className={`px-1 py-3 text-center text-xs ${fw} ${blankOrReinst ? 'text-gray-400' : 'text-indigo-700'} ${isBlank ? '' : 'bg-indigo-50/30'} truncate`} title={tooltip}>{displayVal(isBlank ? 0 : g.med)}</td>,
        <td key={`${i}-high`} className={`px-1 py-3 text-center text-xs ${fw} ${blankOrReinst ? 'text-gray-400' : 'text-gray-900'} truncate`} title={tooltip}>{displayVal(isBlank ? 0 : g.high)}</td>,
      ];
    });
  };

  // Render 15 percentage cells for RE Market Share row (only Gross columns, rest blank)
  const renderMarketSharePercentCells = () => {
    const ms = calcReMarketShare();
    const groups = [ms.gross, ms.netLogan, ms.netLoganExt, ms.reinst, ms.netLoss];
    return groups.flatMap((g, i) => {
      const isGross = i === 0;
      const tooltip = isGross ? 'Calculated as (Total Modeling / Everest Consensus) × 100' : '';
      return [
        <td key={`ms-${i}-low`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-gray-900' : 'text-gray-400'} border-l border-gray-100 truncate`} title={tooltip}>{isGross ? `${g.low.toFixed(2)}%` : '—'}</td>,
        <td key={`ms-${i}-med`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-indigo-700 bg-indigo-50/30' : 'text-gray-400'} truncate`} title={tooltip}>{isGross ? `${g.med.toFixed(2)}%` : '—'}</td>,
        <td key={`ms-${i}-high`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-gray-900' : 'text-gray-400'} truncate`} title={tooltip}>{isGross ? `${g.high.toFixed(2)}%` : '—'}</td>,
      ];
    });
  };

  // Render 15 percentage cells for Everest Market Share Based on Ground Up Losses
  // = Total UW Ground Up / Everest Consensus (Gross only, rest blank)
  const renderGroundUpMarketShareCells = () => {
    const uwTotal = calcTotalUW();
    const consGross = { low: consensus.grossLow, med: consensus.grossBest, high: consensus.grossHigh };
    const uwGross = { low: uwTotal.lossLow, med: (uwTotal.lossLow + uwTotal.lossHigh) / 2, high: uwTotal.lossHigh };
    const pct = (num: number, den: number) => den !== 0 ? (num / den) * 100 : 0;
    return [0, 1, 2, 3, 4].flatMap((i) => {
      const isGross = i === 0;
      const tooltip = isGross ? 'Calculated as (Total UW Ground Up Estimates / Everest Consensus) × 100' : '';
      return [
        <td key={`gums-${i}-low`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-gray-900' : 'text-gray-400'} border-l border-gray-100 truncate`} title={tooltip}>{isGross ? `${pct(uwGross.low, consGross.low).toFixed(2)}%` : '—'}</td>,
        <td key={`gums-${i}-med`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-indigo-700 bg-indigo-50/30' : 'text-gray-400'} truncate`} title={tooltip}>{isGross ? `${pct(uwGross.med, consGross.med).toFixed(2)}%` : '—'}</td>,
        <td key={`gums-${i}-high`} className={`px-1 py-3 text-center text-xs ${isGross ? 'text-gray-900' : 'text-gray-400'} truncate`} title={tooltip}>{isGross ? `${pct(uwGross.high, consGross.high).toFixed(2)}%` : '—'}</td>,
      ];
    });
  };

  const handleAddComment = (method: 'marketShare' | 'air' | 'underwriters') => {
    if (!newComment[method].trim()) {
      toast.error('Please enter a comment');
      return;
    }

    const comment = {
      text: newComment[method],
      author: event?.owner || 'Current User',
      date: new Date().toLocaleString(),
      files: attachedFiles[method].length > 0 ? [...attachedFiles[method]] : undefined,
    };

    setMethodComments({
      ...methodComments,
      [method]: [...methodComments[method], comment],
    });

    setNewComment({ ...newComment, [method]: '' });
    setAttachedFiles({ ...attachedFiles, [method]: [] });
    toast.success('Comment added successfully');
  };

  const handleFileAttach = (method: 'marketShare' | 'air' | 'underwriters', e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const fileNames = Array.from(files).map(file => file.name);
      setAttachedFiles({
        ...attachedFiles,
        [method]: [...attachedFiles[method], ...fileNames],
      });
      toast.success(`${files.length} file(s) attached`);
    }
  };

  const handleRemoveFile = (method: 'marketShare' | 'air' | 'underwriters', fileName: string) => {
    setAttachedFiles({
      ...attachedFiles,
      [method]: attachedFiles[method].filter(f => f !== fileName),
    });
  };

  // Calculate metrics
  const totalUW = calcTotalUW();
  const totalModelingData = calcTotalModeling();

  return (
    <div className="space-y-6">
      {/* Summary Table */}
      <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b bg-gray-50 flex items-center justify-between">
          <h3 className="text-base">Summary</h3>
          
          <div className="flex items-center gap-3">
            {onAddComment && (
              <button
                onClick={onAddComment}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                Add Comment
              </button>
            )}
            {onLockEstimates && (
              <button
                onClick={onLockEstimates}
                className={`flex items-center gap-2 px-4 py-2 text-white rounded-lg hover:opacity-90 transition-all text-sm shadow-sm ${isLocked ? 'bg-amber-600 hover:bg-amber-700' : ''}`}
                style={!isLocked ? { backgroundColor: '#0052FF' } : undefined}
              >
                {isLocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                {isLocked ? 'Unlock Estimates' : 'Lock Estimates'}
              </button>
            )}
            {onDownload && (
              <button
                onClick={onDownload}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                Export
              </button>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full table-fixed" style={{ minWidth: '1100px' }}>
            <thead className="bg-slate-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 w-[180px] sticky left-0 bg-slate-50 z-10"></th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>Gross Loss</th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>Net of Logan (100%)</th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>Net of Logan &amp; Ext. Recov.</th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>Exp. Reinst. Premiums</th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>Net Loss</th>
              </tr>
              <tr className="bg-slate-100">
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-600 sticky left-0 bg-slate-100 z-10"></th>
                {[0,1,2,3,4].flatMap(i => [
                  <th key={`sumh-${i}-l`} className="px-1 py-2 text-center text-xs font-medium text-gray-600 border-l border-gray-200">Low</th>,
                  <th key={`sumh-${i}-b`} className="px-1 py-2 text-center text-xs font-medium text-indigo-700 bg-indigo-50">Best</th>,
                  <th key={`sumh-${i}-h`} className="px-1 py-2 text-center text-xs font-medium text-gray-600">High</th>,
                ])}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              <tr className="bg-amber-50/40">
                <td className="px-4 py-3 text-sm text-gray-900 sticky left-0 bg-amber-50/40 z-10">
                  <div className="flex items-center gap-1.5">
                    <span>Everest Consensus</span>
                    <div className="group relative">
                      <Info className="w-3.5 h-3.5 text-gray-400 cursor-help" />
                      <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-64 p-2.5 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        Pre-populated from Event Creation form. Click any cell to edit manually.
                        <div className="absolute left-6 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                  </div>
                </td>
                {([
                  { key: 'grossLow' as const, border: true },
                  { key: 'grossBest' as const, best: true },
                  { key: 'grossHigh' as const },
                  { key: 'netLoganLow' as const, border: true },
                  { key: 'netLoganBest' as const, best: true },
                  { key: 'netLoganHigh' as const },
                  { key: 'netLoganExtLow' as const, border: true },
                  { key: 'netLoganExtBest' as const, best: true },
                  { key: 'netLoganExtHigh' as const },
                  { key: 'reinstLow' as const, border: true },
                  { key: 'reinstBest' as const, best: true },
                  { key: 'reinstHigh' as const },
                  { key: 'netLossLow' as const, border: true },
                  { key: 'netLossBest' as const, best: true },
                  { key: 'netLossHigh' as const },
                ] as const).map(({ key, border, best }) => {
                  const isGrossCell = key === 'grossLow' || key === 'grossBest' || key === 'grossHigh';
                  const isBlankCell = !isGrossCell;
                  return (
                  <td
                    key={`ec-${key}`}
                    className={`px-1 py-3 text-center ${border ? 'border-l border-amber-200' : ''} ${best && isGrossCell ? 'bg-indigo-50/30' : ''}`}
                  >
                    {isBlankCell ? (
                      <span className="text-sm text-gray-400">—</span>
                    ) : editingConsensusCell === key ? (
                      <input
                        autoFocus
                        type="text"
                        inputMode="decimal"
                        value={editingConsensusValue}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === '' || val === '-' || /^-?\d*\.?\d*$/.test(val)) {
                            setEditingConsensusValue(val);
                          }
                        }}
                        onBlur={() => {
                          const val = editingConsensusValue;
                          const numVal = val === '' || val === '-' ? 0 : (parseFloat(val) || 0);
                          const updated = { ...consensus, [key]: numVal };
                          setConsensus(updated);
                          setSummaryData(prev => ({
                            ...prev,
                            industryLossLow: updated.grossLow,
                            industryLossHigh: updated.grossHigh,
                            industryReinstatementLow: updated.reinstLow,
                            industryReinstatementHigh: updated.reinstHigh,
                          }));
                          setEditingConsensusCell(null);
                          setEditingConsensusValue('');
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            (e.target as HTMLInputElement).blur();
                          } else if (e.key === 'Escape') {
                            setEditingConsensusCell(null);
                            setEditingConsensusValue('');
                          }
                        }}
                        className={`w-20 px-2 py-1 text-center text-sm bg-transparent border-0 border-b border-dashed border-amber-400 focus:outline-none focus:border-amber-600 focus:border-solid ${best ? 'text-indigo-700' : 'text-gray-900'}`}
                      />
                    ) : (
                      <div
                        className="cursor-pointer hover:bg-amber-100/60 rounded px-1 py-0.5 transition-colors"
                        title="Click to edit"
                        onClick={() => {
                          setEditingConsensusCell(key);
                          setEditingConsensusValue(consensus[key].toString());
                        }}
                      ><span className={`text-sm ${best ? 'text-indigo-700' : 'text-gray-900'}`}>{consensus[key] >= 1000 ? `$${(consensus[key] / 1000).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}B` : `$${consensus[key].toLocaleString('en-US', { maximumFractionDigits: 1 })}M`}</span></div>
                    )}
                  </td>
                  );
                })}
              </tr>
              {/* Everest Market Share % — editable percentage row */}
              <tr className="bg-amber-50/40">
                <td className="px-4 py-3 text-sm text-gray-900 sticky left-0 bg-amber-50/40 z-10">
                  <div className="flex items-center gap-1.5">
                    <span>Everest Market Share %</span>
                    <div className="group relative">
                      <Info className="w-3.5 h-3.5 text-gray-400 cursor-help" />
                      <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-64 p-2.5 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        Enter the estimated Everest market share percentage. This applies to the Everest Consensus Gross values.
                        <div className="absolute left-6 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                  </div>
                </td>
                {([ 
                  { idx: 0, border: true },
                  { idx: 1, best: true },
                  { idx: 2 },
                  { idx: 3, border: true },
                  { idx: 4, best: true },
                  { idx: 5 },
                  { idx: 6, border: true },
                  { idx: 7, best: true },
                  { idx: 8 },
                  { idx: 9, border: true },
                  { idx: 10, best: true },
                  { idx: 11 },
                  { idx: 12, border: true },
                  { idx: 13, best: true },
                  { idx: 14 },
                ] as const).map(({ idx, border, best }) => {
                  // Only show values in the first 3 cells (Gross Low/Best/High) — rest are dashes
                  const isGrossCell = idx < 3;
                  if (!isGrossCell) {
                    return (
                      <td key={`ms-pct-${idx}`} className={`px-1 py-3 text-center ${border ? 'border-l border-amber-200' : ''}`}>
                        <span className="text-sm text-gray-400">—</span>
                      </td>
                    );
                  }
                  // Gross cells: independent percentage input per column (Low/Best/High)
                  const pctKeys = ['low', 'best', 'high'] as const;
                  const pctKey = pctKeys[idx];
                  return (
                    <td key={`ms-pct-${idx}`} className={`px-1 py-3 text-center ${border ? 'border-l border-amber-200' : ''} ${best ? 'bg-indigo-50/30' : ''}`}>
                      <div className="flex items-center justify-center">
                        <div className="relative">
                          <input
                            type="text"
                            inputMode="decimal"
                            placeholder="—"
                            value={marketSharePcts[pctKey]}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val === '' || val === '-' || /^-?\d*\.?\d*$/.test(val)) {
                                setMarketSharePcts(prev => ({ ...prev, [pctKey]: val }));
                              }
                            }}
                            className={`w-16 px-1 py-1 text-center text-sm bg-transparent border-0 border-b-2 border-dashed border-amber-300 focus:outline-none focus:border-amber-600 focus:border-solid placeholder:text-gray-300 ${marketSharePcts[pctKey] ? 'text-amber-700 font-semibold' : 'text-gray-400'}`}
                          />
                          {marketSharePcts[pctKey] && (
                            <span className="absolute -right-1 top-1/2 -translate-y-1/2 text-xs text-amber-500 pointer-events-none">%</span>
                          )}
                        </div>
                      </div>
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td className="px-4 py-3 text-sm text-gray-900 sticky left-0 bg-white z-10">EG Market Share Estimate (Based on Modeling)</td>
                {renderMarketSharePercentCells()}
              </tr>
              <tr className="bg-emerald-50/30">
                <td className="px-4 py-3 text-sm text-gray-900 sticky left-0 bg-emerald-50/30 z-10">
                  <div className="flex items-center gap-1.5">
                    <span>Everest Market Share Based on Ground Up Losses</span>
                  </div>
                </td>
                {renderGroundUpMarketShareCells()}
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Estimation Methods Table */}
      <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b bg-gray-50">
          <h3 className="text-base">
            Estimation Methods</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full table-fixed" style={{ minWidth: '1100px' }}>
            <thead className="bg-slate-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900 w-[180px] sticky left-0 bg-slate-50 z-10"></th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>
                  Gross Loss
                </th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>
                  Net of Logan (100%)
                </th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>
                  Net of Logan &amp; Ext. Recov.
                </th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>
                  Exp. Reinst. Premiums
                </th>
                <th className="px-1 py-3 text-center text-xs font-semibold text-gray-900 border-l border-gray-200" colSpan={3}>
                  Net Loss
                </th>
              </tr>
              <tr className="bg-slate-100">
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-600 sticky left-0 bg-slate-100 z-10"></th>
                {[0,1,2,3,4].flatMap(i => [
                  <th key={`met-${i}-l`} className="px-1 py-2 text-center text-xs font-medium text-gray-600 border-l border-gray-200">Low</th>,
                  <th key={`met-${i}-b`} className="px-1 py-2 text-center text-xs font-medium text-indigo-700 bg-indigo-50">Best</th>,
                  <th key={`met-${i}-h`} className="px-1 py-2 text-center text-xs font-medium text-gray-600">High</th>,
                ])}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {/* Everest Market Share — Consensus × per-column % from top section */}
              <tr className="bg-amber-50/40">
                <td className="px-4 py-3 text-sm font-semibold text-gray-900 sticky left-0 bg-amber-50/40 z-10">
                  <div className="flex items-center gap-2">
                    <span>Everest Market Share</span>
                    {(marketSharePcts.low || marketSharePcts.best || marketSharePcts.high) && (
                      null
                    )}
                  </div>
                </td>
                {renderDataCells(
                  {
                    gross: { low: consensus.grossLow * (getMarketShareNum('low') / 100), med: consensus.grossBest * (getMarketShareNum('best') / 100), high: consensus.grossHigh * (getMarketShareNum('high') / 100) },
                    netLogan: null, netLoganExt: null, reinst: null, netLoss: null,
                  },
                  'border-amber-200',
                  true,
                  false,
                  ['Consensus Gross × Everest Market Share %', '', '', '', '']
                )}
              </tr>
              {/* Group 1: Modeling */}
              <tr className="bg-purple-50 cursor-pointer hover:bg-purple-100" onClick={() => toggleSection('modeling')}>
                <td className="px-4 py-3 text-sm font-semibold text-gray-900 sticky left-0 bg-purple-50 z-10">
                  <div className="flex items-center gap-2">
                    {expandedSections.modeling ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    1) Modeling
                  </div>
                </td>
                {renderDataCells(deriveRowData(totalModelingData.lossLow, totalModelingData.lossHigh, totalModelingData.reinstLow, totalModelingData.reinstHigh), 'border-purple-200', true, false, ['', 'Gross Loss × 85% (Logan retention)', 'Net of Logan × 92% (external recovery rate)', '', 'Net of Logan & Ext. Recov. − Expected Reinstatement Premiums'])}
              </tr>
              {expandedSections.modeling && MODELING_GROUPS.map((group) => {
                const subtotal = group.calc();
                return [
                  <tr key={`mg-${group.toggleKey}`} className="bg-purple-50/40 cursor-pointer hover:bg-purple-100/40" onClick={() => toggleSection(group.toggleKey)}>
                    <td className="px-4 py-2 text-sm font-medium text-gray-800 sticky left-0 bg-purple-50/40 z-10" style={{ paddingLeft: '2.2rem' }}>
                      <div className="flex items-center gap-1.5">
                        {expandedSections[group.toggleKey] ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                        {group.name}
                      </div>
                    </td>
                    {renderDataCells(deriveRowData(subtotal.lossLow, subtotal.lossHigh, subtotal.reinstLow, subtotal.reinstHigh), 'border-purple-100', true, false, ['Sum of department estimates', 'Gross Loss × 85%', 'Net of Logan × 92%', 'Sum of department estimates', 'Net of Logan & Ext. Recov. − Reinstatement'])}
                  </tr>,
                  ...(expandedSections[group.toggleKey] ? group.keys.map((key) => {
                    const data = modelingEstimates[key];
                    return (
                      <tr key={`m-${key}`} className="hover:bg-purple-50/20">
                        <td className="px-4 py-2 text-sm text-gray-900 sticky left-0 bg-white z-10" style={{ paddingLeft: '4rem' }}>{BU_LABELS[key] || key}</td>
                        {renderDataCells(deriveRowData(data.lossLow, data.lossHigh, data.reinstatementLow, data.reinstatementHigh), 'border-gray-100', false, false, ['', 'Gross Loss × 85%', 'Net of Logan × 92%', '', 'Net of Logan & Ext. Recov. − Reinstatement'])}
                      </tr>
                    );
                  }) : []),
                ];
              }).flat()}
              {/* Recovery rows (negative, Gross & Net Logan = N/A) */}
              {expandedSections.modeling && (<>
                <tr className="bg-red-50/40 cursor-pointer hover:bg-red-100/40" onClick={() => toggleSection('modelingRecoveries')}>
                  <td className="px-4 py-2 text-sm font-medium text-red-800 sticky left-0 bg-red-50/40 z-10" style={{ paddingLeft: '2.2rem' }}>
                    <div className="flex items-center gap-1.5">
                      {expandedSections.modelingRecoveries ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      Recoveries
                    </div>
                  </td>
                  {renderDataCells(deriveOtherRowData(calcOtherTotal().lossLow, calcOtherTotal().lossHigh, calcOtherTotal().reinstLow, calcOtherTotal().reinstHigh), 'border-red-100', true, false, ['', '', 'Sum of recovery estimates (negative)', 'Sum of recovery estimates (negative)', 'Net of Logan & Ext. Recov. − Reinstatement'])}
                </tr>
                {expandedSections.modelingRecoveries && ([
                  { label: 'AF Cessions Recovery', data: otherEstimates.afCessionsRecovery },
                  { label: 'Cat Bond Recovery', data: otherEstimates.catBondRecovery },
                  { label: 'EI Recovery', data: otherEstimates.eiRecovery },
                ] as const).map(({ label, data }) => (
                  <tr key={`m-rec-${label}`} className="hover:bg-red-50/20">
                    <td className="px-4 py-2 text-sm text-red-700 sticky left-0 bg-white z-10" style={{ paddingLeft: '4rem' }}>{label}</td>
                    {renderDataCells(deriveOtherRowData(data.lossLow, data.lossHigh, data.reinstatementLow, data.reinstatementHigh), 'border-gray-100', false, false, ['', '', 'Recovery estimate (negative)', 'Recovery estimate (negative)', 'Net of Logan & Ext. Recov. − Reinstatement'])}
                  </tr>
                ))}
              </>)}

              {/* Group 2: UW Ground Up Estimates (Gross only — no Net Logan, Reinst, Net Loss) */}
              <tr className="bg-emerald-50 cursor-pointer hover:bg-emerald-100" onClick={() => toggleSection('uwGroundUp')}>
                <td className="px-4 py-3 text-sm font-semibold text-gray-900 sticky left-0 bg-emerald-50 z-10">
                  <div className="flex items-center gap-2">
                    {expandedSections.uwGroundUp ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    2) UW Ground Up Estimates
                  </div>
                </td>
                {renderDataCells(deriveGrossOnlyRowData(calcTotalUW().lossLow, calcTotalUW().lossHigh), 'border-emerald-200', true, false, ['Sum of underwriter ground-up estimates (Gross only)', '', '', '', ''])}
              </tr>
              {expandedSections.uwGroundUp && UW_GROUPS.map((group) => {
                const subtotal = group.calc();
                return [
                  <tr key={`uwg-${group.toggleKey}`} className="bg-emerald-50/40 cursor-pointer hover:bg-emerald-100/40" onClick={() => toggleSection(group.toggleKey)}>
                    <td className="px-4 py-2 text-sm font-medium text-gray-800 sticky left-0 bg-emerald-50/40 z-10" style={{ paddingLeft: '2.2rem' }}>
                      <div className="flex items-center gap-1.5">
                        {expandedSections[group.toggleKey] ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                        {group.name}
                      </div>
                    </td>
                    {renderDataCells(deriveGrossOnlyRowData(subtotal.lossLow, subtotal.lossHigh), 'border-emerald-100', true, false, ['Sum of department estimates (Gross only)', '', '', '', ''])}
                  </tr>,
                  ...(expandedSections[group.toggleKey] ? group.keys.map((key) => {
                    const data = uwEstimates[key];
                    return (
                      <tr key={`uw-${key}`} className="hover:bg-emerald-50/20">
                        <td className="px-4 py-2 text-sm text-gray-900 sticky left-0 bg-white z-10" style={{ paddingLeft: '4rem' }}>{BU_LABELS[key] || key}</td>
                        {renderDataCells(deriveGrossOnlyRowData(data.lossLow, data.lossHigh), 'border-gray-100', false, false, ['', '', '', '', ''])}
                      </tr>
                    );
                  }) : []),
                ];
              }).flat()}

              {/* Rollups */}
              <tr className="bg-slate-100 border-t-2 border-slate-300">
                <td className="px-4 py-3 text-sm font-semibold text-gray-900 sticky left-0 bg-slate-100 z-10">
                  <div className="flex items-center gap-2">
                    <span>Header-Weighted Estimate</span>
                    <div className="group relative">
                      <Info className="w-4 h-4 text-gray-500 cursor-help" />
                      <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-80 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        Weighted estimate based on three method totals: 1) Everest Market Share (Consensus × %), 2) Modeling (including Recoveries), and 3) UW Ground Up Estimates. Only methods with non-zero values are included in the weighted average. Only Gross Loss is weighted; other columns are derived from Modeling only.
                        <div className="absolute left-6 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                  </div>
                </td>
                {(() => {
                  const avg = calcAverageLowHigh();
                  return renderDataCells(
                    {
                      gross: { low: avg.lossLow, med: avg.lossBest, high: avg.lossHigh },
                      netLogan: null, netLoganExt: null, reinst: null, netLoss: null,
                    },
                    'border-slate-300',
                    true,
                    false,
                    ['Weighted average of Everest Market Share, Modeling, and UW estimates (only non-zero values included)', '', '', '', '']
                  );
                })()}
              </tr>
              {/* Everest Estimated — numeric row */}
              <tr className="bg-blue-100 border-t-2 border-blue-300">
                <td className="px-4 py-4 text-sm font-bold text-gray-900 sticky left-0 bg-blue-100 z-10">
                  <div className="flex items-center gap-1.5">
                    <span>Everest Selected Estimated</span>
                    <div className="group relative">
                      <Info className="w-3.5 h-3.5 text-gray-400 cursor-help" />
                      <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-64 p-2.5 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        Enter Everest estimated values. Click any cell to edit.
                        <div className="absolute left-6 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                  </div>
                </td>
                {([
                  { key: 'grossLow' as const, border: true },
                  { key: 'grossBest' as const, best: true },
                  { key: 'grossHigh' as const },
                  { key: 'netLoganLow' as const, border: true },
                  { key: 'netLoganBest' as const, best: true },
                  { key: 'netLoganHigh' as const },
                  { key: 'netLoganExtLow' as const, border: true },
                  { key: 'netLoganExtBest' as const, best: true },
                  { key: 'netLoganExtHigh' as const },
                  { key: 'reinstLow' as const, border: true },
                  { key: 'reinstBest' as const, best: true },
                  { key: 'reinstHigh' as const },
                  { key: 'netLossLow' as const, border: true },
                  { key: 'netLossBest' as const, best: true },
                  { key: 'netLossHigh' as const },
                ] as const).map(({ key, border, best }) => (
                  <td
                    key={`ee-${key}`}
                    className={`px-1 py-3 text-center ${border ? 'border-l border-blue-300' : ''} ${best ? 'bg-indigo-50/30' : ''}`}
                  >
                    {editingEverestEstimatedCell === key ? (
                      <input
                        autoFocus
                        type="text"
                        inputMode="decimal"
                        value={editingEverestEstimatedValue}
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === '' || val === '-' || /^-?\d*\.?\d*$/.test(val)) {
                            setEditingEverestEstimatedValue(val);
                          }
                        }}
                        onBlur={() => {
                          const val = editingEverestEstimatedValue;
                          if (val === '' || val === '-') {
                            setEverestEstimated({ ...everestEstimated, [key]: 0 });
                          } else {
                            setEverestEstimated({ ...everestEstimated, [key]: parseFloat(val) || 0 });
                          }
                          setEditingEverestEstimatedCell(null);
                          setEditingEverestEstimatedValue('');
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            (e.target as HTMLInputElement).blur();
                          } else if (e.key === 'Escape') {
                            setEditingEverestEstimatedCell(null);
                            setEditingEverestEstimatedValue('');
                          }
                        }}
                        className={`w-20 px-2 py-1 text-center text-sm font-bold bg-transparent border-0 border-b border-dashed border-blue-400 focus:outline-none focus:border-blue-600 focus:border-solid ${best ? 'text-indigo-700' : 'text-gray-900'}`}
                      />
                    ) : (
                      <div
                        className="cursor-pointer"
                        onClick={() => {
                          setEditingEverestEstimatedCell(key);
                          setEditingEverestEstimatedValue(everestEstimated[key] === 0 ? '' : everestEstimated[key].toString());
                        }}
                      >
                        {everestEstimated[key] === 0 ? (
                          <span className="text-gray-400 border-b border-dashed border-blue-300 px-2 py-0.5">—</span>
                        ) : (
                          formatCurrency(everestEstimated[key])
                        )}
                      </div>
                    )}
                  </td>
                ))}
              </tr>
              {/* Everest Estimated Market Share % — calculated percentage row */}
              <tr className="bg-blue-100">
                <td className="px-4 py-3 text-sm font-bold text-gray-900 sticky left-0 bg-blue-100 z-10">
                  <div className="flex items-center gap-1.5">
                    <span>Everest Selected Estimated Market Share %</span>
                    <div className="group relative">
                      <Info className="w-3.5 h-3.5 text-gray-400 cursor-help" />
                      <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block w-64 p-2.5 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        Calculated as (Everest Estimated / Everest Consensus) × 100
                        <div className="absolute left-6 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                  </div>
                </td>
                {([
                  { key: 'grossLow' as const, border: true },
                  { key: 'grossBest' as const, best: true },
                  { key: 'grossHigh' as const },
                  { key: 'netLoganLow' as const, border: true },
                  { key: 'netLoganBest' as const, best: true },
                  { key: 'netLoganHigh' as const },
                  { key: 'netLoganExtLow' as const, border: true },
                  { key: 'netLoganExtBest' as const, best: true },
                  { key: 'netLoganExtHigh' as const },
                  { key: 'reinstLow' as const, border: true },
                  { key: 'reinstBest' as const, best: true },
                  { key: 'reinstHigh' as const },
                  { key: 'netLossLow' as const, border: true },
                  { key: 'netLossBest' as const, best: true },
                  { key: 'netLossHigh' as const },
                ] as const).map(({ key, border, best }) => {
                  const marketSharePct = consensus[key] !== 0 ? (everestEstimated[key] / consensus[key]) * 100 : 0;
                  return (
                    <td
                      key={`ee-pct-${key}`}
                      className={`px-1 py-3 text-center ${border ? 'border-l border-blue-300' : ''} ${best ? 'bg-indigo-50/30' : ''}`}
                      title="Calculated as (Everest Selected Estimated / Everest Consensus) × 100"
                    >
                      {everestEstimated[key] === 0 ? (
                        <span className="text-sm text-gray-400">—</span>
                      ) : (
                        <span className={`text-sm font-bold ${best ? 'text-indigo-700' : 'text-blue-700'}`}>
                          {marketSharePct.toFixed(2)}%
                        </span>
                      )}
                    </td>
                  );
                })}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
