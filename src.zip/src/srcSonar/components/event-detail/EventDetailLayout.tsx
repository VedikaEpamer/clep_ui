import { Outlet, useParams, useNavigate, useLocation } from 'react-router';
import { ArrowLeft, FileText, Eye, FolderOpen, History, ChevronLeft, ChevronRight, Bell, DollarSign, Receipt, BarChart3 } from 'lucide-react';
import { useState } from 'react';
import { mockEvents } from '../../lib/mockData';
import { useRole } from '../../lib/roleContext';
import { useTasks } from '../../lib/taskContext';
import everestLogo from 'figma:asset/caba23401a17fe2f9b2a6d285e246c7856b7dfec.png';
import { UWPortfolioProvider } from '../../lib/uwPortfolioContext';
import { PortfolioSidebar } from './PortfolioSidebar';

const navigation = [
  { id: 'overview', name: 'Overview', icon: Eye, permissionKey: 'overview' },
  { id: 'uw-estimation', name: 'UW Estimation', icon: FileText, permissionKey: 'uw-estimation' },
  { id: 'modeling', name: 'Modeling', icon: BarChart3, permissionKey: 'modeling' },
  { id: 'finance', name: 'Finance', icon: DollarSign, permissionKey: 'finance' },
  { id: 'claims', name: 'Claims', icon: Receipt, permissionKey: 'claims' },
  { id: 'documents', name: 'Documents', icon: FolderOpen, permissionKey: 'documents' },
  { id: 'audit', name: 'Audit Log', icon: History, permissionKey: 'audit' },
];

export function EventDetailLayout() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { userName, permissions } = useRole();
  const { getNotificationsForEvent, markNotificationRead } = useTasks();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => sessionStorage.getItem('sidebarCollapsed') === 'true');
  const [showNotifications, setShowNotifications] = useState(false);

  const adminName = 'Admin Team';

  const notifications = eventId ? getNotificationsForEvent(userName, eventId) : [];
  const unreadCount = notifications.filter(n => !n.read).length;

  const formatNotifTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleNotificationClick = (notif: any) => {
    markNotificationRead(notif.id);
    if (notif.taskId) {
      if (notif.type === 'approval-required') {
        navigate(`/events/${eventId}/uw-estimation`);
      } else if (notif.type === 'task-assigned' && notif.message?.toLowerCase().includes('model')) {
        navigate(`/events/${eventId}/modeling`);
      } else if (notif.type === 'task-assigned' && notif.message?.toLowerCase().includes('finance')) {
        navigate(`/events/${eventId}/finance`);
      } else {
        navigate(`/events/${eventId}/uw-estimation`);
      }
    }
    setShowNotifications(false);
  };

  const event = mockEvents.find(e => e.id === eventId);
  const currentPath = location.pathname.split('/').pop();
  const isUWEstimation = currentPath === 'uw-estimation';

  if (!event) {
    return <div className="p-8">Event not found</div>;
  }

  return (
    <UWPortfolioProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 max-w-[100vw] overflow-x-hidden">
        {/* ── Top Header Bar ─────────────────────────────────────────── */}
        <div className="h-16 bg-[#001f3f] border-b border-blue-900/30 flex items-center justify-between px-0 fixed top-0 left-0 right-0 z-[110]">
          <div className="h-full flex items-center px-5 flex-shrink-0">
            <div className="flex items-center gap-3">
              <img src={everestLogo} alt="Everest Logo" className="h-10 object-contain pointer-events-none" />
              <span className="text-white text-xl font-semibold tracking-wide flex items-center">SONAR</span>
            </div>
          </div>

          <div className="flex items-center gap-4 pr-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-xs font-semibold text-white">
                {adminName.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <div className="text-sm font-semibold text-white">{userName}</div>
              </div>
            </div>

            <div className="relative pl-4 border-l border-white/20">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-9 h-9 rounded-lg hover:bg-white/10 flex items-center justify-center transition-all relative"
              >
                <Bell className="w-5 h-5 text-white/80" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 rounded-full ring-2 ring-everest-blue" />
                )}
              </button>

              {showNotifications && (
                <>
                  <div className="fixed inset-0 z-[70]" onClick={() => setShowNotifications(false)} />
                  <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-strong border border-slate-200 overflow-hidden z-[100]">
                    <div className="p-4 border-b border-slate-100">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">Notifications</h4>
                        <span className="text-xs text-slate-500">{unreadCount} new</span>
                      </div>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length > 0 ? notifications.map((notif) => (
                        <div
                          key={notif.id}
                          className={`p-4 border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors ${!notif.read ? 'bg-blue-50/30' : ''}`}
                          onClick={() => handleNotificationClick(notif)}
                        >
                          <div className="flex items-start gap-3">
                            {!notif.read && <div className="w-2 h-2 bg-everest-blue rounded-full mt-2 flex-shrink-0" />}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm mb-0.5">{notif.title}</p>
                              <p className="text-xs text-slate-600 mb-1">{notif.message}</p>
                              <p className="text-xs text-slate-400">{formatNotifTime(notif.createdAt)}</p>
                            </div>
                          </div>
                        </div>
                      )) : (
                        <div className="p-8 text-center">
                          <Bell className="w-10 h-10 text-slate-200 mx-auto mb-2" />
                          <p className="text-sm text-slate-400">No notifications for this event</p>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-1 pt-16">
          {/* ── Blue Left Sidebar ─────────────────────────────────────── */}
          <div
            className={`bg-[#2563EB] flex flex-col fixed left-0 top-16 h-[calc(100vh-64px)] transition-all duration-300 z-40 overflow-y-auto ${
              sidebarCollapsed ? 'w-16' : 'w-48'
            }`}
          >
            {/* Back Button */}
            <div className="h-12 flex items-center px-4 border-b border-white/10 shrink-0">
              {!sidebarCollapsed ? (
                <button
                  onClick={() => navigate('/events')}
                  className="flex items-center gap-2 text-sm text-white/70 hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Events
                </button>
              ) : (
                <button
                  onClick={() => navigate('/events')}
                  className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center mx-auto transition-colors"
                  title="Back to Events"
                >
                  <ArrowLeft className="w-4 h-4 text-white/70" />
                </button>
              )}
            </div>

            {/* Navigation Items */}
            <nav className="p-3 space-y-1 shrink-0">
              {navigation
                .filter((item) => permissions.visibleTabs.includes(item.permissionKey))
                .map((item) => {
                  const Icon = item.icon;
                  const isActive = currentPath === item.id;
                  return (
                    <div key={item.id} className="relative group">
                      <button
                        onClick={() => navigate(`/events/${eventId}/${item.id}`)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm ${
                          isActive
                            ? 'bg-white/20 text-white font-medium'
                            : 'text-white/70 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        {!sidebarCollapsed && <span>{item.name}</span>}
                      </button>
                      {sidebarCollapsed && (
                        <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-3 py-2 bg-slate-900 text-white text-sm rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50 pointer-events-none">
                          {item.name}
                        </div>
                      )}
                    </div>
                  );
                })}
            </nav>

            {/* ── Portfolio Panel — only on UW Estimation, only when expanded ── */}
            {isUWEstimation && !sidebarCollapsed && (
              <PortfolioSidebar />
            )}

            {/* Spacer to push collapse toggle to bottom */}
            <div className="flex-1" />

            {/* Collapse Toggle */}
            <div className="p-3 border-t border-white/10 shrink-0">
              <button
                onClick={() => {
                  const next = !sidebarCollapsed;
                  setSidebarCollapsed(next);
                  sessionStorage.setItem('sidebarCollapsed', String(next));
                }}
                className="w-full flex items-center justify-center px-3 py-2.5 rounded-lg text-white/70 hover:bg-white/10 hover:text-white transition-all"
                title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              >
                {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* ── Main Content Area ─────────────────────────────────────── */}
          <div className={`flex-1 min-w-0 overflow-x-hidden transition-all duration-300 ${
            sidebarCollapsed ? 'ml-16' : 'ml-48'
          }`}>
            <Outlet />
          </div>
        </div>
      </div>
    </UWPortfolioProvider>
  );
}
