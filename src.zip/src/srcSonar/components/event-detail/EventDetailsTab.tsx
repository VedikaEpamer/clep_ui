import { useState } from 'react';
import { Edit2, CheckCircle, X, Lock, Eye, Pencil } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useEventData } from '../../lib/eventDataContext';
import { EventIdentity } from '../event-creation/EventIdentity';
import { ImpactRegionsPerils } from '../event-creation/ImpactRegionsPerils';
import { OtherIds } from '../event-creation/OtherIds';
import { MarketLoss } from '../event-creation/MarketLoss';
import { DeadlinesTracking } from '../event-creation/DeadlinesTracking';

interface EventDetailsTabProps {
  event: any;
  canEdit: boolean;
  isEditing?: boolean;
  setIsEditing?: (isEditing: boolean) => void;
  onSave?: () => void;
  onCancel?: () => void;
}

export function EventDetailsTab({ event, canEdit, isEditing: externalIsEditing, setIsEditing: externalSetIsEditing, onSave: externalOnSave, onCancel: externalOnCancel }: EventDetailsTabProps) {
  const [internalIsEditing, setInternalIsEditing] = useState(false);
  const { setCatCode: setSharedCatCode } = useEventData();
  
  // Use external state if provided, otherwise use internal state
  const isEditing = externalIsEditing !== undefined ? externalIsEditing : internalIsEditing;
  const setIsEditing = externalSetIsEditing || setInternalIsEditing;

  const [eventData, setEventData] = useState({
    eventId: event?.id || '',
    catCode: event?.catCode || '',
    eventName: event?.eventName || '',
    eventType: event?.eventType || '',
    everestEventType: event?.everestEventType || '',
    eventSubType: event?.eventSubType || '',
    peril: event?.peril || '',
    lossDate: event?.lossDate || '',
    lossStartDate: event?.lossStartDate || '',
    lossEndDate: event?.lossEndDate || '',
    owner: event?.owner || '',
    businessUnit: event?.businessUnit || '',
    region: event?.region || '',
    shortDescription: event?.shortDescription || '',
    longDescription: event?.description || '',
    impactedCountries: event?.impactedCountries || [],
    impactedStates: event?.impactedStates || [],
    impactedPerils: event?.impactedPerils || [],
    premiumAllocation: event?.premiumAllocation || '',
    reportingLine: event?.reportingLine || '',
    businessGroups: event?.businessGroups || [],
    externalIds: event?.externalIds || [],
    marketLossLow: event?.marketLossLow || '',
    marketLossMed: event?.marketLossMed || '',
    marketLossHigh: event?.marketLossHigh || '',
    estimateSource: event?.estimateSource || '',
    severityLevel: event?.severityLevel || '',
    marketLossComments: event?.marketLossComments || '',
    trackImmediately: event?.trackImmediately || false,
    operationalSummary: event?.operationalSummary || '',
    deadline1: event?.deadline1 || '',
    deadline2: event?.deadline2 || '',
    deadline3: event?.deadline3 || '',
    deadline4: event?.deadline4 || '',
    functionalTeams: event?.functionalTeams || [],
    executiveAreas: event?.executiveAreas || [],
    additionalRecipients: event?.additionalRecipients || '',
    marketSources: event?.marketSources || [],
    status: event?.status || 'Draft',
  });

  const updateEventData = (data: any) => {
    setEventData({ ...eventData, ...data });
  };

  // no-op handler for read-only mode — form components require onChange
  const noOp = () => {};

  const handleSave = () => {
    // Sync catCode to the shared store so Claims tab & other tabs see the change immediately
    setSharedCatCode(event?.id || '', eventData.catCode);
    toast.success('Event details updated successfully');
    setIsEditing(false);
    if (externalOnSave) {
      externalOnSave();
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset to original event data
    setEventData({
      eventId: event?.id || '',
      catCode: event?.catCode || '',
      eventName: event?.eventName || '',
      eventType: event?.eventType || '',
      everestEventType: event?.everestEventType || '',
      eventSubType: event?.eventSubType || '',
      peril: event?.peril || '',
      lossDate: event?.lossDate || '',
      lossStartDate: event?.lossStartDate || '',
      lossEndDate: event?.lossEndDate || '',
      owner: event?.owner || '',
      businessUnit: event?.businessUnit || '',
      region: event?.region || '',
      shortDescription: event?.shortDescription || '',
      longDescription: event?.description || '',
      impactedCountries: event?.impactedCountries || [],
      impactedStates: event?.impactedStates || [],
      impactedPerils: event?.impactedPerils || [],
      premiumAllocation: event?.premiumAllocation || '',
      reportingLine: event?.reportingLine || '',
      businessGroups: event?.businessGroups || [],
      externalIds: event?.externalIds || [],
      marketLossLow: event?.marketLossLow || '',
      marketLossMed: event?.marketLossMed || '',
      marketLossHigh: event?.marketLossHigh || '',
      estimateSource: event?.estimateSource || '',
      severityLevel: event?.severityLevel || '',
      marketLossComments: event?.marketLossComments || '',
      trackImmediately: event?.trackImmediately || false,
      operationalSummary: event?.operationalSummary || '',
      deadline1: event?.deadline1 || '',
      deadline2: event?.deadline2 || '',
      deadline3: event?.deadline3 || '',
      deadline4: event?.deadline4 || '',
      functionalTeams: event?.functionalTeams || [],
      executiveAreas: event?.executiveAreas || [],
      additionalRecipients: event?.additionalRecipients || '',
      marketSources: event?.marketSources || [],
      status: event?.status || 'Draft',
    });
    if (externalOnCancel) {
      externalOnCancel();
    }
  };

  // Section config — same numbered sections as the creation wizard
  const sections: { num: number; title: string; content: React.ReactNode }[] = [
    {
      num: 1,
      title: 'Event Identity & Core Metadata',
      content: <EventIdentity data={eventData} onChange={isEditing ? updateEventData : noOp} />,
    },
    {
      num: 2,
      title: 'Impact Regions & Perils',
      content: <ImpactRegionsPerils data={eventData} onChange={isEditing ? updateEventData : noOp} />,
    },
    {
      num: 3,
      title: 'Other IDs',
      content: <OtherIds data={eventData} onChange={isEditing ? updateEventData : noOp} />,
    },
    {
      num: 4,
      title: 'Market Loss Estimates',
      content: <MarketLoss data={eventData} onChange={isEditing ? updateEventData : noOp} />,
    },
    {
      num: 5,
      title: 'Deadlines & Operational Tracking',
      content: <DeadlinesTracking data={eventData} onChange={isEditing ? updateEventData : noOp} />,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header with mode indicator + Edit/Save buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div>
            <h2>Event Details</h2>
            <p className="text-gray-500 text-sm mt-1">
              {isEditing ? 'Editing event information — changes are not saved until you click Save.' : 'Viewing event information and metadata.'}
            </p>
          </div>
          {/* Mode badge */}
          {!isEditing && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 border border-slate-200 text-slate-600 rounded-full text-xs">
              <Eye className="w-3 h-3" /> Read Only
            </span>
          )}
          {isEditing && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 border border-amber-200 text-amber-700 rounded-full text-xs">
              <Pencil className="w-3 h-3" /> Editing
            </span>
          )}
        </div>
        {canEdit && (
          <div>
            {isEditing ? (
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCancel}
                  className="flex items-center gap-2 px-6 py-2.5 bg-white border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-all font-medium"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-all font-medium"
                >
                  <CheckCircle className="w-4 h-4" />
                  Save Changes
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                <Edit2 className="w-4 h-4" />
                Edit
              </button>
            )}
          </div>
        )}
      </div>

      {/* Sections — same form components as the creation wizard */}
      {sections.map((section) => (
        <div key={section.num} className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {/* Section header */}
          <div className="px-6 py-4 border-b bg-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-7 h-7 rounded flex items-center justify-center text-sm font-medium border ${isEditing ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-500 text-white border-slate-500'}`}>
                {section.num}
              </div>
              <h3 className="text-base">{section.title}</h3>
            </div>
            {!isEditing && (
              <span className="flex items-center gap-1 text-[10px] text-slate-400">
                <Lock className="w-3 h-3" /> Read only
              </span>
            )}
          </div>
          {/* Section body — pointer-events-none in read-only mode */}
          <div className={`px-6 py-6 bg-white transition-opacity ${!isEditing ? 'pointer-events-none opacity-75 select-none' : ''}`}>
            {section.content}
          </div>
        </div>
      ))}
    </div>
  );
}