import { ChevronDown, ChevronRight, Clock, CheckCircle2, XCircle, BarChart3, Building2, ChevronsDownUp, ChevronsUpDown } from 'lucide-react';
import { useUWPortfolio } from '../../lib/uwPortfolioContext';
import { BU_HIERARCHY, ALL_PARENT_IDS, type BUNode } from '../../lib/buHierarchy';

// ─── Compact currency formatter ───────────────────────────────────────────────
function fmtM(value: number): string {
  if (!value || isNaN(value) || value === 0) return '$0.00M';
  const m = value / 1e6;
  if (Math.abs(m) >= 100) return `$${m.toFixed(1)}M`;
  if (Math.abs(m) >= 1) return `$${m.toFixed(2)}M`;
  return `$${m.toFixed(3)}M`;
}

// ─── BUTreeNode ───────────────────────────────────────────────────────────────
function BUTreeNode({ node, depth }: { node: BUNode; depth: number }) {
  const { selectedBU, setSelectedBU, expandedNodes, toggleExpand, contractCounts, impactedCounts, buStatuses } = useUWPortfolio();
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expandedNodes.has(node.id);
  const isSelected = selectedBU === node.id;
  const count = contractCounts[node.id] || 0;
  const impacted = impactedCounts[node.id] || 0;
  const status = buStatuses[node.id];

  return (
    <div>
      <div
        className={`flex items-center gap-1 py-1 px-2 cursor-pointer rounded transition-colors text-[11px] group ${
          isSelected
            ? 'bg-white/20 text-white border-l-2 border-white'
            : 'text-white/70 hover:bg-white/10 hover:text-white border-l-2 border-transparent'
        }`}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        onClick={() => setSelectedBU(node.id)}
      >
        {hasChildren ? (
          <button
            className="p-0.5 hover:bg-white/20 rounded shrink-0"
            onClick={(e) => { e.stopPropagation(); toggleExpand(node.id); }}
          >
            {isExpanded
              ? <ChevronDown className="w-2.5 h-2.5" />
              : <ChevronRight className="w-2.5 h-2.5" />}
          </button>
        ) : <span className="w-3.5" />}
        <span className={`truncate flex-1 ${depth === 0 ? 'font-semibold' : ''}`}>{node.name}</span>
        <span className="shrink-0 flex items-center gap-0.5">
          {status === 'pending-approval' && <Clock className="w-2.5 h-2.5 text-amber-300" />}
          {status === 'approved' && <CheckCircle2 className="w-2.5 h-2.5 text-green-300" />}
          {status === 'rejected' && <XCircle className="w-2.5 h-2.5 text-red-300" />}
          {count > 0 && (
            <span className="text-[9px] bg-white/15 text-white/80 px-1 py-0.5 rounded">{count}</span>
          )}
          {impacted > 0 && (
            <span className="text-[9px] bg-green-500/30 text-green-200 px-1 py-0.5 rounded">{impacted}</span>
          )}
        </span>
      </div>
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map(child => (
            <BUTreeNode key={child.id} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── PortfolioSidebar ─────────────────────────────────────────────────────────
export function PortfolioSidebar() {
  const {
    selectedBU, setSelectedBU,
    expandedNodes, setExpandedNodes,
    portfolioStats, displayCurrency, totalEstimatesCount,
  } = useUWPortfolio();

  const allExpanded = ALL_PARENT_IDS.every(id => expandedNodes.has(id));

  return (
    <div className="border-t border-white/10 flex flex-col">
      {/* Header */}
      <div className="px-3 py-2 border-b border-white/10 bg-white/5">
        <div className="flex items-center justify-between mb-0.5">
          <div className="flex items-center gap-1.5">
            <Building2 className="w-3 h-3 text-white/70" />
            <span className="text-[10px] font-semibold text-white/80 tracking-widest uppercase">Portfolio</span>
          </div>
          <button
            onClick={() => setExpandedNodes(allExpanded ? new Set() : new Set(ALL_PARENT_IDS))}
            className="flex items-center gap-0.5 px-1 py-0.5 rounded text-[9px] text-white/50 hover:text-white/80 hover:bg-white/10 transition-colors"
            title={allExpanded ? 'Collapse all' : 'Expand all'}
          >
            {allExpanded
              ? <><ChevronsDownUp className="w-2.5 h-2.5" /><span>Collapse</span></>
              : <><ChevronsUpDown className="w-2.5 h-2.5" /><span>Expand</span></>}
          </button>
        </div>

        {/* Stats mini-card */}
        

        {/* All Contracts button */}
        <button
          className={`w-full flex items-center gap-1.5 px-2 py-1.5 mt-1.5 rounded text-[11px] transition-colors ${
            selectedBU === null
              ? 'bg-white/20 text-white'
              : 'text-white/70 hover:bg-white/10 hover:text-white'
          }`}
          onClick={() => setSelectedBU(null)}
        >
          <BarChart3 className="w-3 h-3 shrink-0" />
          <span className="font-medium">All Contracts</span>
          <span className={`ml-auto text-[9px] px-1.5 py-0.5 rounded ${
            selectedBU === null ? 'bg-white/20 text-white' : 'bg-white/10 text-white/60'
          }`}>
            {totalEstimatesCount}
          </span>
        </button>
      </div>

      {/* BU Tree */}
      <div className="py-1">
        {BU_HIERARCHY.map(node => (
          <BUTreeNode key={node.id} node={node} depth={0} />
        ))}
      </div>
    </div>
  );
}