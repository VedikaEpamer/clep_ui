// Modern table styling component for LLEP
export const modernTableStyles = `
  .modern-table {
    @apply bg-white border border-slate-200 overflow-hidden shadow-sm rounded-lg;
  }
  
  .modern-table-header {
    @apply px-5 py-3 flex items-center justify-between;
    background: linear-gradient(135deg, #0052FF 0%, #005587 100%);
  }
  
  .modern-table thead tr {
    @apply bg-gradient-to-r from-slate-50 to-slate-100 border-b-2 border-slate-300;
  }
  
  .modern-table tbody tr:nth-child(even) {
    @apply bg-slate-50/50;
  }
  
  .modern-table tbody tr:hover {
    @apply bg-gradient-to-r from-blue-50 to-transparent transition-all duration-150;
  }
  
  .rank-badge {
    @apply w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow-sm;
  }
  
  .rank-badge-top {
    background: linear-gradient(135deg, #0052FF 0%, #0052FF 100%);
    @apply text-white;
  }
  
  .rank-badge-regular {
    @apply bg-slate-200 text-slate-600;
  }
`;