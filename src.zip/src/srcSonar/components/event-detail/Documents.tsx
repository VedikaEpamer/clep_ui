import { useState } from 'react';
import { Upload, Download, FileText, File, Trash2, Eye, Search } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useParams } from 'react-router';
import { mockEvents } from '../../lib/mockData';
import { useWorkflow } from '../../lib/workflowContext';
import { downloadCSV } from '../../lib/exportUtils';

interface Document {
  id: string;
  name: string;
  category: string;
  uploadedBy: string;
  uploadedByUser: string;
  businessUnit: string;
  uploadedAt: string;
  size: string;
  type: string;
}

const mockDocuments: Document[] = [
  {
    id: '1',
    name: 'Hurricane_Milton_UW_Estimates_v3.xlsx',
    category: 'Underwriting Estimate',
    uploadedBy: 'International Treaty',
    uploadedByUser: 'John Mitchell',
    businessUnit: 'Latin America / Brazil Treaty',
    uploadedAt: '2024-11-28 14:32',
    size: '2.4 MB',
    type: 'excel'
  },
  {
    id: '2',
    name: 'Milton_Model_Output_Final.xlsx',
    category: 'Model Output',
    uploadedBy: 'Cat Modeling',
    uploadedByUser: 'Sarah Chen',
    businessUnit: 'US Treaty Property',
    uploadedAt: '2024-11-28 09:15',
    size: '5.1 MB',
    type: 'excel'
  },
  {
    id: '3',
    name: 'Milton_Model_Output_Contracts.xlsx',
    category: 'Model Output',
    uploadedBy: 'NA Fac',
    uploadedByUser: 'Michael Torres',
    businessUnit: 'North America Fac',
    uploadedAt: '2024-11-27 16:45',
    size: '1.2 MB',
    type: 'excel'
  },
  {
    id: '4',
    name: 'Finance_Net_Position_Report.xlsx',
    category: 'Finance Net Calculations',
    uploadedBy: 'Financial Lines',
    uploadedByUser: 'Emily Rodriguez',
    businessUnit: 'Financial Lines',
    uploadedAt: '2024-11-26 11:20',
    size: '3.8 MB',
    type: 'excel'
  },
  {
    id: '5',
    name: 'Market_Loss_Analysis.pdf',
    category: 'Supporting Document',
    uploadedBy: 'Specialty',
    uploadedByUser: 'David Park',
    businessUnit: 'London Treaty',
    uploadedAt: '2024-11-25 10:05',
    size: '1.5 MB',
    type: 'pdf'
  }
];

const categories = [
  'All Categories',
  'Model Output',
  'Underwriting Estimate',
  'Finance Net Calculations',
  'Supporting Document'
];

export function Documents() {
  const { eventId } = useParams();
  const event = mockEvents.find(e => e.id === eventId);
  const { getWorkflowStatus, getEventStatus } = useWorkflow();
  const [documents] = useState<Document[]>(mockDocuments);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All Categories');

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'All Categories' || doc.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getFileIcon = (type: string) => {
    if (type === 'pdf') return <File className="w-5 h-5 text-red-600" />;
    if (type === 'excel') return <FileText className="w-5 h-5 text-green-600" />;
    return <FileText className="w-5 h-5 text-gray-600" />;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event?.eventName}</h1>
                <h1 className="text-slate-600">- Documents</h1>
                {(() => {
                  const phase = getWorkflowStatus(eventId || '').currentPhase;
                  const phaseBadge: Record<string, string> = {
                    'Event Creation': 'bg-slate-100 text-slate-700 border-slate-200',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-200',
                    'Estimation & Approval': 'bg-amber-50 text-amber-700 border-amber-200',
                    'Finance Review': 'bg-blue-50 text-blue-700 border-blue-200',
                    'Reporting & Close': 'bg-emerald-50 text-emerald-700 border-emerald-200',
                    'Reopened': 'bg-red-50 text-red-700 border-red-200',
                  };
                  const phaseDisplayLabels: Record<string, string> = {
                    'Event Creation': 'Event Creation',
                    'Monitoring': 'Monitoring',
                    'Estimation & Approval': 'UW Estimation',
                    'Finance Review': 'Finance Review',
                    'Reporting & Close': 'Reporting & Close',
                    'Reopened': 'Reopened',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${phaseBadge[phase] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {phaseDisplayLabels[phase] || phase}
                    </span>
                  );
                })()}
                {(() => {
                  const status = getEventStatus(eventId || '');
                  const statusBadge: Record<string, string> = {
                    'Draft': 'bg-slate-100 text-slate-700 border-slate-300',
                    'Monitoring': 'bg-cyan-50 text-cyan-700 border-cyan-300',
                    'Open': 'bg-blue-50 text-blue-700 border-blue-300',
                    'Close Monitor': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                    'Close Archived': 'bg-slate-100 text-slate-600 border-slate-300',
                    'Reopened': 'bg-red-50 text-red-700 border-red-300',
                  };
                  return (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium border ${statusBadge[status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                      {status}
                    </span>
                  );
                })()}
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event?.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Type of Everest Event:</span>
                  <span className="text-slate-900">{event?.everestEventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Type:</span>
                  <span className="text-slate-900">{event?.eventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Sub-Type:</span>
                  <span className="text-slate-900">{event?.eventSubType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event?.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{event?.lossDate ? new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-10 py-8">
        {/* Action Bar */}
        <div className="flex items-center justify-end mb-6">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const input = document.createElement('input');
                input.type = 'file';
                input.multiple = true;
                input.accept = '.xlsx,.xls,.csv,.pdf,.doc,.docx,.pptx,.txt';
                input.onchange = (e) => {
                  const files = (e.target as HTMLInputElement).files;
                  if (files && files.length > 0) {
                    Array.from(files).forEach(f => {
                      toast.success(`"${f.name}" uploaded successfully`);
                    });
                  }
                };
                input.click();
              }}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              Import
            </button>
            
          </div>
        </div>

        {/* Documents Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Document</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Document Type</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Team</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Business Unit</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Uploaded By</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Upload Date</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Size</th>
                <th className="px-6 py-3 text-left text-xs uppercase tracking-wider text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredDocuments.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {getFileIcon(doc.type)}
                      <div className="text-sm">{doc.name}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4"><span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">{doc.category}</span></td>
                  <td className="px-6 py-4 text-sm">{doc.uploadedBy}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs">{doc.businessUnit}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-700">{doc.uploadedByUser}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{doc.uploadedAt}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{doc.size}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const headers = ['Document', 'Category', 'Team', 'Business Unit', 'Uploaded By', 'Upload Date', 'Size'];
                          const rows = [[doc.name, doc.category, doc.uploadedBy, doc.businessUnit, doc.uploadedByUser, doc.uploadedAt, doc.size]];
                          downloadCSV(headers, rows, `SONAR_Documents_${event?.eventName || eventId}_${doc.name.replace(/\.[^.]+$/, '')}`);
                          toast.success(`"${doc.name}" exported to CSV`);
                        }}
                        className="flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium bg-white text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-slate-400 transition-colors shadow-sm" title="Export row as CSV">
                        <Download className="w-3.5 h-3.5" />
                        Export
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredDocuments.length === 0 && (
          <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="mb-2">No documents found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}