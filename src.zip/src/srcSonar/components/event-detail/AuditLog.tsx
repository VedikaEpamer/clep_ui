import { useParams } from 'react-router';
import { mockEvents } from '../../lib/mockData';
import { useWorkflow } from '../../lib/workflowContext';
import { downloadCSV } from '../../lib/exportUtils';
import { toast } from 'sonner@2.0.3';
import { 
  History, 
  Upload, 
  Trash2, 
  CheckCircle, 
  XCircle, 
  FileText, 
  UserPlus, 
  Edit, 
  Download,
  Filter,
  Search,
  ChevronDown,
  ChevronRight,
  Calendar,
  User
} from 'lucide-react';
import { Fragment } from 'react';

type AuditActionType = 
  | 'upload' 
  | 'delete' 
  | 'validation' 
  | 'approval' 
  | 'rejection'
  | 'assignment'
  | 'status_change'
  | 'report_generation'
  | 'data_change';

interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  userRole: string;
  action: AuditActionType;
  description: string;
  details?: {
    field?: string;
    oldValue?: string;
    newValue?: string;
    fileName?: string;
    affectedContracts?: number;
    assignedTo?: string;
    reason?: string;
  };
  ipAddress?: string;
}

const actionConfig: Record<AuditActionType, { icon: any; color: string; label: string }> = {
  upload: { icon: Upload, color: 'text-blue-600 bg-blue-50', label: 'Upload' },
  delete: { icon: Trash2, color: 'text-red-600 bg-red-50', label: 'Delete' },
  validation: { icon: CheckCircle, color: 'text-green-600 bg-green-50', label: 'Validation' },
  approval: { icon: CheckCircle, color: 'text-green-600 bg-green-50', label: 'Approval' },
  rejection: { icon: XCircle, color: 'text-red-600 bg-red-50', label: 'Rejection' },
  assignment: { icon: UserPlus, color: 'text-purple-600 bg-purple-50', label: 'Assignment' },
  status_change: { icon: Edit, color: 'text-amber-600 bg-amber-50', label: 'Status Change' },
  report_generation: { icon: FileText, color: 'text-indigo-600 bg-indigo-50', label: 'Report' },
  data_change: { icon: Edit, color: 'text-slate-600 bg-slate-50', label: 'Data Change' }
};

// Mock audit data
const mockAuditLog: AuditLogEntry[] = [
  {
    id: '1',
    timestamp: '2024-11-28T14:32:00',
    user: 'Cat Modeling Team',
    userRole: 'CAT Modeling',
    action: 'upload',
    description: 'Uploaded model output file',
    details: {
      fileName: 'Milton_Model_Output_v3.xlsx',
      affectedContracts: 812
    },
    ipAddress: '10.125.45.67'
  },
  {
    id: '2',
    timestamp: '2024-11-28T14:28:00',
    user: 'Cat Modeling Team',
    userRole: 'CAT Modeling',
    action: 'validation',
    description: 'Validated model results against RDM',
    details: {
      affectedContracts: 812
    },
    ipAddress: '10.125.45.67'
  },
  {
    id: '3',
    timestamp: '2024-11-28T13:15:00',
    user: 'Underwriting Team',
    userRole: 'Underwriting Manager',
    action: 'approval',
    description: 'Approved underwriter estimates for Property division',
    details: {
      affectedContracts: 124,
      reason: 'All estimates reviewed and validated'
    },
    ipAddress: '10.125.45.89'
  },
  {
    id: '4',
    timestamp: '2024-11-28T12:45:00',
    user: 'Underwriting Team',
    userRole: 'Underwriter',
    action: 'upload',
    description: 'Uploaded contract estimates',
    details: {
      fileName: 'Property_Estimates_Nov28.xlsx',
      affectedContracts: 124
    },
    ipAddress: '10.125.45.92'
  },
  {
    id: '5',
    timestamp: '2024-11-28T11:30:00',
    user: 'Finance Team',
    userRole: 'Finance',
    action: 'assignment',
    description: 'Assigned estimation tasks to Property business unit',
    details: {
      assignedTo: 'Property Team'
    },
    ipAddress: '10.125.45.45'
  },
  {
    id: '6',
    timestamp: '2024-11-28T10:15:00',
    user: 'Cat Modeling Team',
    userRole: 'CAT Modeling',
    action: 'data_change',
    description: 'Updated modeling decision',
    details: {
      field: 'Modeling Decision',
      oldValue: 'Pending',
      newValue: 'Modeled'
    },
    ipAddress: '10.125.45.67'
  },
  {
    id: '7',
    timestamp: '2024-11-28T09:00:00',
    user: 'Finance Team',
    userRole: 'Finance',
    action: 'status_change',
    description: 'Changed event status',
    details: {
      field: 'Event Status',
      oldValue: 'Initial Assessment',
      newValue: 'Estimation In Progress'
    },
    ipAddress: '10.125.45.45'
  },
  {
    id: '8',
    timestamp: '2024-11-27T16:30:00',
    user: 'Cat Modeling Team',
    userRole: 'CAT Modeling',
    action: 'delete',
    description: 'Deleted outdated model output',
    details: {
      fileName: 'Milton_Model_Output_v1_old.xlsx'
    },
    ipAddress: '10.125.45.67'
  },
  {
    id: '9',
    timestamp: '2024-11-27T15:20:00',
    user: 'Underwriting Team',
    userRole: 'Underwriting Manager',
    action: 'rejection',
    description: 'Rejected estimates for revision',
    details: {
      affectedContracts: 15,
      reason: 'Estimates require additional validation and justification'
    },
    ipAddress: '10.125.45.89'
  },
  {
    id: '10',
    timestamp: '2024-11-27T14:00:00',
    user: 'Finance Team',
    userRole: 'Finance',
    action: 'report_generation',
    description: 'Generated loss summary report',
    details: {
      fileName: 'Milton_Loss_Summary_Nov27.pdf'
    },
    ipAddress: '10.125.45.45'
  }
];

export function AuditLog() {
  const { eventId } = useParams();
  const event = mockEvents.find(e => e.id === eventId);
  const { getWorkflowStatus, getEventStatus } = useWorkflow();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-10 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-3">
                <h1 className="text-slate-900">{event?.eventName}</h1>
                <h1 className="text-slate-600">- Audit Log</h1>
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event ID:</span>
                  <span className="text-blue-600" style={{ color: '#0052FF' }}>{event?.id}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Type of Everest Event:</span>
                  <span className="text-slate-900">{event?.everestEventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Type:</span>
                  <span className="text-slate-900">{event?.eventType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Event Sub-Type:</span>
                  <span className="text-slate-900">{event?.eventSubType}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Region:</span>
                  <span className="text-slate-900">{event?.region}</span>
                </div>
                <div className="w-px h-4 bg-slate-300" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Loss Date:</span>
                  <span className="text-slate-900">{event?.lossDate ? new Date(event.lossDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-10 py-8 space-y-6">
        {/* Action Bar */}
        <div className="flex items-center justify-end">
          <button
            onClick={() => {
              const headers = ['Timestamp', 'User', 'Role', 'Action', 'Description', 'IP Address'];
              const rows = mockAuditLog.map(e => [e.timestamp, e.user, e.userRole, actionConfig[e.action].label, e.description, e.ipAddress ?? '']);
              downloadCSV(headers, rows, `SONAR_Audit_Log_${event?.eventName || eventId}`);
              toast.success('Audit Log exported to CSV');
            }}
            className="flex items-center gap-2 px-4 py-2 bg-everest-blue text-white rounded-lg hover:bg-[#0041CC] transition-all">
            <Download className="w-4 h-4" />
            Export Log
          </button>
        </div>

        {/* Power BI Dashboard Embed */}
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden" style={{ height: 'calc(100vh - 300px)' }}>
          <div className="w-full h-full flex items-center justify-center bg-slate-50">
            <div className="text-center p-8">
              <History className="w-16 h-16 text-everest-blue mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Power BI Audit Log Dashboard</h3>
              <p className="text-slate-600 mb-4 max-w-md">
                Connect your Power BI workspace to display comprehensive audit analytics and visualizations
              </p>
              <div className="bg-slate-100 rounded-lg p-4 text-left text-sm text-slate-700 max-w-lg mx-auto">
                <p className="font-semibold mb-2">To embed your dashboard:</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Get your Power BI report embed URL</li>
                  <li>Configure the embed token</li>
                  <li>Replace the placeholder with the iframe</li>
                </ol>
              </div>
              {/* Placeholder for Power BI iframe */}
              {/* <iframe 
                title="Audit Log Dashboard"
                width="100%"
                height="100%"
                src="YOUR_POWER_BI_EMBED_URL"
                frameBorder="0"
                allowFullScreen={true}
              ></iframe> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}