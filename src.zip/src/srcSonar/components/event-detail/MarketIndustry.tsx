import { useState } from 'react';
import { Plus, Trash2, Lock, Unlock, ChevronDown, ChevronUp, TrendingUp, Globe, Building2 } from 'lucide-react';

interface MarketSource {
  id: string;
  source: string;
  customSource: string;
  lowEstimate: string;
  medEstimate: string;
  highEstimate: string;
  asOfDate: string;
  notes: string;
}

const PREDEFINED_SOURCES = [
  'Swiss Re',
  'Munich Re',
  'PCS',
  'NOAA',
  'AIR Worldwide',
  'Verisk',
  'Moody\'s RMS',
  'Aon',
  'Guy Carpenter',
  'Gallagher Re',
  'Howden',
  'CoreLogic',
  'Karen Clark & Co',
  'PERILS AG',
  'Other'
];

const createEmptySource = (): MarketSource => ({
  id: `src-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
  source: '',
  customSource: '',
  lowEstimate: '',
  medEstimate: '',
  highEstimate: '',
  asOfDate: '',
  notes: ''
});

// Sample pre-populated sources for demo
const SAMPLE_SOURCES: MarketSource[] = [
  {
    id: 'src-sample-1',
    source: 'Swiss Re',
    customSource: '',
    lowEstimate: '6,000',
    medEstimate: '8,000',
    highEstimate: '10,000',
    asOfDate: '2026-02-15',
    notes: 'Preliminary sigma estimate'
  },
  {
    id: 'src-sample-2',
    source: 'Aon',
    customSource: '',
    lowEstimate: '7,500',
    medEstimate: '8,500',
    highEstimate: '11,000',
    asOfDate: '2026-02-18',
    notes: 'Based on Impact Forecasting model'
  },
  {
    id: 'src-sample-3',
    source: 'Guy Carpenter',
    customSource: '',
    lowEstimate: '6,500',
    medEstimate: '9,000',
    highEstimate: '12,500',
    asOfDate: '2026-02-20',
    notes: 'Updated with latest aftershock data'
  },
  {
    id: 'src-sample-4',
    source: 'Moody\'s RMS',
    customSource: '',
    lowEstimate: '5,800',
    medEstimate: '8,200',
    highEstimate: '10,500',
    asOfDate: '2026-02-22',
    notes: 'RiskLink v23 run'
  }
];

export function MarketIndustry() {
  const [marketSources, setMarketSources] = useState<MarketSource[]>(SAMPLE_SOURCES);
  const [consensusLocked, setConsensusLocked] = useState(true);
  const [sourcesExpanded, setSourcesExpanded] = useState(true);
  const [consensusExpanded, setConsensusExpanded] = useState(true);

  // Consensus values
  const [consensusLow, setConsensusLow] = useState('7,000');
  const [consensusMed, setConsensusMed] = useState('8,500');
  const [consensusHigh, setConsensusHigh] = useState('11,000');
  const [severityLevel, setSeverityLevel] = useState('severe');
  const [consensusComments, setConsensusComments] = useState(
    'Based on weighted average of 4 external sources. Accounts for aftershock sequence and secondary perils (tsunami, fire following). Range reflects uncertainty in insured vs. economic loss split for Chile market.'
  );

  const severityLevels = [
    { value: 'minor', label: 'Minor', color: 'bg-green-100 text-green-700', borderColor: 'border-green-400' },
    { value: 'moderate', label: 'Moderate', color: 'bg-yellow-100 text-yellow-700', borderColor: 'border-yellow-400' },
    { value: 'major', label: 'Major', color: 'bg-orange-100 text-orange-700', borderColor: 'border-orange-400' },
    { value: 'severe', label: 'Severe', color: 'bg-red-100 text-red-700', borderColor: 'border-red-400' },
    { value: 'catastrophic', label: 'Catastrophic', color: 'bg-purple-100 text-purple-700', borderColor: 'border-purple-400' }
  ];

  const addSource = () => {
    setMarketSources(prev => [...prev, createEmptySource()]);
  };

  const removeSource = (id: string) => {
    setMarketSources(prev => prev.filter(s => s.id !== id));
  };

  const updateSource = (id: string, field: keyof MarketSource, value: string) => {
    setMarketSources(prev => prev.map(s => 
      s.id === id ? { ...s, [field]: value } : s
    ));
  };

  // Calculate summary stats from sources
  const sourcesWithLow = marketSources.filter(s => s.lowEstimate).map(s => parseFloat(s.lowEstimate.replace(/,/g, '')) || 0);
  const sourcesWithHigh = marketSources.filter(s => s.highEstimate).map(s => parseFloat(s.highEstimate.replace(/,/g, '')) || 0);
  const sourcesWithMed = marketSources.filter(s => s.medEstimate).map(s => parseFloat(s.medEstimate.replace(/,/g, '')) || 0);
  const rangeMin = sourcesWithLow.length > 0 ? Math.min(...sourcesWithLow) : 0;
  const rangeMax = sourcesWithHigh.length > 0 ? Math.max(...sourcesWithHigh) : 0;
  const avgMed = sourcesWithMed.length > 0 ? Math.round(sourcesWithMed.reduce((a, b) => a + b, 0) / sourcesWithMed.length) : 0;

  return (
    <div className="px-8 py-6 space-y-6 max-w-full">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-slate-900" style={{ fontSize: '1.25rem', fontWeight: 700 }}>Market Loss & Consensus</h2>
          <p className="text-sm text-slate-500 mt-1">
            Capture external market loss estimates and establish Everest's consensus view.
          </p>
        </div>
      </div>

      {/* Quick Stats Bar */}
      {marketSources.length > 0 && (
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <Globe className="w-4 h-4 text-blue-500" />
              <span className="text-xs text-slate-500" style={{ fontWeight: 500 }}>External Sources</span>
            </div>
            <div className="text-slate-900" style={{ fontSize: '1.5rem', fontWeight: 700 }}>{marketSources.length}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-xs text-slate-500" style={{ fontWeight: 500 }}>Range Low</span>
            </div>
            <div className="text-slate-900" style={{ fontSize: '1.5rem', fontWeight: 700 }}>${rangeMin.toLocaleString()}M</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-amber-500" />
              <span className="text-xs text-slate-500" style={{ fontWeight: 500 }}>Avg. Midpoint</span>
            </div>
            <div className="text-slate-900" style={{ fontSize: '1.5rem', fontWeight: 700 }}>${avgMed.toLocaleString()}M</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-red-500" />
              <span className="text-xs text-slate-500" style={{ fontWeight: 500 }}>Range High</span>
            </div>
            <div className="text-slate-900" style={{ fontSize: '1.5rem', fontWeight: 700 }}>${rangeMax.toLocaleString()}M</div>
          </div>
        </div>
      )}

      {/* ─── Section 1: External Market Sources ─── */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <button
          onClick={() => setSourcesExpanded(!sourcesExpanded)}
          className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-blue-500" />
            <h3 className="text-slate-900" style={{ fontSize: '0.95rem', fontWeight: 600 }}>External Market Sources</h3>
            <span className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
              {marketSources.length} source{marketSources.length !== 1 ? 's' : ''}
            </span>
          </div>
          {sourcesExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </button>

        {sourcesExpanded && (
          <div className="px-6 pb-6 space-y-4">
            <p className="text-xs text-slate-500">
              Capture multiple external market loss estimates from industry sources. Each source can provide Low / Best / High ranges with as-of dates.
            </p>

            {/* Sources Table */}
            {marketSources.length > 0 && (
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-3 py-2.5 text-left text-xs text-slate-600" style={{ fontWeight: 600 }}>Source</th>
                      <th className="px-3 py-2.5 text-right text-xs text-slate-600" style={{ fontWeight: 600 }}>Low ($M)</th>
                      <th className="px-3 py-2.5 text-right text-xs text-slate-600" style={{ fontWeight: 600 }}>Best ($M)</th>
                      <th className="px-3 py-2.5 text-right text-xs text-slate-600" style={{ fontWeight: 600 }}>High ($M)</th>
                      <th className="px-3 py-2.5 text-left text-xs text-slate-600" style={{ fontWeight: 600 }}>As-of Date</th>
                      <th className="px-3 py-2.5 text-left text-xs text-slate-600" style={{ fontWeight: 600 }}>Notes</th>
                      <th className="px-3 py-2.5 w-10"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {marketSources.map((source, idx) => (
                      <tr key={source.id} className={`border-b border-slate-100 ${idx % 2 === 1 ? 'bg-slate-50/50' : ''}`}>
                        <td className="px-3 py-2 min-w-[160px]">
                          <div className="space-y-1">
                            <select
                              value={source.source}
                              onChange={(e) => updateSource(source.id, 'source', e.target.value)}
                              className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                            >
                              <option value="">Select source...</option>
                              {PREDEFINED_SOURCES.map(s => (
                                <option key={s} value={s}>{s}</option>
                              ))}
                            </select>
                            {source.source === 'Other' && (
                              <input
                                type="text"
                                placeholder="Enter source name..."
                                value={source.customSource}
                                onChange={(e) => updateSource(source.id, 'customSource', e.target.value)}
                                className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                              />
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">$</span>
                            <input
                              type="text"
                              placeholder="0"
                              value={source.lowEstimate}
                              onChange={(e) => updateSource(source.id, 'lowEstimate', e.target.value.replace(/[^0-9,.]/g, ''))}
                              className="w-full pl-5 pr-2 py-1.5 text-xs text-right border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">$</span>
                            <input
                              type="text"
                              placeholder="0"
                              value={source.medEstimate}
                              onChange={(e) => updateSource(source.id, 'medEstimate', e.target.value.replace(/[^0-9,.]/g, ''))}
                              className="w-full pl-5 pr-2 py-1.5 text-xs text-right border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">$</span>
                            <input
                              type="text"
                              placeholder="0"
                              value={source.highEstimate}
                              onChange={(e) => updateSource(source.id, 'highEstimate', e.target.value.replace(/[^0-9,.]/g, ''))}
                              className="w-full pl-5 pr-2 py-1.5 text-xs text-right border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <input
                            type="date"
                            value={source.asOfDate}
                            onChange={(e) => updateSource(source.id, 'asOfDate', e.target.value)}
                            className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </td>
                        <td className="px-3 py-2">
                          <input
                            type="text"
                            placeholder="Optional notes..."
                            value={source.notes}
                            onChange={(e) => updateSource(source.id, 'notes', e.target.value)}
                            className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 min-w-[140px]"
                          />
                        </td>
                        <td className="px-3 py-2">
                          <button
                            onClick={() => removeSource(source.id)}
                            className="p-1 text-slate-400 hover:text-red-500 transition-colors rounded hover:bg-red-50"
                            title="Remove source"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Add Source Button */}
            <button
              onClick={addSource}
              className="flex items-center gap-1.5 px-3 py-2 text-xs text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
              style={{ fontWeight: 500 }}
            >
              <Plus className="w-3.5 h-3.5" />
              Add Market Source
            </button>

            {/* Summary bar */}
            {marketSources.length >= 2 && (
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="flex items-center gap-6 text-xs">
                  <span className="text-slate-500" style={{ fontWeight: 600 }}>Source Range Summary:</span>
                  <span className="text-slate-700">
                    Low: <span style={{ fontWeight: 600 }}>${rangeMin.toLocaleString()}M</span>
                  </span>
                  <span className="text-slate-700">
                    Avg Best: <span style={{ fontWeight: 600 }}>${avgMed.toLocaleString()}M</span>
                  </span>
                  <span className="text-slate-700">
                    High: <span style={{ fontWeight: 600 }}>${rangeMax.toLocaleString()}M</span>
                  </span>
                  <span className="text-slate-400">|</span>
                  <span className="text-slate-500">{marketSources.length} sources captured</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ─── Section 2: Everest Market Consensus ─── */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <button
          onClick={() => setConsensusExpanded(!consensusExpanded)}
          className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <h3 className="text-slate-900" style={{ fontSize: '0.95rem', fontWeight: 600 }}>Everest Market Consensus</h3>
            {consensusLocked && (
              <span className="flex items-center gap-1 text-xs text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                <Lock className="w-3 h-3" />
                Controlled
              </span>
            )}
          </div>
          {consensusExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </button>

        {consensusExpanded && (
          <div className="px-6 pb-6 space-y-5">
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500">
                Everest's internal consensus view of the market loss. This field has controlled edit rights — only authorized users can modify.
              </p>
              <button
                onClick={() => setConsensusLocked(!consensusLocked)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border transition-colors shrink-0 ml-4 ${
                  consensusLocked
                    ? 'text-amber-700 bg-amber-50 border-amber-200 hover:bg-amber-100'
                    : 'text-emerald-700 bg-emerald-50 border-emerald-200 hover:bg-emerald-100'
                }`}
                style={{ fontWeight: 500 }}
              >
                {consensusLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                {consensusLocked ? 'Unlock to Edit' : 'Lock Consensus'}
              </button>
            </div>

            <div className={`space-y-5 transition-opacity ${consensusLocked ? 'opacity-60 pointer-events-none' : ''}`}>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-700 mb-1.5 text-xs" style={{ fontWeight: 500 }}>
                    Consensus Low ($ millions)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" style={{ fontWeight: 500 }}>$</span>
                    <input
                      type="text"
                      placeholder="0"
                      value={consensusLow}
                      onChange={(e) => setConsensusLow(e.target.value.replace(/[^0-9,.]/g, ''))}
                      disabled={consensusLocked}
                      className="w-full pl-8 pr-20 py-2.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all disabled:bg-slate-50"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs">millions</span>
                  </div>
                </div>
                <div>
                  <label className="block text-slate-700 mb-1.5 text-xs" style={{ fontWeight: 500 }}>
                    Consensus Best ($ millions)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" style={{ fontWeight: 500 }}>$</span>
                    <input
                      type="text"
                      placeholder="0"
                      value={consensusMed}
                      onChange={(e) => setConsensusMed(e.target.value.replace(/[^0-9,.]/g, ''))}
                      disabled={consensusLocked}
                      className="w-full pl-8 pr-20 py-2.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all disabled:bg-slate-50"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs">millions</span>
                  </div>
                </div>
                <div>
                  <label className="block text-slate-700 mb-1.5 text-xs" style={{ fontWeight: 500 }}>
                    Consensus High ($ millions)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" style={{ fontWeight: 500 }}>$</span>
                    <input
                      type="text"
                      placeholder="0"
                      value={consensusHigh}
                      onChange={(e) => setConsensusHigh(e.target.value.replace(/[^0-9,.]/g, ''))}
                      disabled={consensusLocked}
                      className="w-full pl-8 pr-20 py-2.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all disabled:bg-slate-50"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs">millions</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-2 text-xs" style={{ fontWeight: 500 }}>Severity Level</label>
                <div className="grid grid-cols-5 gap-3">
                  {severityLevels.map(level => (
                    <button
                      key={level.value}
                      type="button"
                      onClick={() => setSeverityLevel(level.value)}
                      disabled={consensusLocked}
                      className={`px-4 py-2.5 rounded-md border-2 transition-all text-xs ${
                        severityLevel === level.value
                          ? `${level.color} ${level.borderColor} shadow-sm`
                          : 'border-slate-200 hover:border-slate-300 text-slate-600'
                      }`}
                      style={{ fontWeight: severityLevel === level.value ? 600 : 400 }}
                    >
                      {level.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-1.5 text-xs" style={{ fontWeight: 500 }}>Consensus Rationale / Comments</label>
                <textarea
                  rows={3}
                  placeholder="Enter rationale for Everest's consensus view, including any caveats or assumptions..."
                  value={consensusComments}
                  onChange={(e) => setConsensusComments(e.target.value)}
                  disabled={consensusLocked}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all resize-none disabled:bg-slate-50"
                />
              </div>
            </div>

            {consensusLocked && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2">
                <Lock className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                <p className="text-xs text-amber-800">
                  The Everest Market Consensus is locked. Only authorized users (Cat Modeling Lead, CUO, or CFO) can unlock and edit this field. Click "Unlock to Edit" if you have the required permissions.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Info box */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
        <h4 className="text-xs text-slate-900 mb-1.5" style={{ fontWeight: 600 }}>About Market Loss & Consensus</h4>
        <p className="text-xs text-slate-600 leading-relaxed">
          External Market Sources capture third-party loss estimates as they are published. The Everest Market Consensus represents leadership's
          agreed-upon view and is used downstream for UW estimation comparisons, reserving benchmarks, and executive reporting.
        </p>
      </div>
    </div>
  );
}
