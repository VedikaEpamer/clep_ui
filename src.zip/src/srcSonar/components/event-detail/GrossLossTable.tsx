import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { FileText, XCircle, Filter, X } from 'lucide-react';

export interface LossByContractRow {
  inUWEst: boolean;
  layerkey: string;
  department: string;
  company: string;
  subtype: string;
  contract: string;
  everestLimit: string;
  limit100: string;
  retention: string;
  aggregateDeductible: string;
  terms: string;
  rol: string;
  share: string;
  event1Gross: string;
  event2Gross: string;
  event3Gross: string;
  netOfLogan: string;
  netOfAllCessions: string;
  expectedRIPs: string;
}

interface GrossLossTableProps {
  data: LossByContractRow[];
  invalidContracts: string[];
  eventNames?: [string, string, string];
}

/** Flat display row: one row per contract-event combination */
interface FlatDisplayRow {
  _id: string;
  _contractGroup: string;
  _isFirstInGroup: boolean;
  _eventIndex: number;
  eventLabel: string;
  inUWEst: boolean;
  layerkey: string;
  department: string;
  company: string;
  subtype: string;
  contract: string;
  everestLimit: string;
  limit100: string;
  retention: string;
  aggregateDeductible: string;
  terms: string;
  rol: string;
  share: string;
  grossLoss: string;
  netOfLogan: string;
  netOfAllCessions: string;
  expectedRIPs: string;
}

const SKELETON_HEADERS = ['#', 'Layerkey', 'Department', 'Company', 'Subtype', 'Contract', 'Event', 'Everest Limit', 'Gross Loss'];

function GrossLossTableSkeleton() {
  return (
    <div className="w-full">
      <div className="flex items-center border-b border-slate-200 bg-slate-50 px-3 py-2 gap-4">
        {SKELETON_HEADERS.map((h) => (
          <div key={h} className="text-[0.7rem] font-semibold uppercase text-slate-500 whitespace-nowrap">{h}</div>
        ))}
      </div>
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-3 py-2.5 border-b border-slate-100">
          {Array.from({ length: 10 }).map((_, j) => (
            <div key={j} className="h-3.5 rounded bg-slate-200 animate-pulse" style={{ width: `${50 + (j * 12) % 70}px` }} />
          ))}
        </div>
      ))}
      <div className="flex items-center justify-center py-6 text-sm text-slate-400">Loading table data...</div>
    </div>
  );
}

function fmtNum(val: string): string {
  if (!val || val === '-' || val === 'NULL' || val === '-   ') return '-';
  const cleaned = val.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '');
  const num = Number(cleaned);
  if (isNaN(num)) return val.trim();
  if (num === 0) return '-';
  const abs = Math.abs(num);
  const formatted = abs >= 1e9
    ? `${(abs / 1e6).toLocaleString('en-US', { maximumFractionDigits: 0 })}`
    : abs >= 1e6
    ? `${(abs / 1e6).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}`
    : abs.toLocaleString('en-US', { maximumFractionDigits: 0 });
  return num < 0 ? `(${formatted})` : formatted;
}

/** Derive a net value by applying the same multiplier used for gross derivation */
function _deriveNet(netStr: string, multiplier: number): string {
  if (!netStr || netStr === '-' || netStr === 'NULL') return '-';
  const cleaned = netStr.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '');
  const num = Number(cleaned);
  if (isNaN(num) || num === 0) return '-';
  const derived = Math.round(num * multiplier);
  return derived.toLocaleString('en-US');
}

// Sort icon components
function SortUnsorted() {
  return (
    <div className="flex flex-col items-center gap-0.5 ml-1 shrink-0">
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#9ca3af' }}><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#9ca3af' }}><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
    </div>
  );
}
function SortAsc() {
  return (
    <div className="flex flex-col items-center gap-0.5 ml-1 shrink-0">
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#2563eb' }}><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#d1d5db' }}><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
    </div>
  );
}
function SortDesc() {
  return (
    <div className="flex flex-col items-center gap-0.5 ml-1 shrink-0">
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#d1d5db' }}><path d="M5 0 L9 5 L1 5 Z" fill="currentColor" /></svg>
      <svg width="10" height="5" viewBox="0 0 10 5" style={{ color: '#2563eb' }}><path d="M5 5 L9 0 L1 0 Z" fill="currentColor" /></svg>
    </div>
  );
}

type SortDir = 'asc' | 'desc' | null;

interface ColumnDef {
  key: string;
  header: string;
  width: number;
  align?: 'left' | 'right' | 'center';
  filterable?: boolean;
  sortable?: boolean;
  group?: 'info' | 'gross' | 'net';
  render?: (row: FlatDisplayRow, idx: number, invalidContracts: string[]) => React.ReactNode;
}

// Column group definitions for multi-row header
interface ColumnGroup {
  id: string;
  label: string;
  colSpan: number;
  bgClass: string;
  borderClass: string;
  textClass: string;
}

/** Event badge colors */
const EVENT_BADGE: Record<number, { bg: string; text: string; border: string }> = {
  0: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  1: { bg: 'bg-violet-50', text: 'text-violet-700', border: 'border-violet-200' },
  2: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
};

function buildColumns(): ColumnDef[] {
  return [
    // -- Contract Info ---
    { key: '_rowNum', header: '#', width: 44, sortable: false, filterable: false, group: 'info', render: (_r, idx) => <span className="text-xs text-slate-500">{idx + 1}</span> },
    { key: 'layerkey', header: 'Layerkey', width: 90, group: 'info' },
    { key: 'department', header: 'Department', width: 145, group: 'info' },
    { key: 'company', header: 'Company', width: 200, group: 'info' },
    { key: 'subtype', header: 'Subtype', width: 75, group: 'info', render: (row) => <span className="text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-700">{row.subtype}</span> },
    {
      key: 'contract', header: 'Contract', width: 170, group: 'info',
      render: (row, _idx, inv) => {
        const isInvalid = inv.includes(row.contract);
        return (
          <div className="flex items-center gap-1">
            <span className={`${isInvalid ? 'text-red-600 font-semibold' : 'text-blue-700'} hover:underline cursor-pointer font-medium`}>{row.contract}</span>
            {isInvalid && (
              <span className="ml-1 inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-red-100 text-red-700">
                <XCircle className="w-3 h-3" /> Not in RDM
              </span>
            )}
          </div>
        );
      },
    },
    {
      key: 'eventLabel', header: 'Event', width: 120, group: 'info',
      render: (row) => {
        const badge = EVENT_BADGE[row._eventIndex] || EVENT_BADGE[0];
        return (
          <span className={`text-xs px-2 py-0.5 rounded border ${badge.bg} ${badge.text} ${badge.border}`}>
            {row.eventLabel}
          </span>
        );
      },
    },
    { key: 'everestLimit', header: 'Everest Limit', width: 125, align: 'right', group: 'info', render: (row) => fmtNum(row.everestLimit) },
    { key: 'limit100', header: '100% Limit', width: 125, align: 'right', group: 'info', render: (row) => fmtNum(row.limit100) },
    { key: 'retention', header: 'Retention', width: 105, align: 'right', group: 'info', render: (row) => fmtNum(row.retention) },
    { key: 'aggregateDeductible', header: 'Agg Deductible', width: 120, align: 'right', group: 'info', render: (row) => fmtNum(row.aggregateDeductible) },
    { key: 'terms', header: 'Terms', width: 100, group: 'info', render: (row) => <span className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700">{row.terms || '-'}</span> },
    { key: 'rol', header: 'ROL', width: 55, group: 'info' },
    { key: 'share', header: 'Share', width: 55, group: 'info' },

    // -- Gross Loss (single column) ---
    { key: 'grossLoss', header: 'Gross Loss', width: 130, align: 'right', group: 'gross', render: (row) => <span className="font-medium">{fmtNum(row.grossLoss)}</span> },

    // -- Net ---
    { key: 'netOfLogan', header: 'Net of Logan', width: 120, align: 'right', group: 'net', render: (row) => fmtNum(row.netOfLogan) },
    { key: 'netOfAllCessions', header: 'Net of All Cessions', width: 140, align: 'right', group: 'net', render: (row) => fmtNum(row.netOfAllCessions) },
    { key: 'expectedRIPs', header: 'Expected RIPs', width: 120, align: 'right', group: 'net', render: (row) => fmtNum(row.expectedRIPs) },
  ];
}

// Filter popover component
function FilterPopover({ column, filterValue, onFilterChange, onClose }: {
  column: ColumnDef;
  filterValue: string;
  onFilterChange: (key: string, val: string) => void;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onClose]);

  return (
    <div ref={ref} className="absolute top-full left-0 mt-1 z-50 bg-white border border-slate-200 rounded-lg shadow-lg p-3 min-w-[200px]" onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-slate-600">Filter: {column.header}</span>
        {filterValue && (
          <button onClick={() => onFilterChange(column.key as string, '')} className="text-xs text-red-500 hover:text-red-700">Clear</button>
        )}
      </div>
      <input
        ref={inputRef}
        type="text"
        value={filterValue}
        onChange={e => onFilterChange(column.key as string, e.target.value)}
        placeholder={`Filter ${column.header}...`}
        className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
      />
    </div>
  );
}

/** Multipliers: event1 = 1.0, event2 = 0.72, event3 = 1.35 */
const EVENT_MULTIPLIERS = [1, 0.72, 1.35];

function GrossLossTableInner({ data, invalidContracts, eventNames = ['Event 1', 'Event 2', 'Event 3'] }: GrossLossTableProps) {
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<SortDir>(null);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [openFilter, setOpenFilter] = useState<string | null>(null);

  const COLUMNS = useMemo(() => buildColumns(), []);

  // Flatten data: 3 rows per contract (one per event)
  const flatData = useMemo<FlatDisplayRow[]>(() => {
    const rows: FlatDisplayRow[] = [];
    data.forEach((row, rIdx) => {
      const contractGroup = `${row.layerkey}-${row.contract}-${rIdx}`;
      const grossValues = [row.event1Gross, row.event2Gross, row.event3Gross];
      eventNames.forEach((eName, eIdx) => {
        const mult = EVENT_MULTIPLIERS[eIdx];
        rows.push({
          _id: `${contractGroup}-e${eIdx}`,
          _contractGroup: contractGroup,
          _isFirstInGroup: eIdx === 0,
          _eventIndex: eIdx,
          eventLabel: eName,
          inUWEst: row.inUWEst,
          layerkey: row.layerkey,
          department: row.department,
          company: row.company,
          subtype: row.subtype,
          contract: row.contract,
          everestLimit: row.everestLimit,
          limit100: row.limit100,
          retention: row.retention,
          aggregateDeductible: row.aggregateDeductible,
          terms: row.terms,
          rol: row.rol,
          share: row.share,
          grossLoss: grossValues[eIdx],
          netOfLogan: eIdx === 0 ? row.netOfLogan : _deriveNet(row.netOfLogan, mult),
          netOfAllCessions: eIdx === 0 ? row.netOfAllCessions : _deriveNet(row.netOfAllCessions, mult),
          expectedRIPs: eIdx === 0 ? row.expectedRIPs : _deriveNet(row.expectedRIPs, mult),
        });
      });
    });
    return rows;
  }, [data, eventNames]);

  const handleSort = useCallback((key: string) => {
    if (sortCol === key) {
      if (sortDir === 'asc') setSortDir('desc');
      else if (sortDir === 'desc') { setSortCol(null); setSortDir(null); }
      else setSortDir('asc');
    } else {
      setSortCol(key);
      setSortDir('asc');
    }
  }, [sortCol, sortDir]);

  const handleFilterChange = useCallback((key: string, val: string) => {
    setFilters(prev => {
      const next = { ...prev };
      if (val) next[key] = val;
      else delete next[key];
      return next;
    });
  }, []);

  const toggleFilter = useCallback((key: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenFilter(prev => prev === key ? null : key);
  }, []);

  // Filtered data
  const filteredData = useMemo(() => {
    if (Object.keys(filters).length === 0) return flatData;
    return flatData.filter(row => {
      return Object.entries(filters).every(([key, val]) => {
        if (!val) return true;
        const cellVal = String((row as any)[key] ?? '');
        return cellVal.toLowerCase().includes(val.toLowerCase());
      });
    });
  }, [flatData, filters]);

  // Sorted data
  const sortedData = useMemo(() => {
    if (!sortCol || !sortDir) return filteredData;
    return [...filteredData].sort((a, b) => {
      let aVal: any = (a as any)[sortCol];
      let bVal: any = (b as any)[sortCol];
      const aNum = typeof aVal === 'string' ? Number(aVal.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '')) : (typeof aVal === 'boolean' ? (aVal ? 1 : 0) : Number(aVal));
      const bNum = typeof bVal === 'string' ? Number(bVal.replace(/[, ]/g, '').replace(/^\(/, '-').replace(/\)$/, '')) : (typeof bVal === 'boolean' ? (bVal ? 1 : 0) : Number(bVal));
      if (!isNaN(aNum) && !isNaN(bNum)) {
        return sortDir === 'asc' ? aNum - bNum : bNum - aNum;
      }
      aVal = String(aVal ?? '').toLowerCase();
      bVal = String(bVal ?? '').toLowerCase();
      if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortCol, sortDir]);

  const activeFilterCount = Object.keys(filters).length;

  // Build column groups for the top header row
  const columnGroups = useMemo<ColumnGroup[]>(() => {
    const infoCols = COLUMNS.filter(c => c.group === 'info').length;
    const grossCols = COLUMNS.filter(c => c.group === 'gross').length;
    const netCols = COLUMNS.filter(c => c.group === 'net').length;
    return [
      { id: 'info', label: 'Contract Information', colSpan: infoCols, bgClass: 'bg-slate-100', borderClass: 'border-slate-300', textClass: 'text-slate-600' },
      { id: 'gross', label: 'Gross Loss', colSpan: grossCols, bgClass: 'bg-amber-50', borderClass: 'border-amber-200', textClass: 'text-amber-800' },
      { id: 'net', label: 'Net Loss', colSpan: netCols, bgClass: 'bg-emerald-50', borderClass: 'border-emerald-200', textClass: 'text-emerald-800' },
    ];
  }, [COLUMNS]);

  if (data.length === 0) {
    return (
      <div className="px-6 py-12 text-center">
        <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <p className="text-slate-500 mb-2">No contract data available</p>
        <p className="text-sm text-slate-400">Upload model output files to view contract-level results</p>
      </div>
    );
  }

  // Helper to get cell bg class based on group
  const cellGroupClass = (group?: string) => {
    if (group === 'gross') return 'bg-amber-50/40';
    if (group === 'net') return 'bg-emerald-50/40';
    return '';
  };

  return (
    <div className="w-full">
      {activeFilterCount > 0 && (
        <div className="px-3 py-1.5 bg-blue-50 border-b border-blue-100 flex items-center gap-2 text-xs">
          <Filter className="w-3 h-3 text-blue-500" />
          <span className="text-blue-700">{activeFilterCount} active filter{activeFilterCount > 1 ? 's' : ''} · {sortedData.length} of {flatData.length} rows</span>
          <button onClick={() => setFilters({})} className="ml-auto text-blue-600 hover:text-blue-800 flex items-center gap-1">
            <X className="w-3 h-3" /> Clear all
          </button>
        </div>
      )}
      <div className="overflow-auto" style={{ maxHeight: 'calc(100vh - 420px)' }}>
        <table className="w-full text-[0.8rem] border-collapse" style={{ minWidth: `${COLUMNS.reduce((s, c) => s + c.width, 0)}px` }}>
          <thead className="sticky top-0 z-10">
            {/* -- Group Header Row -- */}
            <tr>
              {columnGroups.map(g => (
                <th
                  key={g.id}
                  colSpan={g.colSpan}
                  className={`px-3 py-1.5 text-center whitespace-nowrap select-none border-b ${g.borderClass} ${g.bgClass}`}
                  style={{ fontSize: '0.65rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}
                >
                  <span className={g.textClass}>{g.label}</span>
                </th>
              ))}
            </tr>
            {/* -- Individual Column Header Row -- */}
            <tr className="bg-slate-50 border-b border-slate-200">
              {COLUMNS.map(col => {
                const isSorted = sortCol === col.key;
                const canSort = col.sortable !== false && col.key !== '_rowNum';
                const canFilter = col.filterable !== false && col.key !== '_rowNum';
                const hasFilter = !!filters[col.key as string];

                const groupBg = col.group === 'gross' ? 'bg-amber-50/70' : col.group === 'net' ? 'bg-emerald-50/70' : 'bg-slate-50';

                return (
                  <th
                    key={col.key}
                    className={`px-3 py-2 text-${col.align || 'left'} whitespace-nowrap select-none border-b border-slate-200 ${groupBg} ${canSort ? 'cursor-pointer hover:bg-slate-100' : ''}`}
                    style={{ width: col.width, minWidth: col.width, fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase' as const, position: 'relative' }}
                    onClick={() => canSort && handleSort(col.key as string)}
                  >
                    <div className="flex items-center gap-1" style={{ justifyContent: col.align === 'right' ? 'flex-end' : 'flex-start' }}>
                      <span className="text-slate-500">{col.header}</span>
                      {canSort && (
                        isSorted
                          ? (sortDir === 'asc' ? <SortAsc /> : <SortDesc />)
                          : <SortUnsorted />
                      )}
                      {canFilter && (
                        <button
                          onClick={(e) => toggleFilter(col.key as string, e)}
                          className={`p-0.5 rounded hover:bg-slate-200 transition-colors ${hasFilter ? 'text-blue-600' : 'text-slate-400'}`}
                        >
                          <Filter className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    {openFilter === col.key && (
                      <FilterPopover
                        column={col}
                        filterValue={filters[col.key as string] || ''}
                        onFilterChange={handleFilterChange}
                        onClose={() => setOpenFilter(null)}
                      />
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {sortedData.map((row, idx) => {
              const isInvalid = invalidContracts.includes(row.contract);
              const isSubRow = row._eventIndex > 0;
              const borderClass = !isSubRow ? 'border-t-2 border-t-slate-300' : '';
              const rowBg = isInvalid
                ? 'bg-red-50 hover:bg-red-100'
                : isSubRow
                  ? 'bg-gray-50/80 hover:bg-gray-100/80'
                  : 'hover:bg-slate-50';

              return (
                <tr
                  key={row._id}
                  className={`border-b border-slate-100 transition-colors ${rowBg} ${borderClass}`}
                >
                  {COLUMNS.map(col => {
                    // For event rows 2 & 3: hide all contract info columns (except # and Event)
                    const isInfoCol = col.group === 'info'
                      && col.key !== '_rowNum'
                      && col.key !== 'eventLabel';

                    if (isInfoCol && isSubRow) {
                      let subContent: React.ReactNode;
                      if (col.render) {
                        subContent = col.render(row, idx, invalidContracts);
                      } else {
                        subContent = String((row as any)[col.key] ?? '-');
                      }
                      return (
                        <td
                          key={col.key}
                          className={`px-3 py-1.5 text-${col.align || 'left'} ${cellGroupClass(col.group)} text-slate-400`}
                          style={{ width: col.width, minWidth: col.width }}
                        >
                          {subContent}
                        </td>
                      );
                    }

                    let content: React.ReactNode;
                    if (col.render) {
                      content = col.render(row, idx, invalidContracts);
                    } else {
                      content = String((row as any)[col.key] ?? '-');
                    }
                    return (
                      <td
                        key={col.key}
                        className={`px-3 py-1.5 text-${col.align || 'left'} ${cellGroupClass(col.group)}`}
                        style={{ width: col.width, minWidth: col.width }}
                      >
                        {content}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary footer */}
      <div className="px-3 py-2 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[0.7rem] text-slate-500">
        <span>{data.length} contract{data.length !== 1 ? 's' : ''} · {sortedData.length} row{sortedData.length !== 1 ? 's' : ''}{activeFilterCount > 0 ? ` (filtered from ${flatData.length})` : ''}</span>
        <span className="text-[0.65rem] text-slate-400 italic">Values displayed in USD · Amounts in millions where applicable</span>
      </div>
    </div>
  );
}

export function GrossLossTable({ data, invalidContracts, eventNames }: GrossLossTableProps) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let inner = 0;
    const outer = requestAnimationFrame(() => {
      inner = requestAnimationFrame(() => setReady(true));
    });
    return () => {
      cancelAnimationFrame(outer);
      cancelAnimationFrame(inner);
    };
  }, []);

  if (!ready) {
    return <GrossLossTableSkeleton />;
  }

  return <GrossLossTableInner data={data} invalidContracts={invalidContracts} eventNames={eventNames} />;
}