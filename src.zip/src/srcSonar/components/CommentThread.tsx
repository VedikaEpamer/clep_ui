import { MessageSquare, Paperclip, User, Lock } from 'lucide-react';
import { Comment } from '../lib/commentContext';

interface CommentThreadProps {
  comments: Comment[];
  showTeamBadge?: boolean;
}

export function CommentThread({ comments, showTeamBadge = false }: CommentThreadProps) {
  if (comments.length === 0) {
    return (
      <div className="text-center py-8 px-4">
        <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-sm text-gray-500">No comments yet</p>
        <p className="text-xs text-gray-400 mt-1">Be the first to add a comment</p>
      </div>
    );
  }

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getTeamLabel = (team: string) => {
    const labels: Record<string, string> = {
      'intl-fac': 'International Fac', 'latam-fac': 'Latin America Fac', 'london-fac': 'London Fac', 'singapore-fac': 'Singapore Fac',
      'aviation': 'Aviation', 'dublin-zurich': 'Dublin / Zurich', 'latam-brazil-treaty': 'Latin America / Brazil Treaty',
      'london-treaty': 'London Treaty', 'marine': 'Marine', 'me-africa': 'ME / Africa', 'singapore-treaty': 'Singapore Treaty',
      'bermuda-fac': 'Bermuda Fac', 'canada-fac': 'Canada Fac', 'fac-casualty': 'FAC Casualty', 'fac-property': 'FAC Property',
      'bermuda-treaty': 'Bermuda Treaty', 'canada-treaty': 'Canada Treaty',
      'parametric': 'Parametric', 'surety': 'Surety', 'treaty-casualty': 'Treaty Casualty', 'treaty-property': 'Treaty Property',
    };
    return labels[team] || team;
  };

  const getTeamColor = (team: string) => {
    const colors: Record<string, string> = {
      'latam-fac': 'bg-blue-100 text-blue-700 border-blue-200',
      'latam-brazil-treaty': 'bg-blue-100 text-blue-700 border-blue-200',
      'london-fac': 'bg-purple-100 text-purple-700 border-purple-200',
      'london-treaty': 'bg-purple-100 text-purple-700 border-purple-200',
      'bermuda-fac': 'bg-orange-100 text-orange-700 border-orange-200',
      'bermuda-treaty': 'bg-orange-100 text-orange-700 border-orange-200',
      'intl-fac': 'bg-pink-100 text-pink-700 border-pink-200',
      'treaty-property': 'bg-indigo-100 text-indigo-700 border-indigo-200',
      'marine': 'bg-teal-100 text-teal-700 border-teal-200',
      'dublin-zurich': 'bg-green-100 text-green-700 border-green-200',
    };
    return colors[team] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'submission':
        return '📤';
      case 'review':
        return '📋';
      default:
        return '💬';
    }
  };

  return (
    <div className="space-y-4">
      {comments.map((comment) => (
        <div
          key={comment.id}
          className={`border rounded-lg p-4 transition-all hover:shadow-sm ${
            comment.isInternal
              ? 'bg-amber-50 border-amber-200'
              : 'bg-white border-gray-200'
          }`}
        >
          {/* Header */}
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                {comment.author.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-medium text-gray-900">{comment.author}</h4>
                  {comment.isInternal && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-full border border-amber-200">
                      <Lock className="w-3 h-3" />
                      Internal
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>{comment.authorRole}</span>
                  {showTeamBadge && (
                    <>
                      <span>•</span>
                      <span className={`px-2 py-0.5 rounded-full border text-xs ${getTeamColor(comment.team)}`}>
                        {getTeamLabel(comment.team)}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">{getTypeIcon(comment.type)}</span>
              <span className="text-xs text-gray-500">{formatTimestamp(comment.timestamp)}</span>
            </div>
          </div>

          {/* Comment Text */}
          <div className="text-sm text-gray-700 whitespace-pre-wrap mb-3">
            {comment.text}
          </div>

          {/* Attachments */}
          {comment.files && comment.files.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {comment.files.map((file, index) => (
                <div
                  key={index}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-lg text-xs text-gray-700 border border-gray-200 transition-colors cursor-pointer"
                >
                  <Paperclip className="w-3 h-3" />
                  <span className="truncate max-w-[150px]">{file}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
