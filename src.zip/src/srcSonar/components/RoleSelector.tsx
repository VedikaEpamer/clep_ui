import { useState, useRef, useEffect } from 'react';
import { ChevronDown, User, CheckCircle2 } from 'lucide-react';
import { useRole, SonarRole, ALL_SONAR_ROLES } from '../lib/roleContext';
import { useNavigate } from 'react-router';

const roleDescriptions: Record<SonarRole, string> = {
  'Administrator': 'Full system access — All permissions, user management, configuration',
  'Event Coordinator': 'Claim team — Create/Modify events, Read All Modules',
  'Finance Contributor': 'Finance team — Create/Modify events, Update/Lock/Unlock estimates, Reopen',
  'CAT Contributor': 'CAT team — Update Cat Data, Read All Modules',
  'UW Contributor': 'Underwriting — Upload loss data, basic Reader access',
  'Executive Area Lead': 'Underwriting — Reads all BUs in Executive Area, assigns tasks, approves within area',
  'Business Unit Lead': 'Underwriting — Reads own BU only, assigns tasks, approves within BU scope',
  'Reader': 'Management — Read-only access across all modules',
};

const roleColors: Record<SonarRole, string> = {
  'Administrator': 'bg-red-100 text-red-700',
  'Event Coordinator': 'bg-orange-100 text-orange-700',
  'Finance Contributor': 'bg-emerald-100 text-emerald-700',
  'CAT Contributor': 'bg-purple-100 text-purple-700',
  'UW Contributor': 'bg-blue-100 text-blue-700',
  'Executive Area Lead': 'bg-blue-100 text-blue-700',
  'Business Unit Lead': 'bg-blue-100 text-blue-700',
  'Reader': 'bg-slate-100 text-slate-600',
};

export function RoleSelector() {
  const { currentRole, setCurrentRole } = useRole();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRoleChange = (role: SonarRole) => {
    setCurrentRole(role);
    setIsOpen(false);
    navigate('/events');
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg border border-white/20 bg-white/10 hover:bg-white/20 transition-colors"
      >
        <User className="w-4 h-4 text-white" />
        <div className="text-left">
          <div className="text-sm font-medium text-white">View as</div>
          <div className="text-xs text-white/80">{currentRole}</div>
        </div>
        <ChevronDown className={`w-4 h-4 text-white transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-96 bg-white rounded-lg shadow-xl border border-slate-200 z-50 overflow-hidden">
          <div className="p-3 bg-slate-50 border-b border-slate-200">
            <div className="text-xs font-semibold text-slate-900 uppercase tracking-wide">Switch Role Perspective</div>
            <div className="text-xs text-slate-600 mt-0.5">SONAR 8-role system</div>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {ALL_SONAR_ROLES.map((role) => (
              <button
                key={role}
                onClick={() => handleRoleChange(role)}
                className={`w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-100 ${
                  currentRole === role ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-slate-900">{role}</span>
                      {currentRole === role && (
                        <CheckCircle2 className="w-4 h-4 text-everest-blue" />
                      )}
                    </div>
                    <div className="text-xs text-slate-600">{roleDescriptions[role]}</div>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${roleColors[role]}`}>
                    {role.split(' ')[0]}
                  </span>
                </div>
              </button>
            ))}
          </div>
          
          <div className="p-3 bg-slate-50 border-t border-slate-200">
            <div className="text-xs text-slate-500">
              Current view shows permissions and features for <span className="font-semibold text-slate-900">{currentRole}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}