import { Globe, RefreshCw } from 'lucide-react';
import { useCurrency } from '../lib/currencyContext';
import { toast } from 'sonner@2.0.3';
import { useState } from 'react';

const CURRENCY_OPTIONS = [
  { code: 'original', label: 'Original Currency', symbol: '' },
  { code: 'USD', label: 'USD — US Dollar', symbol: '$', flag: '🇺🇸' },
  { code: 'EUR', label: 'EUR — Euro', symbol: '€', flag: '🇪🇺' },
  { code: 'GBP', label: 'GBP — British Pound', symbol: '£', flag: '🇬🇧' },
  { code: 'CAD', label: 'CAD — Canadian Dollar', symbol: 'C$', flag: '🇨🇦' },
];

export function CurrencySelector() {
  const { settings, setDisplayMode, setBaseCurrency, updateFXRates } = useCurrency();
  const [isUpdating, setIsUpdating] = useState(false);

  const currentValue = settings.displayMode === 'original' ? 'original' : settings.baseCurrency;
  const activeCurrency = CURRENCY_OPTIONS.find(c => c.code === currentValue);

  const handleCurrencyChange = (value: string) => {
    if (value === 'original') {
      setDisplayMode('original');
    } else {
      setBaseCurrency(value);
    }
  };

  const handleUpdateRates = async () => {
    setIsUpdating(true);
    try {
      await updateFXRates();
      toast.success('FX rates updated successfully');
    } catch (error) {
      toast.error('Failed to update FX rates');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="flex items-center gap-3">
      {/* Currency Display Mode Selector */}
      <div className="flex items-center gap-2 px-3 py-1.5 bg-white rounded-lg border border-slate-300 shadow-sm">
        <Globe className="w-4 h-4 text-slate-600" />
        <select 
          value={currentValue}
          onChange={(e) => handleCurrencyChange(e.target.value)}
          className="bg-transparent text-sm font-medium text-slate-700 border-0 focus:ring-0 focus:outline-none cursor-pointer pr-2"
        >
          {CURRENCY_OPTIONS.map(opt => (
            <option key={opt.code} value={opt.code}>
              {opt.code === 'original' ? opt.label : `${opt.flag} ${opt.code}`}
            </option>
          ))}
        </select>
      </div>

      {/* Active currency indicator pills */}
      {settings.displayMode === 'base' && (
        <div className="flex items-center gap-1">
          {CURRENCY_OPTIONS.filter(c => c.code !== 'original').map(opt => (
            null
          ))}
        </div>
      )}

      {/* FX Rate Info & Update */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-slate-500">
          FX as of {new Date(settings.fxEffectiveDate).toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric',
            year: 'numeric'
          })}
        </span>
        <button
          onClick={handleUpdateRates}
          disabled={isUpdating}
          className="flex items-center gap-1 text-blue-600 hover:text-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          title="Update FX rates"
        >
          <RefreshCw className={`w-3 h-3 ${isUpdating ? 'animate-spin' : ''}`} />
          <span>Update</span>
        </button>
      </div>
    </div>
  );
}
