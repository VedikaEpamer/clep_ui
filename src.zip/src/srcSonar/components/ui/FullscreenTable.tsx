/**
 * FullscreenTable Component
 * 
 * A wrapper component that adds fullscreen expand functionality to any table.
 * 
 * Usage Example:
 * ```tsx
 * import { FullscreenTable } from './ui/FullscreenTable';
 * 
 * <FullscreenTable title="Contract Data">
 *   <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
 *     <table className="w-full">
 *       <thead>
 *         <tr className="border-b border-slate-200 bg-slate-50">
 *           <th className="px-4 py-3 text-left">Column 1</th>
 *           <th className="px-4 py-3 text-left">Column 2</th>
 *         </tr>
 *       </thead>
 *       <tbody>
 *         <tr>
 *           <td className="px-4 py-3">Data 1</td>
 *           <td className="px-4 py-3">Data 2</td>
 *         </tr>
 *       </tbody>
 *     </table>
 *   </div>
 * </FullscreenTable>
 * ```
 */

import { ReactNode, useState } from 'react';
import { Maximize2, X } from 'lucide-react';

interface FullscreenTableProps {
  children: ReactNode;
  title?: string;
}

export function FullscreenTable({ children, title }: FullscreenTableProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  return (
    <>
      {/* Normal View with Expand Button */}
      <div className="relative">
        <button
          onClick={() => setIsFullscreen(true)}
          className="absolute top-3 right-3 z-10 p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-sm"
          title="Expand to fullscreen"
        >
          <Maximize2 className="w-4 h-4 text-slate-600" />
        </button>
        {children}
      </div>

      {/* Fullscreen Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-50 bg-white flex flex-col">
          {/* Header */}
          <div className="h-16 border-b border-slate-200 flex items-center justify-between px-6 bg-white flex-shrink-0">
            <h2 className="font-semibold text-slate-900">{title || 'Table View'}</h2>
            <button
              onClick={() => setIsFullscreen(false)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              title="Exit fullscreen"
            >
              <X className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          {/* Table Content */}
          <div className="flex-1 overflow-auto p-6">
            {children}
          </div>
        </div>
      )}
    </>
  );
}
