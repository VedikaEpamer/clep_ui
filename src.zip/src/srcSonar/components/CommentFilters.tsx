import { Filter, Lock, Globe, MessageSquare } from 'lucide-react';

interface CommentFiltersProps {
  filter: 'all';
  onFilterChange: (filter: 'all') => void;
  counts: {
    all: number;
  };
}

export function CommentFilters({ filter, onFilterChange, counts }: CommentFiltersProps) {
  const filters = [
    { value: 'all' as const, label: 'All Comments', icon: MessageSquare, count: counts.all },
  ];

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {filters.map((f) => {
        const Icon = f.icon;
        return (
          <button
            key={f.value}
            onClick={() => onFilterChange(f.value)}
            className={`px-3 py-1.5 rounded-lg text-sm flex items-center gap-2 transition-colors ${
              filter === f.value
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Icon className="w-4 h-4" />
            {f.label}
            {f.count > 0 && (
              <span className={`px-1.5 py-0.5 rounded-full text-xs ${
                filter === f.value
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}>
                {f.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}