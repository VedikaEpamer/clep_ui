import svgPaths from "./svg-g3y4qzlsk7";

function Heading() {
  return (
    <div className="h-[36px] relative shrink-0 w-[469.563px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[36px] relative w-[469.563px]">
        <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[36px] left-0 text-[#0f172b] text-[30px] top-[-3.67px] tracking-[-0.3px] w-[470px]">Hurricane Milton - UW Estimation</p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 10V2" id="Vector" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_2" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p19411800} id="Vector_3" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-white border-[#cad5e2] border-[1.333px] border-solid h-[36.667px] left-0 rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] top-0 w-[167.208px]" data-name="Button">
      <Icon />
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[94px] text-[#314158] text-[12px] text-center text-nowrap top-[6px] translate-x-[-50%] whitespace-pre">Download Template</p>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 2V10" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p26e09a00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#155dfc] h-[34px] left-[179.21px] rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] top-[1.33px] w-[173.521px]" data-name="Button">
      <Icon1 />
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99px] text-[12px] text-center text-nowrap text-white top-[6px] translate-x-[-50%] whitespace-pre">Upload UW Estimates</p>
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 10V2" id="Vector" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_2" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p19411800} id="Vector_3" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-white border-[#cad5e2] border-[1.333px] border-solid h-[36.667px] left-[364.73px] rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] top-0 w-[186.667px]" data-name="Button">
      <Icon2 />
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[104px] text-[#314158] text-[12px] text-center text-nowrap top-[6px] translate-x-[-50%] whitespace-pre">Download All Estimates</p>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 2V10" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p26e09a00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#009966] h-[34px] left-[563.4px] rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] top-[1.33px] w-[190px]" data-name="Button">
      <Icon3 />
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[107.5px] text-[12px] text-center text-nowrap text-white top-[6px] translate-x-[-50%] whitespace-pre">Upload Final Net Figures</p>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[36.667px] relative shrink-0 w-[753.396px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[36.667px] relative w-[753.396px]">
        <Button />
        <Button1 />
        <Button2 />
        <Button3 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex h-[78px] items-center justify-between left-0 pb-[1.333px] pt-0 px-[32px] top-0 w-[2625.33px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid inset-0 pointer-events-none" />
      <Heading />
      <Container />
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[47.333px] relative shrink-0 w-[94.979px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#0052ff] border-[0px_0px_1.333px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[47.333px] items-start pb-[15.333px] pt-[14px] px-[4px] relative w-[94.979px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[18px] relative shrink-0 text-[#0052ff] text-[12px] text-center text-nowrap whitespace-pre">Contract Details</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[47.333px] relative shrink-0 w-[97.958px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[47.333px] items-start pb-[15.333px] pt-[14px] px-[4px] relative w-[97.958px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[18px] relative shrink-0 text-[#45556c] text-[12px] text-center text-nowrap whitespace-pre">Loss by Contract</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex gap-[24px] h-[47.333px] items-center left-[32px] top-[78px] w-[2561.33px]" data-name="Container">
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container3() {
  return (
    <div className="bg-white h-[126.667px] relative shrink-0 w-[2625.33px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[126.667px] relative w-[2625.33px]">
        <Container1 />
        <Container2 />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[16px] relative shrink-0 w-[85.771px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[16px] items-start relative w-[85.771px]">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#45556c] text-[12px] text-nowrap tracking-[0.3px] uppercase whitespace-pre">UW Summary</p>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p140c1100} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M15 14.1667V7.5" id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10.8333 14.1667V4.16667" id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M6.66667 14.1667V11.6667" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[20px] items-center justify-between relative w-full">
          <Text />
          <Icon4 />
        </div>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-0 text-[#003057] text-[30px] text-nowrap top-[-3.67px] whitespace-pre">$4.0M</p>
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#62748e] text-[12px]">Medium scenario estimate</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[12px] h-[174.667px] items-start left-0 pb-[1.333px] pt-[25.333px] px-[25.333px] rounded-[10px] top-0 w-[622.333px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px] border-slate-200 border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      <Container4 />
      <Container5 />
      <Container6 />
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[107.479px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[16px] items-start relative w-[107.479px]">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#45556c] text-[12px] text-nowrap tracking-[0.3px] uppercase whitespace-pre">Model Summary</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p140c1100} id="Vector" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M15 14.1667V7.5" id="Vector_2" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10.8333 14.1667V4.16667" id="Vector_3" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M6.66667 14.1667V11.6667" id="Vector_4" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex h-[20px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Text1 />
      <Icon5 />
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-0 text-[#003057] text-[30px] text-nowrap top-[-3.67px] whitespace-pre">$4.4M</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#62748e] text-[12px]">Medium scenario modeling</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[12px] h-[174.667px] items-start left-[646.33px] pb-[1.333px] pt-[25.333px] px-[25.333px] rounded-[10px] top-0 w-[622.333px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px] border-slate-200 border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      <Container8 />
      <Container9 />
      <Container10 />
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[16px] relative shrink-0 w-[116.896px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[16px] items-start relative w-[116.896px]">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#45556c] text-[12px] text-nowrap tracking-[0.3px] uppercase whitespace-pre">Finance Summary</p>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M10 1.66667V18.3333" id="Vector" stroke="var(--stroke-0, #9810FA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p3055a600} id="Vector_2" stroke="var(--stroke-0, #9810FA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex h-[20px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Text2 />
      <Icon6 />
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-0 text-[#003057] text-[30px] text-nowrap top-[-3.67px] whitespace-pre">$3.9M</p>
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#62748e] text-[12px]">Gross Loss</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[12px] h-[174.667px] items-start left-[1292.67px] pb-[1.333px] pt-[25.333px] px-[25.333px] rounded-[10px] top-0 w-[622.333px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px] border-slate-200 border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      <Container12 />
      <Container13 />
      <Container14 />
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[16px] relative shrink-0 w-[59.396px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[16px] items-start relative w-[59.396px]">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#45556c] text-[12px] text-nowrap tracking-[0.3px] uppercase whitespace-pre">Variance</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_132_3623)" id="Icon">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, #FE9A00)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 6.66667V10" id="Vector_2" stroke="var(--stroke-0, #FE9A00)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 13.3333H10.0083" id="Vector_3" stroke="var(--stroke-0, #FE9A00)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_132_3623">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-between left-[24px] top-[24px] w-[571.667px]" data-name="Container">
      <Text3 />
      <Icon7 />
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute h-[36px] left-[24px] top-[56px] w-[571.667px]" data-name="Container">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-0 text-[30px] text-emerald-600 text-nowrap top-[-3.67px] whitespace-pre">-10.2%</p>
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[24px] top-[100px] w-[571.667px]" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#62748e] text-[12px]">UW vs CAT Model</p>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[24px] top-[132px] w-[571.667px]" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Review recommended</p>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute bg-white border-[1.333px] border-slate-200 border-solid h-[174.667px] left-[1939px] rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] top-0 w-[622.333px]" data-name="Container">
      <Container16 />
      <Container17 />
      <Container18 />
      <Container19 />
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[174.667px] relative shrink-0 w-full" data-name="Container">
      <Container7 />
      <Container11 />
      <Container15 />
      <Container20 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2133ea00} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="basis-0 grow h-[18px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[18px] items-start relative w-full">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[18px] relative shrink-0 text-[#0f172b] text-[12px] text-nowrap whitespace-pre">{`Filters & Grouping`}</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[20px] relative shrink-0 w-[127.292px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] h-[20px] items-center relative w-[127.292px]">
        <Icon8 />
        <Text4 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[13.33px] size-[16px] top-[9.33px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p3de75880} id="Vector" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1e4da180} id="Vector_2" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p83b6680} id="Vector_3" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p8635c80} id="Vector_4" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-[113.917px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[34.667px] relative w-[113.917px]">
        <Icon9 />
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[69.83px] text-[#314158] text-[14px] text-center text-nowrap top-[5.33px] translate-x-[-50%] whitespace-pre">Fullscreen</p>
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-[13.33px] size-[16px] top-[9.33px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-[141.313px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[34.667px] relative w-[141.313px]">
        <Icon10 />
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[82.33px] text-[#314158] text-[14px] text-center text-nowrap top-[5.33px] translate-x-[-50%] whitespace-pre">Collapse Table</p>
      </div>
    </div>
  );
}

function Label() {
  return (
    <div className="h-[20px] relative shrink-0 w-[62.563px]" data-name="Label">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[62.563px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[#45556c] text-[14px] text-nowrap whitespace-pre">Group by:</p>
      </div>
    </div>
  );
}

function Option() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">No Grouping</p>
    </div>
  );
}

function Option1() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Cedant</p>
    </div>
  );
}

function Option2() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Program Type</p>
    </div>
  );
}

function Option3() {
  return (
    <div className="h-0 relative shrink-0 w-full" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Broker</p>
    </div>
  );
}

function Dropdown() {
  return (
    <div className="basis-0 bg-white grow h-[33.333px] min-h-px min-w-px relative rounded-[4px] shrink-0" data-name="Dropdown">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[33.333px] items-start pb-[1.333px] pr-[2824px] relative w-full">
          <Option />
          <Option1 />
          <Option2 />
          <Option3 />
        </div>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[33.333px] relative shrink-0 w-[207.896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] h-[33.333px] items-center relative w-[207.896px]">
        <Label />
        <Dropdown />
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="h-[34.667px] relative shrink-0 w-[487.125px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] h-[34.667px] items-center relative w-[487.125px]">
        <Button6 />
        <Button7 />
        <Container23 />
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[34.667px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[34.667px] items-center justify-between relative w-full">
          <Container22 />
          <Container24 />
        </div>
      </div>
    </div>
  );
}

function Label1() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Contract Number</p>
    </div>
  );
}

function TextInput() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex h-[34.667px] items-center px-[12px] py-[6px] relative w-full">
          <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[14px] text-[rgba(49,65,88,0.5)] text-nowrap whitespace-pre">Search...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container26() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-0 top-0 w-[618.667px]" data-name="Container">
      <Label1 />
      <TextInput />
    </div>
  );
}

function Label2() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Contract Name</p>
    </div>
  );
}

function TextInput1() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex h-[34.667px] items-center px-[12px] py-[6px] relative w-full">
          <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[14px] text-[rgba(49,65,88,0.5)] text-nowrap whitespace-pre">Search...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container27() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-[630.67px] top-0 w-[618.667px]" data-name="Container">
      <Label2 />
      <TextInput1 />
    </div>
  );
}

function Label3() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Cedant</p>
    </div>
  );
}

function TextInput2() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex h-[34.667px] items-center px-[12px] py-[6px] relative w-full">
          <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[14px] text-[rgba(49,65,88,0.5)] text-nowrap whitespace-pre">Search...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-[1261.33px] top-0 w-[618.667px]" data-name="Container">
      <Label3 />
      <TextInput2 />
    </div>
  );
}

function Label4() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Program Type</p>
    </div>
  );
}

function Option4() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">All</p>
    </div>
  );
}

function Option5() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">QS</p>
    </div>
  );
}

function Option6() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">XL</p>
    </div>
  );
}

function Option7() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">PR</p>
    </div>
  );
}

function Option8() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Specialty</p>
    </div>
  );
}

function Option9() {
  return (
    <div className="absolute left-[-2205.33px] size-0 top-[-525.33px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">FAC</p>
    </div>
  );
}

function Dropdown1() {
  return (
    <div className="bg-white h-[33.333px] relative rounded-[4px] shrink-0 w-full" data-name="Dropdown">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Option4 />
      <Option5 />
      <Option6 />
      <Option7 />
      <Option8 />
      <Option9 />
    </div>
  );
}

function Container29() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-[1892px] top-0 w-[618.667px]" data-name="Container">
      <Label4 />
      <Dropdown1 />
    </div>
  );
}

function Label5() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Broker</p>
    </div>
  );
}

function TextInput3() {
  return (
    <div className="bg-white h-[34.667px] relative rounded-[4px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex h-[34.667px] items-center px-[12px] py-[6px] relative w-full">
          <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[14px] text-[rgba(49,65,88,0.5)] text-nowrap whitespace-pre">Search...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
    </div>
  );
}

function Container30() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-0 top-[66.67px] w-[618.667px]" data-name="Container">
      <Label5 />
      <TextInput3 />
    </div>
  );
}

function Label6() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Reporting Level</p>
    </div>
  );
}

function Option10() {
  return (
    <div className="absolute left-[-944px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">All</p>
    </div>
  );
}

function Option11() {
  return (
    <div className="absolute left-[-944px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Full Loss Reporting</p>
    </div>
  );
}

function Option12() {
  return (
    <div className="absolute left-[-944px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Aggregate Only</p>
    </div>
  );
}

function Option13() {
  return (
    <div className="absolute left-[-944px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Summary Reporting</p>
    </div>
  );
}

function Dropdown2() {
  return (
    <div className="bg-white h-[33.333px] relative rounded-[4px] shrink-0 w-full" data-name="Dropdown">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Option10 />
      <Option11 />
      <Option12 />
      <Option13 />
    </div>
  );
}

function Container31() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-[630.67px] top-[66.67px] w-[618.667px]" data-name="Container">
      <Label6 />
      <Dropdown2 />
    </div>
  );
}

function Label7() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#45556c] text-[12px]">Status</p>
    </div>
  );
}

function Option14() {
  return (
    <div className="absolute left-[-1574.67px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">All</p>
    </div>
  );
}

function Option15() {
  return (
    <div className="absolute left-[-1574.67px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Impacted</p>
    </div>
  );
}

function Option16() {
  return (
    <div className="absolute left-[-1574.67px] size-0 top-[-592px]" data-name="Option">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[normal] left-0 text-[#314158] text-[14px] top-0 w-0">Not Impacted</p>
    </div>
  );
}

function Dropdown3() {
  return (
    <div className="bg-white h-[33.333px] relative rounded-[4px] shrink-0 w-full" data-name="Dropdown">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Option14 />
      <Option15 />
      <Option16 />
    </div>
  );
}

function Container32() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[54.667px] items-start left-[1261.33px] top-[66.67px] w-[618.667px]" data-name="Container">
      <Label7 />
      <Dropdown3 />
    </div>
  );
}

function Container33() {
  return (
    <div className="h-[121.333px] relative shrink-0 w-full" data-name="Container">
      <Container26 />
      <Container27 />
      <Container28 />
      <Container29 />
      <Container30 />
      <Container31 />
      <Container32 />
    </div>
  );
}

function Container34() {
  return (
    <div className="bg-white h-[222.667px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px] border-slate-200 border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[16px] h-[222.667px] items-start pb-[1.333px] pt-[25.333px] px-[25.333px] relative w-full">
          <Container25 />
          <Container33 />
        </div>
      </div>
    </div>
  );
}

function HeaderCell() {
  return (
    <div className="absolute h-[80.667px] left-[389.63px] top-0 w-[118.604px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[63px]">Program Type</p>
    </div>
  );
}

function HeaderCell1() {
  return (
    <div className="absolute h-[80.667px] left-[508.23px] top-0 w-[96.021px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] text-nowrap top-[31px] tracking-[0.6px] uppercase whitespace-pre">Limit</p>
    </div>
  );
}

function HeaderCell2() {
  return (
    <div className="absolute h-[80.667px] left-[604.25px] top-0 w-[122.771px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] text-nowrap top-[31px] tracking-[0.6px] uppercase whitespace-pre">Deductible</p>
    </div>
  );
}

function HeaderCell3() {
  return (
    <div className="absolute h-[80.667px] left-[727.02px] top-0 w-[110.125px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[52px]">Everest Line %</p>
    </div>
  );
}

function HeaderCell4() {
  return (
    <div className="absolute h-[80.667px] left-[837.15px] top-0 w-[117.708px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[62px]">Effective Date</p>
    </div>
  );
}

function HeaderCell5() {
  return (
    <div className="absolute h-[80.667px] left-[954.85px] top-0 w-[98.458px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[43px]">Expiry Date</p>
    </div>
  );
}

function HeaderCell6() {
  return (
    <div className="absolute h-[80.667px] left-[1053.31px] top-0 w-[114.333px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] text-nowrap top-[31px] tracking-[0.6px] uppercase whitespace-pre">Broker</p>
    </div>
  );
}

function HeaderCell7() {
  return (
    <div className="absolute h-[80.667px] left-[1167.65px] top-0 w-[127.354px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[71px]">Reporting Level</p>
    </div>
  );
}

function HeaderCell8() {
  return (
    <div className="absolute h-[80.667px] left-[1295px] top-0 w-[113.438px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] text-nowrap top-[31px] tracking-[0.6px] uppercase whitespace-pre">Currency</p>
    </div>
  );
}

function HeaderCell9() {
  return (
    <div className="absolute h-[80.667px] left-[1408.44px] top-0 w-[158.396px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[100px]">Reinstatement Terms</p>
    </div>
  );
}

function HeaderCell10() {
  return (
    <div className="absolute h-[80.667px] left-[1566.83px] top-0 w-[128.75px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[64.02px] text-[#bb4d00] text-[12px] text-center text-nowrap top-[31px] tracking-[0.6px] translate-x-[-50%] uppercase whitespace-pre">Status</p>
    </div>
  );
}

function HeaderCell11() {
  return (
    <div className="absolute h-[80.667px] left-[1695.58px] top-0 w-[120.458px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[96.65px] text-[#1447e6] text-[12px] text-right top-[15px] tracking-[0.6px] translate-x-[-100%] uppercase w-[59px]">UW Estimate Low</p>
    </div>
  );
}

function HeaderCell12() {
  return (
    <div className="absolute h-[80.667px] left-[1816.04px] top-0 w-[126.354px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[102.54px] text-[#1447e6] text-[12px] text-right top-[15px] tracking-[0.6px] translate-x-[-100%] uppercase w-[59px]">UW Estimate Medium</p>
    </div>
  );
}

function HeaderCell13() {
  return (
    <div className="absolute h-[80.667px] left-[1942.4px] top-0 w-[121.417px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[97.6px] text-[#1447e6] text-[12px] text-right top-[15px] tracking-[0.6px] translate-x-[-100%] uppercase w-[59px]">UW Estimate High</p>
    </div>
  );
}

function HeaderCell14() {
  return (
    <div className="absolute h-[80.667px] left-[2063.81px] top-0 w-[122.354px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[98.63px] text-[#007a55] text-[12px] text-right top-[23px] tracking-[0.6px] translate-x-[-100%] uppercase w-[67px]">Modeling Low</p>
    </div>
  );
}

function HeaderCell15() {
  return (
    <div className="absolute h-[80.667px] left-[2186.17px] top-0 w-[128.271px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[104.54px] text-[#007a55] text-[12px] text-right top-[23px] tracking-[0.6px] translate-x-[-100%] uppercase w-[67px]">Modeling Medium</p>
    </div>
  );
}

function HeaderCell16() {
  return (
    <div className="absolute h-[80.667px] left-[2314.44px] top-0 w-[123.313px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[99.58px] text-[#007a55] text-[12px] text-right top-[23px] tracking-[0.6px] translate-x-[-100%] uppercase w-[67px]">Modeling High</p>
    </div>
  );
}

function HeaderCell17() {
  return (
    <div className="absolute h-[80.667px] left-[2437.75px] top-0 w-[120.917px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[97.04px] text-[#8200db] text-[12px] text-right top-[15px] tracking-[0.6px] translate-x-[-100%] uppercase w-[54px]">Finance Gross Loss</p>
    </div>
  );
}

function TableRow() {
  return (
    <div className="absolute bg-slate-50 border-[0px_0px_1.333px] border-slate-200 border-solid h-[80.667px] left-0 top-0 w-[2558.67px]" data-name="Table Row">
      <HeaderCell />
      <HeaderCell1 />
      <HeaderCell2 />
      <HeaderCell3 />
      <HeaderCell4 />
      <HeaderCell5 />
      <HeaderCell6 />
      <HeaderCell7 />
      <HeaderCell8 />
      <HeaderCell9 />
      <HeaderCell10 />
      <HeaderCell11 />
      <HeaderCell12 />
      <HeaderCell13 />
      <HeaderCell14 />
      <HeaderCell15 />
      <HeaderCell16 />
      <HeaderCell17 />
    </div>
  );
}

function TableHeader() {
  return (
    <div className="absolute h-[80.667px] left-0 top-0 w-[2558.67px]" data-name="Table Header">
      <TableRow />
    </div>
  );
}

function TableCell() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell1() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$50M xs $10M</p>
    </div>
  );
}

function TableCell2() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$10M</p>
    </div>
  );
}

function TableCell3() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">15.5%</p>
    </div>
  );
}

function TableCell4() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-01-01</p>
    </div>
  );
}

function TableCell5() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2024-12-31</p>
    </div>
  );
}

function TableCell6() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">AON</p>
    </div>
  );
}

function TableCell7() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell8() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell9() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2 @ 100%</p>
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute bg-[#d0fae5] content-stretch flex h-[24px] items-start left-[26.88px] px-[12px] py-[4px] rounded-[4.47392e+07px] top-[31.67px] w-[75px]" data-name="Text">
      <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#007a55] text-[12px] text-center text-nowrap whitespace-pre">Impacted</p>
    </div>
  );
}

function TableCell10() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text5 />
    </div>
  );
}

function TableCell11() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.67px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.2M</p>
    </div>
  );
}

function TableCell12() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.21px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.8M</p>
    </div>
  );
}

function TableCell13() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.63px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$2.5M</p>
    </div>
  );
}

function TableCell14() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.56px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.5M</p>
    </div>
  );
}

function TableCell15() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[105.13px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$2.1M</p>
    </div>
  );
}

function TableCell16() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.52px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$2.8M</p>
    </div>
  );
}

function TableCell17() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.73px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.9M</p>
    </div>
  );
}

function TableRow1() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-0 w-[2558.67px]" data-name="Table Row">
      <TableCell />
      <TableCell1 />
      <TableCell2 />
      <TableCell3 />
      <TableCell4 />
      <TableCell5 />
      <TableCell6 />
      <TableCell7 />
      <TableCell8 />
      <TableCell9 />
      <TableCell10 />
      <TableCell11 />
      <TableCell12 />
      <TableCell13 />
      <TableCell14 />
      <TableCell15 />
      <TableCell16 />
      <TableCell17 />
    </div>
  );
}

function TableCell18() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">QS</p>
    </div>
  );
}

function TableCell19() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[37px]">25% of $200M</p>
    </div>
  );
}

function TableCell20() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">N/A</p>
    </div>
  );
}

function TableCell21() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">12.0%</p>
    </div>
  );
}

function TableCell22() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-01-01</p>
    </div>
  );
}

function TableCell23() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2024-12-31</p>
    </div>
  );
}

function TableCell24() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">AON</p>
    </div>
  );
}

function TableCell25() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Aggregate</p>
    </div>
  );
}

function TableCell26() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell27() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Pro-rata</p>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute bg-[#d0fae5] content-stretch flex h-[24px] items-start left-[26.88px] px-[12px] py-[4px] rounded-[4.47392e+07px] top-[31.67px] w-[75px]" data-name="Text">
      <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#007a55] text-[12px] text-center text-nowrap whitespace-pre">Impacted</p>
    </div>
  );
}

function TableCell28() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text6 />
    </div>
  );
}

function TableCell29() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.6px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$850K</p>
    </div>
  );
}

function TableCell30() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.21px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.2M</p>
    </div>
  );
}

function TableCell31() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.63px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.8M</p>
    </div>
  );
}

function TableCell32() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.5px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$900K</p>
    </div>
  );
}

function TableCell33() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[105.13px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.3M</p>
    </div>
  );
}

function TableCell34() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.52px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.9M</p>
    </div>
  );
}

function TableCell35() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.6px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.1M</p>
    </div>
  );
}

function TableRow2() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[87.33px] w-[2558.67px]" data-name="Table Row">
      <TableCell18 />
      <TableCell19 />
      <TableCell20 />
      <TableCell21 />
      <TableCell22 />
      <TableCell23 />
      <TableCell24 />
      <TableCell25 />
      <TableCell26 />
      <TableCell27 />
      <TableCell28 />
      <TableCell29 />
      <TableCell30 />
      <TableCell31 />
      <TableCell32 />
      <TableCell33 />
      <TableCell34 />
      <TableCell35 />
    </div>
  );
}

function TableCell36() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell37() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$75M xs $25M</p>
    </div>
  );
}

function TableCell38() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$25M</p>
    </div>
  );
}

function TableCell39() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">18.0%</p>
    </div>
  );
}

function TableCell40() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-01-01</p>
    </div>
  );
}

function TableCell41() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2024-12-31</p>
    </div>
  );
}

function TableCell42() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Marsh</p>
    </div>
  );
}

function TableCell43() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell44() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell45() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[81px]">1 @ 100%, 1 @ 110%</p>
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell46() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text7 />
    </div>
  );
}

function TableCell47() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell48() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell49() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell50() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell51() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell52() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell53() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow3() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[174.67px] w-[2558.67px]" data-name="Table Row">
      <TableCell36 />
      <TableCell37 />
      <TableCell38 />
      <TableCell39 />
      <TableCell40 />
      <TableCell41 />
      <TableCell42 />
      <TableCell43 />
      <TableCell44 />
      <TableCell45 />
      <TableCell46 />
      <TableCell47 />
      <TableCell48 />
      <TableCell49 />
      <TableCell50 />
      <TableCell51 />
      <TableCell52 />
      <TableCell53 />
    </div>
  );
}

function TableCell54() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">QS</p>
    </div>
  );
}

function TableCell55() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[37px]">30% of $150M</p>
    </div>
  );
}

function TableCell56() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">N/A</p>
    </div>
  );
}

function TableCell57() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">20.0%</p>
    </div>
  );
}

function TableCell58() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-06-01</p>
    </div>
  );
}

function TableCell59() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2025-05-31</p>
    </div>
  );
}

function TableCell60() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[40px]">Willis Towers Watson</p>
    </div>
  );
}

function TableCell61() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Aggregate</p>
    </div>
  );
}

function TableCell62() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell63() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Pro-rata</p>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute bg-[#d0fae5] content-stretch flex h-[24px] items-start left-[26.88px] px-[12px] py-[4px] rounded-[4.47392e+07px] top-[31.67px] w-[75px]" data-name="Text">
      <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#007a55] text-[12px] text-center text-nowrap whitespace-pre">Impacted</p>
    </div>
  );
}

function TableCell64() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text8 />
    </div>
  );
}

function TableCell65() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.6px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$650K</p>
    </div>
  );
}

function TableCell66() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.33px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$950K</p>
    </div>
  );
}

function TableCell67() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.63px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.4M</p>
    </div>
  );
}

function TableCell68() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.5px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$700K</p>
    </div>
  );
}

function TableCell69() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[105.13px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.0M</p>
    </div>
  );
}

function TableCell70() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.52px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$1.5M</p>
    </div>
  );
}

function TableCell71() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[96.94px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$880K</p>
    </div>
  );
}

function TableRow4() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[262px] w-[2558.67px]" data-name="Table Row">
      <TableCell54 />
      <TableCell55 />
      <TableCell56 />
      <TableCell57 />
      <TableCell58 />
      <TableCell59 />
      <TableCell60 />
      <TableCell61 />
      <TableCell62 />
      <TableCell63 />
      <TableCell64 />
      <TableCell65 />
      <TableCell66 />
      <TableCell67 />
      <TableCell68 />
      <TableCell69 />
      <TableCell70 />
      <TableCell71 />
    </div>
  );
}

function TableCell72() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell73() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$100M xs $20M</p>
    </div>
  );
}

function TableCell74() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$20M</p>
    </div>
  );
}

function TableCell75() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">25.0%</p>
    </div>
  );
}

function TableCell76() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-06-01</p>
    </div>
  );
}

function TableCell77() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2025-05-31</p>
    </div>
  );
}

function TableCell78() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[40px]">Willis Towers Watson</p>
    </div>
  );
}

function TableCell79() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell80() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell81() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2 @ 100%</p>
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell82() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text9 />
    </div>
  );
}

function TableCell83() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell84() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell85() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell86() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell87() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell88() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell89() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow5() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[349.33px] w-[2558.67px]" data-name="Table Row">
      <TableCell72 />
      <TableCell73 />
      <TableCell74 />
      <TableCell75 />
      <TableCell76 />
      <TableCell77 />
      <TableCell78 />
      <TableCell79 />
      <TableCell80 />
      <TableCell81 />
      <TableCell82 />
      <TableCell83 />
      <TableCell84 />
      <TableCell85 />
      <TableCell86 />
      <TableCell87 />
      <TableCell88 />
      <TableCell89 />
    </div>
  );
}

function TableCell90() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell91() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$30M xs $5M</p>
    </div>
  );
}

function TableCell92() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$5M</p>
    </div>
  );
}

function TableCell93() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">10.0%</p>
    </div>
  );
}

function TableCell94() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-03-01</p>
    </div>
  );
}

function TableCell95() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2025-02-28</p>
    </div>
  );
}

function TableCell96() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[53px]">Guy Carpenter</p>
    </div>
  );
}

function TableCell97() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell98() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell99() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">1 @ 100%</p>
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell100() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text10 />
    </div>
  );
}

function TableCell101() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell102() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell103() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell104() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell105() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell106() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell107() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow6() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[436.67px] w-[2558.67px]" data-name="Table Row">
      <TableCell90 />
      <TableCell91 />
      <TableCell92 />
      <TableCell93 />
      <TableCell94 />
      <TableCell95 />
      <TableCell96 />
      <TableCell97 />
      <TableCell98 />
      <TableCell99 />
      <TableCell100 />
      <TableCell101 />
      <TableCell102 />
      <TableCell103 />
      <TableCell104 />
      <TableCell105 />
      <TableCell106 />
      <TableCell107 />
    </div>
  );
}

function TableCell108() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">QS</p>
    </div>
  );
}

function TableCell109() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[37px]">15% of $80M</p>
    </div>
  );
}

function TableCell110() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">N/A</p>
    </div>
  );
}

function TableCell111() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">8.5%</p>
    </div>
  );
}

function TableCell112() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-03-01</p>
    </div>
  );
}

function TableCell113() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2025-02-28</p>
    </div>
  );
}

function TableCell114() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[53px]">Guy Carpenter</p>
    </div>
  );
}

function TableCell115() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Aggregate</p>
    </div>
  );
}

function TableCell116() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell117() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Pro-rata</p>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell118() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text11 />
    </div>
  );
}

function TableCell119() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell120() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell121() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell122() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell123() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell124() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell125() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow7() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[524px] w-[2558.67px]" data-name="Table Row">
      <TableCell108 />
      <TableCell109 />
      <TableCell110 />
      <TableCell111 />
      <TableCell112 />
      <TableCell113 />
      <TableCell114 />
      <TableCell115 />
      <TableCell116 />
      <TableCell117 />
      <TableCell118 />
      <TableCell119 />
      <TableCell120 />
      <TableCell121 />
      <TableCell122 />
      <TableCell123 />
      <TableCell124 />
      <TableCell125 />
    </div>
  );
}

function TableCell126() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell127() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$20M xs $10M</p>
    </div>
  );
}

function TableCell128() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$10M</p>
    </div>
  );
}

function TableCell129() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">5.0%</p>
    </div>
  );
}

function TableCell130() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-01-01</p>
    </div>
  );
}

function TableCell131() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2024-12-31</p>
    </div>
  );
}

function TableCell132() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">AON</p>
    </div>
  );
}

function TableCell133() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell134() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell135() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">None</p>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell136() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text12 />
    </div>
  );
}

function TableCell137() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell138() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell139() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell140() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell141() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell142() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell143() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow8() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[611.33px] w-[2558.67px]" data-name="Table Row">
      <TableCell126 />
      <TableCell127 />
      <TableCell128 />
      <TableCell129 />
      <TableCell130 />
      <TableCell131 />
      <TableCell132 />
      <TableCell133 />
      <TableCell134 />
      <TableCell135 />
      <TableCell136 />
      <TableCell137 />
      <TableCell138 />
      <TableCell139 />
      <TableCell140 />
      <TableCell141 />
      <TableCell142 />
      <TableCell143 />
    </div>
  );
}

function TableCell144() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell145() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">$15M xs $5M</p>
    </div>
  );
}

function TableCell146() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">$5M</p>
    </div>
  );
}

function TableCell147() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">7.5%</p>
    </div>
  );
}

function TableCell148() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-01-01</p>
    </div>
  );
}

function TableCell149() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2024-12-31</p>
    </div>
  );
}

function TableCell150() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Marsh</p>
    </div>
  );
}

function TableCell151() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell152() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">USD</p>
    </div>
  );
}

function TableCell153() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">1 @ 100%</p>
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell154() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text13 />
    </div>
  );
}

function TableCell155() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell156() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell157() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell158() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell159() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell160() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell161() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow9() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[698.67px] w-[2558.67px]" data-name="Table Row">
      <TableCell144 />
      <TableCell145 />
      <TableCell146 />
      <TableCell147 />
      <TableCell148 />
      <TableCell149 />
      <TableCell150 />
      <TableCell151 />
      <TableCell152 />
      <TableCell153 />
      <TableCell154 />
      <TableCell155 />
      <TableCell156 />
      <TableCell157 />
      <TableCell158 />
      <TableCell159 />
      <TableCell160 />
      <TableCell161 />
    </div>
  );
}

function TableCell162() {
  return (
    <div className="absolute h-[87.333px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">XL</p>
    </div>
  );
}

function TableCell163() {
  return (
    <div className="absolute h-[87.333px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[45px]">€40M xs €15M</p>
    </div>
  );
}

function TableCell164() {
  return (
    <div className="absolute h-[87.333px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">€15M</p>
    </div>
  );
}

function TableCell165() {
  return (
    <div className="absolute h-[87.333px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">12.5%</p>
    </div>
  );
}

function TableCell166() {
  return (
    <div className="absolute h-[87.333px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2024-04-01</p>
    </div>
  );
}

function TableCell167() {
  return (
    <div className="absolute h-[87.333px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[49px]">2025-03-31</p>
    </div>
  );
}

function TableCell168() {
  return (
    <div className="absolute h-[87.333px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[40px]">Willis Towers Watson</p>
    </div>
  );
}

function TableCell169() {
  return (
    <div className="absolute h-[87.333px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Occurrence</p>
    </div>
  );
}

function TableCell170() {
  return (
    <div className="absolute h-[87.333px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">EUR</p>
    </div>
  );
}

function TableCell171() {
  return (
    <div className="absolute h-[87.333px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">2 @ 100%</p>
    </div>
  );
}

function Text14() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[23.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell172() {
  return (
    <div className="absolute h-[87.333px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text14 />
    </div>
  );
}

function TableCell173() {
  return (
    <div className="absolute h-[87.333px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell174() {
  return (
    <div className="absolute h-[87.333px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell175() {
  return (
    <div className="absolute h-[87.333px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell176() {
  return (
    <div className="absolute h-[87.333px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell177() {
  return (
    <div className="absolute h-[87.333px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell178() {
  return (
    <div className="absolute h-[87.333px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell179() {
  return (
    <div className="absolute h-[87.333px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[32.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow10() {
  return (
    <div className="absolute border-[0px_0px_1.333px] border-slate-200 border-solid h-[87.333px] left-0 top-[786px] w-[2558.67px]" data-name="Table Row">
      <TableCell162 />
      <TableCell163 />
      <TableCell164 />
      <TableCell165 />
      <TableCell166 />
      <TableCell167 />
      <TableCell168 />
      <TableCell169 />
      <TableCell170 />
      <TableCell171 />
      <TableCell172 />
      <TableCell173 />
      <TableCell174 />
      <TableCell175 />
      <TableCell176 />
      <TableCell177 />
      <TableCell178 />
      <TableCell179 />
    </div>
  );
}

function TableCell180() {
  return (
    <div className="absolute h-[72.667px] left-[389.63px] top-0 w-[118.604px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">QS</p>
    </div>
  );
}

function TableCell181() {
  return (
    <div className="absolute h-[72.667px] left-[508.23px] top-0 w-[96.021px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[16.67px] w-[37px]">20% of €100M</p>
    </div>
  );
}

function TableCell182() {
  return (
    <div className="absolute h-[72.667px] left-[604.25px] top-0 w-[122.771px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">N/A</p>
    </div>
  );
}

function TableCell183() {
  return (
    <div className="absolute h-[72.667px] left-[727.02px] top-0 w-[110.125px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">9.0%</p>
    </div>
  );
}

function TableCell184() {
  return (
    <div className="absolute h-[72.667px] left-[837.15px] top-0 w-[117.708px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">2024-04-01</p>
    </div>
  );
}

function TableCell185() {
  return (
    <div className="absolute h-[72.667px] left-[954.85px] top-0 w-[98.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[16.67px] w-[49px]">2025-03-31</p>
    </div>
  );
}

function TableCell186() {
  return (
    <div className="absolute h-[72.667px] left-[1053.31px] top-0 w-[114.333px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[16.67px] w-[53px]">Guy Carpenter</p>
    </div>
  );
}

function TableCell187() {
  return (
    <div className="absolute h-[72.667px] left-[1167.65px] top-0 w-[127.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">Aggregate</p>
    </div>
  );
}

function TableCell188() {
  return (
    <div className="absolute h-[72.667px] left-[1295px] top-0 w-[113.438px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">EUR</p>
    </div>
  );
}

function TableCell189() {
  return (
    <div className="absolute h-[72.667px] left-[1408.44px] top-0 w-[158.396px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">Pro-rata</p>
    </div>
  );
}

function Text15() {
  return (
    <div className="absolute bg-slate-100 h-[40px] left-[24px] rounded-[4.47392e+07px] top-[16.67px] w-[80.75px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[40.38px] text-[#45556c] text-[12px] text-center top-[3px] translate-x-[-50%] w-[51px]">Not Impacted</p>
    </div>
  );
}

function TableCell190() {
  return (
    <div className="absolute h-[72.667px] left-[1566.83px] top-0 w-[128.75px]" data-name="Table Cell">
      <Text15 />
    </div>
  );
}

function TableCell191() {
  return (
    <div className="absolute h-[72.667px] left-[1695.58px] top-0 w-[120.458px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[96.52px] text-[#1447e6] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell192() {
  return (
    <div className="absolute h-[72.667px] left-[1816.04px] top-0 w-[126.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[103.02px] text-[#1447e6] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell193() {
  return (
    <div className="absolute h-[72.667px] left-[1942.4px] top-0 w-[121.417px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[97.48px] text-[#1447e6] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell194() {
  return (
    <div className="absolute h-[72.667px] left-[2063.81px] top-0 w-[122.354px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[98.42px] text-[#007a55] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell195() {
  return (
    <div className="absolute h-[72.667px] left-[2186.17px] top-0 w-[128.271px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[104.94px] text-[#007a55] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell196() {
  return (
    <div className="absolute h-[72.667px] left-[2314.44px] top-0 w-[123.313px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[99.38px] text-[#007a55] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableCell197() {
  return (
    <div className="absolute h-[72.667px] left-[2437.75px] top-0 w-[120.917px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[18px] left-[97.58px] text-[#8200db] text-[12px] text-nowrap text-right top-[25.67px] translate-x-[-100%] whitespace-pre">$0</p>
    </div>
  );
}

function TableRow11() {
  return (
    <div className="absolute h-[72.667px] left-0 top-[873.33px] w-[2558.67px]" data-name="Table Row">
      <TableCell180 />
      <TableCell181 />
      <TableCell182 />
      <TableCell183 />
      <TableCell184 />
      <TableCell185 />
      <TableCell186 />
      <TableCell187 />
      <TableCell188 />
      <TableCell189 />
      <TableCell190 />
      <TableCell191 />
      <TableCell192 />
      <TableCell193 />
      <TableCell194 />
      <TableCell195 />
      <TableCell196 />
      <TableCell197 />
    </div>
  );
}

function TableBody() {
  return (
    <div className="absolute h-[946px] left-0 top-[80.67px] w-[2558.67px]" data-name="Table Body">
      <TableRow1 />
      <TableRow2 />
      <TableRow3 />
      <TableRow4 />
      <TableRow5 />
      <TableRow6 />
      <TableRow7 />
      <TableRow8 />
      <TableRow9 />
      <TableRow10 />
      <TableRow11 />
    </div>
  );
}

function Table() {
  return (
    <div className="absolute h-[1026.67px] left-0 top-0 w-[2558.67px]" data-name="Table">
      <TableHeader />
      <TableBody />
    </div>
  );
}

function TableCell198() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[80.67px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[66px]">PROP-2024-001</p>
    </div>
  );
}

function TableCell199() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[80.67px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[51px]">California Wildfire Coverage</p>
    </div>
  );
}

function TableCell200() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[80.67px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[77px]">ABC Insurance Company</p>
    </div>
  );
}

function TableCell201() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[168px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[66px]">PROP-2024-002</p>
    </div>
  );
}

function TableCell202() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[168px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[59px]">Texas Windstorm Treaty</p>
    </div>
  );
}

function TableCell203() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[168px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[77px]">ABC Insurance Company</p>
    </div>
  );
}

function TableCell204() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[255.33px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[66px]">PROP-2024-003</p>
    </div>
  );
}

function TableCell205() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[255.33px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[52px]">Florida Hurricane Treaty</p>
    </div>
  );
}

function TableCell206() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[255.33px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[77px]">ABC Insurance Company</p>
    </div>
  );
}

function TableCell207() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[342.67px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[62px]">TRES-2024-045</p>
    </div>
  );
}

function TableCell208() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[342.67px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[57px]">Mexico QS Property</p>
    </div>
  );
}

function TableCell209() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[342.67px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[64px]">Global Reinsurance Ltd</p>
    </div>
  );
}

function TableCell210() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[430px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[62px]">TRES-2024-046</p>
    </div>
  );
}

function TableCell211() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[430px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Mexico CAT XL</p>
    </div>
  );
}

function TableCell212() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[430px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[64px]">Global Reinsurance Ltd</p>
    </div>
  );
}

function TableCell213() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[517.33px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[73px]">LATAM-2024-023</p>
    </div>
  );
}

function TableCell214() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[517.33px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">Brazil CAT XL</p>
    </div>
  );
}

function TableCell215() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[517.33px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[51px]">LATAM Insurance Group</p>
    </div>
  );
}

function TableCell216() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[604.67px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[73px]">LATAM-2024-024</p>
    </div>
  );
}

function TableCell217() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[604.67px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[48px]">Brazil QS Property</p>
    </div>
  );
}

function TableCell218() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[604.67px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[51px]">LATAM Insurance Group</p>
    </div>
  );
}

function TableCell219() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[692px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">CAS-2024-012</p>
    </div>
  );
}

function TableCell220() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[692px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[85px]">General Liability XL</p>
    </div>
  );
}

function TableCell221() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[692px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[50px]">North American Mutual</p>
    </div>
  );
}

function TableCell222() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[779.33px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">CAS-2024-013</p>
    </div>
  );
}

function TableCell223() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[779.33px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[79px]">Workers Comp XL</p>
    </div>
  );
}

function TableCell224() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[779.33px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[14.67px] w-[50px]">North American Mutual</p>
    </div>
  );
}

function TableCell225() {
  return (
    <div className="absolute bg-white h-[87.333px] left-0 top-[866.67px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[32.67px] whitespace-pre">EUR-2024-067</p>
    </div>
  );
}

function TableCell226() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[140px] top-[866.67px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[86px]">European Storm XL</p>
    </div>
  );
}

function TableCell227() {
  return (
    <div className="absolute bg-white h-[87.333px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[866.67px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[23.67px] w-[75px]">European Risk Partners</p>
    </div>
  );
}

function TableCell228() {
  return (
    <div className="absolute bg-white h-[72.667px] left-0 top-[954px] w-[128.146px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">EUR-2024-068</p>
    </div>
  );
}

function TableCell229() {
  return (
    <div className="absolute bg-white h-[72.667px] left-[140px] top-[954px] w-[134px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-nowrap text-slate-900 top-[25.67px] whitespace-pre">UK QS Property</p>
    </div>
  );
}

function TableCell230() {
  return (
    <div className="absolute bg-white h-[72.667px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-[954px] w-[127.479px]" data-name="Table Cell">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[24px] text-[12px] text-slate-900 top-[16.67px] w-[75px]">European Risk Partners</p>
    </div>
  );
}

function HeaderCell18() {
  return (
    <div className="absolute bg-slate-50 h-[80.667px] left-0 top-0 w-[128.146px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[67px]">Contract Number</p>
    </div>
  );
}

function HeaderCell19() {
  return (
    <div className="absolute bg-slate-50 h-[80.667px] left-[140px] top-0 w-[134px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] top-[23px] tracking-[0.6px] uppercase w-[67px]">Contract Name</p>
    </div>
  );
}

function HeaderCell20() {
  return (
    <div className="absolute bg-slate-50 h-[80.667px] left-[340px] shadow-[2px_0px_4px_0px_rgba(0,0,0,0.06)] top-0 w-[127.479px]" data-name="Header Cell">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[16px] left-[24px] text-[#314158] text-[12px] text-nowrap top-[31px] tracking-[0.6px] uppercase whitespace-pre">Cedant</p>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[1026.67px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <Table />
      <TableCell198 />
      <TableCell199 />
      <TableCell200 />
      <TableCell201 />
      <TableCell202 />
      <TableCell203 />
      <TableCell204 />
      <TableCell205 />
      <TableCell206 />
      <TableCell207 />
      <TableCell208 />
      <TableCell209 />
      <TableCell210 />
      <TableCell211 />
      <TableCell212 />
      <TableCell213 />
      <TableCell214 />
      <TableCell215 />
      <TableCell216 />
      <TableCell217 />
      <TableCell218 />
      <TableCell219 />
      <TableCell220 />
      <TableCell221 />
      <TableCell222 />
      <TableCell223 />
      <TableCell224 />
      <TableCell225 />
      <TableCell226 />
      <TableCell227 />
      <TableCell228 />
      <TableCell229 />
      <TableCell230 />
      <HeaderCell18 />
      <HeaderCell19 />
      <HeaderCell20 />
    </div>
  );
}

function Container36() {
  return (
    <div className="bg-white h-[1029.33px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col h-[1029.33px] items-start p-[1.333px] relative w-full">
          <Container35 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[1.333px] border-slate-200 border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[1546.67px] relative shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[32px] h-[1546.67px] items-start pb-0 pt-[32px] px-[32px] relative w-full">
          <Container21 />
          <Container34 />
          <Container36 />
        </div>
      </div>
    </div>
  );
}

function Container38() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[2625.33px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-full items-start overflow-clip relative rounded-[inherit] w-[2625.33px]">
        <Container37 />
      </div>
    </div>
  );
}

function UnderwriterEstimationNew() {
  return (
    <div className="basis-0 bg-slate-50 grow h-[1753.33px] min-h-px min-w-px relative shrink-0" data-name="UnderwriterEstimationNew">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[1753.33px] items-start relative w-full">
        <Container3 />
        <Container38 />
      </div>
    </div>
  );
}

function EventDetailLayout() {
  return (
    <div className="absolute content-stretch flex h-[1817.33px] items-start left-0 pb-0 pl-[256px] pr-0 pt-[64px] top-0 w-[2881.33px]" data-name="EventDetailLayout" style={{ backgroundImage: "linear-gradient(147.759deg, rgb(248, 250, 252) 0%, rgb(239, 246, 255) 50%, rgb(248, 250, 252) 100%), linear-gradient(90deg, rgb(248, 250, 252) 0%, rgb(248, 250, 252) 100%)" }}>
      <UnderwriterEstimationNew />
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[20px] relative shrink-0 w-[167.896px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[20px] relative w-[167.896px]">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#45556c] text-[14px] top-[-2px] w-[168px]">Showing 11 of 11 contracts</p>
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-[25.33px] size-[16px] top-[12.33px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p3c401780} id="Vector" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p56b0600} id="Vector_2" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p17caa400} id="Vector_3" stroke="var(--stroke-0, #314158)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[40.667px] relative rounded-[10px] shrink-0 w-[131.146px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#cad5e2] border-[1.333px] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[40.667px] relative w-[131.146px]">
        <Icon11 />
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[77.83px] text-[#314158] text-[12px] text-center text-nowrap top-[9.33px] translate-x-[-50%] whitespace-pre">Save Draft</p>
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="absolute left-[24px] size-[16px] top-[11px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_132_3652)" id="Icon">
          <path d={svgPaths.p151c1700} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1110efc0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_132_3652">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="bg-[#0052ff] h-[38px] relative rounded-[10px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] shrink-0 w-[165.729px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[38px] relative w-[165.729px]">
        <Icon12 />
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[18px] left-[95px] text-[12px] text-center text-nowrap text-white top-[8px] translate-x-[-50%] whitespace-pre">Submit Estimates</p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[40.667px] relative shrink-0 w-[308.875px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] h-[40.667px] items-center relative w-[308.875px]">
        <Button8 />
        <Button9 />
      </div>
    </div>
  );
}

function UnderwriterEstimationNew1() {
  return (
    <div className="absolute bg-white content-stretch flex h-[74px] items-center justify-between left-0 pb-0 pt-[1.333px] px-[32px] top-[1148.67px] w-[2881.33px]" data-name="UnderwriterEstimationNew">
      <div aria-hidden="true" className="absolute border-[1.333px_0px_0px] border-slate-200 border-solid inset-0 pointer-events-none shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)]" />
      <Container39 />
      <Container40 />
    </div>
  );
}

function TextInput4() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] h-[38.667px] left-0 rounded-[10px] top-0 w-[448px]" data-name="Text Input">
      <div className="content-stretch flex h-[38.667px] items-center overflow-clip pl-[40px] pr-[16px] py-[8px] relative rounded-[inherit] w-[448px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.5)] text-nowrap whitespace-pre">Search events...</p>
      </div>
      <div aria-hidden="true" className="absolute border-[1.333px] border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[11.33px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M14 14L11.1067 11.1067" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.5" strokeWidth="1.33333" />
          <path d={svgPaths.p107a080} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.5" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container41() {
  return (
    <div className="absolute h-[38.667px] left-[32px] top-[12px] w-[448px]" data-name="Container">
      <TextInput4 />
      <Icon13 />
    </div>
  );
}

function Container42() {
  return (
    <div className="bg-[rgba(255,255,255,0.2)] relative rounded-[10px] shrink-0 size-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-[32px]">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[12px] text-nowrap text-white whitespace-pre">SM</p>
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-full">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[20px] relative shrink-0 text-[14px] text-nowrap text-white whitespace-pre">Demo User</p>
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[32px] items-center left-0 top-[2px] w-[110.604px]" data-name="Container">
      <Container42 />
      <Container43 />
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-[8px] size-[20px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p18235680} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p1f3d9f80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text16() {
  return <div className="absolute bg-[#2b7fff] left-[22px] rounded-[4.47392e+07px] shadow-[0px_0px_0px_2px_#0f172a] size-[8px] top-[6px]" data-name="Text" />;
}

function Button10() {
  return (
    <div className="h-[36px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon14 />
      <Text16 />
    </div>
  );
}

function Container45() {
  return (
    <div className="absolute content-stretch flex flex-col h-[36px] items-start left-[126.6px] pl-[17.333px] pr-0 py-0 top-0 w-[53.333px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_0px_1.333px] border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none" />
      <Button10 />
    </div>
  );
}

function Container46() {
  return (
    <div className="absolute h-[36px] left-[2413.4px] top-[13.33px] w-[179.938px]" data-name="Container">
      <Container44 />
      <Container45 />
    </div>
  );
}

function EventDetailLayout1() {
  return (
    <div className="absolute bg-[#0052ff] border-[0px_0px_1.333px] border-[rgba(255,255,255,0.1)] border-solid h-[64px] left-[256px] top-0 w-[2625.33px]" data-name="EventDetailLayout">
      <Container41 />
      <Container46 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d={svgPaths.p21b96680} fill="var(--fill-0, #0052FF)" id="Vector" opacity="0.2" />
          <path d={svgPaths.p2f833b80} fill="var(--fill-0, #0052FF)" id="Vector_2" />
          <path d={svgPaths.p19ad8a00} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.p1db6dd00} fill="var(--fill-0, white)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Bold',sans-serif] font-bold grow leading-[20px] min-h-px min-w-px relative shrink-0 text-[14px] text-white">Dream Re</p>
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex h-[13.5px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[13.5px] relative shrink-0 text-[9px] text-[rgba(255,255,255,0.6)] text-nowrap tracking-[0.45px] uppercase whitespace-pre">LLEP Platform</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="basis-0 grow h-[33.5px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[33.5px] items-start relative w-full">
        <Container47 />
        <Container48 />
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="h-[33.5px] relative shrink-0 w-[106.458px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] h-[33.5px] items-center relative w-[106.458px]">
        <Icon15 />
        <Container49 />
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="absolute content-stretch flex h-[64px] items-center left-0 pb-[1.333px] pl-[16px] pr-0 pt-0 top-0 w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
      <Container50 />
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-0 size-[16px] top-[2px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p203476e0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M12.6667 8H3.33333" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="h-[20px] relative shrink-0 w-[115.688px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[20px] relative w-[115.688px]">
        <Icon16 />
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[70px] text-[14px] text-[rgba(255,255,255,0.7)] text-center text-nowrap top-[-2px] translate-x-[-50%] whitespace-pre">Back to Events</p>
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="absolute content-stretch flex h-[48px] items-center left-0 pb-[1.333px] pl-[16px] pr-0 pt-0 top-[64px] w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
      <Button11 />
    </div>
  );
}

function Container53() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[12px] text-[rgba(255,255,255,0.5)] tracking-[0.3px] uppercase">Current Event</p>
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Arimo:Bold',sans-serif] font-bold grow leading-[20px] min-h-px min-w-px relative shrink-0 text-[14px] text-white">Hurricane Milton</p>
    </div>
  );
}

function Container55() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Regular',sans-serif] leading-[16px] left-0 not-italic text-[12px] text-[rgba(255,255,255,0.6)] text-nowrap top-[0.33px] whitespace-pre">EVT-2024-001</p>
    </div>
  );
}

function Container56() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[60px] items-start relative shrink-0 w-full" data-name="Container">
      <Container53 />
      <Container54 />
      <Container55 />
    </div>
  );
}

function Container57() {
  return (
    <div className="basis-0 bg-[rgba(255,255,255,0.2)] grow min-h-px min-w-px relative rounded-[4px] shrink-0 w-[224px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-full items-center px-[10px] py-[4px] relative w-[224px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[16px] relative shrink-0 text-[12px] text-nowrap text-white whitespace-pre">Active</p>
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div className="h-[16px] relative shrink-0 w-[224px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[16px] relative w-[224px]">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[16px] left-0 text-[12px] text-[rgba(255,255,255,0.7)] top-[-1px] w-[128px]">Phase 3 • 68% complete</p>
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Container57 />
      <Container58 />
    </div>
  );
}

function Container60() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[153.333px] items-start left-0 pb-[1.333px] pt-[16px] px-[16px] top-[112px] w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1.333px] border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
      <Container56 />
      <Container59 />
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p23e13900} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d={svgPaths.p28db2b80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text17() {
  return (
    <div className="h-[20px] relative shrink-0 w-[59.542px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[59.542px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.7)] text-center text-nowrap whitespace-pre">Overview</p>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] h-[40px] items-center pl-[12px] pr-0 py-0 relative w-full">
          <Icon17 />
          <Text17 />
        </div>
      </div>
    </div>
  );
}

function Icon18() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p32c00400} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2f10900} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M6.66667 6H5.33333" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M10.6667 8.66667H5.33333" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M10.6667 11.3333H5.33333" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text18() {
  return (
    <div className="h-[20px] relative shrink-0 w-[94.167px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[94.167px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] text-center text-nowrap text-white whitespace-pre">UW Estimation</p>
      </div>
    </div>
  );
}

function Button13() {
  return (
    <div className="bg-[rgba(255,255,255,0.2)] h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] h-[40px] items-center pl-[12px] pr-0 py-0 relative w-full">
          <Icon18 />
          <Text18 />
        </div>
      </div>
    </div>
  );
}

function Icon19() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p90824c0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M12 11.3333V6" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M8.66667 11.3333V3.33333" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M5.33333 11.3333V9.33333" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[20px] relative shrink-0 w-[61.104px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[61.104px]">
        <p className="basis-0 font-['Arimo:Regular',sans-serif] font-normal grow leading-[20px] min-h-px min-w-px relative shrink-0 text-[14px] text-[rgba(255,255,255,0.7)] text-center">Modeling</p>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] h-[40px] items-center pl-[12px] pr-0 py-0 relative w-full">
          <Icon19 />
          <Text19 />
        </div>
      </div>
    </div>
  );
}

function Icon20() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p34c7cb00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text20() {
  return (
    <div className="h-[20px] relative shrink-0 w-[72.271px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[72.271px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.7)] text-center text-nowrap whitespace-pre">Documents</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] h-[40px] items-center pl-[12px] pr-0 py-0 relative w-full">
          <Icon20 />
          <Text20 />
        </div>
      </div>
    </div>
  );
}

function Icon21() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p12949080} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M2 2V5.33333H5.33333" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d="M8 4.66667V8L10.6667 9.33333" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text21() {
  return (
    <div className="h-[20px] relative shrink-0 w-[62.208px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[20px] items-start relative w-[62.208px]">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.7)] text-center text-nowrap whitespace-pre">Audit Log</p>
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] h-[40px] items-center pl-[12px] pr-0 py-0 relative w-full">
          <Icon21 />
          <Text21 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[830.667px] items-start left-0 overflow-clip pb-0 pt-[12px] px-[12px] top-[265.33px] w-[256px]" data-name="Navigation">
      <Button12 />
      <Button13 />
      <Button14 />
      <Button15 />
      <Button16 />
    </div>
  );
}

function Icon22() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M10 12L6 8L10 4" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button17() {
  return (
    <div className="content-stretch flex h-[36px] items-center justify-center relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon22 />
    </div>
  );
}

function Container61() {
  return (
    <div className="absolute content-stretch flex flex-col h-[61.333px] items-start left-0 pb-0 pt-[13.333px] px-[12px] top-[1096px] w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px_0px_0px] border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
      <Button17 />
    </div>
  );
}

function Icon23() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p27ba7fa0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
          <path d={svgPaths.p28db2b80} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.7" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button18() {
  return (
    <div className="h-[40px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <Icon23 />
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[66.5px] text-[14px] text-[rgba(255,255,255,0.7)] text-center text-nowrap top-[8px] translate-x-[-50%] whitespace-pre">Settings</p>
    </div>
  );
}

function Container62() {
  return (
    <div className="absolute content-stretch flex flex-col h-[65.333px] items-start left-0 pb-0 pt-[13.333px] px-[12px] top-[1157.33px] w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[1.333px_0px_0px] border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none" />
      <Button18 />
    </div>
  );
}

function EventDetailLayout2() {
  return (
    <div className="absolute bg-[#0052ff] h-[1222.67px] left-0 top-0 w-[256px]" data-name="EventDetailLayout">
      <Container51 />
      <Container52 />
      <Container60 />
      <Navigation />
      <Container61 />
      <Container62 />
    </div>
  );
}

export default function LargeLossEventPlatform() {
  return (
    <div className="bg-white relative size-full" data-name="Large Loss Event Platform">
      <EventDetailLayout />
      <UnderwriterEstimationNew1 />
      <EventDetailLayout1 />
      <EventDetailLayout2 />
    </div>
  );
}