Everest SONAR
Roles, Responsibilities, Workflow & Notification System
Inference — CAT Event Management  |  Final Reference Document


Document contents
1.  System Overview & Scope Enforcement
2.  Roles & Responsibilities — Full Matrix
3.  Role Profiles — Detailed Description per Role
4.  Workflow Diagram — End-to-End CAT Event Process
5.  Notification System — Matrix & Full Message Drafts

1  System Overview & Scope Enforcement



SONAR Role Matrix
Platform:   Everest SONAR — Administration
Total roles: 8
Total users: 50
Teams:       Admin  |  CAT  |  Claim  |  Finance  |  Management  |  Underwriting

AD Group:    SONAR_Platform_Users — all SONAR users belong to this single AD group.
             Team and role are assigned within SONAR, not at the AD group level.

Scope Enforcement — How Access is Controlled
Access is further limited by event assignment. Users must be assigned to an event to view it.

Profit Center Scope   — limits which contracts a Contributor can edit.
Track Scope (UW / CAT / Finance) — determines which screens are editable per role.
Business Unit Scope   — Underwriting read scope depends on BU / Sub-Unit selection rule.
Executive Area Scope  — limits visibility to the assigned executive area.

Sub Unit Leads and UW Contributors can read only their own sub-units.
Segment Leads and Executive Area Leads read their executive area only.

Access Level Definitions
Access Level	Meaning	Can Edit	Can Approve	Can Lock/Unlock
Admin	Full control	Yes	Yes	Yes (global)
Contributor	Standard editor within scope	Yes (role-scoped)	Yes (if role grants)	Yes (if role grants)
Reader	View only	No	No	No

2  Roles & Responsibilities — Full Matrix



Role	Team	Users	Read Access	Edit Finance	Edit CAT	Edit UW	Lock	Reopen	Approve	Admin Override	Key Actions
Administrator	Admin	1	All Priorities
All Units
All Modules	✓	✓	✓	✓	✓	✓	✓	Global admin override
Emergency unlock/lock
All admin controls
Read/edit all modules
Event Coordinator	Claim	6	All Priorities
All Units
Claims/Event	✓	–	–	–	–	–	–	Create Event
Modify Event
Publish Event
Activate Monitoring/Tracking
Finance Contributor	Finance	3	All Priorities
All Units
Overview/Finance	✓	–	✓	✓	✓	–	–	Create/Modify Event
Update Estimate
Lock Estimate
Reopen Estimate
CAT Contributor	CAT	2	All Priorities
All Units
All modules (read-only)	–	✓	–	✓	–	–	–	Edit CAT Data
Lock CAT
Unlock CAT
CAT loss estimation
Unit Lead	Underwriting	4	Own Units
UW Module	–	–	✓	–	✓	✓	–	Upload Data
Assign Tasks
Approve estimates
Scoped to Business Unit
Sub Unit Lead (Exec Area Lead)	Underwriting	24	Own Units
UW Module
+ granted read	–	–	✓	–	✓	✓	–	Upload Data
Assign Tasks
Approve (scoped)
Scoped to Executive Area
UW Contributor	Underwriting	7	Own Units
UW Module	–	–	✓	–	–	–	–	Upload Data
Enter UW estimates
Scoped to Business Unit
Profit Center scope
Reader	Management	3	All Business Units
All modules (read-only)	–	–	–	–	–	–	–	View only
No edit access
No task capability

Notes on the matrix
✓  =  Permission granted for this role
–  =  Permission not granted / greyed out in system
Finance lock controls: Lock Estimate → Finance; Reopen → Finance (confirmed)
CAT unlock controls: managed by CAT Contributor
Underwriting read scope: depends on BU / Sub-Unit selection configured at onboarding
One or multiple roles can be assigned per user during onboarding

3  Role Profiles — Detailed Description



Administrator  |  Team: Admin  |  1 user
Administrator
Access Level:    Admin — full system access
Executive Area:  Administration
Business Units:  Administration

Read:            All Priorities / All Units / All Modules
Edit:            Finance Module, CAT Module, UW Module, Overview
Lifecycle:       Lock Estimates, Unlock Estimates, Reopen Estimates
Approval:        Approve Estimates, Admin Override, Emergency Controls

Key Actions:
  – Global admin override and emergency unlock/lock
  – Read and edit across all modules and all business units
  – System configuration and user onboarding oversight
  – Admin Override can bypass normal workflow gates if required

Event Coordinator  |  Team: Claim  |  6 users
Event Coordinator
Access Level:    Contributor
Executive Area:  Claims 
Business Units:  All Business Units (read)

Read:            All Priorities / All Units / Claims/Event modules
Edit:            Edit Finance, Edit CAT, Edit UW
Lifecycle:       Lock Estimates, Reopen Estimate
Approval:        Not granted

Key Actions:
  – Create and publish CAT events
  – Set event mode: Monitoring or Track Immediately at publish
  – Return to published event form to activate Tracking post-publish
  – Assign participants and configure recipient notifications
  – Enter and update Operational Summary
  – Close events when no longer operationally active

Finance Contributor  |  Team: Finance  |  3 users
Finance Contributor
Access Level:    Contributor
Executive Area:  Finance
Business Units:  All Business Units (read)

Read:            All Priorities / All Units / Overview / Finance modules
Edit:            Edit Finance, Edit UW
Lifecycle:       Lock Estimates, Reopen Estimate
Approval:        Not granted

Key Actions:
  – Update and manage financial estimates
  – Lock estimates to prevent further modification
  – Reopen estimates when revision is required
  – Consume approved exposure output for reserving use
  – Reserving extract completion

CAT Contributor  |  Team: CAT  |  2 users
CAT Contributor
Access Level:    Contributor
Executive Area:  Cat Modeling
Business Units:  All Business Units (read)

Read:            All Priorities / All Units / All modules (read-only)
Edit:            Edit CAT only
Lifecycle:       Lock CAT (1/2 — partial lifecycle access)
Approval:        Not granted

Key Actions:
  – Perform initial event footprint and severity assessment (Monitoring phase)
  – Edit CAT modeling data, scenarios, and industry loss figures
  – Lock and unlock CAT data
  – Run and update CAT model calculations
  – Provide first assessment input to the Monitoring/Tracking decision gate

Unit Lead  |  Team: Underwriting  |  4 users
Unit Lead
Access Level:    Contributor
Executive Area:  Underwriting — Business Unit scope
Business Units:  Own units (scoped by BU/Sub-Unit selection)

Read:            Own Units / UW Module
Edit:            Edit UW (within assigned profit center scope)
Lifecycle:       Reopen Estimate
Approval:        Approve Estimates

Key Actions:
  – Upload underwriting data
  – Assign estimation tasks to team members
  – Approve UW estimate submissions within scope
  – Oversee contract-level review and validation

Sub Unit Lead / Executive Area Lead  |  Team: Underwriting  |  24 users
Sub Unit Lead / Executive Area Lead
Access Level:    Contributor
Executive Area:  Underwriting — Executive Area scope
Business Units:  Business Unit (read permissions as granted)

Read:            Own Units / UW Module / All modules (read-only except UW Module)
Edit:            Edit UW (within assigned profit center scope)
Lifecycle:       Reopen Estimate
Approval:        Approve Estimates (scoped to executive area)

Key Actions:
  – Upload underwriting data for their sub-units
  – Assign estimation tasks
  – Approve scoped UW estimate submissions
  – Can read only their own sub-units (confirmed scope rule)
  – Largest role group: 24 users

UW Contributor  |  Team: Underwriting  |  7 users
UW Contributor
Access Level:    Contributor
Executive Area:  Underwriting
Business Units:  Business Unit (profit center scope)

Read:            Own Units / UW Module
Edit:            Edit UW (within assigned profit center scope)
Lifecycle:       Not granted
Approval:        Not granted

Key Actions:
  – Upload underwriting data
  – Enter and submit UW exposure estimates
  – Scoped strictly to own business unit and profit center
  – Cannot lock, reopen, or approve

Reader  |  Team: Management  |  3 users
Reader
Access Level:    Reader (view-only)
Executive Area:  Management
Business Units:  All Business Units

Read:            All modules (read-only)
Edit:            Not granted
Lifecycle:       Not granted
Approval:        Not granted

Key Actions:
  – View all event data and estimates
  – No edit, task, lock, or approval capability
  – Awareness and senior management oversight only

 
4  Workflow Diagram — End-to-End CAT Event Process



How to read this diagram
Each box shows the action, the role responsible, and the system state after that step.
Diamond shapes ◆ are decision gates. Arrows show the flow direction.
Notification IDs (NF-xx) show which notification fires at each step.

PHASE 0 — EVENT CREATION
EVENT COORDINATOR creates new event Enters event details, participants, deadlines, Operational Summary
↓
Selects event mode: Monitoring (default)  or  Track Immediately
↓
Publishes the event Event enters the system  →  NF-01 or NF-02 fires

PHASE 1 — MONITORING
EVENT STATUS: MONITORING Awareness only. No UW tasks. No deadline countdown. Recipients notified: Group Underwriting, Finance, Claims, Cat Modeling
↓
CAT CONTRIBUTOR performs first assessment Event footprint, severity, impacted regions, early market loss view
↓
◆  Decision Gate — Is underwriting estimation required?  ◆
↓
NO → Stay in Monitoring Exposure uncertain / immaterial No Everest contracts identified Leadership wants awareness only	YES → Activate Tracking Claims returns to published event form Updates mode from Monitoring to Tracking NF-03 fires

PHASE 2 — TRACKING ACTIVATED
EVENT STATUS: TRACKING Workflow start timestamp = date/time of form update Deadline countdowns begin (populated fields only) UW tasks created  →  NF-03 + NF-04 fire
↓
UNDERWRITING GROUPS (Unit Lead / Sub Unit Lead / UW Contributor) Receive task assignments Begin high-level exposure estimation by group and region
↓
HIGH-LEVEL EXPOSURE ESTIMATES DEADLINE If 48 hrs remaining  →  NF-05 fires If overdue  →  NF-06 fires

PHASE 3 — CONTRACT-LEVEL REVIEW
UNDERWRITING GROUPS Contract-level estimates submitted Unit Lead / Sub Unit Lead assigns and reviews tasks UW Contributor enters and submits estimates
↓
CONTRACT-LEVEL ESTIMATES DEADLINE If 48 hrs remaining  →  NF-05 fires If overdue  →  NF-06 fires
↓
UNIT LEAD / SUB UNIT LEAD approves estimates NF-09 fires on approval FINANCE CONTRIBUTOR locks estimates  →  NF-07 fires

PHASE 4 — FINANCE & RESERVING CONSOLIDATION
FINANCE CONTRIBUTOR Consumes approved estimation output Completes reserving extract Captures updated CAT model runs
↓
RESERVING EXTRACT DEADLINE  +  CAT MODEL RUN UPDATES DEADLINE If 48 hrs remaining  →  NF-05 fires If overdue  →  NF-06 fires

PHASE 5 — ONGOING UPDATES & CLOSURE
EVENT COORDINATOR Event updates continue as needed Estimates revised / CAT model refreshed All participants may be notified of material updates
↓
EVENT CLOSED by Event Coordinator No further tasks or deadlines active NF-10 fires to all participants Event record remains available for reference

 
5  Notification System



How to read this section
Each notification is defined by: Trigger | Recipients | Subject | Message body.
Variables in [brackets] are system-populated at send time.
NF-01 to NF-10 correspond to the IDs used in the workflow diagram above.
Channel: In-app notification + Email unless otherwise noted.

5.1  Notification Matrix
ID	Trigger	Recipients	Channel	Timing	Sent By / Role
NF-01	Event published — Monitoring	Event Coordinator, Finance Contributor, CAT Contributor, Group Underwriting (awareness)	In-app + Email	At publish	Event Coordinator
NF-02	Event published — Track Immediately	All selected recipients across Monitoring and Tracking groups	In-app + Email	At publish	Event Coordinator
NF-03	Event updated — Monitoring to Tracking	All selected Tracking recipients (UW groups, Finance, CAT)	In-app + Email	At form update	Event Coordinator
NF-04	Estimation task assigned	Assigned underwriting group (Unit Lead / Sub Unit Lead / UW Contributor)	In-app + Email	At Tracking activation	System (auto)
NF-05	Deadline approaching — 48 hrs	Deadline owner for each active deadline	In-app + Email	48 hrs before deadline	System (auto)
NF-06	Deadline overdue	Deadline owner + Event Coordinator + Unit Lead / Underwriting Leadership	In-app + Email	At deadline timestamp	System (auto)
NF-07	Estimate locked	UW Contributor (their estimate is locked) + Unit Lead	In-app	On lock action	Finance Contributor / Unit Lead
NF-08	Estimate reopened	UW Contributor (their estimate is reopened) + Unit Lead	In-app	On reopen action	Finance Contributor / Unit Lead
NF-09	Estimate approved	UW Contributor + Unit Lead	In-app + Email	On approval	Unit Lead / Sub Unit Lead
NF-10	Event closed	All participants on the event	In-app + Email	At event closure	Event Coordinator

5.2  Full Message Drafts

NF-01  —  Event Published in Monitoring
Trigger: Event published with Monitoring selected
Recipients: Event Coordinator, Finance Contributor, CAT Contributor, Group Underwriting
Subject: CAT Event Notification — [Event Name] is now being monitored
Message:

A new catastrophe event has been published and is currently in Monitoring.

Event:         [Event Name]
Event ID:      [Event ID]
Published:     [Date / Time]
Published by:  [User Name]
Status:        Monitoring — Awareness Only

What this means:
The event has been recorded in the system. No underwriting estimation is required at this stage.
Cat Modeling will perform an initial assessment. No tasks have been assigned to you at this time.

You are receiving this notification because you are listed as a Monitoring recipient for this event.
If the event moves to Tracking, you will receive a separate notification.

[View Event]

NF-02  —  Event Published with Track Immediately
Trigger: Event published with Track Immediately selected
Recipients: All selected recipients (Monitoring + Tracking groups)
Subject: CAT Event — Action Required — [Event Name] Tracking Activated
Message:

A new catastrophe event has been published and the estimation workflow has started immediately.

Event:          [Event Name]
Event ID:       [Event ID]
Published:      [Date / Time]
Published by:   [User Name]
Status:         Tracking — Workflow Active

Your task:      [Task Name]
Deadline:       [Deadline Date / Time]

The operational countdown is now running. Please review your assigned task and submit your estimates by the deadline above.

Operational Summary:
[Operational Summary text — or: No summary provided.]

[View Event]     [View My Task]

NF-03  —  Event Updated from Monitoring to Tracking
Trigger: Claims returns to published event form and switches mode to Tracking
Recipients: All selected Tracking recipients
Subject: CAT Event — Action Required — [Event Name] moved to Tracking
Message:

A catastrophe event that was being monitored has been moved to Tracking. The estimation workflow is now active.

Event:           [Event Name]
Event ID:        [Event ID]
Updated:         [Date / Time]
Updated by:      [User Name]
Previous status: Monitoring
Current status:  Tracking — Workflow Active

Your task:       [Task Name]
Deadline:        [Deadline Date / Time]

The operational countdown started at the time this event was moved to Tracking.
Please review your assigned task and submit your estimates by the deadline above.

Operational Summary:
[Operational Summary text — or: No summary provided.]

[View Event]     [View My Task]

NF-04  —  Estimation Task Assigned
Trigger: Tracking activated — estimation task created
Recipients: Assigned underwriting group (Unit Lead / Sub Unit Lead / UW Contributor)
Subject: Task Assigned — [Task Name] — [Event Name]
Message:

You have been assigned an estimation task for the following event.

Event:        [Event Name]
Event ID:     [Event ID]
Task:         [Task Name]
Assigned to:  [Group / User Name]
Deadline:     [Deadline Date / Time]
Assigned by:  System — triggered by Tracking activation

Action required:
Complete your exposure estimate and submit it before the deadline.
Log in to review the full event details and submit your response.

[View Event]     [View My Task]

NF-05  —  Deadline Approaching (48 Hours)
Trigger: 48 hours remaining before a workflow deadline
Recipients: Owner of the approaching deadline
Subject: Reminder — [Deadline Name] due in 48 hours — [Event Name]
Message:

This is a reminder that a workflow deadline is approaching.

Event:       [Event Name]
Event ID:    [Event ID]
Deadline:    [Deadline Name]
Due:         [Deadline Date / Time]
Time left:   48 hours

If your submission is already complete, no further action is needed.
If it is not yet complete, please submit before the deadline to avoid an overdue status.

[View Event]     [View My Task]

NF-06  —  Deadline Overdue
Trigger: Deadline timestamp passed without completed submission
Recipients: Deadline owner + Event Coordinator + Unit Lead / Underwriting Leadership
Subject: Overdue — [Deadline Name] — [Event Name]
Message:

A workflow deadline has passed without a completed submission.

Event:       [Event Name]
Event ID:    [Event ID]
Deadline:    [Deadline Name]
Was due:     [Deadline Date / Time]
Status:      Overdue

Action required:
If this deadline is still outstanding, please submit as soon as possible.
The Event Coordinator and Underwriting Leadership have been notified.

If this deadline was completed outside the system or is no longer applicable,
please update the event record accordingly.

[View Event]     [View My Task]

NF-07  —  Estimate Locked
Trigger: Finance Contributor or Unit Lead locks an estimate
Recipients: UW Contributor (their estimate is locked) + Unit Lead
Subject: Your Estimate Has Been Locked — [Event Name]
Message:

An estimate assigned to you has been locked and can no longer be modified.

Event:       [Event Name]
Event ID:    [Event ID]
Estimate:    [Estimate Name / Reference]
Locked by:   [User Name]
Locked at:   [Date / Time]

If you believe this was done in error or a revision is required,
please contact your Unit Lead or Finance Contributor to request a reopen.

[View Event]