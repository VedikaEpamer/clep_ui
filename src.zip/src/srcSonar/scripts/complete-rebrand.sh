#!/bin/bash

# Dream Re Rebranding - Complete remaining email updates
# This script updates all remaining @everest.com emails to @dreamre.com

echo "🔄 Completing Dream Re rebranding..."
echo "=================================="

# Files to update
files=(
  "components/admin/UsersDirectory.tsx"
  "components/admin/RoutingRules.tsx"
  "components/event/EventParticipants.tsx"
)

# Replacement patterns
replacements=(
  "s/@everest\.com/@dreamre.com/g"
  "s/@everestre\.com/@dreamre.com/g"
  "s/user@everest\.com/user@dreamre.com/g"
)

count=0
for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "✅ Updating: $file"
    for pattern in "${replacements[@]}"; do
      sed -i "$pattern" "$file" 2>/dev/null || sed -i '' "$pattern" "$file" 2>/dev/null
    done
    ((count++))
  else
    echo "⚠️  Not found: $file"
  fi
done

echo "=================================="
echo "✨ Rebranding complete!"
echo "   Updated $count files"
echo ""
echo "Summary:"
echo "  - All @everest.com → @dreamre.com"
echo "  - All @everestre.com → @dreamre.com"
echo "  - Company name: Dream Re"
echo "  - Logo: Updated"
echo "  - CSS classes: Preserved"
