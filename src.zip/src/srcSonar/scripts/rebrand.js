// Rebranding Script: Everest → Dream Re
// This script performs find-and-replace across the codebase

const replacements = [
  // CSS Classes
  { from: /bg-everest-blue/g, to: 'bg-dreamre-blue' },
  { from: /text-everest-blue/g, to: 'text-dreamre-blue' },
  { from: /border-everest-blue/g, to: 'border-dreamre-blue' },
  { from: /ring-everest-blue/g, to: 'ring-dreamre-blue' },
  
  // Email domains
  { from: /@everest\.com/g, to: '@dreamre.com' },
  { from: /@everestre\.com/g, to: '@dreamre.com' },
  
  // Company name in text
  { from: /Everest Reinsurance/g, to: 'Dream Re' },
  { from: /everest\b(?!-)/gi, to: 'Dream Re' },
  
  // CSS variables (already done in globals.css)
  { from: /--everest-blue/g, to: '--dreamre-blue' },
];

console.log('Rebranding replacements defined');
console.log('Apply these replacements to all .tsx, .ts, .css, and .md files');
console.log(`Total replacement patterns: ${replacements.length}`);
