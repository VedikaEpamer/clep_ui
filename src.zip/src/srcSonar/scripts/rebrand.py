#!/usr/bin/env python3
"""
DreamRe Rebranding Script
Replaces all text occurrences of "Everest" with "Dream Re" while preserving CSS class names
"""

import re
from pathlib import Path

# Files to process
files_to_update = [
    'components/event-creation/DeadlinesTracking.tsx',
    'components/event-detail/TeamAssignments.tsx',
    'components/EventSummaryDocument.tsx',
    'components/AssignmentNotificationPreview.tsx',
    'components/admin/UsersDirectory.tsx',
    'components/admin/RoutingRules.tsx',
    'components/event/EventParticipants.tsx',
    'components/event-detail/EventDetailLayout.tsx',
]

# Text replacements (NOT CSS class names)
text_replacements = [
    ('@everest.com', '@dreamre.com'),
    ('@everestre.com', '@dreamre.com'),
    ('Everest Reinsurance', 'Dream Re'),
    ('user@everest.com', 'user@dreamre.com'),
]

def rebrand_file(filepath):
    """Apply text replacements to a single file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Apply all text replacements
        for old, new in text_replacements:
            content = content.replace(old, new)
        
        # Only write if changes were made
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        return False
    except Exception as e:
        print(f"Error processing {filepath}: {e}")
        return False

def main():
    """Main execution"""
    print("🔄 Starting DreamRe rebranding...")
    print("=" * 50)
    
    updated_count = 0
    for filepath in files_to_update:
        full_path = Path(filepath)
        if full_path.exists():
            if rebrand_file(full_path):
                print(f"✅ Updated: {filepath}")
                updated_count += 1
            else:
                print(f"⏭️  No changes: {filepath}")
        else:
            print(f"⚠️  Not found: {filepath}")
    
    print("=" * 50)
    print(f"✨ Rebranding complete! Updated {updated_count} files.")
    print("\n📋 Summary:")
    print("   - Email domains: @everest.com → @dreamre.com")
    print("   - Company name: Everest Reinsurance → Dream Re")
    print("   - CSS classes: PRESERVED (no changes)")

if __name__ == '__main__':
    main()
