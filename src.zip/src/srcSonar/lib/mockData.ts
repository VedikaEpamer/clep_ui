export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  actionType: string;
  itemType: string;
  itemId: string;
  description: string;
}

export interface Phase {
  name: string;
  description: string;
}

export const phases: Phase[] = [
  { name: 'Event Creation', description: 'Event setup and configuration' },
  { name: 'Monitoring', description: 'Awareness - monitoring exposure' },
  { name: 'Estimation & Approval', description: 'UW and CAT team estimation' },
  { name: 'Finance Review', description: 'Finance review and approval' },
  { name: 'Reporting & Close', description: 'Final reporting and close' }
];

export interface Event {
  id: string;
  eventName: string;
  peril: string;
  lossDate: string;
  grossAmountRange: string;
  contracts: number;
  progress: number;
  phase: number;
  region: string;
  catCode?: string;
  everestEventType: string;  // "NAT CAT" | "Man Made CAT"
  eventType: string;         // "Natural Catastrophe" | "Large Loss (Single Risk)" | "Casualty Event" | "Cyber" | "Financial / Credit" | "Pandemic / Biological" | "War & Terror"
  eventSubType: string;      // e.g. "Hurricane" | "Earthquake" | "Wildfire"
  businessUnit: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  primaryLOB: string;
  creationDate: string;
  netAmount: string;
  marketLoss: string;
  grossLoss?: number; // in millions USD - Market Loss Estimate
  totalIncurred?: string;
  bestEstimate?: string;
  tracked?: boolean; // true = Tracked, false = Untracked
  estimationStatus?: 'Open' | 'Closed for Estimating' | 'Archived'; // Event estimation lifecycle
}

export interface Contract {
  id: string;
  contractNumber: string;
  contractName: string;
  team: string;
  assignedTo: string;
  impacted: boolean;
  systemLabel: 'Listed' | 'Not Listed' | 'UW Not Selected';
  uwLow?: number;
  uwMed?: number;
  uwHigh?: number;
  modelLow?: number;
  modelMed?: number;
  modelHigh?: number;
  marketLow?: number;
  marketMed?: number;
  marketHigh?: number;
}

export const mockEvents: Event[] = [
  {
    id: 'EVT-2024-012',
    eventName: 'Chile Earthquake (Maule Region)',
    peril: 'Earthquake',
    lossDate: '2010-02-27',
    grossAmountRange: '$8B - $10B',
    contracts: 1247,
    progress: 42,
    phase: 1,
    region: 'LATAM',
    catCode: 'CAT-2010-CL-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Earthquake',
    businessUnit: 'Property',
    description: 'Major earthquake event in central Chile - Team assignment and contract capture in progress',
    createdAt: '2010-02-27',
    updatedAt: '2010-03-15',
    primaryLOB: 'Property',
    creationDate: '2010-02-27',
    netAmount: '$8B - $10B',
    marketLoss: '$9.5B',
    grossLoss: 9500,
    totalIncurred: '$7.2B',
    bestEstimate: '$8.8B',
    tracked: true,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    peril: 'Hurricane',
    lossDate: '2024-10-15',
    grossAmountRange: '$2B - $5B',
    contracts: 847,
    progress: 68,
    phase: 3,
    region: 'North America',
    catCode: 'CAT-2024-US-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Hurricane',
    businessUnit: 'Property',
    description: 'Finance team reviewing UW and CAT model estimates before submitting to management',
    createdAt: '2024-10-16',
    updatedAt: '2024-11-28',
    primaryLOB: 'Property',
    creationDate: '2024-10-16',
    netAmount: '$2B - $5B',
    marketLoss: '$3.5B',
    grossLoss: 3500,
    totalIncurred: '$1.8B',
    bestEstimate: '$3.1B',
    tracked: true,
    estimationStatus: 'Closed for Estimating'
  },
  {
    id: 'EVT-2024-002',
    eventName: 'California Wildfires',
    peril: 'Wildfire',
    lossDate: '2024-09-22',
    grossAmountRange: '$500M - $1.5B',
    contracts: 423,
    progress: 92,
    phase: 4,
    region: 'North America',
    catCode: 'CAT-2024-US-002',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Wildfire',
    businessUnit: 'Property',
    description: 'Approved by management, generating reports and monitoring claims development',
    createdAt: '2024-09-23',
    updatedAt: '2024-11-25',
    primaryLOB: 'Property',
    creationDate: '2024-09-23',
    netAmount: '$500M - $1.5B',
    marketLoss: '$1.2B',
    grossLoss: 1200,
    totalIncurred: '$950M',
    bestEstimate: '$1.1B',
    tracked: true,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-003',
    eventName: 'European Windstorm Petra',
    peril: 'Wind',
    lossDate: '2024-08-10',
    grossAmountRange: '$800M - $2B',
    contracts: 612,
    progress: 100,
    phase: 3,
    region: 'Europe',
    catCode: 'CAT-2024-EU-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Wind - Non Hurricane',
    businessUnit: 'Property',
    description: 'Reopened — sent back for re-estimation',
    createdAt: '2024-08-11',
    updatedAt: '2024-11-20',
    primaryLOB: 'Property',
    creationDate: '2024-08-11',
    netAmount: '$800M - $2B',
    marketLoss: '$1.8B',
    grossLoss: 1800,
    totalIncurred: '$1.2B',
    bestEstimate: '$1.6B',
    tracked: true,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-004',
    eventName: 'Japan Earthquake',
    peril: 'Earthquake',
    lossDate: '2024-07-05',
    grossAmountRange: '$1.2B - $3B',
    contracts: 234,
    progress: 100,
    phase: 4,
    region: 'Asia Pacific',
    catCode: 'CAT-2024-JP-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Earthquake',
    businessUnit: 'Property',
    description: 'Magnitude 7.2 earthquake near Tokyo - All reporting complete and event archived',
    createdAt: '2024-07-06',
    updatedAt: '2024-10-15',
    primaryLOB: 'Property',
    creationDate: '2024-07-06',
    netAmount: '$1.2B - $3B',
    marketLoss: '$2.4B',
    grossLoss: 2400,
    totalIncurred: '$2.1B',
    bestEstimate: '$2.3B',
    tracked: true,
    estimationStatus: 'Archived'
  },
  {
    id: 'EVT-2024-005',
    eventName: 'Texas Hailstorm',
    peril: 'Hail',
    lossDate: '2024-11-18',
    grossAmountRange: '$100M - $300M',
    contracts: 156,
    progress: 34,
    phase: 1,
    region: 'North America',
    catCode: 'CAT-2024-US-003',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Hail',
    businessUnit: 'Property',
    description: 'Event Coordinator capturing contracts for the event',
    createdAt: '2024-11-19',
    updatedAt: '2024-11-29',
    primaryLOB: 'Property',
    creationDate: '2024-11-19',
    netAmount: '$100M - $300M',
    marketLoss: '$0.225B',
    grossLoss: 225,
    totalIncurred: '$85M',
    bestEstimate: '$180M',
    tracked: true,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-006',
    eventName: 'Cyber Attack - Financial Services',
    peril: 'Cyber',
    lossDate: '2024-11-25',
    grossAmountRange: '$50M - $150M',
    contracts: 0,
    progress: 5,
    phase: 0,
    region: 'Global',
    everestEventType: 'Man Made CAT',
    eventType: 'Cyber',
    eventSubType: 'Ransomware',
    businessUnit: 'Casualty',
    description: 'Event just created by Finance, not yet published to teams',
    createdAt: '2024-11-26',
    updatedAt: '2024-11-30',
    primaryLOB: 'Casualty',
    creationDate: '2024-11-26',
    netAmount: '$50M - $150M',
    marketLoss: '$0.095B',
    grossLoss: 95,
    totalIncurred: '—',
    bestEstimate: '$75M',
    tracked: false,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-007',
    eventName: 'UK Flood Event',
    peril: 'Flood',
    lossDate: '2024-06-12',
    grossAmountRange: '$200M - $600M',
    contracts: 342,
    progress: 78,
    phase: 2,
    region: 'Europe',
    catCode: 'CAT-2024-UK-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Flood',
    businessUnit: 'Property',
    description: 'UW and CAT teams estimating losses across impacted contracts',
    createdAt: '2024-06-13',
    updatedAt: '2024-11-15',
    primaryLOB: 'Property',
    creationDate: '2024-06-13',
    netAmount: '$200M - $600M',
    marketLoss: '$0.425B',
    grossLoss: 425,
    totalIncurred: '$310M',
    bestEstimate: '$390M',
    tracked: true,
    estimationStatus: 'Open'
  },
  {
    id: 'EVT-2024-008',
    eventName: 'Australian Bushfire',
    peril: 'Wildfire',
    lossDate: '2024-01-15',
    grossAmountRange: '$400M - $900M',
    contracts: 289,
    progress: 85,
    phase: 2,
    region: 'Asia Pacific',
    catCode: 'CAT-2024-AU-001',
    everestEventType: 'NAT CAT',
    eventType: 'Natural Catastrophe',
    eventSubType: 'Wildfire',
    businessUnit: 'Property',
    description: 'Teams assigned, underwriters and CAT modelers estimating losses',
    createdAt: '2024-01-16',
    updatedAt: '2024-11-10',
    primaryLOB: 'Property',
    creationDate: '2024-01-16',
    netAmount: '$400M - $900M',
    marketLoss: '$0.675B',
    grossLoss: 675,
    totalIncurred: '$520M',
    bestEstimate: '$620M',
    tracked: true,
    estimationStatus: 'Open'
  }
];

export const mockContracts: Contract[] = [
  {
    id: 'C001',
    contractNumber: 'RE-2024-12345',
    contractName: 'ABC Insurance Property Treaty',
    team: 'Property Per-Risk',
    assignedTo: 'John Smith',
    impacted: true,
    systemLabel: 'Listed',
    uwLow: 2500000,
    uwMed: 4200000,
    uwHigh: 6800000,
    modelLow: 2100000,
    modelMed: 3800000,
    modelHigh: 6200000,
    marketLow: 2000000,
    marketMed: 3500000,
    marketHigh: 5500000
  },
  {
    id: 'C002',
    contractNumber: 'RE-2024-12346',
    contractName: 'Global Re XL Program',
    team: 'Property CAT XOL',
    assignedTo: 'Maria Garcia',
    impacted: true,
    systemLabel: 'Listed',
    uwLow: 5000000,
    uwMed: 8500000,
    uwHigh: 12000000,
    modelLow: 4500000,
    modelMed: 7800000,
    modelHigh: 11500000,
    marketLow: 4000000,
    marketMed: 7000000,
    marketHigh: 10000000
  },
  {
    id: 'C003',
    contractNumber: 'RE-2024-12347',
    contractName: 'Regional Property QS',
    team: 'Property Pro-Rata',
    assignedTo: 'James Wilson',
    impacted: false,
    systemLabel: 'UW Not Selected',
    uwLow: 0,
    uwMed: 0,
    uwHigh: 0,
    modelLow: 500000,
    modelMed: 1200000,
    modelHigh: 2000000
  }
];

export const mockAuditLog: AuditLogEntry[] = [
  {
    id: 'A001',
    timestamp: '2024-11-30 14:32:15',
    user: 'Sarah Johnson',
    role: 'Event Coordinator',
    actionType: 'Upload',
    itemType: 'UW Estimation',
    itemId: 'EVT-2024-001',
    description: 'Uploaded UW estimation file (243 contracts)'
  },
  {
    id: 'A002',
    timestamp: '2024-11-30 13:45:22',
    user: 'Michael Chen',
    role: 'Cat Modeling',
    actionType: 'Upload',
    itemType: 'Model Output',
    itemId: 'EVT-2024-002',
    description: 'Uploaded Loss by Contract modeling file'
  },
  {
    id: 'A003',
    timestamp: '2024-11-30 12:18:44',
    user: 'Emma Williams',
    role: 'Business Unit Owner',
    actionType: 'Approve',
    itemType: 'Management Summary',
    itemId: 'EVT-2024-003',
    description: 'Approved management summary for Phase 4'
  }
];

export const userRoles = [
  'Application Admin',
  'Operations / Event Coordinator',
  'Business Unit Owner',
  'Cat Modeling',
  'Senior Management',
  'Read-Only'
];

export const regionsHierarchy = [
  {
    name: 'Asia',
    code: 'A00',
    subRegions: [
      {
        name: 'Northeast Asia',
        code: 'A10',
        countries: [
          { name: 'China', code: 'A11' },
          { name: 'Hong Kong', code: 'A12' },
          { name: 'Japan', code: 'A13' },
          { name: 'Macau', code: 'A14' },
          { name: 'Mongolia', code: 'A15' },
          { name: 'North Korea', code: 'A16' },
          { name: 'South Korea', code: 'A17' },
          { name: 'Taiwan', code: 'A18' }
        ]
      },
      {
        name: 'Southeast Asia',
        code: 'A20',
        countries: [
          { name: 'Brunei', code: 'A21' },
          { name: 'Myanmar', code: 'A22' },
          { name: 'Cambodia', code: 'A23' },
          { name: 'Indonesia', code: 'A24' },
          { name: 'Kampuchea, Democratic Re', code: 'A25' },
          { name: 'Laos', code: 'A26' },
          { name: 'Malaysia', code: 'A27' },
          { name: 'Philippines', code: 'A28' },
          { name: 'Singapore', code: 'A29' },
          { name: 'Thailand', code: 'A2A' },
          { name: 'Vietnam', code: 'A2B' }
        ]
      },
      {
        name: 'West Asia',
        code: 'A30',
        countries: [
          { name: 'Afghanistan', code: 'A31' },
          { name: 'Armenia', code: 'A32' },
          { name: 'Azerbaijan', code: 'A33' },
          { name: 'Bangladesh', code: 'A34' },
          { name: 'Georgia (Asia)', code: 'A35' },
          { name: 'India', code: 'A36' },
          { name: 'Kazakstan', code: 'A37' },
          { name: 'Kyrgyzstan', code: 'A38' },
          { name: 'Maldives', code: 'A39' },
          { name: 'Nepal', code: 'A3A' },
          { name: 'Pakistan', code: 'A3B' },
          { name: 'Sri Lanka', code: 'A3C' },
          { name: 'Turkmenistan', code: 'A3D' },
          { name: 'Uzbekistan', code: 'A3E' }
        ]
      },
      {
        name: 'Pacific Asia',
        code: 'A40',
        countries: [
          { name: 'Fiji', code: 'A41' },
          { name: 'Guam', code: 'A42' },
          { name: 'Micronesia', code: 'A43' },
          { name: 'Papua New Guinea', code: 'A44' }
        ]
      }
    ]
  },
  {
    name: 'Canada',
    code: 'C00',
    subRegions: [
      {
        name: 'Maritime Provinces',
        code: 'C10',
        countries: [
          { name: 'New Brunswick', code: 'C11' },
          { name: 'Newfoundland', code: 'C12' },
          { name: 'Nova Scotia', code: 'C13' },
          { name: 'Prince Edward Island', code: 'C14' }
        ]
      },
      {
        name: 'Western Canadian Provs',
        code: 'C20',
        countries: [
          { name: 'Alberta', code: 'C21' },
          { name: 'British Columbia', code: 'C22' },
          { name: 'Manitoba', code: 'C23' },
          { name: 'Northwest Territory', code: 'C24' },
          { name: 'Saskatchewan', code: 'C25' },
          { name: 'Yukon Territory', code: 'C26' },
          { name: 'Nunavut', code: 'C27' }
        ]
      },
      {
        name: 'Central Canadian Provs',
        code: 'C30',
        countries: [
          { name: 'Ontario', code: 'C31' },
          { name: 'Quebec', code: 'C32' }
        ]
      }
    ]
  },
  {
    name: 'North America',
    code: 'D00',
    subRegions: [
      {
        name: 'North America',
        code: 'D10',
        countries: [
          { name: 'North America Excl Mexico', code: 'D10' }
        ]
      }
    ]
  },
  {
    name: 'Europe',
    code: 'E00',
    subRegions: [
      {
        name: 'Central Europe',
        code: 'E10',
        countries: [
          { name: 'Austria', code: 'E11' },
          { name: 'Czech Republic', code: 'E12' },
          { name: 'Germany', code: 'E13' },
          { name: 'Hungary', code: 'E14' },
          { name: 'Poland', code: 'E15' },
          { name: 'Slovakia', code: 'E16' }
        ]
      },
      {
        name: 'East Europe / North Asia',
        code: 'E20',
        countries: [
          { name: 'Belarus', code: 'E21' },
          { name: 'Estonia', code: 'E22' },
          { name: 'Latvia', code: 'E23' },
          { name: 'Lithuania', code: 'E24' },
          { name: 'Russia', code: 'E25' },
          { name: 'Ukraine', code: 'E26' }
        ]
      },
      {
        name: 'North Europe',
        code: 'E30',
        countries: [
          { name: 'Denmark', code: 'E31' },
          { name: 'Faeroe Islands', code: 'E32' },
          { name: 'Finland', code: 'E33' },
          { name: 'Netherlands', code: 'E34' },
          { name: 'Norway', code: 'E35' },
          { name: 'Sweden', code: 'E36' }
        ]
      },
      {
        name: 'South Europe',
        code: 'E40',
        countries: [
          { name: 'Albania', code: 'E41' },
          { name: 'Andorra', code: 'E42' },
          { name: 'Bosnia-Herzegovina', code: 'E43' },
          { name: 'Bulgaria', code: 'E44' },
          { name: 'Croatia', code: 'E45' },
          { name: 'Cyprus', code: 'E46' },
          { name: 'Gibraltar', code: 'E47' },
          { name: 'Greece', code: 'E48' },
          { name: 'Italy', code: 'E49' },
          { name: 'Macedonia', code: 'E4A' },
          { name: 'Malta', code: 'E4B' },
          { name: 'Moldova', code: 'E4C' },
          { name: 'Monaco', code: 'E4D' },
          { name: 'Portugal', code: 'E4E' },
          { name: 'Romania', code: 'E4F' },
          { name: 'San Marino', code: 'E4G' },
          { name: 'Slovenia', code: 'E4H' },
          { name: 'Spain', code: 'E4I' },
          { name: 'Vatican City', code: 'E4J' },
          { name: 'Yugoslavia / Montenegro', code: 'E4K' }
        ]
      },
      {
        name: 'West Europe',
        code: 'E50',
        countries: [
          { name: 'Belgium', code: 'E51' },
          { name: 'France', code: 'E52' },
          { name: 'Ireland', code: 'E53' },
          { name: 'Liechtenstein', code: 'E54' },
          { name: 'Luxembourg', code: 'E55' },
          { name: 'Switzerland', code: 'E56' },
          { name: 'United Kingdom', code: 'E57' }
        ]
      }
    ]
  },
  {
    name: 'Africa',
    code: 'F00',
    subRegions: [
      {
        name: 'Central African Continent',
        code: 'F10',
        countries: [
          { name: 'Angola', code: 'F11' },
          { name: 'Cameroon', code: 'F12' },
          { name: 'Central African Republic', code: 'F13' },
          { name: 'Congo', code: 'F14' },
          { name: 'Equatorial Guinea', code: 'F15' },
          { name: 'Gabon', code: 'F16' },
          { name: 'Malawi', code: 'F17' },
          { name: 'Sao Tome & Principe', code: 'F18' },
          { name: 'Zaire', code: 'F19' },
          { name: 'Zambia', code: 'F1A' }
        ]
      },
      {
        name: 'East African Continent',
        code: 'F20',
        countries: [
          { name: 'Burundi', code: 'F21' },
          { name: 'Djibouti', code: 'F22' },
          { name: 'Eritrea', code: 'F23' },
          { name: 'Ethiopia', code: 'F24' },
          { name: 'Kenya', code: 'F25' },
          { name: 'Rwanda', code: 'F26' },
          { name: 'Somalia', code: 'F27' },
          { name: 'Sudan', code: 'F28' },
          { name: 'Tanzania', code: 'F29' },
          { name: 'Uganda', code: 'F2A' }
        ]
      },
      {
        name: 'North African Continent',
        code: 'F30',
        countries: [
          { name: 'Algeria', code: 'F31' },
          { name: 'Chad', code: 'F32' },
          { name: 'Libya', code: 'F33' },
          { name: 'Mali', code: 'F34' },
          { name: 'Mauritania', code: 'F35' },
          { name: 'Morocco', code: 'F36' },
          { name: 'Niger', code: 'F37' },
          { name: 'Tunisia', code: 'F38' },
          { name: 'Western Sahara', code: 'F39' }
        ]
      },
      {
        name: 'South African Continent',
        code: 'F40',
        countries: [
          { name: 'Botswana', code: 'F41' },
          { name: 'Lesotho', code: 'F42' },
          { name: 'Mozambique', code: 'F43' },
          { name: 'Namibia', code: 'F44' },
          { name: 'South Africa (Republic)', code: 'F45' },
          { name: 'Swaziland', code: 'F46' },
          { name: 'Zimbabwe', code: 'F47' }
        ]
      },
      {
        name: 'West African Continent',
        code: 'F50',
        countries: [
          { name: 'Benin', code: 'F51' },
          { name: 'Burkina Faso', code: 'F52' },
          { name: 'Gambia', code: 'F53' },
          { name: 'Ghana', code: 'F54' },
          { name: 'Guinea', code: 'F55' },
          { name: 'Guinea-Bissau', code: 'F56' },
          { name: 'Ivory Coast', code: 'F57' },
          { name: 'Liberia', code: 'F58' },
          { name: 'Nigeria', code: 'F59' },
          { name: 'Senegal', code: 'F5A' },
          { name: 'Sierra Leone', code: 'F5B' },
          { name: 'Togo', code: 'F5C' }
        ]
      },
      {
        name: 'Misc African Islands',
        code: 'F60',
        countries: [
          { name: 'Canary Islands', code: 'F61' },
          { name: 'Cape Verde', code: 'F62' },
          { name: 'Comoros Islands', code: 'F63' },
          { name: 'Madagascar', code: 'F64' },
          { name: 'Madeira Islands', code: 'F65' },
          { name: 'Mauritius', code: 'F66' },
          { name: 'Reunion', code: 'F67' },
          { name: 'Seychelles', code: 'F68' }
        ]
      }
    ]
  },
  {
    name: 'Islands',
    code: 'I00',
    subRegions: [
      {
        name: 'Atlantic Ocean Islands',
        code: 'I10',
        countries: [
          { name: 'Bermuda', code: 'I11' },
          { name: 'Bouvet Island', code: 'I12' },
          { name: 'Falkland Islands', code: 'I13' },
          { name: 'Greenland', code: 'I14' },
          { name: 'Iceland', code: 'I15' },
          { name: 'St Pierre & Miquelon', code: 'I16' },
          { name: 'St Helena', code: 'I17' }
        ]
      },
      {
        name: 'Indian Ocean Islands',
        code: 'I20',
        countries: [
          { name: 'British Indian Ocean Ter', code: 'I21' },
          { name: 'Christmas Island', code: 'I22' },
          { name: 'Cocos Islands', code: 'I23' },
          { name: 'Heard & McDonald Islands', code: 'I24' }
        ]
      },
      {
        name: 'Pacific Ocean Islands',
        code: 'I30',
        countries: [
          { name: 'American Samoa', code: 'I31' },
          { name: 'Bhutan', code: 'I32' },
          { name: 'Canton & Enderbury Is', code: 'I33' },
          { name: 'Cook Islands', code: 'I34' },
          { name: 'East Timor', code: 'I35' },
          { name: 'French Polynesia', code: 'I36' },
          { name: 'Johnston Islands', code: 'I37' },
          { name: 'Marshall Islands', code: 'I38' },
          { name: 'Nauru', code: 'I39' },
          { name: 'New Caledonia', code: 'I3A' },
          { name: 'Niue', code: 'I3B' },
          { name: 'Norfolk Islands', code: 'I3C' },
          { name: 'Northern Mariana Islands', code: 'I3D' },
          { name: 'Palau', code: 'I3E' },
          { name: 'Pitcairn Islands', code: 'I3F' },
          { name: 'Solomon Islands', code: 'I3G' },
          { name: 'Tokelau', code: 'I3H' },
          { name: 'Tonga', code: 'I3I' },
          { name: 'Trust Territory', code: 'I3J' },
          { name: 'Tuvalu', code: 'I3K' },
          { name: 'US Minor Outlying Island', code: 'I3L' },
          { name: 'Vanuatu', code: 'I3M' },
          { name: 'Wallis & Futuna Island', code: 'I3N' },
          { name: 'Samoa', code: 'I3O' }
        ]
      },
      {
        name: 'Arctic Ocean Islands',
        code: 'I40',
        countries: [
          { name: 'Svalbard & Jan Mayen', code: 'I41' }
        ]
      }
    ]
  },
  {
    name: 'Latin America',
    code: 'L00',
    subRegions: [
      {
        name: 'South America',
        code: 'L10',
        countries: [
          { name: 'Argentina', code: 'L11' },
          { name: 'Bolivia', code: 'L12' },
          { name: 'Brazil', code: 'L13' },
          { name: 'Chile', code: 'L14' },
          { name: 'Colombia', code: 'L15' },
          { name: 'Ecuador', code: 'L16' },
          { name: 'French Guiana', code: 'L17' },
          { name: 'Guyana', code: 'L18' },
          { name: 'Paraguay', code: 'L19' },
          { name: 'Peru', code: 'L1A' },
          { name: 'Suriname', code: 'L1B' },
          { name: 'Uruguay', code: 'L1C' },
          { name: 'Venezuela', code: 'L1D' }
        ]
      },
      {
        name: 'Central America',
        code: 'L20',
        countries: [
          { name: 'Belize', code: 'L21' },
          { name: 'Costa Rica', code: 'L22' },
          { name: 'El Salvador', code: 'L23' },
          { name: 'Guatemala', code: 'L24' },
          { name: 'Honduras', code: 'L25' },
          { name: 'Nicaragua', code: 'L26' },
          { name: 'Panama', code: 'L27' }
        ]
      },
      {
        name: 'Mexico',
        code: 'L30',
        countries: [
          { name: 'Mexico', code: 'L30' }
        ]
      },
      {
        name: 'Caribbean Islands',
        code: 'L40',
        countries: [
          { name: 'Antigua', code: 'L41' },
          { name: 'Aruba', code: 'L42' },
          { name: 'Bahamas', code: 'L43' },
          { name: 'Barbados', code: 'L44' },
          { name: 'British Virgin Islands', code: 'L45' },
          { name: 'Cayman Islands', code: 'L46' },
          { name: 'Cuba', code: 'L47' },
          { name: 'Dominica', code: 'L48' },
          { name: 'Dominican Republic', code: 'L49' },
          { name: 'Grenada', code: 'L4A' },
          { name: 'Guadeloupe', code: 'L4B' },
          { name: 'Haiti', code: 'L4C' },
          { name: 'Jamaica', code: 'L4D' },
          { name: 'Martinique', code: 'L4E' },
          { name: 'Montserrat', code: 'L4F' },
          { name: 'Netherlands Antilles', code: 'L4G' },
          { name: 'Puerto Rico', code: 'L4H' },
          { name: 'St Kitts-Nevis-Angui', code: 'L4I' },
          { name: 'St Lucia', code: 'L4J' },
          { name: 'St Vincent & Grenadine', code: 'L4K' },
          { name: 'Trinidad & Tobago', code: 'L4L' },
          { name: 'Turks & Caicos Islands', code: 'L4M' },
          { name: 'US Virgin Islands', code: 'L4N' },
          { name: 'Curacao', code: 'L4O' }
        ]
      }
    ]
  },
  {
    name: 'Middle East',
    code: 'M00',
    subRegions: [
      {
        name: 'Middle East',
        code: 'M10',
        countries: [
          { name: 'Bahrain', code: 'M11' },
          { name: 'Egypt', code: 'M12' },
          { name: 'Iran', code: 'M13' },
          { name: 'Iraq', code: 'M14' },
          { name: 'Israel', code: 'M15' },
          { name: 'Jordan', code: 'M16' },
          { name: 'Kuwait', code: 'M17' },
          { name: 'Lebanon', code: 'M18' },
          { name: 'Oman', code: 'M19' },
          { name: 'Qatar', code: 'M1A' },
          { name: 'Saudi Arabia', code: 'M1B' },
          { name: 'Syria', code: 'M1C' },
          { name: 'Turkey', code: 'M1D' },
          { name: 'United Arab Emirates', code: 'M1E' },
          { name: 'Yemen', code: 'M1F' },
          { name: 'Yemen-Peoples Dem Rep', code: 'M1G' }
        ]
      }
    ]
  },
  {
    name: 'Outerspace',
    code: 'R00',
    subRegions: []
  },
  {
    name: 'Oceans & Seas',
    code: 'S00',
    subRegions: [
      {
        name: 'Antarctic Ocean',
        code: 'S10',
        countries: []
      },
      {
        name: 'Arctic Ocean',
        code: 'S20',
        countries: []
      },
      {
        name: 'Atlantic Ocean',
        code: 'S30',
        countries: []
      },
      {
        name: 'Indian Ocean',
        code: 'S40',
        countries: []
      },
      {
        name: 'Pacific Ocean',
        code: 'S50',
        countries: []
      }
    ]
  },
  {
    name: 'United States',
    code: 'U00',
    subRegions: [
      {
        name: 'Mid-Atlantic States',
        code: 'U10',
        countries: [
          { name: 'Delaware', code: 'U11' },
          { name: 'Maryland', code: 'U12' },
          { name: 'New Jersey', code: 'U13' },
          { name: 'New York', code: 'U14' },
          { name: 'Pennsylvania', code: 'U15' }
        ]
      },
      {
        name: 'Midwest States',
        code: 'U20',
        countries: [
          { name: 'Illinois', code: 'U21' },
          { name: 'Indiana', code: 'U22' },
          { name: 'Iowa', code: 'U23' },
          { name: 'Kansas', code: 'U24' },
          { name: 'Michigan', code: 'U25' },
          { name: 'Minnesota', code: 'U26' },
          { name: 'Missouri', code: 'U27' },
          { name: 'Nebraska', code: 'U28' },
          { name: 'North Dakota', code: 'U29' },
          { name: 'Ohio', code: 'U2A' },
          { name: 'South Dakota', code: 'U2B' },
          { name: 'Wisconsin', code: 'U2C' }
        ]
      },
      {
        name: 'Mountain States',
        code: 'U30',
        countries: [
          { name: 'Arizona', code: 'U31' },
          { name: 'Colorado', code: 'U32' },
          { name: 'Idaho', code: 'U33' },
          { name: 'Montana', code: 'U34' },
          { name: 'Nevada', code: 'U35' },
          { name: 'New Mexico', code: 'U36' },
          { name: 'Utah', code: 'U37' },
          { name: 'Wyoming', code: 'U38' }
        ]
      },
      {
        name: 'New England States',
        code: 'U40',
        countries: [
          { name: 'Connecticut', code: 'U41' },
          { name: 'Maine', code: 'U42' },
          { name: 'Massachusetts', code: 'U43' },
          { name: 'New Hampshire', code: 'U44' },
          { name: 'Rhode Island', code: 'U45' },
          { name: 'Vermont', code: 'U46' }
        ]
      },
      {
        name: 'Pacific States',
        code: 'U50',
        countries: [
          { name: 'Alaska', code: 'U51' },
          { name: 'California', code: 'U52' },
          { name: 'Hawaii', code: 'U53' },
          { name: 'Oregon', code: 'U54' },
          { name: 'Washington', code: 'U55' }
        ]
      },
      {
        name: 'South Atlantic States',
        code: 'U60',
        countries: [
          { name: 'District of Columbia', code: 'U61' },
          { name: 'Florida', code: 'U62' },
          { name: 'Georgia', code: 'U63' },
          { name: 'North Carolina', code: 'U64' },
          { name: 'South Carolina', code: 'U65' },
          { name: 'Virginia', code: 'U66' },
          { name: 'West Virginia', code: 'U67' }
        ]
      },
      {
        name: 'South Central States',
        code: 'U70',
        countries: [
          { name: 'Alabama', code: 'U71' },
          { name: 'Arkansas', code: 'U72' },
          { name: 'Kentucky', code: 'U73' },
          { name: 'Louisiana', code: 'U74' },
          { name: 'Mississippi', code: 'U75' },
          { name: 'Oklahoma', code: 'U76' },
          { name: 'Tennessee', code: 'U77' },
          { name: 'Texas', code: 'U78' }
        ]
      }
    ]
  },
  {
    name: 'Australia/New Zealand',
    code: 'Z00',
    subRegions: [
      {
        name: 'Australia',
        code: 'Z10',
        countries: [
          { name: 'Australia', code: 'Z11' }
        ]
      },
      {
        name: 'New Zealand',
        code: 'Z20',
        countries: [
          { name: 'New Zealand', code: 'Z21' }
        ]
      }
    ]
  }
];