import React, { createContext, useContext, useState, ReactNode } from 'react';

export type CurrencyDisplayMode = 'original' | 'accounting' | 'base' | 'all';

export interface MultiCurrencyAmount {
  original: { amount: number; currency: string };
  accounting: { amount: number; currency: string };
  base: { amount: number; currency: string };
}

export interface FXRate {
  fromCurrency: string;
  toCurrency: string;
  rate: number;
  effectiveDate: string;
  source: string;
  bidRate?: number;
  askRate?: number;
  midRate: number;
}

interface CurrencySettings {
  displayMode: CurrencyDisplayMode;
  baseCurrency: string;
  fxSource: string;
  fxEffectiveDate: string;
}

interface CurrencyContextType {
  settings: CurrencySettings;
  setDisplayMode: (mode: CurrencyDisplayMode) => void;
  setBaseCurrency: (currency: string) => void;
  formatAmount: (amount: MultiCurrencyAmount | number, fallbackCurrency?: string) => string;
  formatCurrency: (amount: number, currency: string) => string;
  getFXRate: (from: string, to: string) => number;
  updateFXRates: () => Promise<void>;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

// Mock FX rates - in production, this would come from API
const mockFXRates: Record<string, Record<string, number>> = {
  'USD': { 'USD': 1.00, 'EUR': 0.92, 'GBP': 0.79, 'JPY': 149.50, 'BRL': 4.98, 'CLP': 973.50, 'MXN': 17.15, 'CAD': 1.35 },
  'EUR': { 'USD': 1.09, 'EUR': 1.00, 'GBP': 0.86, 'JPY': 162.80, 'BRL': 5.42, 'CLP': 1060.00, 'MXN': 18.68, 'CAD': 1.47 },
  'GBP': { 'USD': 1.27, 'EUR': 1.16, 'GBP': 1.00, 'JPY': 189.30, 'BRL': 6.31, 'CLP': 1232.50, 'MXN': 21.76, 'CAD': 1.71 },
  'BRL': { 'USD': 0.20, 'EUR': 0.18, 'GBP': 0.16, 'JPY': 30.00, 'BRL': 1.00, 'CLP': 195.50, 'MXN': 3.44, 'CAD': 0.27 },
  'CLP': { 'USD': 0.00103, 'EUR': 0.00094, 'GBP': 0.00081, 'JPY': 0.154, 'BRL': 0.0051, 'CLP': 1.00, 'MXN': 0.0176, 'CAD': 0.0014 },
  'JPY': { 'USD': 0.0067, 'EUR': 0.0061, 'GBP': 0.0053, 'JPY': 1.00, 'BRL': 0.033, 'CLP': 6.50, 'MXN': 0.115, 'CAD': 0.009 },
  'MXN': { 'USD': 0.058, 'EUR': 0.054, 'GBP': 0.046, 'JPY': 8.72, 'BRL': 0.29, 'CLP': 56.80, 'MXN': 1.00, 'CAD': 0.079 },
  'CAD': { 'USD': 0.74, 'EUR': 0.68, 'GBP': 0.58, 'JPY': 110.70, 'BRL': 3.69, 'CLP': 720.40, 'MXN': 12.66, 'CAD': 1.00 }
};

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<CurrencySettings>({
    displayMode: 'base',
    baseCurrency: 'USD',
    fxSource: 'Bloomberg',
    fxEffectiveDate: new Date().toISOString().split('T')[0]
  });

  const setDisplayMode = (mode: CurrencyDisplayMode) => {
    setSettings(prev => ({ ...prev, displayMode: mode }));
  };

  const setBaseCurrency = (currency: string) => {
    setSettings(prev => ({ ...prev, baseCurrency: currency, displayMode: 'base' }));
  };

  const getFXRate = (from: string, to: string): number => {
    if (from === to) return 1.00;
    return mockFXRates[from]?.[to] || 1.00;
  };

  const formatCurrency = (amount: number, currency: string): string => {
    // Format with appropriate decimal places based on currency
    const decimalPlaces = ['JPY', 'KRW', 'CLP'].includes(currency) ? 0 : 2;
    
    // Format large numbers
    if (Math.abs(amount) >= 1_000_000_000) {
      return `${currency} ${(amount / 1_000_000_000).toFixed(1)}B`;
    } else if (Math.abs(amount) >= 1_000_000) {
      return `${currency} ${(amount / 1_000_000).toFixed(1)}M`;
    } else if (Math.abs(amount) >= 1_000) {
      return `${currency} ${(amount / 1_000).toFixed(1)}K`;
    }
    
    return `${currency} ${amount.toLocaleString('en-US', { 
      minimumFractionDigits: decimalPlaces,
      maximumFractionDigits: decimalPlaces 
    })}`;
  };

  const formatAmount = (amount: MultiCurrencyAmount | number, fallbackCurrency: string = 'USD'): string => {
    // Handle simple number (backwards compatibility)
    if (typeof amount === 'number') {
      return formatCurrency(amount, fallbackCurrency);
    }

    // Handle multi-currency amount
    switch (settings.displayMode) {
      case 'original':
        return formatCurrency(amount.original.amount, amount.original.currency);
      case 'accounting':
        return formatCurrency(amount.accounting.amount, amount.accounting.currency);
      case 'base':
        return formatCurrency(amount.base.amount, amount.base.currency);
      case 'all':
        // For 'all' mode, return base currency (UI will show all three separately)
        return formatCurrency(amount.base.amount, amount.base.currency);
      default:
        return formatCurrency(amount.base.amount, amount.base.currency);
    }
  };

  const updateFXRates = async (): Promise<void> => {
    // In production, this would call the FX rate API
    // For now, just update the effective date
    setSettings(prev => ({
      ...prev,
      fxEffectiveDate: new Date().toISOString().split('T')[0]
    }));
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
  };

  return (
    <CurrencyContext.Provider value={{
      settings,
      setDisplayMode,
      setBaseCurrency,
      formatAmount,
      formatCurrency,
      getFXRate,
      updateFXRates
    }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}