import { createContext, useContext, ReactNode, useState } from 'react';

// SONAR Role System — matches RolesAndPermissions.tsx exactly (8 roles)
export type SonarRole =
  | 'Administrator'
  | 'Event Coordinator'
  | 'Finance Contributor'
  | 'CAT Contributor'
  | 'UW Contributor'
  | 'Executive Area Lead'
  | 'Business Unit Lead'
  | 'Reader';

export interface RolePermissions {
  canCreateEvents: boolean;
  canEditEventMetadata: boolean;
  canLockUnlockEstimates: boolean;
  canAccessAdmin: boolean;
  canUploadGrossToNet: boolean;
  canAssignParticipants: boolean;
  canEditUWEstimates: boolean;
  canUploadModeling: boolean;
  canViewAllEvents: boolean;
  canExportReports: boolean;
  visibleTabs: string[];
  eventFilter: 'all' | 'assigned';
}

// Representative demo user for each role — real users from UsersDirectory
export const roleDemoUsers: Record<SonarRole, { name: string; team: string; area: string }> = {
  'Administrator':       { name: 'David Chen',            team: 'Admin',        area: 'Administration' },
  'Event Coordinator':   { name: 'Andrew McBride',        team: 'Claim',        area: 'Claims' },
  'Finance Contributor': { name: 'Clem Demetz',           team: 'Finance',      area: 'Finance' },
  'CAT Contributor':     { name: 'Neil Schwarzenberger',  team: 'CAT',          area: 'Cat Modeling' },
  'UW Contributor':      { name: 'Thomas Brennan',        team: 'Underwriting', area: 'International Treaty' },
  'Executive Area Lead': { name: 'Juan Delgado',          team: 'Underwriting', area: 'Facultative' },
  'Business Unit Lead':  { name: 'Mike Cellura',          team: 'Underwriting', area: 'Facultative' },
  'Reader':              { name: 'Reena Boltax',          team: 'Management',   area: 'Group Underwriting' },
};

/*
 * Permission matrix — mapped 1-to-1 from the RolesAndPermissions.tsx permission IDs:
 *
 *   create_event      → canCreateEvents
 *   modify_event      → canEditEventMetadata
 *   update_cat_data   → canUploadModeling
 *   upload_data       → canEditUWEstimates
 *   assign_task       → canAssignParticipants
 *   approve_estimates → canLockUnlockEstimates (BU-level approval)
 *   update_estimate   → canUploadGrossToNet
 *   reopen_event      → canEditEventMetadata (already true for these roles)
 *   lock_estimate     → canLockUnlockEstimates
 *   can_unlock        → canLockUnlockEstimates
 *   read_all_modules  → canViewAllEvents + full visibleTabs + canExportReports
 *   reader_access     → basic read, eventFilter 'assigned'
 */
const rolePermissionsMap: Record<SonarRole, RolePermissions> = {
  // ── Administrator ──
  // Permissions: ALL
  'Administrator': {
    canCreateEvents: true,
    canEditEventMetadata: true,
    canLockUnlockEstimates: true,
    canAccessAdmin: true,
    canUploadGrossToNet: true,
    canAssignParticipants: true,
    canEditUWEstimates: true,
    canUploadModeling: true,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents', 'audit'],
    eventFilter: 'all',
  },

  // ── Event Coordinator ──
  // Permissions: create_event, modify_event, read_all_modules
  'Event Coordinator': {
    canCreateEvents: true,
    canEditEventMetadata: true,
    canLockUnlockEstimates: false,
    canAccessAdmin: true,
    canUploadGrossToNet: false,
    canAssignParticipants: false,
    canEditUWEstimates: false,
    canUploadModeling: false,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents', 'audit'],
    eventFilter: 'all',
  },

  // ── Finance Contributor ──
  // Permissions: create_event, modify_event, update_estimate, reopen_event, lock_estimate, can_unlock, read_all_modules
  'Finance Contributor': {
    canCreateEvents: true,
    canEditEventMetadata: true,
    canLockUnlockEstimates: true,
    canAccessAdmin: true,
    canUploadGrossToNet: true,
    canAssignParticipants: false,
    canEditUWEstimates: false,
    canUploadModeling: false,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents', 'audit'],
    eventFilter: 'all',
  },

  // ── CAT Contributor ──
  // Permissions: update_cat_data, edit_finance, read_all_modules
  'CAT Contributor': {
    canCreateEvents: false,
    canEditEventMetadata: false,
    canLockUnlockEstimates: false,
    canAccessAdmin: false,
    canUploadGrossToNet: false,
    canAssignParticipants: false,
    canEditUWEstimates: false,
    canUploadModeling: true,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents'],
    eventFilter: 'all',
  },

  // ── UW Contributor ──
  // Permissions: upload_data, reader_access
  'UW Contributor': {
    canCreateEvents: false,
    canEditEventMetadata: false,
    canLockUnlockEstimates: false,
    canAccessAdmin: false,
    canUploadGrossToNet: false,
    canAssignParticipants: false,
    canEditUWEstimates: true,
    canUploadModeling: false,
    canViewAllEvents: false,
    canExportReports: false,
    visibleTabs: ['overview', 'uw-estimation', 'claims', 'documents'],
    eventFilter: 'assigned',
  },

  // ── Executive Area Lead ──
  // Reads across all BUs and all modules within own Executive Area. Assigns tasks, approves within exec area scope.
  'Executive Area Lead': {
    canCreateEvents: false,
    canEditEventMetadata: false,
    canLockUnlockEstimates: false,
    canAccessAdmin: false,
    canUploadGrossToNet: false,
    canAssignParticipants: true,
    canEditUWEstimates: true,
    canUploadModeling: false,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents'],
    eventFilter: 'assigned',
  },

  // ── Business Unit Lead ──
  // Scoped to own BU only. Read-only view of own BU data across all modules. Assigns tasks, approves within own BU scope.
  'Business Unit Lead': {
    canCreateEvents: false,
    canEditEventMetadata: false,
    canLockUnlockEstimates: true,  // approve_estimates
    canAccessAdmin: false,
    canUploadGrossToNet: false,
    canAssignParticipants: true,
    canEditUWEstimates: true,
    canUploadModeling: false,
    canViewAllEvents: false,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents', 'audit'],
    eventFilter: 'assigned',
  },

  // ── Reader (Management) ──
  // Permissions: reader_access, read_all_modules
  'Reader': {
    canCreateEvents: false,
    canEditEventMetadata: false,
    canLockUnlockEstimates: false,
    canAccessAdmin: false,
    canUploadGrossToNet: false,
    canAssignParticipants: false,
    canEditUWEstimates: false,
    canUploadModeling: false,
    canViewAllEvents: true,
    canExportReports: true,
    visibleTabs: ['overview', 'uw-estimation', 'modeling', 'finance', 'claims', 'documents'],
    eventFilter: 'all',
  },
};

// Keep old type alias for backward compatibility
export type UserRole = SonarRole;

export const ALL_SONAR_ROLES: SonarRole[] = [
  'Administrator',
  'Event Coordinator',
  'Finance Contributor',
  'CAT Contributor',
  'UW Contributor',
  'Executive Area Lead',
  'Business Unit Lead',
  'Reader',
];

interface RoleContextType {
  permissions: RolePermissions;
  userName: string;
  currentRole: SonarRole;
  setCurrentRole: (role: SonarRole) => void;
  allRoles: SonarRole[];
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRole] = useState<SonarRole>('Administrator');

  const demoUser = roleDemoUsers[currentRole];

  return (
    <RoleContext.Provider value={{
      permissions: rolePermissionsMap[currentRole],
      userName: demoUser.name,
      currentRole,
      setCurrentRole,
      allRoles: ALL_SONAR_ROLES,
    }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}