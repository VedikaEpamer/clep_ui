import { createContext, useContext, useState, ReactNode } from 'react';

export interface Comment {
  id: string;
  eventId: string;
  team: string; // Keep for display/context, but comments are event-level
  author: string;
  authorRole: string;
  text: string;
  timestamp: Date;
  files?: string[];
  type: 'general' | 'submission' | 'review' | 'modeling-decision';
  isInternal?: boolean;
  workflowStage?: 'modeling' | 'underwriting' | 'finance' | 'management'; // Track which stage comment was made
}

interface CommentContextType {
  comments: Comment[];
  addComment: (comment: Omit<Comment, 'id' | 'timestamp'>) => void;
  getCommentsByEvent: (eventId: string) => Comment[];
  getCommentsByTeam: (eventId: string, team: string) => Comment[];
  deleteComment: (commentId: string) => void;
}

const CommentContext = createContext<CommentContextType | undefined>(undefined);

export function CommentProvider({ children }: { children: ReactNode }) {
  const [comments, setComments] = useState<Comment[]>([
    // Sample comments for demonstration
    {
      id: '1',
      eventId: 'EVT-2024-012',
      team: 'latam-brazil-treaty',
      author: 'LATAM Treaty Team',
      authorRole: 'Senior Underwriter - LATAM',
      text: 'Initial assessment complete. Loss estimates based on portfolio exposure analysis and preliminary cedent reports. Key contracts include major utilities and industrial risks in the Santiago region. Waiting for modeling validation to refine estimates.',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      type: 'submission',
      isInternal: false,
      files: ['LATAM_Portfolio_Analysis.xlsx', 'Cedent_Reports_Summary.pdf'],
      workflowStage: 'underwriting',
    },
    {
      id: '2',
      eventId: 'EVT-2024-012',
      team: 'london-treaty',
      author: 'London Treaty Team',
      authorRole: 'Underwriter - London',
      text: 'London office estimates submitted. Our exposure is primarily through facultative placements. Estimates include potential reinstatement premiums based on contract terms. Total estimate: £18.5M gross.',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      type: 'submission',
      isInternal: false,
      workflowStage: 'underwriting',
    },
    {
      id: '3',
      eventId: 'EVT-2024-012',
      team: 'latam-brazil-treaty',
      author: 'LATAM Treaty Team',
      authorRole: 'UW Manager - LATAM & Caribbean',
      text: 'Reviewed team estimates. Contacted three major cedents for updated loss advices. Expecting revised figures by EOD tomorrow. May need to adjust our initial estimates upward by 10-15%.',
      timestamp: new Date(Date.now() - 18 * 60 * 60 * 1000),
      type: 'general',
      isInternal: true,
      workflowStage: 'underwriting',
    },
    {
      id: '4',
      eventId: 'EVT-2024-012',
      team: 'treaty-property',
      author: 'Treaty Property Team',
      authorRole: 'Treaty Property Manager',
      text: 'Treaty Property (Bermuda) submission complete. Limited exposure due to attachment points. Most impacted contracts are above deductibles but below our layers. Confident in current estimates.',
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
      type: 'submission',
      isInternal: false,
      workflowStage: 'underwriting',
    },
    {
      id: '5',
      eventId: 'EVT-2024-012',
      team: 'intl-fac',
      author: 'International Fac Team',
      authorRole: 'Intl FAC Underwriter',
      text: 'International FAC exposure minimal. Two contracts potentially impacted, both with high attachment points. Conservative estimate provided pending additional information from brokers.',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      type: 'submission',
      isInternal: false,
      workflowStage: 'underwriting',
    },
    {
      id: '6',
      eventId: 'EVT-2024-012',
      team: 'modeling',
      author: 'Cat Modeling Team',
      authorRole: 'CAT Modeling Team Lead',
      text: 'AIR catastrophe model run complete. Ground motion data shows PGA values ranging 0.3-0.8g across impacted regions. Model output indicates loss range $2.1B - $6.2B across portfolio. 812 contracts matched successfully (95.9% match rate). Detailed loss-by-contract file uploaded to system.',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      type: 'submission',
      isInternal: false,
      files: ['AIR_Model_Output.xlsx', 'Loss_By_Contract_Detail.csv', 'Model_Validation_Report.pdf'],
      workflowStage: 'modeling',
    },
    {
      id: '7',
      eventId: 'EVT-2024-012',
      team: 'modeling',
      author: 'Cat Modeling Team',
      authorRole: 'CAT Modeling Team Lead',
      text: 'Note: Two contracts (TP-2024-213-290 and TP-2024-ACG-818) not found in RDM database. Working with underwriting teams to validate contract details. These represent approximately $15M in potential exposure that is NOT included in current model estimates.',
      timestamp: new Date(Date.now() - 3.5 * 60 * 60 * 1000),
      type: 'general',
      isInternal: true,
      workflowStage: 'modeling',
    },
    {
      id: '8',
      eventId: 'EVT-2024-012',
      team: 'finance',
      author: 'Finance Team',
      authorRole: 'Finance Manager',
      text: 'Preliminary finance calculations complete. Applied RI cessions and Mount Logan retro coverage to underwriting and modeling estimates. Current net-net-net position: $45.2M. Key driver is concentration in Chilean industrial and infrastructure treaties.',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      type: 'general',
      isInternal: false,
      workflowStage: 'finance',
    },
    {
      id: '9',
      eventId: 'EVT-2024-012',
      team: 'finance',
      author: 'Finance Team',
      authorRole: 'Finance Manager',
      text: 'Flagging potential issue: Mount Logan coverage may not attach for this event based on preliminary aggregate loss tracking. Will coordinate with RI Accounting to confirm. If ML does not attach, net position could increase by ~$2.3M.',
      timestamp: new Date(Date.now() - 1.5 * 60 * 60 * 1000),
      type: 'general',
      isInternal: true,
      workflowStage: 'finance',
    },
  ]);

  const addComment = (comment: Omit<Comment, 'id' | 'timestamp'>) => {
    const newComment: Comment = {
      ...comment,
      id: `comment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };
    setComments([...comments, newComment]);
  };

  const getCommentsByEvent = (eventId: string) => {
    return comments.filter(c => c.eventId === eventId).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  };

  const getCommentsByTeam = (eventId: string, team: string) => {
    return comments.filter(c => c.eventId === eventId && c.team === team).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  };

  const deleteComment = (commentId: string) => {
    setComments(comments.filter(c => c.id !== commentId));
  };

  return (
    <CommentContext.Provider value={{ comments, addComment, getCommentsByEvent, getCommentsByTeam, deleteComment }}>
      {children}
    </CommentContext.Provider>
  );
}

export function useComments() {
  const context = useContext(CommentContext);
  if (context === undefined) {
    throw new Error('useComments must be used within a CommentProvider');
  }
  return context;
}