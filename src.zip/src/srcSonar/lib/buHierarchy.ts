// ─── Business Unit Hierarchy — shared data/utilities ──────────────────────────

export interface BUNode { id: string; name: string; children?: BUNode[]; }

export const BU_HIERARCHY: BUNode[] = [
  {
    id: 'facultative', name: 'Facultative', children: [
      {
        id: 'intl-fac', name: 'International Fac', children: [
          { id: 'latam-fac', name: 'Latin America Fac' },
          { id: 'london-fac', name: 'London Fac' },
          { id: 'singapore-fac', name: 'Singapore Fac' },
        ]
      },
      {
        id: 'na-fac', name: 'North America Fac', children: [
          { id: 'bermuda-fac', name: 'Bermuda Fac' },
          { id: 'canada-fac', name: 'Canada Fac' },
          { id: 'fac-casualty', name: 'US FAC Casualty' },
          { id: 'fac-property', name: 'US FAC Property' },
        ]
      },
    ]
  },
  {
    id: 'intl-treaty', name: 'International Treaty', children: [
      { id: 'dublin', name: 'Dublin' },
      { id: 'zurich', name: 'Zurich' },
      { id: 'latam-brazil-treaty', name: 'Latin America / Brazil Treaty' },
      { id: 'london-treaty', name: 'London Treaty' },
      { id: 'me-africa', name: 'ME / Africa' },
      { id: 'singapore-treaty', name: 'Singapore Treaty' },
    ]
  },
  {
    id: 'na-treaty', name: 'North America Treaty', children: [
      { id: 'bermuda-treaty', name: 'Bermuda Treaty' },
      { id: 'canada-treaty', name: 'Canada Treaty' },
      { id: 'treaty-casualty', name: 'US Treaty Casualty' },
      { id: 'treaty-property', name: 'US Treaty Property' },
    ]
  },
  {
    id: 'product', name: 'Product', children: [
      { id: 'accident-health', name: 'Accident & Health' },
      { id: 'alternative-risk', name: 'Alternative Risk' },
      { id: 'aviation', name: 'Aviation' },
      { id: 'cyber', name: 'Cyber' },
      { id: 'energy', name: 'Energy' },
      { id: 'engineering', name: 'Engineering' },
      { id: 'marine', name: 'Marine' },
      { id: 'parametric', name: 'Parametric' },
      { id: 'pvt', name: 'PVT' },
    ]
  },
  {
    id: 'financial-lines', name: 'Financial Lines', children: [
      { id: 'financial', name: 'Financial' },
      { id: 'mortgage', name: 'Mortgage' },
    ]
  },
  {
    id: 'insurance', name: 'Insurance', children: [
      { id: 'insurance-div', name: 'Insurance' },
      { id: 'lloyds', name: "Lloyd's" },
    ]
  },
];

export function collectBUIds(node: BUNode): string[] {
  const ids = [node.id];
  if (node.children) node.children.forEach(c => ids.push(...collectBUIds(c)));
  return ids;
}

export function findBUNode(nodes: BUNode[], id: string): BUNode | null {
  for (const n of nodes) {
    if (n.id === id) return n;
    if (n.children) { const f = findBUNode(n.children, id); if (f) return f; }
  }
  return null;
}

export function collectParentIds(nodes: BUNode[]): string[] {
  const ids: string[] = [];
  for (const n of nodes) {
    if (n.children && n.children.length > 0) { ids.push(n.id); ids.push(...collectParentIds(n.children)); }
  }
  return ids;
}

export function collectLeafBUs(nodes: BUNode[]): BUNode[] {
  const leaves: BUNode[] = [];
  for (const n of nodes) {
    if (!n.children || n.children.length === 0) leaves.push(n);
    else leaves.push(...collectLeafBUs(n.children));
  }
  return leaves;
}

export function buildNameMap(nodes: BUNode[], map: Record<string, string> = {}): Record<string, string> {
  nodes.forEach(n => { map[n.id] = n.name; if (n.children) buildNameMap(n.children, map); });
  return map;
}

export const ALL_PARENT_IDS = collectParentIds(BU_HIERARCHY);
export const BU_NAME_MAP = buildNameMap(BU_HIERARCHY);

const PRODUCT_NODE = findBUNode(BU_HIERARCHY, 'product');
export const ALL_PRODUCT_IDS = new Set(PRODUCT_NODE ? collectBUIds(PRODUCT_NODE) : []);

export function isProductSelection(buId: string | null): boolean {
  return buId !== null && ALL_PRODUCT_IDS.has(buId);
}

export const PRODUCT_NODE_TO_NAME: Record<string, string> = {
  'accident-health': 'Accident & Health',
  'alternative-risk': 'Alternative Risk',
  'aviation': 'Aviation',
  'cyber': 'Cyber',
  'energy': 'Energy',
  'engineering': 'Engineering',
  'marine': 'Marine',
  'parametric': 'Parametric',
  'pvt': 'PVT & Terror',
};

export const RL_TO_TEAM: Record<string, string> = {
  'LAF': 'latam-fac', 'LF': 'london-fac', 'ASF': 'singapore-fac', 'CF': 'canada-fac',
  'FP': 'fac-property', 'FC': 'fac-casualty', 'LAT': 'latam-brazil-treaty',
  'DU': 'dublin', 'ZU': 'zurich', 'LN': 'london-treaty', 'MEA': 'me-africa',
  'AS': 'singapore-treaty', 'TP': 'treaty-property', 'BM': 'bermuda-treaty', 'LV': 'aviation',
};

export function resolveTeam(reportingLevel: string): string {
  const prefixes = Object.keys(RL_TO_TEAM).sort((a, b) => b.length - a.length);
  for (const prefix of prefixes) {
    if (reportingLevel.startsWith(prefix + ' ') || reportingLevel.startsWith(prefix + ' -')) return RL_TO_TEAM[prefix];
  }
  return 'latam-fac';
}
