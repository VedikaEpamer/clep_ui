import { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export interface PortfolioStats {
  total: number;
  impactedCount: number;
  totalUWMed: number;
}

interface PublishedPortfolioData {
  contractCounts: Record<string, number>;
  impactedCounts: Record<string, number>;
  buStatuses: Record<string, string>;
  portfolioStats: PortfolioStats;
  displayCurrency: string;
  totalEstimatesCount: number;
}

interface UWPortfolioContextValue {
  // Shared interactive state
  selectedBU: string | null;
  setSelectedBU: (id: string | null) => void;
  expandedNodes: Set<string>;
  setExpandedNodes: React.Dispatch<React.SetStateAction<Set<string>>>;
  toggleExpand: (id: string) => void;
  // Published data (UW Estimation → Layout)
  contractCounts: Record<string, number>;
  impactedCounts: Record<string, number>;
  buStatuses: Record<string, string>;
  portfolioStats: PortfolioStats;
  displayCurrency: string;
  totalEstimatesCount: number;
  publishPortfolioData: (data: PublishedPortfolioData) => void;
}

const UWPortfolioContext = createContext<UWPortfolioContextValue>({
  selectedBU: null,
  setSelectedBU: () => {},
  expandedNodes: new Set(),
  setExpandedNodes: () => {},
  toggleExpand: () => {},
  contractCounts: {},
  impactedCounts: {},
  buStatuses: {},
  portfolioStats: { total: 0, impactedCount: 0, totalUWMed: 0 },
  displayCurrency: 'USD',
  totalEstimatesCount: 0,
  publishPortfolioData: () => {},
});

export function UWPortfolioProvider({ children }: { children: ReactNode }) {
  const [selectedBU, setSelectedBU] = useState<string | null>(null);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [contractCounts, setContractCounts] = useState<Record<string, number>>({});
  const [impactedCounts, setImpactedCounts] = useState<Record<string, number>>({});
  const [buStatuses, setBuStatuses] = useState<Record<string, string>>({});
  const [portfolioStats, setPortfolioStats] = useState<PortfolioStats>({ total: 0, impactedCount: 0, totalUWMed: 0 });
  const [displayCurrency, setDisplayCurrencyState] = useState('USD');
  const [totalEstimatesCount, setTotalEstimatesCount] = useState(0);

  const toggleExpand = useCallback((id: string) => {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const publishPortfolioData = useCallback((data: PublishedPortfolioData) => {
    setContractCounts(data.contractCounts);
    setImpactedCounts(data.impactedCounts);
    setBuStatuses(data.buStatuses);
    setPortfolioStats(data.portfolioStats);
    setDisplayCurrencyState(data.displayCurrency);
    setTotalEstimatesCount(data.totalEstimatesCount);
  }, []);

  return (
    <UWPortfolioContext.Provider value={{
      selectedBU, setSelectedBU,
      expandedNodes, setExpandedNodes, toggleExpand,
      contractCounts, impactedCounts, buStatuses,
      portfolioStats, displayCurrency, totalEstimatesCount,
      publishPortfolioData,
    }}>
      {children}
    </UWPortfolioContext.Provider>
  );
}

export function useUWPortfolio() {
  return useContext(UWPortfolioContext);
}
