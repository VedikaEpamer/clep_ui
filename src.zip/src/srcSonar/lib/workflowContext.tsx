import { createContext, useContext, useState, type ReactNode } from 'react';

// WORKFLOW PHASES - LINEAR PATH WITH MONITORING
export type WorkflowPhase =
  | 'Event Creation'
  | 'Monitoring'
  | 'Estimation & Approval'
  | 'Finance Review'
  | 'Reporting & Close'
  | 'Reopened';

export interface WorkflowStep {
  phase: WorkflowPhase;
  status: 'not-started' | 'in-progress' | 'completed';
  assignedTo?: string;
  completedBy?: string;
  completedAt?: string;
  dueDate?: string;
}

export type Phase4CloseStatus = 'Close Monitor' | 'Close Archived';

export interface EventWorkflow {
  eventId: string;
  currentPhase: WorkflowPhase;
  steps: WorkflowStep[];
  isReopened?: boolean;
  /** When Phase 4 is completed, tracks whether it's Close Monitor or Close Archived */
  phase4CloseStatus?: Phase4CloseStatus;
  /** Lock status - true if event is locked, false or undefined if unlocked (default: unlocked) */
  isLocked?: boolean;
}

export type EventStatus = 'Draft' | 'Monitoring' | 'Open' | 'Close Monitor' | 'Close Archived' | 'Reopened';

// ─── BUSINESS RULES (BR-CRNEVT.001.01 – .05) ───────────────────────────
// Allowed phase transitions per current phase:
//   Phase 0 (Draft)         -> Phase 1 (Monitoring) | Phase 2 (Track Immediately)
//   Phase 1 (Monitoring)    -> Phase 2 | Phase 4 Open | Close Event (Phase 4 Close Monitor)
//   Phase 2 (Open)          -> Phase 3 (SYSTEM-DRIVEN ONLY when all estimations received — NOT manually selectable)
//   Phase 3 (Open)          -> Phase 4 (Reporting & Close)
//   Phase 4 in-prog (Open)  -> Complete Phase 4 (Close Monitor by default)
//   Phase 4 Close Monitor   -> Close Archived | Reopened
//   Phase 4 Close Archived  -> Reopened
//   Reopened                -> Returns to Phase 1 (Monitoring) ONLY. Resets Phases 2-4. Transition behavior, not a stored phase.
// You can NEVER jump backward to Draft (Phase 0). Phase 0 is pre-activation only.

export type PhaseTransitionInfo = {
  phase: WorkflowPhase | 'Complete Phase 4' | 'Close Event' | 'Close Archived';
  allowed: boolean;
  reason?: string;
  ruleId?: string;
};

interface WorkflowContextType {
  workflows: Record<string, EventWorkflow>;
  updateWorkflow: (eventId: string, updates: Partial<EventWorkflow>) => void;
  advancePhase: (eventId: string) => void;
  reopenEvent: (eventId: string) => void;
  setPhase: (eventId: string, phase: WorkflowPhase) => void;
  completePhase4: (eventId: string) => void;
  closeEvent: (eventId: string) => void;
  archiveEvent: (eventId: string) => void;
  getAllowedPhases: (eventId: string) => PhaseTransitionInfo[];
  canTrack: (eventId: string) => boolean;
  getWorkflowStatus: (eventId: string) => EventWorkflow;
  getEventStatus: (eventId: string) => EventStatus;
  lockEvent: (eventId: string) => void;
  unlockEvent: (eventId: string) => void;
  isEventLocked: (eventId: string) => boolean;
}

// Default no-op context to prevent crashes during HMR (hot module reload).
// When workflowContext.tsx is edited, the module re-evaluates creating a new context
// reference. Providing a safe default ensures EventDetailLayout won't throw while the
// provider tree catches up.
const DEFAULT_WORKFLOW: EventWorkflow = {
  eventId: '',
  currentPhase: 'Event Creation',
  steps: [],
  isReopened: false,
};

const noop = () => {};
const defaultCtx: WorkflowContextType = {
  workflows: {},
  updateWorkflow: noop,
  advancePhase: noop,
  reopenEvent: noop,
  setPhase: noop,
  completePhase4: noop,
  closeEvent: noop,
  archiveEvent: noop,
  getAllowedPhases: () => [],
  canTrack: () => false,
  getWorkflowStatus: () => DEFAULT_WORKFLOW,
  getEventStatus: () => 'Draft',
  lockEvent: noop,
  unlockEvent: noop,
  isEventLocked: () => false,
};

const WorkflowContext = createContext<WorkflowContextType>(defaultCtx);

const ALL_PHASES: WorkflowPhase[] = [
  'Event Creation',
  'Monitoring',
  'Estimation & Approval',
  'Finance Review',
  'Reporting & Close',
];

// Simple default workflow - one linear path
const createDefaultWorkflow = (eventId: string): EventWorkflow => ({
  eventId,
  currentPhase: 'Event Creation',
  isReopened: false,
  steps: [
    {
      phase: 'Event Creation',
      status: 'completed',
      completedBy: 'System',
      completedAt: new Date().toISOString(),
    },
    {
      phase: 'Monitoring',
      status: 'in-progress',
      assignedTo: 'Group UW, Finance, Cat Modeling, Claims',
    },
    {
      phase: 'Estimation & Approval',
      status: 'not-started',
      assignedTo: 'UW & CAT Teams',
      dueDate: '2024-12-20',
    },
    {
      phase: 'Finance Review',
      status: 'not-started',
      assignedTo: 'Finance Team',
      dueDate: '2024-12-25',
    },
    {
      phase: 'Reporting & Close',
      status: 'not-started',
      assignedTo: 'Finance & Operations',
      dueDate: '2024-12-31',
    },
  ],
});

// Helper to create a workflow at a specific phase
const createWorkflowAtPhase = (eventId: string, targetPhase: WorkflowPhase): EventWorkflow => {
  const targetIndex = ALL_PHASES.indexOf(targetPhase);
  const base = createDefaultWorkflow(eventId);
  return {
    ...base,
    currentPhase: targetPhase,
    steps: base.steps.map((step, i) => {
      if (i < targetIndex) {
        return { ...step, status: 'completed' as const, completedBy: 'System', completedAt: new Date().toISOString() };
      } else if (i === targetIndex) {
        return { ...step, status: 'in-progress' as const };
      }
      return step;
    }),
  };
};

// Helper to create a reopened workflow — event restarts at Monitoring with Phases 2-4 reset
const createReopenedWorkflow = (eventId: string): EventWorkflow => {
  const base = createDefaultWorkflow(eventId);
  return {
    ...base,
    currentPhase: 'Monitoring',
    isReopened: true,
    steps: base.steps.map((step) => {
      if (step.phase === 'Event Creation') {
        return { ...step, status: 'completed' as const, completedBy: 'System', completedAt: new Date().toISOString() };
      }
      if (step.phase === 'Monitoring') {
        return { ...step, status: 'in-progress' as const };
      }
      // Phases 2-4 reset to not-started per BR-CRNEVT.001.05
      return step; // already not-started from createDefaultWorkflow
    }),
  };
};

// Helper to create a workflow at Phase 4 completed (Close Monitor by default)
const createClosedWorkflow = (eventId: string, closeStatus: Phase4CloseStatus = 'Close Monitor'): EventWorkflow => {
  const base = createDefaultWorkflow(eventId);
  return {
    ...base,
    currentPhase: 'Reporting & Close',
    phase4CloseStatus: closeStatus,
    steps: base.steps.map((step) => ({
      ...step,
      status: 'completed' as const,
      completedBy: 'System',
      completedAt: new Date().toISOString(),
    })),
  };
};

export function WorkflowProvider({ children }: { children: ReactNode }) {
  const [workflows, setWorkflows] = useState<Record<string, EventWorkflow>>({
    // Phase 0: Event Creation
    'EVT-2024-006': createWorkflowAtPhase('EVT-2024-006', 'Event Creation'),
    // Phase 1: Monitoring
    'EVT-2024-005': createWorkflowAtPhase('EVT-2024-005', 'Monitoring'),
    'EVT-2024-012': createWorkflowAtPhase('EVT-2024-012', 'Monitoring'),
    // Phase 2: Estimation & Approval
    'EVT-2024-008': createWorkflowAtPhase('EVT-2024-008', 'Estimation & Approval'),
    'EVT-2024-007': createWorkflowAtPhase('EVT-2024-007', 'Estimation & Approval'),
    // Phase 3: Finance Review
    'EVT-2024-001': createWorkflowAtPhase('EVT-2024-001', 'Finance Review'),
    // Reopened -- was closed, reopened to restart lifecycle at Monitoring (isReopened = true)
    'EVT-2024-003': createReopenedWorkflow('EVT-2024-003'),
    // Phase 4: Reporting & Close (in-progress = Open)
    'EVT-2024-002': createWorkflowAtPhase('EVT-2024-002', 'Reporting & Close'),
    // Phase 4: Closed (Close Monitor)
    'EVT-2024-004': createClosedWorkflow('EVT-2024-004', 'Close Monitor'),
  });

  const updateWorkflow = (eventId: string, updates: Partial<EventWorkflow>) => {
    setWorkflows((prev) => ({
      ...prev,
      [eventId]: {
        ...(prev[eventId] || createDefaultWorkflow(eventId)),
        ...updates,
      },
    }));
  };

  const advancePhase = (eventId: string) => {
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    // If reopened, go back to Phase 1: Monitoring (restarts monitoring cycle)
    if (workflow.currentPhase === 'Reopened') {
      const updatedSteps = workflow.steps.map((step) => {
        if (step.phase === 'Monitoring') {
          return { ...step, status: 'in-progress' as const, completedBy: undefined, completedAt: undefined };
        }
        if (step.phase === 'Estimation & Approval' || step.phase === 'Finance Review' || step.phase === 'Reporting & Close') {
          return { ...step, status: 'not-started' as const, completedBy: undefined, completedAt: undefined };
        }
        return step;
      });
      updateWorkflow(eventId, {
        currentPhase: 'Monitoring',
        steps: updatedSteps,
        isReopened: false,
        phase4CloseStatus: undefined,
      });
      return;
    }

    const currentIndex = workflow.steps.findIndex(
      (step) => step.phase === workflow.currentPhase
    );

    if (currentIndex < workflow.steps.length - 1) {
      const updatedSteps = [...workflow.steps];
      updatedSteps[currentIndex] = {
        ...updatedSteps[currentIndex],
        status: 'completed',
        completedAt: new Date().toISOString(),
      };
      updatedSteps[currentIndex + 1] = {
        ...updatedSteps[currentIndex + 1],
        status: 'in-progress',
      };

      updateWorkflow(eventId, {
        currentPhase: workflow.steps[currentIndex + 1].phase,
        steps: updatedSteps,
      });
    }
  };

  const reopenEvent = (eventId: string) => {
    // Reopened is transition behavior, not a stored phase (BR-CRNEVT.001.05)
    // Directly restart lifecycle at Phase 1 (Monitoring), reset Phases 2-4 to not-started
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const updatedSteps = workflow.steps.map((step) => {
      if (step.phase === 'Event Creation') {
        return { ...step, status: 'completed' as const, completedBy: 'System', completedAt: new Date().toISOString() };
      }
      if (step.phase === 'Monitoring') {
        return { ...step, status: 'in-progress' as const, completedBy: undefined, completedAt: undefined };
      }
      // Reset Phases 2-4 to not-started
      return { ...step, status: 'not-started' as const, completedBy: undefined, completedAt: undefined };
    });
    updateWorkflow(eventId, {
      currentPhase: 'Monitoring',
      steps: updatedSteps,
      isReopened: true,
      phase4CloseStatus: undefined,
    });
  };

  const setPhase = (eventId: string, phase: WorkflowPhase) => {
    if (phase === 'Reopened') {
      reopenEvent(eventId);
      return;
    }
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const targetIndex = ALL_PHASES.indexOf(phase);
    const updatedSteps = workflow.steps.map((step, i) => {
      if (i < targetIndex) {
        return { ...step, status: 'completed' as const, completedBy: 'System', completedAt: new Date().toISOString() };
      } else if (i === targetIndex) {
        return { ...step, status: 'in-progress' as const, completedBy: undefined, completedAt: undefined };
      }
      return { ...step, status: 'not-started' as const, completedBy: undefined, completedAt: undefined };
    });
    updateWorkflow(eventId, {
      currentPhase: phase,
      steps: updatedSteps,
      isReopened: false,
      phase4CloseStatus: undefined,
    });
  };

  // Complete Phase 4 → Close Monitor (default)
  const completePhase4 = (eventId: string) => {
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const phase4Step = workflow.steps.find(s => s.phase === 'Reporting & Close');
    if (phase4Step?.status === 'in-progress') {
      const updatedSteps = [...workflow.steps];
      const phase4Index = updatedSteps.findIndex(s => s.phase === 'Reporting & Close');
      updatedSteps[phase4Index] = {
        ...updatedSteps[phase4Index],
        status: 'completed',
        completedAt: new Date().toISOString(),
      };
      updateWorkflow(eventId, {
        currentPhase: 'Reporting & Close',
        steps: updatedSteps,
        phase4CloseStatus: 'Close Monitor',
      });
    }
  };

  // Jump directly to Phase 4 completed with Close Monitor (from Phase 1)
  const closeEvent = (eventId: string) => {
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const updatedSteps = workflow.steps.map((step) => ({
      ...step,
      status: 'completed' as const,
      completedBy: 'System',
      completedAt: new Date().toISOString(),
    }));
    updateWorkflow(eventId, {
      currentPhase: 'Reporting & Close',
      steps: updatedSteps,
      isReopened: false,
      phase4CloseStatus: 'Close Monitor',
    });
  };

  // Move from Close Monitor → Close Archived
  const archiveEvent = (eventId: string) => {
    updateWorkflow(eventId, {
      phase4CloseStatus: 'Close Archived',
    });
  };

  const getAllowedPhases = (eventId: string): PhaseTransitionInfo[] => {
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const currentPhase = workflow.currentPhase;

    const allowedPhases: PhaseTransitionInfo[] = [];

    if (currentPhase === 'Reopened') {
      // Reopened is transient — should not persist, but if reached, only allow Phase 1
      // Per spec: "Returns to Phase 1 – Monitoring. Reset Phases 2-4 to not started."
      allowedPhases.push({ phase: 'Monitoring', allowed: true, ruleId: 'BR-CRNEVT.001.05', reason: 'Restart lifecycle at Monitoring' });
    } else if (currentPhase === 'Event Creation') {
      // Phase 0 (Draft) → Phase 1 (Monitoring) or Phase 2 (Track Immediately)
      allowedPhases.push({ phase: 'Monitoring', allowed: true, ruleId: 'BR-CRNEVT.001.01', reason: 'Publish with Monitoring' });
      allowedPhases.push({ phase: 'Estimation & Approval', allowed: true, ruleId: 'BR-CRNEVT.001.01', reason: 'Track Immediately — activate estimation' });
    } else if (currentPhase === 'Monitoring') {
      // Phase 1 → Phase 2 (escalate), Phase 4 Open (jump), or Close Event (Phase 4 Close Monitor)
      allowedPhases.push({ phase: 'Estimation & Approval', allowed: true, ruleId: 'BR-CRNEVT.001.02', reason: 'Escalate to active estimation' });
      allowedPhases.push({ phase: 'Reporting & Close', allowed: true, ruleId: 'BR-CRNEVT.001.02', reason: 'Jump to Reporting & Close (Open)' });
      allowedPhases.push({ phase: 'Close Event', allowed: true, ruleId: 'BR-CRNEVT.001.02', reason: 'Close event (Close Monitor)' });
    } else if (currentPhase === 'Estimation & Approval') {
      // Phase 2 → Phase 3: manually selectable AND auto-triggers when all estimations received
      allowedPhases.push({ phase: 'Finance Review', allowed: true, ruleId: 'BR-CRNEVT.001.03', reason: 'Advance to Finance Review (also auto-triggers when all estimations received)' });
    } else if (currentPhase === 'Finance Review') {
      // Phase 3 → Phase 4 (Reporting & Close)
      allowedPhases.push({ phase: 'Reporting & Close', allowed: true, ruleId: 'BR-CRNEVT.001.04', reason: 'Advance to Reporting & Close' });
    } else if (currentPhase === 'Reporting & Close') {
      const phase4Step = workflow.steps.find(s => s.phase === 'Reporting & Close');
      if (phase4Step?.status === 'in-progress') {
        // Phase 4 Open → can complete (becomes Close Monitor)
        allowedPhases.push({ phase: 'Complete Phase 4', allowed: true, ruleId: 'BR-CRNEVT.001.04', reason: 'Complete — sets status to Close Monitor' });
      } else if (workflow.phase4CloseStatus === 'Close Monitor') {
        // Close Monitor → can archive or reopen
        allowedPhases.push({ phase: 'Close Archived', allowed: true, ruleId: 'BR-CRNEVT.001.04', reason: 'Archive this event' });
        allowedPhases.push({ phase: 'Reopened', allowed: true, ruleId: 'BR-CRNEVT.001.05', reason: 'Reopen — restarts at Monitoring' });
      } else if (workflow.phase4CloseStatus === 'Close Archived') {
        // Close Archived → can only reopen
        allowedPhases.push({ phase: 'Reopened', allowed: true, ruleId: 'BR-CRNEVT.001.05', reason: 'Reopen — restarts at Monitoring' });
      }
    }

    return allowedPhases;
  };

  const canTrack = (eventId: string): boolean => {
    const workflow = workflows[eventId] || createDefaultWorkflow(eventId);
    const currentPhase = workflow.currentPhase;
    // Track is available from Draft (Phase 0), Monitoring (Phase 1), and Reopened
    return currentPhase === 'Event Creation' || currentPhase === 'Monitoring' || currentPhase === 'Reopened';
  };

  const getWorkflowStatus = (eventId: string): EventWorkflow => {
    return workflows[eventId] || createDefaultWorkflow(eventId);
  };

  // Derive event status from current phase + step completion + phase4CloseStatus
  // Phase 0 -> Draft | Phase 1 -> Monitoring | Phase 2/3/4(in-progress) -> Open
  // Phase 4(completed) -> Close Monitor (default) or Close Archived | Reopened -> Reopened
  const getEventStatus = (eventId: string): EventStatus => {
    const workflow = getWorkflowStatus(eventId);
    const phase = workflow.currentPhase;

    if (phase === 'Reopened') return 'Reopened';
    if (phase === 'Event Creation') return 'Draft';
    if (phase === 'Monitoring') return 'Monitoring';
    if (phase === 'Reporting & Close') {
      const phase4Step = workflow.steps.find(s => s.phase === 'Reporting & Close');
      if (phase4Step?.status === 'completed') {
        return workflow.phase4CloseStatus || 'Close Monitor';
      }
      return 'Open';
    }
    // Phase 2 or Phase 3 -> Open
    return 'Open';
  };

  const lockEvent = (eventId: string) => {
    updateWorkflow(eventId, {
      isLocked: true,
    });
  };

  const unlockEvent = (eventId: string) => {
    updateWorkflow(eventId, {
      isLocked: false,
    });
  };

  const isEventLocked = (eventId: string) => {
    const workflow = getWorkflowStatus(eventId);
    // Auto-lock when phase is Finance Review or beyond (Reporting & Close with completed steps)
    // Manual isLocked flag can also lock at any phase for edge cases
    if (workflow.isLocked) return true;
    const phase = workflow.currentPhase;
    if (phase === 'Finance Review') return true;
    if (phase === 'Reporting & Close') return true;
    return false;
  };

  return (
    <WorkflowContext.Provider
      value={{
        workflows,
        updateWorkflow,
        advancePhase,
        reopenEvent,
        setPhase,
        completePhase4,
        closeEvent,
        archiveEvent,
        getAllowedPhases,
        canTrack,
        getWorkflowStatus,
        getEventStatus,
        lockEvent,
        unlockEvent,
        isEventLocked,
      }}
    >
      {children}
    </WorkflowContext.Provider>
  );
}

export function useWorkflow() {
  const context = useContext(WorkflowContext);
  return context;
}