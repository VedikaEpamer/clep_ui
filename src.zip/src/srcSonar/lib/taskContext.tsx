import { createContext, useContext, useState, ReactNode } from 'react';
import { toast } from 'sonner@2.0.3';

export interface Task {
  id: string;
  eventId: string;
  eventName: string;
  title: string;
  description: string;
  assignedTo: string;
  assignedBy: string;
  assignedAt: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'in-progress' | 'completed' | 'overdue';
  type: 'assignment' | 'estimation' | 'approval' | 'modeling' | 'review';
  metadata?: any;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'task-assigned' | 'approval-required' | 'deadline-approaching' | 'estimate-submitted' | 'workflow-advanced' | 'info';
  read: boolean;
  createdAt: string;
  taskId?: string;
  eventId?: string;
}

interface TaskContextType {
  tasks: Task[];
  notifications: Notification[];
  createTask: (task: Omit<Task, 'id' | 'assignedAt' | 'status'>) => Task;
  updateTaskStatus: (taskId: string, status: Task['status']) => void;
  completeTask: (taskId: string) => void;
  getTasksForUser: (userId: string) => Task[];
  getNotificationsForUser: (userId: string) => Notification[];
  getNotificationsForEvent: (userId: string, eventId: string) => Notification[];
  markNotificationRead: (notificationId: string) => void;
  sendNotification: (notification: Omit<Notification, 'id' | 'createdAt' | 'read'>) => void;
  getUnreadCount: (userId: string) => number;
  getUnreadCountForEvent: (userId: string, eventId: string) => number;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

// ── Seed tasks ────────────────────────────────────────────────────
const seedTasks: Task[] = [
  // ── Hurricane Milton (EVT-2024-001) — Phase 3 (Finance Review) ──
  {
    id: 'TASK-001',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Provide Gross Loss Estimates',
    description: 'Enter your gross loss estimates for all assigned contracts for Hurricane Milton.',
    assignedTo: 'Thomas Brennan',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-10-18T09:00:00Z',
    dueDate: '2024-10-25T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'estimation',
  },
  {
    id: 'TASK-002',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Upload CAT Model Output',
    description: 'Upload RMS and AIR model results for Hurricane Milton exposure analysis.',
    assignedTo: 'Neil Schwarzenberger',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-10-18T09:30:00Z',
    dueDate: '2024-10-28T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'modeling',
  },
  {
    id: 'TASK-003',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Review & Approve UW Estimates',
    description: 'Review the consolidated underwriting estimates and approve or send back for revision.',
    assignedTo: 'Juan Delgado',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-10-26T08:00:00Z',
    dueDate: '2024-10-30T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'approval',
  },
  {
    id: 'TASK-004',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Executive Sign-Off on Estimates',
    description: 'Final executive approval of the consolidated loss estimates before Finance review.',
    assignedTo: 'Mike Cellura',
    assignedBy: 'Juan Delgado',
    assignedAt: '2024-10-31T08:00:00Z',
    dueDate: '2024-11-03T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'approval',
  },
  {
    id: 'TASK-005',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Run Gross-to-Net Calculations',
    description: 'Execute gross-to-net calculations and validate ceded reinsurance offsets.',
    assignedTo: 'Clem Demetz',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-04T08:00:00Z',
    dueDate: '2024-11-15T17:00:00Z',
    priority: 'high',
    status: 'in-progress',
    type: 'review',
  },
  {
    id: 'TASK-006',
    eventId: 'EVT-2024-001',
    eventName: 'Hurricane Milton',
    title: 'Assign Participants to Event',
    description: 'Ensure all required teams and underwriters are assigned to Hurricane Milton.',
    assignedTo: 'Andrew McBride',
    assignedBy: 'David Chen',
    assignedAt: '2024-10-16T10:00:00Z',
    dueDate: '2024-10-18T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'assignment',
  },

  // ── California Wildfires (EVT-2024-002) — Phase 4 (Reporting & Close) ──
  {
    id: 'TASK-010',
    eventId: 'EVT-2024-002',
    eventName: 'California Wildfires',
    title: 'Provide Gross Loss Estimates',
    description: 'Enter your gross loss estimates for California Wildfires assigned contracts.',
    assignedTo: 'Thomas Brennan',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-09-25T09:00:00Z',
    dueDate: '2024-10-05T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'estimation',
  },
  {
    id: 'TASK-011',
    eventId: 'EVT-2024-002',
    eventName: 'California Wildfires',
    title: 'Upload CAT Model Output',
    description: 'Upload wildfire model results for California Wildfires.',
    assignedTo: 'Neil Schwarzenberger',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-09-25T09:30:00Z',
    dueDate: '2024-10-08T17:00:00Z',
    priority: 'medium',
    status: 'completed',
    type: 'modeling',
  },
  {
    id: 'TASK-012',
    eventId: 'EVT-2024-002',
    eventName: 'California Wildfires',
    title: 'Approve Final Estimates',
    description: 'Review and approve final loss estimates for California Wildfires.',
    assignedTo: 'Mike Cellura',
    assignedBy: 'Juan Delgado',
    assignedAt: '2024-10-12T08:00:00Z',
    dueDate: '2024-10-18T17:00:00Z',
    priority: 'high',
    status: 'completed',
    type: 'approval',
  },
  {
    id: 'TASK-013',
    eventId: 'EVT-2024-002',
    eventName: 'California Wildfires',
    title: 'Finalize Finance Review',
    description: 'Complete gross-to-net calculations and finalize Finance review.',
    assignedTo: 'Clem Demetz',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-10-20T08:00:00Z',
    dueDate: '2024-11-01T17:00:00Z',
    priority: 'medium',
    status: 'completed',
    type: 'review',
  },

  // ── European Windstorm Petra (EVT-2024-003) — Phase 3 ──
  {
    id: 'TASK-020',
    eventId: 'EVT-2024-003',
    eventName: 'European Windstorm Petra',
    title: 'Re-estimate Gross Losses',
    description: 'Event has been reopened — please provide revised gross loss estimates.',
    assignedTo: 'Thomas Brennan',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-15T08:00:00Z',
    dueDate: '2024-11-25T17:00:00Z',
    priority: 'high',
    status: 'in-progress',
    type: 'estimation',
  },
  {
    id: 'TASK-021',
    eventId: 'EVT-2024-003',
    eventName: 'European Windstorm Petra',
    title: 'Update CAT Model Results',
    description: 'Updated wind field data available — refresh model output for Petra.',
    assignedTo: 'Neil Schwarzenberger',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-15T08:30:00Z',
    dueDate: '2024-11-25T17:00:00Z',
    priority: 'high',
    status: 'in-progress',
    type: 'modeling',
  },
  {
    id: 'TASK-022',
    eventId: 'EVT-2024-003',
    eventName: 'European Windstorm Petra',
    title: 'Approve Revised Estimates',
    description: 'Once revised estimates are submitted, review and approve.',
    assignedTo: 'Juan Delgado',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-15T09:00:00Z',
    dueDate: '2024-11-28T17:00:00Z',
    priority: 'medium',
    status: 'pending',
    type: 'approval',
  },

  // ── Chile Earthquake (EVT-2024-012) — Phase 1 ──
  {
    id: 'TASK-030',
    eventId: 'EVT-2024-012',
    eventName: 'Chile Earthquake (Maule Region)',
    title: 'Capture Exposed Contracts',
    description: 'Identify and capture all contracts with exposure to the Chile earthquake zone.',
    assignedTo: 'Andrew McBride',
    assignedBy: 'David Chen',
    assignedAt: '2024-11-20T08:00:00Z',
    dueDate: '2024-12-01T17:00:00Z',
    priority: 'high',
    status: 'in-progress',
    type: 'assignment',
  },
  {
    id: 'TASK-031',
    eventId: 'EVT-2024-012',
    eventName: 'Chile Earthquake (Maule Region)',
    title: 'Provide Initial Loss Estimates',
    description: 'Provide preliminary gross loss estimates for Chile EQ exposed contracts.',
    assignedTo: 'Thomas Brennan',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-22T08:00:00Z',
    dueDate: '2024-12-05T17:00:00Z',
    priority: 'high',
    status: 'pending',
    type: 'estimation',
  },
  {
    id: 'TASK-032',
    eventId: 'EVT-2024-012',
    eventName: 'Chile Earthquake (Maule Region)',
    title: 'Run Earthquake Models',
    description: 'Run RMS earthquake model for Chile Maule Region epicenter.',
    assignedTo: 'Neil Schwarzenberger',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-22T08:30:00Z',
    dueDate: '2024-12-05T17:00:00Z',
    priority: 'high',
    status: 'pending',
    type: 'modeling',
  },

  // ── Texas Hailstorm (EVT-2024-005) — Phase 1 ──
  {
    id: 'TASK-040',
    eventId: 'EVT-2024-005',
    eventName: 'Texas Hailstorm',
    title: 'Assign UW Team',
    description: 'Assign underwriters with Texas book exposure to this hailstorm event.',
    assignedTo: 'Andrew McBride',
    assignedBy: 'David Chen',
    assignedAt: '2024-11-19T10:00:00Z',
    dueDate: '2024-11-22T17:00:00Z',
    priority: 'medium',
    status: 'in-progress',
    type: 'assignment',
  },
  {
    id: 'TASK-041',
    eventId: 'EVT-2024-005',
    eventName: 'Texas Hailstorm',
    title: 'Provide Gross Loss Estimates',
    description: 'Enter gross loss estimates for Texas Hailstorm exposed contracts.',
    assignedTo: 'Thomas Brennan',
    assignedBy: 'Andrew McBride',
    assignedAt: '2024-11-23T08:00:00Z',
    dueDate: '2024-12-05T17:00:00Z',
    priority: 'medium',
    status: 'pending',
    type: 'estimation',
  },

  // ── Cyber Attack (EVT-2024-006) — Phase 0 ──
  {
    id: 'TASK-050',
    eventId: 'EVT-2024-006',
    eventName: 'Cyber Attack - Financial Services',
    title: 'Create Event & Set Parameters',
    description: 'Finalize event creation and configure initial parameters for this cyber event.',
    assignedTo: 'David Chen',
    assignedBy: 'David Chen',
    assignedAt: '2024-11-26T08:00:00Z',
    dueDate: '2024-11-28T17:00:00Z',
    priority: 'medium',
    status: 'in-progress',
    type: 'assignment',
  },
];

// ── Seed notifications (one per task + some workflow/status updates) ──
const seedNotifications: Notification[] = [
  // ── Hurricane Milton (EVT-2024-001) ──
  {
    id: 'NOTIF-001',
    userId: 'Thomas Brennan',
    title: 'Estimation Complete',
    message: 'Your gross loss estimates for Hurricane Milton have been accepted and locked.',
    type: 'info',
    read: true,
    createdAt: '2024-10-26T08:00:00Z',
    taskId: 'TASK-001',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-002',
    userId: 'Neil Schwarzenberger',
    title: 'Model Upload Complete',
    message: 'CAT model output for Hurricane Milton has been processed successfully.',
    type: 'info',
    read: true,
    createdAt: '2024-10-27T10:00:00Z',
    taskId: 'TASK-002',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-003',
    userId: 'Juan Delgado',
    title: 'Estimates Approved',
    message: 'You approved the consolidated UW estimates for Hurricane Milton.',
    type: 'info',
    read: true,
    createdAt: '2024-10-30T14:00:00Z',
    taskId: 'TASK-003',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-004',
    userId: 'Mike Cellura',
    title: 'Executive Sign-Off Completed',
    message: 'You signed off on Hurricane Milton estimates. Event advanced to Finance Review.',
    type: 'info',
    read: true,
    createdAt: '2024-11-02T16:00:00Z',
    taskId: 'TASK-004',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-005',
    userId: 'Clem Demetz',
    title: 'Finance Review Required',
    message: 'Hurricane Milton has entered Finance Review — run gross-to-net calculations.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-04T08:00:00Z',
    taskId: 'TASK-005',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-005b',
    userId: 'Clem Demetz',
    title: 'Deadline Approaching',
    message: 'Gross-to-net calculations for Hurricane Milton are due Nov 15.',
    type: 'deadline-approaching',
    read: false,
    createdAt: '2024-11-12T08:00:00Z',
    taskId: 'TASK-005',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-006',
    userId: 'Andrew McBride',
    title: 'Participants Assigned',
    message: 'All required teams have been assigned to Hurricane Milton.',
    type: 'info',
    read: true,
    createdAt: '2024-10-17T12:00:00Z',
    taskId: 'TASK-006',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-006b',
    userId: 'Andrew McBride',
    title: 'Phase Advanced: Finance Review',
    message: 'Hurricane Milton has moved to Phase 3 — Finance Review.',
    type: 'workflow-advanced',
    read: false,
    createdAt: '2024-11-04T08:15:00Z',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-006c',
    userId: 'David Chen',
    title: 'Phase Advanced: Finance Review',
    message: 'Hurricane Milton has moved to Phase 3 — Finance Review.',
    type: 'workflow-advanced',
    read: true,
    createdAt: '2024-11-04T08:15:00Z',
    eventId: 'EVT-2024-001',
  },

  // ── California Wildfires (EVT-2024-002) ──
  {
    id: 'NOTIF-010',
    userId: 'Thomas Brennan',
    title: 'Estimation Complete',
    message: 'Your estimates for California Wildfires were approved and event is now in Reporting.',
    type: 'info',
    read: true,
    createdAt: '2024-10-08T10:00:00Z',
    taskId: 'TASK-010',
    eventId: 'EVT-2024-002',
  },
  {
    id: 'NOTIF-011',
    userId: 'Neil Schwarzenberger',
    title: 'Model Upload Complete',
    message: 'CAT model output for California Wildfires has been processed.',
    type: 'info',
    read: true,
    createdAt: '2024-10-07T15:00:00Z',
    taskId: 'TASK-011',
    eventId: 'EVT-2024-002',
  },
  {
    id: 'NOTIF-012',
    userId: 'Mike Cellura',
    title: 'Final Approval Complete',
    message: 'You approved the final estimates for California Wildfires.',
    type: 'info',
    read: true,
    createdAt: '2024-10-17T11:00:00Z',
    taskId: 'TASK-012',
    eventId: 'EVT-2024-002',
  },
  {
    id: 'NOTIF-013',
    userId: 'Clem Demetz',
    title: 'Finance Review Complete',
    message: 'Gross-to-net calculations finalized for California Wildfires.',
    type: 'info',
    read: true,
    createdAt: '2024-10-30T14:00:00Z',
    taskId: 'TASK-013',
    eventId: 'EVT-2024-002',
  },
  {
    id: 'NOTIF-013b',
    userId: 'Andrew McBride',
    title: 'Event Closed: California Wildfires',
    message: 'California Wildfires has entered Reporting & Close phase.',
    type: 'workflow-advanced',
    read: true,
    createdAt: '2024-11-01T08:00:00Z',
    eventId: 'EVT-2024-002',
  },

  // ── European Windstorm Petra (EVT-2024-003) — Reopened ──
  {
    id: 'NOTIF-020',
    userId: 'Thomas Brennan',
    title: 'Re-Estimation Required',
    message: 'European Windstorm Petra has been reopened — please provide revised loss estimates.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-15T08:00:00Z',
    taskId: 'TASK-020',
    eventId: 'EVT-2024-003',
  },
  {
    id: 'NOTIF-021',
    userId: 'Neil Schwarzenberger',
    title: 'Model Update Required',
    message: 'Updated wind field data available for Petra — please refresh model output.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-15T08:30:00Z',
    taskId: 'TASK-021',
    eventId: 'EVT-2024-003',
  },
  {
    id: 'NOTIF-022',
    userId: 'Juan Delgado',
    title: 'Approval Pending',
    message: 'Once revised estimates for Windstorm Petra are submitted, your approval will be needed.',
    type: 'approval-required',
    read: false,
    createdAt: '2024-11-15T09:00:00Z',
    taskId: 'TASK-022',
    eventId: 'EVT-2024-003',
  },
  {
    id: 'NOTIF-022b',
    userId: 'Andrew McBride',
    title: 'Event Reopened: Windstorm Petra',
    message: 'European Windstorm Petra has been reopened for re-estimation.',
    type: 'workflow-advanced',
    read: false,
    createdAt: '2024-11-15T07:45:00Z',
    eventId: 'EVT-2024-003',
  },
  {
    id: 'NOTIF-022c',
    userId: 'Mike Cellura',
    title: 'Event Reopened: Windstorm Petra',
    message: 'Windstorm Petra has been sent back for re-estimation. Your approval will be required after.',
    type: 'workflow-advanced',
    read: false,
    createdAt: '2024-11-15T07:45:00Z',
    eventId: 'EVT-2024-003',
  },

  // ── Chile Earthquake (EVT-2024-012) — Phase 1 ──
  {
    id: 'NOTIF-030',
    userId: 'Andrew McBride',
    title: 'Contract Capture Required',
    message: 'Chile Earthquake — identify and capture all exposed contracts.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-20T08:00:00Z',
    taskId: 'TASK-030',
    eventId: 'EVT-2024-012',
  },
  {
    id: 'NOTIF-031',
    userId: 'Thomas Brennan',
    title: 'Estimation Assignment',
    message: 'You have been assigned to provide initial gross loss estimates for Chile Earthquake.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-22T08:00:00Z',
    taskId: 'TASK-031',
    eventId: 'EVT-2024-012',
  },
  {
    id: 'NOTIF-032',
    userId: 'Neil Schwarzenberger',
    title: 'Modeling Assignment',
    message: 'Run earthquake models for the Chile Maule Region event.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-22T08:30:00Z',
    taskId: 'TASK-032',
    eventId: 'EVT-2024-012',
  },

  // ── Texas Hailstorm (EVT-2024-005) ──
  {
    id: 'NOTIF-040',
    userId: 'Andrew McBride',
    title: 'Team Assignment Required',
    message: 'Assign underwriters with Texas exposure to the Texas Hailstorm event.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-19T10:00:00Z',
    taskId: 'TASK-040',
    eventId: 'EVT-2024-005',
  },
  {
    id: 'NOTIF-041',
    userId: 'Thomas Brennan',
    title: 'Estimation Assignment',
    message: 'You have been assigned to provide gross loss estimates for Texas Hailstorm.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-23T08:00:00Z',
    taskId: 'TASK-041',
    eventId: 'EVT-2024-005',
  },

  // ── Cyber Attack (EVT-2024-006) — Phase 0 ──
  {
    id: 'NOTIF-050',
    userId: 'David Chen',
    title: 'Event Created: Cyber Attack',
    message: 'Cyber Attack — Financial Services event has been created. Configure parameters.',
    type: 'task-assigned',
    read: false,
    createdAt: '2024-11-26T08:00:00Z',
    taskId: 'TASK-050',
    eventId: 'EVT-2024-006',
  },

  // ── Reader gets read-only status updates ──
  {
    id: 'NOTIF-R01',
    userId: 'Reena Boltax',
    title: 'Hurricane Milton — Finance Review',
    message: 'Hurricane Milton has entered Finance Review phase.',
    type: 'workflow-advanced',
    read: false,
    createdAt: '2024-11-04T08:15:00Z',
    eventId: 'EVT-2024-001',
  },
  {
    id: 'NOTIF-R02',
    userId: 'Reena Boltax',
    title: 'California Wildfires — Reporting & Close',
    message: 'California Wildfires has entered Reporting & Close phase.',
    type: 'workflow-advanced',
    read: true,
    createdAt: '2024-11-01T08:00:00Z',
    eventId: 'EVT-2024-002',
  },
  {
    id: 'NOTIF-R03',
    userId: 'Reena Boltax',
    title: 'Windstorm Petra — Reopened',
    message: 'European Windstorm Petra has been reopened for re-estimation.',
    type: 'workflow-advanced',
    read: false,
    createdAt: '2024-11-15T07:50:00Z',
    eventId: 'EVT-2024-003',
  },
];

export function TaskProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(seedTasks);
  const [notifications, setNotifications] = useState<Notification[]>(seedNotifications);

  const createTask = (taskData: Omit<Task, 'id' | 'assignedAt' | 'status'>): Task => {
    const newTask: Task = {
      ...taskData,
      id: `TASK-${Date.now()}`,
      assignedAt: new Date().toISOString(),
      status: 'pending',
    };

    setTasks((prev) => [...prev, newTask]);

    // Auto-create notification for assignee
    sendNotification({
      userId: newTask.assignedTo,
      title: 'New Task Assigned',
      message: newTask.title,
      type: 'task-assigned',
      taskId: newTask.id,
      eventId: newTask.eventId,
    });

    // Show toast notification
    toast.success(`Task assigned to ${newTask.assignedTo}`);

    return newTask;
  };

  const updateTaskStatus = (taskId: string, status: Task['status']) => {
    setTasks((prev) =>
      prev.map((task) => (task.id === taskId ? { ...task, status } : task))
    );
  };

  const completeTask = (taskId: string) => {
    const task = tasks.find((t) => t.id === taskId);
    updateTaskStatus(taskId, 'completed');
    
    if (task) {
      // Notify the assigner that task is complete
      sendNotification({
        userId: task.assignedBy,
        title: 'Task Completed',
        message: `${task.assignedTo} completed: ${task.title}`,
        type: 'info',
        taskId,
        eventId: task.eventId,
      });
      
      toast.success('Task marked as complete');
    }
  };

  const getTasksForUser = (userId: string): Task[] => {
    return tasks.filter((task) => task.assignedTo === userId);
  };

  const getNotificationsForUser = (userId: string): Notification[] => {
    return notifications
      .filter((notif) => notif.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  };

  const getNotificationsForEvent = (userId: string, eventId: string): Notification[] => {
    return notifications
      .filter((notif) => notif.userId === userId && notif.eventId === eventId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  };

  const markNotificationRead = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((notif) =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const sendNotification = (notifData: Omit<Notification, 'id' | 'createdAt' | 'read'>) => {
    const newNotification: Notification = {
      ...notifData,
      id: `NOTIF-${Date.now()}`,
      createdAt: new Date().toISOString(),
      read: false,
    };

    setNotifications((prev) => [newNotification, ...prev]);
  };

  const getUnreadCount = (userId: string): number => {
    return notifications.filter((notif) => notif.userId === userId && !notif.read).length;
  };

  const getUnreadCountForEvent = (userId: string, eventId: string): number => {
    return notifications.filter((notif) => notif.userId === userId && notif.eventId === eventId && !notif.read).length;
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        notifications,
        createTask,
        updateTaskStatus,
        completeTask,
        getTasksForUser,
        getNotificationsForUser,
        getNotificationsForEvent,
        markNotificationRead,
        sendNotification,
        getUnreadCount,
        getUnreadCountForEvent,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
}

const noopTask: Task = { id: '', eventId: '', eventName: '', title: '', description: '', assignedTo: '', assignedBy: '', assignedAt: '', dueDate: '', priority: 'low', status: 'pending', type: 'assignment' };

const fallbackContext: TaskContextType = {
  tasks: [],
  notifications: [],
  createTask: () => noopTask,
  updateTaskStatus: () => {},
  completeTask: () => {},
  getTasksForUser: () => [],
  getNotificationsForUser: () => [],
  getNotificationsForEvent: () => [],
  markNotificationRead: () => {},
  sendNotification: () => {},
  getUnreadCount: () => 0,
  getUnreadCountForEvent: () => 0,
};

export function useTasks() {
  const context = useContext(TaskContext);
  return context ?? fallbackContext;
}