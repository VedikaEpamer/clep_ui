import { createContext, useContext, useState, type ReactNode } from 'react';
import { mockEvents } from './mockData';

// ─── Shared CAT code list (used by EventIdentity, ClaimsEstimation, EventDetailsTab) ───
export const BACKEND_CAT_CODES = [
  { code: 'CAT-2024-US-001', label: 'CAT-2024-US-001 — Hurricane Milton (FL)' },
  { code: 'CAT-2024-US-002', label: 'CAT-2024-US-002 — Hurricane Helene (SE US)' },
  { code: 'CAT-2024-US-003', label: 'CAT-2024-US-003 — Texas Hailstorm' },
  { code: 'CAT-2024-US-004', label: 'CAT-2024-US-004 — California Wildfire' },
  { code: 'CAT-2024-US-005', label: 'CAT-2024-US-005 — Midwest Tornado Outbreak' },
  { code: 'CAT-2024-EU-001', label: 'CAT-2024-EU-001 — Storm Boris (Central EU)' },
  { code: 'CAT-2024-EU-002', label: 'CAT-2024-EU-002 — UK Flooding' },
  { code: 'CAT-2024-EU-003', label: 'CAT-2024-EU-003 — Spain Flash Floods' },
  { code: 'CAT-2024-JP-001', label: 'CAT-2024-JP-001 — Japan Earthquake (Noto)' },
  { code: 'CAT-2024-JP-002', label: 'CAT-2024-JP-002 — Typhoon Shanshan' },
  { code: 'CAT-2024-AU-001', label: 'CAT-2024-AU-001 — Australia Cyclone' },
  { code: 'CAT-2024-MX-001', label: 'CAT-2024-MX-001 — Mexico Earthquake' },
  { code: 'CAT-2024-CA-001', label: 'CAT-2024-CA-001 — Jasper Wildfire (Alberta)' },
  { code: 'CAT-2024-CL-001', label: 'CAT-2024-CL-001 — Chile Wildfire (Valparaiso)' },
  { code: 'CAT-2023-US-010', label: 'CAT-2023-US-010 — Hurricane Idalia' },
  { code: 'CAT-2023-TR-001', label: 'CAT-2023-TR-001 — Turkey Earthquake' },
  { code: 'CAT-2023-NZ-001', label: 'CAT-2023-NZ-001 — Cyclone Gabrielle' },
  { code: 'CAT-2023-LY-001', label: 'CAT-2023-LY-001 — Libya Flooding (Storm Daniel)' },
  { code: 'CAT-2023-MA-001', label: 'CAT-2023-MA-001 — Morocco Earthquake' },
];

// ─── Context ─────────────────────────────────────────────────────────────────
interface EventDataContextValue {
  getCatCode: (eventId: string) => string;
  setCatCode: (eventId: string, catCode: string) => void;
}

const EventDataContext = createContext<EventDataContextValue>({
  getCatCode: (id) => mockEvents.find(e => e.id === id)?.catCode || '',
  setCatCode: () => {},
});

export function EventDataProvider({ children }: { children: ReactNode }) {
  // overrides map: eventId → catCode (for real-time reactivity across tabs)
  const [overrides, setOverrides] = useState<Record<string, string>>({});

  const getCatCode = (eventId: string): string => {
    if (overrides[eventId] !== undefined) return overrides[eventId];
    return mockEvents.find(e => e.id === eventId)?.catCode || '';
  };

  const setCatCode = (eventId: string, catCode: string) => {
    // Persist to mock store so navigating away and back still reflects the value
    const ev = mockEvents.find(e => e.id === eventId);
    if (ev) ev.catCode = catCode;
    // Update context overrides for immediate reactivity in all mounted components
    setOverrides(prev => ({ ...prev, [eventId]: catCode }));
  };

  return (
    <EventDataContext.Provider value={{ getCatCode, setCatCode }}>
      {children}
    </EventDataContext.Provider>
  );
}

export function useEventData() {
  return useContext(EventDataContext);
}
