# SONAR Platform - Impact Regions & Perils Field Specification

**Module:** Impact Regions & Perils (ImpactRegionsPerils.tsx)
**Section:** Event Creation > Impact Regions & Perils Tab
**Component Location:** `/components/event-creation/ImpactRegionsPerils.tsx`
**Last Updated:** 2026-03-07

---

## Field Definitions

| Field Label | Field Type | Data Type | Field Length in characters | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Source | Notes, Conditions, Rules (Reset, Display, Validation, Error) | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Broader Risk Zone | Custom Dropdown (Multi-Select) | String[] | 3 per code; unlimited selections | RDM Country Code Hierarchy — Level 1 (X00 pattern codes: A00, C00, D00, E00, F00, I00, L00, M00, R00, S00, T00, U00, X00, Z00) | TRUE | FALSE | TRUE | Empty (no selection) | A00 - ASIA, U00 - UNITED STATES | Everest RDM Country Code Master | **Display:** Shows selected count badge when ≥1 selected; displays up to 2 labels inline, then "{n} selected" for 3+. Checkbox panel with Select All row. **Cascade-Down (BR-IRP.003):** "Select All" selects all 14 area codes AND auto-fills all child zones into Risk Zone AND all child countries into Main Risk Area. **Cascade-Down (BR-IRP.005):** "Clear All" clears all areas AND cascades to clear child zones and countries belonging to those areas. **Filter (BR-IRP.008):** When area(s) selected, Risk Zone dropdown filters to show only zones under selected areas; Main Risk Area filters to countries under selected areas. **Reset:** Master "Clear All" button resets this field to empty. **Validation:** No minimum required; field is not mandatory. **Error:** None. | 1.0 |
| Risk Zone | Custom Dropdown (Multi-Select) | String[] | 3 per code; unlimited selections | RDM Country Code Hierarchy — Level 2 (X_0 pattern codes where not X00, e.g. A10, A20, E10, E30, U10, U30, etc.) | TRUE | FALSE | TRUE | Empty (no selection) | A10 - NORTHEAST ASIA, U30 - SOUTHEASTERN STATES | Everest RDM Country Code Master | **Display:** Shows selected count badge when ≥1 selected; displays up to 2 labels inline, then "{n} selected" for 3+. Checkbox panel with Select All row. Includes search/filter input. **Options Filtering (BR-IRP.008):** If Broader Risk Zone has selections, only zones belonging to those areas are shown. If no areas selected, all zones across all areas are shown. **Cascade-Up (BR-IRP.002):** Selecting a zone auto-selects its parent Broader Risk Zone (e.g. selecting A10 auto-adds A00). **Cascade-Down (BR-IRP.004):** "Select All" selects all visible zone codes AND auto-fills all child countries into Main Risk Area. **Cascade-Down (BR-IRP.006):** "Clear All" clears all zones AND cascades to clear child countries belonging to those zones. **Filter (BR-IRP.009):** When zone(s) selected, Main Risk Area dropdown filters to show only countries under selected zones. **Reset:** Master "Clear All" button resets this field to empty. **Validation:** No minimum required. **Error:** None. | 1.0 |
| Main Risk Area | Custom Dropdown (Multi-Select) | String[] | 3 per code; unlimited selections | RDM Country Code Hierarchy — Level 3 (All non-X00, non-X_0 codes, e.g. A11, E57, U32, L4H, etc.) | TRUE | TRUE | TRUE | Empty (no selection) | U32 - FLORIDA, A13 - JAPAN, E57 - UNITED KINGDOM | Everest RDM Country Code Master | **Display:** Shows selected count badge when ≥1 selected; displays up to 2 labels inline, then "{n} selected" for 3+. Checkbox panel with Select All row. Includes search/filter input (searches code, label, and word initials). **Options Filtering (BR-IRP.009):** If Risk Zone has selections, only countries under those zones are shown. Else if Broader Risk Zone has selections, only countries under those areas are shown (BR-IRP.008). If neither selected, all countries across all areas are shown (BR-IRP.010). **Cascade-Up (BR-IRP.001):** Selecting a country auto-selects its parent Risk Zone (if exists) + parent Broader Risk Zone + W00 in Worldwide dropdown. **Cascade-Down:** None (leaf level). **Reset:** Master "Clear All" button resets this field to empty. **Validation:** At least 1 country must be selected (field is mandatory). **Error:** "At least one impacted region must be selected" if empty on form submission. | 1.0 |
| Worldwide | Custom Dropdown (Multi-Select) | String[] | 3 per code; max 4 selections | RDM Country Code Hierarchy — Level 0 (W-prefix codes: W00 - WORLDWIDE, W01 - WORLDWIDE EX NORTH AMER, W02 - WORLDWIDE EX US & CANADA, W03 - WORLDWIDE EX US) | TRUE | FALSE | TRUE | Empty (no selection) | W00 - WORLDWIDE | Everest RDM Country Code Master | **Display:** Shows selected count badge when ≥1 selected; displays up to 2 labels inline, then "{n} selected" for 3+. Checkbox panel with Select All row. **Auto-Add (BR-IRP.001):** W00 is automatically added when any country is selected in Main Risk Area. W00 can be freely deselected afterward — no protection/lock. **No Cascade:** Selecting/deselecting Worldwide codes does not affect other dropdowns. **Scope Qualifiers:** W01/W02/W03 are scope qualifiers for treaty/program classification — manually selected only, never auto-added. **Reset:** Master "Clear All" button resets this field to empty. **Validation:** No minimum required; field is not mandatory. **Error:** None. | 1.0 |

---

## Supporting UI Elements

| Field Label | Field Type | Data Type | Field Length in characters | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Source | Notes, Conditions, Rules (Reset, Display, Validation, Error) | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Selected Count Label | Read-Only Label | String | Variable | N/A | FALSE | N/A | TRUE | "0 locations selected" | "12 locations selected" | Computed (sum of all selected codes across all 4 dropdowns) | **Display:** Shows "{n} location(s) selected" in the card header. Automatically updates as selections change across any dropdown. Pluralizes "location" vs "locations". **Reset:** Resets to "0 locations selected" on Clear All. | 1.0 |
| Clear All Button | Action Button | N/A | N/A | N/A | TRUE | N/A | Conditional | N/A | N/A | N/A | **Visibility:** Only visible when selectedItems.length > 0 (at least 1 code selected across any dropdown). **Action (BR-IRP.007):** Clears all 4 dropdown states (selectedCountries, selectedZones, selectedAreas, selectedWorldwides) and resets master selectedItems to empty. **Styling:** Red outline button with Trash2 icon. | 1.0 |
| Helper Text | Read-Only Label | String | Static | N/A | FALSE | N/A | TRUE | Static text | N/A | Static | **Display:** "Start with Broader Risk Zone to filter Risk Zones and Main Risk Areas top-down. Or select countries directly in Main Risk Area — parent zones and areas auto-fill upward. All dropdowns support multi-select with Select All." Always visible below the dropdown grid. | 1.0 |

---

## Search/Filter Behavior (Risk Zone & Main Risk Area dropdowns)

| Feature | Behavior |
|---|---|
| Search Input | Text input with Search icon; auto-focuses when dropdown opens |
| Match Logic | Matches against: (1) code (case-insensitive contains), (2) label (case-insensitive contains), (3) word initials (e.g. "NE" matches "NEW ENGLAND"), (4) word-start for queries ≤3 chars |
| Select All with Search | When search is active, "Select All" only affects filtered/visible items |
| Clear All with Search | When search is active, individual deselection; when no search, bulk clear via onClearAll handler |
| No Results | Displays "No matches found" centered text |
| Close Behavior | Closes on click outside (mousedown event listener); resets search text on close |

---

## Data Flow

```
User Action                          System Response
─────────────────────────────────────────────────────────────────
Select Country (Main Risk Area)  →   Auto-add parent Zone (Risk Zone)
                                 →   Auto-add parent Area (Broader Risk Zone)  
                                 →   Auto-add W00 (Worldwide)
                                 →   Update selectedItems master list
                                 →   Fire onChange({ impactedCountries: [...] })

Select Zone (Risk Zone)          →   Auto-add parent Area (Broader Risk Zone)
                                 →   Update selectedItems master list
                                 →   Fire onChange({ impactedCountries: [...] })

Select Area (Broader Risk Zone)  →   Update selectedItems master list
                                 →   Filter Risk Zone options to children
                                 →   Filter Main Risk Area options to children
                                 →   Fire onChange({ impactedCountries: [...] })

Select All (Broader Risk Zone)   →   Select all 14 area codes
                                 →   Cascade: select all child zones
                                 →   Cascade: select all child countries
                                 →   Auto-add W00
                                 →   Fire onChange({ impactedCountries: [...] })

Clear All (Master Button)        →   Reset selectedCountries = []
                                 →   Reset selectedZones = []
                                 →   Reset selectedAreas = []
                                 →   Reset selectedWorldwides = []
                                 →   Reset selectedItems = []
                                 →   Fire onChange({ impactedCountries: [] })
```

---

## Output Format

The component outputs data via `onChange({ impactedCountries: string[] })` where each entry is formatted as:

```
"{CODE}-{LABEL}"
```

**Examples:**
- `"U32-FLORIDA"`
- `"A00-ASIA"`
- `"W00-WORLDWIDE"`
- `"E57-UNITED KINGDOM"`

This array includes ALL selected codes across all 4 dropdowns (areas + zones + countries + worldwide qualifiers) merged into a single flat list.
