# S3.7 - Event Detail: Claims Estimation

**Screen:** Claims Estimation
**File:** `/components/event-detail/ClaimsEstimation.tsx`
**Route:** `/events/:eventId/claims`
**Description:** Claims tracking table comparing estimated losses to actual claims with variance analysis, claim counts, and settlement status per contract.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.7.1 | 1.0 | Header | Claims Estimation | Page Title | — | — | — | — | No | — | Always | — | "Claims Estimation" | Page header with event name. | R1 |
| S3.7.2 | 1.0 | Claims Table | Contract ID | Column | String | 20 | contractId | — | No | — | Always | — | "PROP-2024-0847" | Contract identifier. | R1 |
| S3.7.3 | 1.0 | Claims Table | Cedent | Column | String | 30 | cedent | — | No | — | Always | — | "State Farm" | Cedent name. | R1 |
| S3.7.4 | 1.0 | Claims Table | Business Unit | Column | String | 20 | bu | — | No | — | Always | — | "US Property" | Business unit assignment. | R1 |
| S3.7.5 | 1.0 | Claims Table | Estimated Loss | Column | Currency | 15 | estimatedLoss | — | No | — | Always | — | "$12,400,000" | Original UW loss estimate. | R1 |
| S3.7.6 | 1.0 | Claims Table | Actual Claims | Column | Currency | 15 | actualClaims | — | No | — | Always | — | "$11,800,000" | Actual claims reported. | R1 |
| S3.7.7 | 1.0 | Claims Table | Variance ($) | Column | Currency | 15 | variance | — | No | — | Always | — | "-$600,000" | actualClaims - estimatedLoss. Red if positive (over), green if negative (under). | R1 |
| S3.7.8 | 1.0 | Claims Table | Variance (%) | Column | Percentage | 8 | variancePercent | — | No | — | Always | — | "-4.8%" | Percentage variance. Color-coded. | R1 |
| S3.7.9 | 1.0 | Claims Table | Claims Count | Column | Number | 6 | claimsCount | — | No | — | Always | — | "847" | Number of individual claims. | R1 |
| S3.7.10 | 1.0 | Claims Table | Status | Column / Badge | Enum | — | status | Status Typelist | No | — | Always | — | "Settled" | Settlement status badge. | R1 |
| S3.7.11 | 1.0 | Claims Table | Last Updated | Column | Date | 10 | lastUpdated | — | No | — | Always | — | "2024-12-15" | Last update timestamp. | R1 |

### Status Typelist
| Value | Style |
|---|---|
| Settled | bg-green-100 text-green-700 |
| In Progress | bg-amber-100 text-amber-700 |

### Business Rules
- **BR-S3.7.01:** Variance = actualClaims - estimatedLoss.
- **BR-S3.7.02:** Positive variance (over-estimate by cedent / under-estimate by UW) shown in red.
- **BR-S3.7.03:** Negative variance (under actual vs estimate) shown in green.
