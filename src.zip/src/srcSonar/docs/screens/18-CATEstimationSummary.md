# S3.3 - Event Detail: CAT Estimation Summary

**Screen:** CAT Estimation Summary
**File:** `/components/event-detail/CATEstimationSummary.tsx`
**Route:** Embedded in Event Overview (Summary tab)
**Description:** Multi-method CAT loss estimation summary with 5 column groups (Gross, Net of Logan, Ex Reinst, Net of Logan Ex, Net Loss), 3 estimation methods (Market Share, AIR Model, UW Ground-Up), consensus row, booked row, and method-level comments.

## Column Groups (5 x Low/Best/High = 15 cells per row)

| Group | Columns | Derivation |
|---|---|---|
| Gross | Low, Best, High | Base input (editable for consensus) |
| Net of Logan | Low, Best, High | Gross x LOGAN_RETENTION (0.85) |
| Ex Reinst (Reinstatement) | Low, Best, High | Direct input |
| Net of Logan Ex | Low, Best, High | Net of Logan x EXTERNAL_RECOV_RATE (0.92) |
| Net Loss | Low, Best, High | Net of Logan Ex - Reinstatement |

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.3.1 | 1.0 | Header Actions | Save Draft | Button | — | — | — | — | Yes | — | Always | — | — | Saves current estimation state. | R1 |
| S3.3.2 | 1.0 | Header Actions | Lock / Unlock Estimates | Toggle Button | Boolean | — | isLocked | — | Conditional | — | Role-based | false | — | Locks all editable cells. | R1 |
| S3.3.3 | 1.0 | Header Actions | Download | Dropdown | — | — | — | Format Typelist | Yes | — | Always | — | — | PDF, CSV, Excel export. | R1 |
| S3.3.4 | 1.0 | Header Actions | Add Comment | Button | — | — | — | — | Yes | — | Always | — | — | Opens comment form. | R1 |
| S3.3.5 | 1.0 | Method 1 | Market Share Applied | Collapsible Section | — | — | — | — | No | — | Always | Collapsed | — | Calculated: Industry Loss x RE Market Share %. Shows Low/Best/High for each column group. | R1 |
| S3.3.6 | 1.0 | Method 1 | RE Market Share % | Calculated Display | Decimal | — | — | — | No | — | Always | — | "3.2%" | Auto-calculated: Total Modeling / Industry Estimate. | R1 |
| S3.3.7 | 1.0 | Method 1 | Reinstatement Low/High | Currency Input | Decimal | 15 | reinstatementLow/High | — | Yes | No | Always | 0 | "1.5" | Editable reinstatement inputs for Market Share method. | R1 |
| S3.3.8 | 1.0 | Method 2 | AIR Model | Collapsible Section | — | — | — | — | No | — | Always | Collapsed | — | Contains 100% and 60% rows with modeling estimates. | R1 |
| S3.3.9 | 1.0 | Method 3 | UW Ground-Up | Collapsible Section | — | — | — | — | No | — | Always | Collapsed | — | Contains expandable departments: Intl Fac, Intl Treaty, NA Fac, NA Treaty, Specialty, Financial Lines. Each with sub-BU rows. | R1 |
| S3.3.10 | 1.0 | UW Ground-Up | Modeling Estimates | Currency Input | Decimal | 15 | lossLow/High, reinstLow/High | — | Yes | No | Per BU row | 0 | "42" | Editable per-BU modeling loss and reinstatement values. | R1 |
| S3.3.11 | 1.0 | UW Ground-Up | UW Estimates | Currency Input | Decimal | 15 | lossLow/High | — | Yes | No | Per BU row | 0 | "50" | Editable per-BU underwriting estimates. | R1 |
| S3.3.12 | 1.0 | Other | Salvage & Subrogation | Display Row | — | — | — | — | No | — | Always | — | "-4.0 / -6.0" | Negative adjustments. Gross & Net of Logan columns = 0 (blank). | R1 |
| S3.3.13 | 1.0 | Other | Reserve Adjustments | Display Row | — | — | — | — | No | — | Always | — | "-2.2 / -3.0" | Negative adjustments. | R1 |
| S3.3.14 | 1.0 | Other | Other Recoveries | Display Row | — | — | — | — | No | — | Always | — | "-2.5 / -3.5" | Negative adjustments. | R1 |
| S3.3.15 | 1.0 | Summary | Total Modeling | Calculated Row | — | — | — | — | No | — | Always | — | — | Sum of all modeling BU estimates. Bold subtotal row. | R1 |
| S3.3.16 | 1.0 | Summary | Total UW | Calculated Row | — | — | — | — | No | — | Always | — | — | Sum of all UW BU estimates. Bold subtotal row. | R1 |
| S3.3.17 | 1.0 | Summary | Consensus | Inline-Editable Row | Decimal | 15 | consensus.* | — | Yes | No | Always | Derived from event | "8,000" | Click-to-edit cells for all 15 values. Blue highlight row. Auto-derived initially from event gross/reinst inputs. | R1 |
| S3.3.18 | 1.0 | Summary | Booked | Inline-Editable Row | Decimal | 15 | booked.* | — | Yes | No | Always | Pre-set | "345" | Click-to-edit cells. Green highlight row. Pre-populated with initial booked values. | R1 |
| S3.3.19 | 1.0 | RE Market Share | Market Share Row | Calculated Row | Decimal | — | — | — | No | — | Always | — | "3.2%" | RE Market Share % = Total Modeling / Industry Estimate per column group. | R1 |
| S3.3.20 | 1.0 | Method Comments | Method Notes | Textarea | String | 5000 | notes.* | — | Yes | No | Per method | "" | "Based on Dream Re's historical market share..." | Per-method notes textarea. | R1 |
| S3.3.21 | 1.0 | Method Comments | Comment Thread | List | — | — | methodComments.* | — | Yes | No | Per method | [] | — | Threaded comments with author, date, optional file attachments. | R1 |
| S3.3.22 | 1.0 | Method Comments | File Attachments | File Input | File | — | attachedFiles.* | — | Yes | No | Per method | [] | — | Attach files to comments per method. | R1 |

### BU Rows in UW Ground-Up (Modeling & UW Estimates)
| Department Group | Sub-BUs |
|---|---|
| Facultative (International) | Latin America Fac, London Fac, Singapore Fac |
| International Treaty | Dublin/Zurich, LATAM/Brazil Treaty, London Treaty, ME/Africa, Singapore Treaty |
| Facultative (North America) | Bermuda Fac, Canada Fac, FAC Casualty, FAC Property |
| North America Treaty | Bermuda Treaty, Canada Treaty, Treaty Casualty, Treaty Property |
| Specialty | Aviation, Parametric, Marine |
| Financial Lines | Surety |

### Known Issues (Stale References)
- `engineering`, `cyber`, `renewableEnergy`, `mortgage` still present in modelingEstimates and uwEstimates state — these BUs were removed and should show 0/blank or be removed entirely.
- **Ground-up numbers should NOT show values in "Net of Logan", "Ex Reinst", and "Net of Logan Ex" columns (should be blank).**

### Constants
| Constant | Value | Description |
|---|---|---|
| LOGAN_RETENTION | 0.85 | Mount Logan sidecar retention rate |
| EXTERNAL_RECOV_RATE | 0.92 | External recovery/cession rate |

### Business Rules
- **BR-S3.3.01:** Gross -> Net of Logan = Gross x 0.85.
- **BR-S3.3.02:** Net of Logan -> Net of Logan Ex = Net of Logan x 0.92.
- **BR-S3.3.03:** Net Loss = Net of Logan Ex - Reinstatement.
- **BR-S3.3.04:** Best = (Low + High) / 2 for all auto-calculated rows.
- **BR-S3.3.05:** Consensus row is inline-editable (click cell to enter edit mode).
- **BR-S3.3.06:** Booked row is inline-editable with pre-populated values.
- **BR-S3.3.07:** Total Modeling and Total UW are auto-summed from all BU rows.
- **BR-S3.3.08:** RE Market Share % = Total Modeling / Industry Estimate per column.
- **BR-S3.3.09 (Pending):** Ground-up UW rows should blank out Net of Logan, Ex Reinst, and Net of Logan Ex columns.
