# S7 - SailPoint Access Request Form

**Screen:** SailPoint Access Request
**File:** `/components/SailPointAccessForm.tsx`
**Route:** `/access-request`
**Description:** Self-service access request form for SONAR platform. Users request roles, specify executive area and business unit, with automated SailPoint ticket generation.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S7.1 | 1.0 | Requestor Info | Full Name | Text Input | String | 100 | fullName | — | Yes | Yes | Always | "" | "John Smith" | Required. | R1 |
| S7.2 | 1.0 | Requestor Info | Email | Email Input | String | 100 | email | — | Yes | Yes | Always | "" | "john.smith@everest.com" | Required. Email format validation. | R1 |
| S7.3 | 1.0 | Requestor Info | Employee ID | Text Input | String | 20 | employeeId | — | Yes | Yes | Always | "" | "EMP-12345" | Required. | R1 |
| S7.4 | 1.0 | Access Details | Requested Role | Dropdown | String | 30 | requestedRole | Role Typelist | Yes | Yes | Always | "" | "UW Contributor" | Required. Filters available executive areas and business units. | R1 |
| S7.5 | 1.0 | Access Details | Executive Area | Dropdown | String | 30 | executiveArea | Exec Area Typelist | Yes | Yes | Always | "" | "International Treaty" | Required. Options filtered by selected role. | R1 |
| S7.6 | 1.0 | Access Details | Business Unit | Dropdown | String | 30 | businessUnit | BU Typelist | Yes | Yes | Always | "" | "London" | Required. Options filtered by selected executive area. | R1 |
| S7.7 | 1.0 | Access Details | Justification | Textarea | String | 2000 | justification | — | Yes | Yes | Always | "" | "Need access to review London portfolio..." | Required. Business justification for access. | R1 |
| S7.8 | 1.0 | Access Details | Manager Approval | Text Input | String | 100 | managerName | — | Yes | Yes | Always | "" | "Sarah Mitchell" | Required. Name of approving manager. | R1 |
| S7.9 | 1.0 | Actions | Submit Request | Button | — | — | — | — | Yes | — | Always | — | — | Validates all required fields, generates SailPoint ticket. | R1 |
| S7.10 | 1.0 | Actions | Cancel | Button | — | — | — | — | Yes | — | Always | — | — | Clears form. | R1 |

### Business Rules
- **BR-S7.01:** Executive Area options are filtered based on the selected Role.
- **BR-S7.02:** Business Unit options are filtered based on the selected Executive Area.
- **BR-S7.03:** Removed business units (Renewable Energy, Mortgage, Engineering, Cyber) should not appear in dropdowns.
- **BR-S7.04:** All fields are required for submission.
