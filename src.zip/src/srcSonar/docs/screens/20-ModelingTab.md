# S3.6 - Event Detail: Modeling Tab

**Screen:** Modeling Tab (CAT Model Scenarios)
**File:** `/components/event-detail/ModelingTab.tsx`
**Route:** Embedded in Event Overview (Modeling tab)
**Description:** Displays CAT model scenario results with department-level breakdowns across multiple event IDs. Static scenario data with expandable department rows showing sub-type breakdowns (CAT, PR, RSK).

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.6.1 | 1.0 | Scenario Header | Scenario Table | Static Table | — | — | SCENARIOS | — | No | — | Always | — | — | 3 scenarios with Event ID, Max Wind, Location, Industry Loss, Gross, Gross Share%, Net, Net Share%. | R1 |
| S3.6.2 | 1.0 | Scenario Row | Event ID | Display | String | 10 | eventId | — | No | — | Always | — | "270184630" | AIR/RMS event identifier. | R1 |
| S3.6.3 | 1.0 | Scenario Row | Max Wind (mph) | Display | Decimal | 8 | maxWind | — | No | — | Always | — | "119.8" | Maximum wind speed. | R1 |
| S3.6.4 | 1.0 | Scenario Row | Location | Display | String | 30 | location | — | No | — | Always | — | "Manatee, FL" | Landfall or impact location. | R1 |
| S3.6.5 | 1.0 | Scenario Row | Industry Loss ($M) | Display | Currency | 15 | industryLoss | — | No | — | Always | — | "18,411" | Industry-wide loss in millions. | R1 |
| S3.6.6 | 1.0 | Scenario Row | Gross ($M) | Display | Currency | 15 | gross | — | No | — | Always | — | "437.8" | Everest gross loss. | R1 |
| S3.6.7 | 1.0 | Scenario Row | Gross Share % | Display | Percentage | 5 | grossShare | — | No | — | Always | — | "2.4%" | Gross / Industry. | R1 |
| S3.6.8 | 1.0 | Scenario Row | Net ($M) | Display | Currency | 15 | net | — | No | — | Always | — | "304.6" | Everest net loss. | R1 |
| S3.6.9 | 1.0 | Scenario Row | Net Share % | Display | Percentage | 5 | netShare | — | No | — | Always | — | "1.7%" | Net / Industry. | R1 |
| S3.6.10 | 1.0 | Department Table | Department Rows | Expandable Table | — | — | DEPARTMENT_DATA | — | No | — | Always | — | — | Departments: Bermuda, Canada, Dublin, EI Recovery, FP, etc. Each shows totals per event scenario. | R1 |
| S3.6.11 | 1.0 | Department Table | Sub-Type Rows | Child Rows | — | — | subRows | — | No | — | When expanded | — | — | Sub-types: CAT, PR, RSK. Values per event scenario (null = blank). | R1 |

### Departments
Bermuda, Canada, Dublin, EI Recovery^, FP, FC, FS, Group Re London, IB, Insurance, IP, IT, LP, PT, SP, US Property, US Specialty

### Business Rules
- **BR-S3.6.01:** All data is read-only / static scenario output from CAT model runs.
- **BR-S3.6.02:** Department rows expand to show sub-type breakdown (CAT/PR/RSK).
- **BR-S3.6.03:** Null values in sub-rows render as blank cells.
- **BR-S3.6.04:** Column headers show Event IDs from SCENARIOS array.
