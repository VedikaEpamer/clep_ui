# S6 - Workflow Tracker

**Screen:** Workflow Tracker (embedded component)
**File:** `/components/WorkflowTracker.tsx`
**Context File:** `/lib/workflowContext.tsx`
**Description:** Visual workflow progress tracker showing the 4-phase linear workflow with step status indicators. Supports "Reopened" status with visual banner.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S6.1 | 1.0 | Header | Workflow Progress | Label | — | — | — | — | No | — | Always | — | "Workflow Progress" | Section title. | R1 |
| S6.2 | 1.0 | Header | Current Phase | Display | String | 50 | currentPhase | Phase Typelist | No | — | Always | — | "Phase 1: UW Estimation" | Blue text for normal phases, red text for "Reopened". | R1 |
| S6.3 | 1.0 | Reopened Banner | Reopened Indicator | Alert Banner | — | — | isReopened | — | No | — | Conditional | — | — | Red-50 banner with RotateCcw icon. Shown when event has been reopened. Text: "This event has been reopened and returned to the estimation workflow." | R1 |
| S6.4 | 1.0 | Step List | Phase Step | Visual Step | — | — | phase | Phase Typelist | No | — | Always | — | — | Each step shows: icon (CheckCircle2 = completed, Clock = in-progress, Circle = not-started), phase name, assigned-to, due date, completed info. Connected by vertical line. | R1 |
| S6.5 | 1.0 | Step List | Step Status | Icon + Color | Enum | — | status | Step Status Typelist | No | — | Always | — | "completed" | Green check = completed, blue clock = in-progress, gray circle = not-started. | R1 |
| S6.6 | 1.0 | Step List | Assigned To | Display | String | 50 | assignedTo | — | No | — | Conditional | — | "UW & CAT Teams" | Shown for in-progress and not-started steps. | R1 |
| S6.7 | 1.0 | Step List | Due Date | Display | Date | 10 | dueDate | — | No | — | Conditional | — | "2024-12-20" | Shown for steps with due dates. | R1 |
| S6.8 | 1.0 | Step List | Completed By | Display | String | 50 | completedBy | — | No | — | Conditional | — | "System" | Shown for completed steps. | R1 |
| S6.9 | 1.0 | Step List | Completed At | Display | DateTime | 20 | completedAt | — | No | — | Conditional | — | "2024-10-10T14:30:00Z" | Shown for completed steps. | R1 |

### Phase Typelist (4 phases + Reopened)
| Phase | Step Order | Default Assignee |
|---|---|---|
| Phase 0: Event Creation | 1 | System |
| Phase 1: UW Estimation | 2 | UW & CAT Teams |
| Phase 2: Finance/Management Review | 3 | Finance & Management |
| Phase 3: Reporting & Close | 4 | Finance & Operations |
| Reopened | Special | — |

### Step Status Typelist
| Value | Icon | Color |
|---|---|---|
| completed | CheckCircle2 | Green (text-green-500) |
| in-progress | Clock | Blue (text-blue-500) |
| not-started | Circle | Gray (text-gray-300) |

### Workflow State Machine
```
Phase 0 → Phase 1 → Phase 2 → Phase 3 → [Closed]
                                    ↓
                                Reopened → Phase 1 (re-enters estimation)
```

### Business Rules
- **BR-S6.01:** `advancePhase()` moves from current phase to next sequential phase, marking current as completed.
- **BR-S6.02:** `reopenEvent()` sets currentPhase to "Reopened" and sets isReopened flag.
- **BR-S6.03:** When advancing from "Reopened", workflow returns to Phase 1 and resets Phase 2 & 3 to not-started.
- **BR-S6.04:** Completed steps show completedBy and completedAt timestamp.
- **BR-S6.05:** Vertical connector line between steps shows green for completed segments, gray for remaining.

### Mock Event Phase Assignments
| Event ID | Phase |
|---|---|
| EVT-2024-006 | Phase 0: Event Creation |
| EVT-2024-005, EVT-2024-012 | Phase 1: UW Estimation |
| EVT-2024-008, EVT-2024-007 | Phase 1: UW Estimation |
| EVT-2024-001, EVT-2024-003 | Phase 2: Finance/Management Review |
| EVT-2024-002, EVT-2024-004 | Phase 3: Reporting & Close |