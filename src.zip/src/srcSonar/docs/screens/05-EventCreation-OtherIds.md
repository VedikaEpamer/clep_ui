# S2.4 - Event Creation: Other IDs

**Screen:** Event Creation - Step 4
**File:** `/components/event-creation/OtherIds.tsx`
**Route:** `/create-event` (section 4)
**Description:** Associate external catastrophe identifiers with the event, ensuring alignment with industry sources, third-party reporting systems, and downstream financial/actuarial workflows.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.4.1 | 1.0 | Other IDs | External Source | Custom Dropdown | String | 30 | name | External Source Typelist | Yes | No | Per row | "" | "PCS Event ID" | Custom dropdown component (opens downward). When "Custom" selected, switches to text input for custom source name with "Back" button. Known issue: z-index on "Custom" option may be cut off (pending fix). | R1 |
| S2.4.2 | 1.0 | Other IDs | Custom Source Name | Text Input | String | 50 | customName | — | Yes | Conditional | When source="Custom" | "" | "Lloyd's Event ID" | Shown only when External Source = "Custom". Auto-focuses. Has "Back" button to return to dropdown. | R1 |
| S2.4.3 | 1.0 | Other IDs | Event ID | Text Input | String | 50 | value | — | Yes | No | Per row | "" | "PCS-2024-1234" | Free-text external event identifier. Placeholder: "Enter external event ID" | R1 |
| S2.4.4 | 1.0 | Other IDs | Add External Event ID | Button (dashed) | — | — | — | — | Yes | — | Always | — | — | Full-width dashed border button. Adds new empty identifier row. | R1 |
| S2.4.5 | 1.0 | Other IDs | Remove Row | Button (icon) | — | — | — | — | Yes | — | Per row | — | — | Red trash icon. Removes the identifier row. | R1 |
| S2.4.6 | 1.0 | Other IDs | External IDs Summary | Display Panel | — | — | — | — | No | — | When >= 1 valid entry | — | — | Blue info panel showing source name -> value pairs. Only shows entries where both name and value are filled. | R1 |
| S2.4.7 | 1.0 | Other IDs | Empty State | Display | — | — | — | — | No | — | When 0 entries | — | — | Gray centered text: "No external event IDs added yet." with helper text. | R1 |

### External Source Typelist
| Value | Label |
|---|---|
| PCS Event ID | PCS Event ID |
| NOAA Event ID | NOAA Event ID |
| Swiss Re Event ID | Swiss Re Event ID |
| Munich Re Event ID | Munich Re Event ID |
| AIR Event ID | AIR Event ID |
| RMS Event ID | RMS Event ID |
| Insurance Event ID | Insurance Event ID |
| Claim Group ID from SICs | Claim Group ID from SICs |
| Custom | Custom |

### Business Rules
- **BR-S2.4.01:** External IDs are optional but support industry reconciliation and reporting.
- **BR-S2.4.02:** When "Custom" is selected, field switches to free-text input with a "Back" button to return to dropdown.
- **BR-S2.4.03:** Summary panel only displays entries where both source name and value are populated.
- **BR-S2.4.04 (Known Issue):** The "Custom" dropdown option may be visually cut off due to z-index issue (pending fix).
