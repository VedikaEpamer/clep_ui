# S5.5 - Administration: Organization Hierarchy

**Screen:** Organization Hierarchy (Info Panel)
**File:** `/components/admin/OrganizationHierarchy.tsx`
**Route:** Embedded in Admin screens
**Description:** Read-only informational panel showing the cascading organizational hierarchy used for task routing and assignment. 4-tier structure: Executive Management -> Executive Areas -> Business Units -> Underwriters.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.5.1 | 1.0 | Header | Organizational Hierarchy & Roles | Display | — | — | — | — | No | — | Always | — | — | Blue info panel with Users icon. | R1 |
| S5.5.2 | 1.0 | Tier 1 | Executive Management | Card | — | — | — | — | No | — | Always | — | — | CEO, CUO, CFO. Role: Executive Viewer. Purple badge. Read-only access, notifications only. | R1 |
| S5.5.3 | 1.0 | Tier 2 | Executive Areas | Card | — | — | — | — | No | — | Always | — | — | Phase 1 Coordinators. Role: Event Coordinator. Blue badge. Auto-assigned on event creation. | R1 |
| S5.5.4 | 1.0 | Tier 3 | Business Units | Card | — | — | — | — | No | — | Always | — | — | Regional Heads. Role: UW Lead. Green badge. Assigned by Event Coordinators. | R1 |
| S5.5.5 | 1.0 | Tier 4 | Underwriters | Card | — | — | — | — | No | — | Always | — | — | Individual Contributors. Role: UW Contributor. Amber badge. Assigned by BU Leads. | R1 |
| S5.5.6 | 1.0 | Connectors | Hierarchy Arrows | Visual | — | — | — | — | No | — | Always | — | — | Downward chevron arrows between tiers. | R1 |

### Business Rules
- **BR-S5.5.01:** This is a read-only informational panel — no editable fields.
- **BR-S5.5.02:** Hierarchy reflects the SONAR cascading assignment model for routing rules.
