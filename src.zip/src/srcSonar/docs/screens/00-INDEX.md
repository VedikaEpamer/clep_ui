# SONAR Platform - Functional Requirements Document (FRD) Index

**Platform:** SONAR (Cat and Large Event Platform)
**Client:** Everest Re
**Last Updated:** March 7, 2026
**Total Screens Documented:** 31

---

## Screen Inventory

### Event Dashboard
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 01 | [01-EventDashboard.md](01-EventDashboard.md) | S1 | Event Dashboard | `EventDashboard.tsx` | `/` |

### Event Creation Wizard
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 16 | [16-EventCreation-Wizard.md](16-EventCreation-Wizard.md) | S2 | Event Creation Wizard (Container) | `EventCreation.tsx` | `/events/new` |
| 02 | [02-EventCreation-EventIdentity.md](02-EventCreation-EventIdentity.md) | S2.1 | Event Identity & Core Metadata | `event-creation/EventIdentity.tsx` | Step 1 |
| 03 | [03-EventCreation-ImpactRegionsPerils.md](03-EventCreation-ImpactRegionsPerils.md) | S2.2 | Impact Regions & Perils | `event-creation/ImpactRegionsPerils.tsx` | Step 2 |
| 05 | [05-EventCreation-OtherIds.md](05-EventCreation-OtherIds.md) | S2.4 | Other IDs | `event-creation/OtherIds.tsx` | Step 3 |
| 04 | [04-EventCreation-MarketLoss.md](04-EventCreation-MarketLoss.md) | S2.3 | Market Loss & Consensus | `event-creation/MarketLoss.tsx` | Step 4 |
| 06 | [06-EventCreation-DeadlinesTracking.md](06-EventCreation-DeadlinesTracking.md) | S2.5 | Deadlines & Tracking | `event-creation/DeadlinesTracking.tsx` | Step 5 |
| 07 | [07-EventCreation-Participants.md](07-EventCreation-Participants.md) | S2.6 | Event Notification Recipients | `event-creation/EventParticipantsSection.tsx` | Step 6 |

### Event Detail Screens
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 17 | [17-EventOverview.md](17-EventOverview.md) | S3.0 | Event Overview (Hub) | `event-detail/EventOverview-NEW.tsx` | `/events/:id/overview` |
| 14 | [14-EventDetail-EventDetailsTab.md](14-EventDetail-EventDetailsTab.md) | S3.1 | Event Details Tab | `event-detail/EventDetailsTab.tsx` | `/events/:id` |
| 08 | [08-EventDetail-ContractCapture.md](08-EventDetail-ContractCapture.md) | S3.2 | Contract Capture / Exposure | `event-detail/ContractCapture.tsx` | `/events/:id/contracts` |
| 18 | [18-CATEstimationSummary.md](18-CATEstimationSummary.md) | S3.3 | CAT Estimation Summary | `event-detail/CATEstimationSummary.tsx` | Embedded |
| 09 | [09-EventDetail-FinanceEstimation.md](09-EventDetail-FinanceEstimation.md) | S3.4 | Finance Estimation | `event-detail/FinanceEstimation.tsx` | `/events/:id/finance` |
| 19 | [19-ExecutiveSummary.md](19-ExecutiveSummary.md) | S3.5 | Executive Summary | `event-detail/ExecutiveSummary.tsx` | Embedded (Executive tab) |
| 20 | [20-ModelingTab.md](20-ModelingTab.md) | S3.6 | Modeling Tab (CAT Scenarios) | `event-detail/ModelingTab.tsx` | Embedded (Modeling tab) |
| 21 | [21-ClaimsEstimation.md](21-ClaimsEstimation.md) | S3.7 | Claims Estimation | `event-detail/ClaimsEstimation.tsx` | `/events/:id/claims` |
| 22 | [22-Documents.md](22-Documents.md) | S3.8 | Documents | `event-detail/Documents.tsx` | `/events/:id/documents` |
| 23 | [23-AuditLog.md](23-AuditLog.md) | S3.9 | Audit Log | `event-detail/AuditLog.tsx` | `/events/:id/audit` |
| 30 | [30-MarketIndustry.md](30-MarketIndustry.md) | S3.10 | Market & Industry Loss | `event-detail/MarketIndustry.tsx` | `/events/:id/market` |
| 31 | [31-MarketShare.md](31-MarketShare.md) | S3.11 | Market Share Analysis | `event-detail/MarketShare.tsx` | Embedded (Market tab) |

### Comments, Tasks & Notifications
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 24 | [24-CommentThread.md](24-CommentThread.md) | S4.1 | Comment Thread | `CommentThread.tsx` | Reusable component |
| 25 | [25-TaskInbox.md](25-TaskInbox.md) | S4.2 | Task Inbox | `TaskInbox.tsx` | Header popover |
| 26 | [26-NotificationCenter.md](26-NotificationCenter.md) | S4.3 | Notification Center | `NotificationCenter.tsx` | Header popover |

### Administration
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 10 | [10-Admin-UsersDirectory.md](10-Admin-UsersDirectory.md) | S5.1 | Users Directory | `admin/UsersDirectory.tsx` | `/admin/users` |
| 11 | [11-Admin-RolesAndPermissions.md](11-Admin-RolesAndPermissions.md) | S5.2 | Roles & Permissions | `admin/RolesAndPermissions.tsx` | `/admin/roles` |
| 12 | [12-Admin-RoutingRules.md](12-Admin-RoutingRules.md) | S5.3 | Routing Rules | `admin/RoutingRules.tsx` | `/admin/routing` |
| 27 | [27-Admin-TaskManagement.md](27-Admin-TaskManagement.md) | S5.4 | Task Management | `admin/TaskManagement.tsx` | `/admin/tasks` |
| 28 | [28-Admin-OrganizationHierarchy.md](28-Admin-OrganizationHierarchy.md) | S5.5 | Organization Hierarchy | `admin/OrganizationHierarchy.tsx` | Embedded |
| 29 | [29-Admin-FXRateManagement.md](29-Admin-FXRateManagement.md) | S5.6 | FX Rate Management | `administration/FXRateManagement.tsx` | `/admin/fx-rates` |

### Workflow & Access
| # | Doc | Screen ID | Screen Name | File | Route |
|---|---|---|---|---|---|
| 13 | [13-WorkflowTracker.md](13-WorkflowTracker.md) | S6 | Workflow Tracker | `WorkflowTracker.tsx` | Embedded component |
| 15 | [15-SailPointAccessForm.md](15-SailPointAccessForm.md) | S7 | SailPoint Access Form | `SailPointAccessForm.tsx` | `/access-request` |

---

## Workflow Phases (4 + Reopened)
| Phase | Name | Badge Color | Description |
|---|---|---|---|
| Phase 0 | Event Creation | Slate | Event draft or newly created |
| Phase 1 | UW Estimation | Amber | UW, CAT, and team estimation in progress |
| Phase 2 | Finance/Management Review | Blue | Finance review and management sign-off |
| Phase 3 | Reporting & Close | Emerald | Final reporting and event closure |
| Special | Reopened | Red | Sent back for re-estimation (cycles to Phase 1) |

## Roles (8 total, 50 users)
| Role | Team | Access Level | Count | Scope |
|---|---|---|---|---|
| Administrator | Admin | Admin | 1 | Full system access, all modules |
| Event Coordinator | Claim | Coordinator | 6 | All BUs (read), edit Overview/Finance, create events |
| Finance Contributor | Finance | Coordinator | 3 | All BUs (read), edit Finance module |
| CAT Contributor | CAT | Contributor | 2 | All BUs (read), edit CAT module |
| Unit Lead | Underwriting | Contributor | 5 | Scoped to Executive Area, approve within EA |
| Business Unit Lead | UW / Management | Contributor | 20+ | Scoped to BU, manage UW team estimates |
| UW Contributor | Underwriting | Contributor | 8 | Scoped to BU, edit UW estimates |
| Reader | Management | Reader | 3 | Read-only across all modules |

## Access Levels (4)
| Level | Permissions |
|---|---|
| Admin | All 9 permission columns enabled |
| Coordinator | read_all_priorities, read_all_units, edit_finance, edit_cat, edit_uw, lock_estimates, reopen_estimate |
| Contributor | read_all_priorities, read_all_units + scoped edit permissions |
| Reader | Read-only, no edit permissions |

## Permission Matrix (9 columns)
| Permission | Admin | Coordinator | Contributor | Reader |
|---|---|---|---|---|
| read_all_priorities | Y | Y | Y | Y |
| read_all_units | Y | Y | Y | Y |
| edit_finance | Y | Y | — | — |
| edit_cat | Y | Y | Scoped | — |
| edit_uw | Y | Y | Scoped | — |
| lock_estimates | Y | Y | — | — |
| reopen_estimate | Y | Y | — | — |
| approve | Y | — | Scoped | — |
| admin_override | Y | — | — | — |

## Executive Areas
International Treaty, NA Treaty, Facultative, Specialty, Financial Lines, Risk Management

## Business Units by Executive Area
| Executive Area | Business Units |
|---|---|
| International Treaty | Zurich/Dublin, Latam, London, Middle East, Singapore |
| NA Treaty | Bermuda, Canada, Treaty Casualty, Treaty Property |
| Facultative | NA Fac Property, NA Fac Casualty, Canada Fac, Latin America Fac, London Fac, Singapore Fac |
| Specialty | Aviation, Marine, Parametric |
| Financial Lines | Surety |
| Risk Management | Risk Management (team = Management) |

## Key Constants
| Constant | Value | Used In |
|---|---|---|
| LOGAN_RETENTION | 0.85 | CATEstimationSummary, ExecutiveSummary |
| EXTERNAL_RECOV_RATE | 0.92 | CATEstimationSummary |

---

## Pending Items / Known Issues
1. **EventIdentity.tsx:** `handleChange` should auto-default Event Sub-Type to first available sub-type instead of clearing to empty.
2. **EventDetailsTab.tsx:** `premiumAllocation` references may still exist and need cleanup.
3. **EventDetailsTab.tsx:** `peril` field is a legacy reference needing cleanup.
4. **EventDetailsTab.tsx:** `everestEventType` field may need reflecting.
5. **OtherIds.tsx:** "Custom" dropdown option cut off due to z-index issue.
6. **CATEstimationSummary.tsx:** Ground-up UW numbers should NOT show values in "Net of Logan", "Ex Reinst", and "Net of Logan Ex" columns (should be blank).
7. **EventOverview-NEW.tsx:** Stale team slugs (`engineering`, `cyber`, `renewable-energy`, `mortgage`) in teamDisplayNames map.
8. **CATEstimationSummary.tsx:** Stale BU keys (`engineering`, `cyber`, `renewableEnergy`, `mortgage`) in modelingEstimates / uwEstimates.
9. **FinanceEstimation.tsx:** IBNR mapping may contain stale Cyber/Mortgage references.
10. **CommentThread.tsx:** Team label map contains stale slugs (`engineering`, `cyber`, `renewable-energy`).
11. **UsersDirectory.tsx:** Three stale user entries — Jonathan Mesagaes/Renewable Energy (U033), Catherine Rudow/Cyber (U034), Alex Haines/Engineering (U035).
12. **DeadlinesTracking.tsx + EventParticipantsSection.tsx:** Stale person entries (Jonathan Mesagaes/Renewable Energy, Catherine Rudow/Cyber, Alex Haines/Engineering, Marco Schiattone/Mortgage).
13. **Codebase-wide:** Possible remaining `peril` field references needing cleanup.
14. **MainLayout.tsx:** Role simulation dropdown was removed from header.

---

## Documentation Format
Each screen document uses this field specification table:

```
UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type |
Field Length | Column1 | Typelist | Editable | Mandatory | Visible |
Default Value | Sample Value | Notes, Conditions, Rules | Release
```

Each document also includes:
- Typelist definitions (dropdown options, badges, enums)
- Business Rules (BR-SX.XX format)
- Known Issues (where applicable)