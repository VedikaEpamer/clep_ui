# S3.2 - Event Detail: Contract Exposure / Contract Capture

**Screen:** Event Detail - Contract Capture Tab
**File:** `/components/event-detail/ContractCapture.tsx`
**Route:** `/events/:eventId/contracts`
**Description:** Displays all contracts linked to the event, grouped by cedant, with program structure details. Gateway to UW estimation.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.2.1 | 1.0 | Header | Contract Exposure | Page Title | — | — | — | — | No | — | Always | — | "Contract Exposure" | Blue (#0052FF) header with event name subtitle. | R1 |
| S3.2.2 | 1.0 | Summary Stats | Total Contracts | Display | Number | — | — | — | No | — | Always | — | 24 | Total count of contracts. | R1 |
| S3.2.3 | 1.0 | Summary Stats | Total Cedants | Display | Number | — | — | — | No | — | Always | — | 8 | Count of unique cedants. | R1 |
| S3.2.4 | 1.0 | Contract Table | Contract Number | Column | String | 20 | contractNumber | — | No | — | Always | — | "PROP-2024-001" | Unique contract identifier. | R1 |
| S3.2.5 | 1.0 | Contract Table | Contract Name | Column | String | 100 | contractName | — | No | — | Always | — | "California Wildfire Coverage" | Descriptive contract name. | R1 |
| S3.2.6 | 1.0 | Contract Table | Cedant | Column / Group Header | String | 50 | cedant | — | No | — | Always | — | "ABC Insurance Company" | Contracts grouped by cedant with expandable sections. Cedant row shows count badge. | R1 |
| S3.2.7 | 1.0 | Contract Table | Program Type | Column / Badge | String | 10 | programType | Program Type Typelist | No | — | Always | — | "XL" | Color-coded badge. | R1 |
| S3.2.8 | 1.0 | Contract Table | Limit | Column | String | 30 | limit | — | No | — | Always | — | "$50M xs $10M" | Formatted limit/attachment string. | R1 |
| S3.2.9 | 1.0 | Contract Table | Deductible | Column | String | 20 | deductible | — | No | — | Always | — | "$10M" | Formatted deductible or "N/A". | R1 |
| S3.2.10 | 1.0 | Contract Table | Everest Line | Column | String | 10 | everestLine | — | No | — | Always | — | "15.5%" | Everest's participation percentage. | R1 |
| S3.2.11 | 1.0 | Contract Table | Treaty Hierarchy | Column | String | 10 | treatyHierarchy | Treaty Hierarchy Typelist | No | — | Always | — | "XL→QS" | Treaty ordering. | R1 |
| S3.2.12 | 1.0 | Contract Table | Effective Date | Column | Date | 10 | effectiveDate | — | No | — | Always | — | "2024-01-01" | Contract start date. | R1 |
| S3.2.13 | 1.0 | Contract Table | Expiry Date | Column | Date | 10 | expiryDate | — | No | — | Always | — | "2024-12-31" | Contract end date. | R1 |
| S3.2.14 | 1.0 | Contract Table | Broker | Column | String | 30 | broker | — | No | — | Always | — | "AON" | Broker name. | R1 |
| S3.2.15 | 1.0 | Contract Table | Reporting Level | Column | String | 20 | reportingLevel | — | No | — | Always | — | "Occurrence" | Occurrence or Aggregate. | R1 |
| S3.2.16 | 1.0 | Contract Table | Currency | Column | String | 5 | currency | — | No | — | Always | — | "USD" | Contract currency. | R1 |
| S3.2.17 | 1.0 | Contract Table | Reinstatement Terms | Column | String | 30 | reinstatementTerms | — | No | — | Always | — | "2 @ 100%" | Reinstatement provisions. | R1 |
| S3.2.18 | 1.0 | Actions | Continue to Estimates | Button | — | — | — | — | Yes | — | Always | — | — | Stores contract metadata to sessionStorage, navigates to `/events/{eventId}/uw-estimation`. | R1 |

### Program Type Typelist
| Value | Label |
|---|---|
| QS | Quota Share |
| XL | Excess of Loss |
| SS | Stop Loss |
| PR | Pro Rata |
| Specialty | Specialty |
| FAC | Facultative |
| Other | Other |

### Treaty Hierarchy Typelist
QS→XL, XL→QS, PR Only, N/A

### Business Rules
- **BR-S3.2.01:** Contracts are grouped by cedant in collapsible sections; all expanded by default.
- **BR-S3.2.02:** "Continue to Estimates" stores contract metadata in sessionStorage for downstream UW Estimation.
