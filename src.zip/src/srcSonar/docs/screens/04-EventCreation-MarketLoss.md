# S2.3 - Event Creation: Market Loss & Consensus

**Screen:** Event Creation - Step 3
**File:** `/components/event-creation/MarketLoss.tsx`
**Route:** `/create-event` (section 3)
**Description:** Capture multiple external market loss estimates from industry sources and Everest's internal consensus view.

## Section 1: External Market Sources

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.3.1 | 1.0 | External Market Sources | Source | Dropdown | String | 30 | source | Market Source Typelist | Yes | No | Always | "" | "Swiss Re" | Per-row dropdown. When "Other" selected, a custom text input appears below. | R1 |
| S2.3.2 | 1.0 | External Market Sources | Custom Source | Text Input | String | 50 | customSource | — | Yes | Conditional | When source="Other" | "" | "Karen Clark & Co" | Shown only when Source = "Other". | R1 |
| S2.3.3 | 1.0 | External Market Sources | Low ($M) | Currency Input | Decimal | 15 | lowEstimate | — | Yes | No | Always | "" | "25,000" | Numeric only (regex: /[^0-9,.]/). Dollar prefix shown. Units: millions. | R1 |
| S2.3.4 | 1.0 | External Market Sources | Best ($M) | Currency Input | Decimal | 15 | medEstimate | — | Yes | No | Always | "" | "35,000" | Numeric only. Dollar prefix. Units: millions. | R1 |
| S2.3.5 | 1.0 | External Market Sources | High ($M) | Currency Input | Decimal | 15 | highEstimate | — | Yes | No | Always | "" | "50,000" | Numeric only. Dollar prefix. Units: millions. | R1 |
| S2.3.6 | 1.0 | External Market Sources | As-of Date | Date Picker | Date (ISO) | 10 | asOfDate | — | Yes | No | Always | "" | "2024-10-15" | Date when the source published the estimate. | R1 |
| S2.3.7 | 1.0 | External Market Sources | Notes | Text Input | String | 500 | notes | — | Yes | No | Always | "" | "Preliminary estimate" | Optional freetext notes per source. | R1 |
| S2.3.8 | 1.0 | External Market Sources | Add Market Source | Button | — | — | — | — | Yes | — | Always | — | — | Adds a new empty row to the sources table. | R1 |
| S2.3.9 | 1.0 | External Market Sources | Remove Source | Button (icon) | — | — | — | — | Yes | — | Per row | — | — | Trash icon. Removes the source row. | R1 |
| S2.3.10 | 1.0 | External Market Sources | Source Range Summary | Display | — | — | — | — | No | — | When >= 2 sources | — | "Low: $25,000M / High: $50,000M / 3 sources" | Auto-computed min(low) and max(high) across all sources. | R1 |

## Section 2: Everest Market Consensus

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.3.11 | 1.0 | Everest Consensus | Consensus Low ($ millions) | Currency Input | Decimal | 15 | marketLossLow | — | Conditional | No | Always | "" | "30,000" | Editable only when consensus is unlocked. Dollar prefix, "millions" suffix. | R1 |
| S2.3.12 | 1.0 | Everest Consensus | Consensus Best ($ millions) | Currency Input | Decimal | 15 | marketLossMed | — | Conditional | No | Always | "" | "40,000" | Editable only when unlocked. | R1 |
| S2.3.13 | 1.0 | Everest Consensus | Consensus High ($ millions) | Currency Input | Decimal | 15 | marketLossHigh | — | Conditional | No | Always | "" | "55,000" | Editable only when unlocked. | R1 |
| S2.3.14 | 1.0 | Everest Consensus | Severity Level | Button Group | Enum | — | severityLevel | Severity Typelist | Conditional | No | Always | "" | "major" | 5-button radio group. Editable only when unlocked. | R1 |
| S2.3.15 | 1.0 | Everest Consensus | Consensus Rationale / Comments | Textarea | String | 5000 | marketLossComments | — | Conditional | No | Always | "" | "Based on initial PCS report..." | 3 rows. Editable only when unlocked. | R1 |
| S2.3.16 | 1.0 | Everest Consensus | Unlock to Edit / Lock Consensus | Toggle Button | Boolean | — | consensusLocked | — | Yes | — | Always | Locked | — | Toggle lock state. When locked: fields disabled + 60% opacity + amber warning banner. Only authorized users (Cat Modeling Lead, CUO, CFO) can unlock. | R1 |

### Market Source Typelist
Swiss Re, Munich Re, PCS, NOAA, AIR Worldwide, Verisk, Moody's RMS, Aon, Guy Carpenter, Gallagher Re, Howden, CoreLogic, Karen Clark & Co, PERILS AG, Other

### Severity Typelist
| Value | Label | Style |
|---|---|---|
| minor | Minor | bg-green-100 text-green-700 |
| moderate | Moderate | bg-yellow-100 text-yellow-700 |
| major | Major | bg-orange-100 text-orange-700 |
| severe | Severe | bg-red-100 text-red-700 |
| catastrophic | Catastrophic | bg-purple-100 text-purple-700 |

### Business Rules
- **BR-S2.3.01:** Source Range Summary auto-computes when >= 2 sources exist.
- **BR-S2.3.02:** Consensus fields are disabled (opacity 60%, pointer-events none) when locked.
- **BR-S2.3.03:** Lock toggle requires appropriate role (Cat Modeling Lead, CUO, or CFO).
- **BR-S2.3.04:** Currency inputs strip non-numeric characters except commas and periods.
