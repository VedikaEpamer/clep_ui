# S4.3 - Notification Center

**Screen:** Notification Center (Header Popover)
**File:** `/components/NotificationCenter.tsx`
**Context:** `/lib/taskContext.tsx`
**Description:** Bell icon popover showing system notifications for the current user. Supports unread count badge, click-through navigation, and mark-as-read.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S4.3.1 | 1.0 | Header | Bell Icon | Icon Button | — | — | — | — | Yes | — | Always | — | — | Bell icon with red unread count badge. Toggles popover. | R1 |
| S4.3.2 | 1.0 | Header | Unread Count | Badge | Number | — | unreadCount | — | No | — | When > 0 | 0 | 3 | Red circle badge on bell icon. | R1 |
| S4.3.3 | 1.0 | Notification | Title | Display | String | 200 | title | — | No | — | Always | — | "UW estimates approved" | Notification headline. | R1 |
| S4.3.4 | 1.0 | Notification | Message | Display | String | 500 | message | — | No | — | Always | — | "Management has approved..." | Notification body text. | R1 |
| S4.3.5 | 1.0 | Notification | Read Status | Visual | Boolean | — | read | — | No | — | Always | false | — | Unread = bold/highlighted, Read = normal. | R1 |
| S4.3.6 | 1.0 | Notification | Timestamp | Display | DateTime | 20 | createdAt | — | No | — | Always | — | "2 hours ago" | Relative or absolute timestamp. | R1 |

### Business Rules
- **BR-S4.3.01:** Clicking a notification marks it as read and navigates to the linked event/task.
- **BR-S4.3.02:** Navigation follows same task type routing as TaskInbox (S4.2).
- **BR-S4.3.03:** Notifications are filtered by current user (based on active role).
- **BR-S4.3.04:** Unread count only shows if > 0.
