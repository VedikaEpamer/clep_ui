# S1 - Event Dashboard

**Screen:** Event Dashboard
**File:** `/components/EventDashboard.tsx`
**Route:** `/`
**Description:** Main landing screen displaying all events in a sortable, filterable table with workflow phase badges, assignment status, and quick navigation to event details.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S1.1.1 | 1.0 | Dashboard Header | Page Title | Label | String | — | — | — | No | — | Always | "Event Dashboard" | "Event Dashboard" | Static header text | R1 |
| S1.1.2 | 1.0 | Dashboard Header | Create New Event | Button | — | — | — | — | No | — | Role-based | — | — | Visible only if user has `create_event` permission. Navigates to `/create-event` | R1 |
| S1.1.3 | 1.0 | Summary Cards | Active Events | Display | Number | — | — | — | No | — | Always | 0 | 7 | Count of events where phase != "Phase 3: Reporting & Close" | R1 |
| S1.1.4 | 1.0 | Summary Cards | In Estimation | Display | Number | — | — | — | No | — | Always | 0 | 3 | Count of events in "Phase 1: UW Estimation" | R1 |
| S1.1.5 | 1.0 | Summary Cards | Pending Review | Display | Number | — | — | — | No | — | Always | 0 | 2 | Count of events in "Phase 2: Finance/Management Review" | R1 |
| S1.1.6 | 1.0 | Summary Cards | Closed | Display | Number | — | — | — | No | — | Always | 0 | 2 | Count of events in "Phase 3: Reporting & Close" | R1 |
| S1.1.7 | 1.0 | Events Table | Sort Controls | Button | — | — | — | — | Yes | — | Always | No sort | — | Click column header to toggle asc/desc sort. Arrow indicators shown. | R1 |
| S1.2.1 | 1.0 | Events Table | Event Name | Column / Link | String | 100 | eventName | — | No | — | Always | — | "Hurricane Milton" | Clickable. Navigates to `/events/{eventId}`. Display with icon badge. | R1 |
| S1.2.2 | 1.0 | Events Table | EVT Code | Column | String | 20 | id | — | No | — | Always | — | "EVT-2024-001" | Auto-generated event identifier | R1 |
| S1.2.3 | 1.0 | Events Table | Loss Date | Column | Date | 10 | lossDate | — | No | — | Always | — | "2024-10-09" | Formatted as locale date string | R1 |
| S1.2.4 | 1.0 | Events Table | Phase | Column / Badge | String | 50 | currentPhase | Phase Typelist | No | — | Always | — | "Phase 1: UW Estimation" | Color-coded badge. Typelist: Phase 0: Event Creation, Phase 1: UW Estimation, Phase 2: Finance/Management Review, Phase 3: Reporting & Close, Reopened | R1 |
| S1.2.5 | 1.0 | Events Table | Region | Column | String | 50 | region | — | No | — | Always | — | "North America" | Geographic region of event | R1 |
| S1.2.6 | 1.0 | Events Table | Contracts | Column | Number | 5 | contractCount | — | No | — | Always | — | 24 | Count of contracts linked to event | R1 |
| S1.2.7 | 1.0 | Events Table | Market Loss | Column | Currency | 15 | marketLoss | — | No | — | Always | — | "$45B" | Formatted currency display in billions/millions | R1 |
| S1.2.8 | 1.0 | Events Table | Gross Amount Range | Column | String | 30 | grossAmountRange | — | No | — | Always | — | "$150M - $200M" | Low-High gross estimate range | R1 |
| S1.2.9 | 1.0 | Events Table | Net Amount | Column | Currency | 15 | netAmount | — | No | — | Always | — | "$85M" | Net amount after cessions | R1 |
| S1.2.10 | 1.0 | Events Table | Creation Date | Column | Date | 10 | creationDate | — | No | — | Always | — | "2024-10-10" | Date event was created | R1 |
| S1.3.1 | 1.0 | Column Filters | Event Name Filter | Text Input | String | 100 | — | — | Yes | No | Always | "" | "Hurricane" | Filters table rows by event name substring match | R1 |
| S1.3.2 | 1.0 | Column Filters | EVT Code Filter | Text Input | String | 20 | — | — | Yes | No | Always | "" | "EVT-2024" | Filters by event code | R1 |
| S1.3.3 | 1.0 | Column Filters | Phase Filter | Dropdown | String | — | — | Phase Typelist | Yes | No | Always | "" (All) | "Phase 1: UW Estimation" | Filters by workflow phase | R1 |
| S1.3.4 | 1.0 | Column Filters | Region Filter | Text Input | String | 50 | — | — | Yes | No | Always | "" | "North America" | Filters by region | R1 |

### Phase Typelist
| Value | Badge Style |
|---|---|
| Phase 0: Event Creation | bg-slate-100 text-slate-700 |
| Phase 1: UW Estimation | bg-amber-50 text-amber-700 |
| Phase 2: Finance/Management Review | bg-blue-50 text-blue-700 |
| Phase 3: Reporting & Close | bg-emerald-50 text-emerald-700 |
| Reopened | bg-red-50 text-red-700 |

### Business Rules
- **BR-S1.01:** Only users with `create_event` permission see the "Create New Event" button.
- **BR-S1.02:** Summary card counts are dynamically computed from workflow state.
- **BR-S1.03:** Column sorting toggles between ascending, descending, and no sort.
- **BR-S1.04:** Multiple column filters can be applied simultaneously (AND logic).