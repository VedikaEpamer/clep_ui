# S3.0 - Event Detail: Event Overview

**Screen:** Event Overview (Main Event Detail Hub)
**File:** `/components/event-detail/EventOverview-NEW.tsx`
**Route:** `/events/:eventId/overview`
**Description:** Central hub for event management. Displays workflow tracker, event summary, CAT estimation summary, team assignments, contract tables (by BU and by Cedent), team comments, and approval actions. Contains sub-tabs: Summary, Executive, Modeling, Details, Market.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.0.1 | 1.0 | Header | Event Name | Display | String | 200 | eventName | — | No | — | Always | — | "Chile Earthquake 2024" | Large blue header with event name. | R1 |
| S3.0.2 | 1.0 | Header | Event ID | Badge | String | 20 | eventId | — | No | — | Always | — | "EVT-2024-012" | Small gray badge. | R1 |
| S3.0.3 | 1.0 | Header | Download | Dropdown Button | — | — | — | Format Typelist | Yes | — | Always | — | — | Download event data as PDF, CSV, or Excel. | R1 |
| S3.0.4 | 1.0 | Header | Add Comment | Button | — | — | — | — | Yes | — | Always | — | — | Opens comment form. | R1 |
| S3.0.5 | 1.0 | Sub-Tabs | Tab Navigation | Tab Bar | String | — | activeTab | Tab Typelist | Yes | — | Always | "summary" | "executive" | 5 tabs: Summary, Executive, Modeling, Details, Market. | R1 |
| S3.0.6 | 1.0 | Approval Banner | Pending Approval | Alert Banner | — | — | approvalRequest | — | No | — | Conditional | — | — | Yellow banner shown when event has pending management approval. Shows Approve / Request Changes buttons. | R1 |
| S3.0.7 | 1.0 | Approval Banner | Approve | Button | — | — | — | — | Conditional | — | When approval pending | — | — | Approves estimates. Sends notifications to Finance & CAT teams. Toast: "Estimates Approved". | R1 |
| S3.0.8 | 1.0 | Approval Banner | Request Changes | Button | — | — | — | — | Conditional | — | When approval pending | — | — | Rejects approval. Sends back for revision. | R1 |
| S3.0.9 | 1.0 | Workflow Panel | Workflow Tracker | Embedded Component | — | — | — | — | No | — | Always | — | — | WorkflowTracker component showing 4-phase progress. | R1 |
| S3.0.10 | 1.0 | Event Details Panel | Collapsible Details | Expandable Section | — | — | — | — | Yes | — | Always | Collapsed | — | Expandable panel with inline edit mode for event details. | R1 |
| S3.0.11 | 1.0 | CAT Estimation | CAT Estimation Summary | Embedded Component | — | — | — | — | Conditional | — | Summary tab | — | — | CATEstimationSummary component with lock/save/download actions. | R1 |
| S3.0.12 | 1.0 | BU Table | Business Unit Summary | Sortable Table | — | — | — | — | No | — | Summary tab | — | — | Expandable rows by BU: US Property, USA Casualty, Bermuda, etc. Shows contracts, exposure, gross/net estimates. | R1 |
| S3.0.13 | 1.0 | BU Table | Search | Text Input | String | 100 | buSearchTerm | — | Yes | No | Always | "" | "Property" | Filters BU table by name. | R1 |
| S3.0.14 | 1.0 | Cedent Table | Top Companies | Sortable Table | — | — | — | — | No | — | Summary tab | — | — | Expandable rows by Cedent (State Farm, Liberty Mutual, etc.). Shows contracts per cedent. | R1 |
| S3.0.15 | 1.0 | Comments Table | Team Comments & Updates | Sortable/Filterable Table | — | — | — | — | No | — | Summary tab | — | — | Audit-style table with Name, Date, Column, Comment. Sortable headers. Role and BU filter dropdowns. | R1 |
| S3.0.16 | 1.0 | Comments | Add Comment Form | Textarea + Dropdown | — | — | — | Team Typelist | Conditional | — | When toggled | "" | — | Team dropdown + textarea. Team defaults to "latam-brazil-treaty". | R1 |

### Tab Typelist
| Value | Label |
|---|---|
| summary | Summary |
| executive | Executive Summary |
| modeling | Modeling |
| details | Event Details |
| market | Market Share |

### Team Display Name Map (Slug -> Label)
| Slug | Display Name |
|---|---|
| intl-fac | International Fac |
| latam-fac | Latin America Fac |
| london-fac | London Fac |
| singapore-fac | Singapore Fac |
| dublin-zurich | Dublin / Zurich |
| latam-brazil-treaty | Latin America / Brazil Treaty |
| london-treaty | London Treaty |
| me-africa | ME / Africa |
| singapore-treaty | Singapore Treaty |
| bermuda-fac | Bermuda Fac |
| canada-fac | Canada Fac |
| fac-casualty | FAC Casualty |
| fac-property | FAC Property |
| bermuda-treaty | Bermuda Treaty |
| canada-treaty | Canada Treaty |
| treaty-casualty | Treaty Casualty |
| treaty-property | Treaty Property |
| aviation | Aviation |
| parametric | Parametric |
| marine | Marine |
| modeling | CAT Modeling |
| finance | Finance |

### Known Issues (Stale References)
- `engineering`, `cyber`, `renewable-energy`, `mortgage` still present in `teamDisplayNames` map — pending cleanup.

### Business Rules
- **BR-S3.0.01:** Approval banner reads from sessionStorage `pendingApprovals` array.
- **BR-S3.0.02:** Approve action stores approval status and sends notifications to Finance and CAT teams via sessionStorage.
- **BR-S3.0.03:** BU table rows are expandable to show individual contracts.
- **BR-S3.0.04:** Cedent table rows are expandable to show contracts per cedent.
- **BR-S3.0.05:** Comment filters support Role and Business Unit filtering.
