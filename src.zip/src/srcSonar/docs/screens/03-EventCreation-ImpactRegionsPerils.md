# S2.2 - Event Creation: Impact Regions & Perils

**Screen:** Event Creation - Step 2
**File:** `/components/event-creation/ImpactRegionsPerils.tsx`
**Route:** `/create-event` (section 2)
**Description:** Define the geographic and peril scope of the event for internal classification, reporting, and validation against RDM.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.2.1 | 1.0 | Impacted Regions | Impacted Regions | Hierarchical Checkbox Tree | Array[String] | — | impactedCountries | RDM Regions Hierarchy | Yes | Yes | Always | [] | ["United States", "Mexico"] | Required. Multi-level expandable tree: Region -> Sub-Region -> Country. US has additional state-level hierarchy. Badge chips shown for selected items with X to remove. Counter shows "N locations selected". | R1 |
| S2.2.2 | 1.0 | Impacted Regions | Global | Checkbox | Boolean | — | — | — | Yes | No | Always | unchecked | checked | Top-level checkbox for "GLOBAL" scope. Part of impactedCountries array. | R1 |
| S2.2.3 | 1.0 | Impacted Regions | US States | Hierarchical Checkbox Tree | Array[String] | — | impactedStates | US States Hierarchy | Yes | No | Conditional | [] | ["Florida", "Georgia"] | Visible when "United States" is expanded. Grouped by US region: New England, Midatlantic, Southeastern, Great Lakes, Plains, Southwestern, Mountain, Pacific, South-Central. Each region header has select-all checkbox. | R1 |
| S2.2.4 | 1.0 | Impacted Regions | Selected Locations Badges | Display | Array[String] | — | — | — | No | — | Conditional | — | "UNITED STATES", "FLORIDA" | Blue pill badges with X remove button. Shown in blue-50 container when 1+ locations selected. Countries and states shown as separate badges. | R1 |

### US States Hierarchy
| Region | States |
|---|---|
| New England States | Connecticut, Maine, Massachusetts, New Hampshire, Rhode Island, Vermont |
| Midatlantic States | Delaware, Maryland, New Jersey, New York, Pennsylvania |
| Southeastern States | Alabama, Florida, Georgia, Kentucky, Mississippi, North Carolina, South Carolina, Tennessee, Virginia, West Virginia |
| Great Lakes States | Illinois, Indiana, Michigan, Ohio, Wisconsin |
| Plains States | Iowa, Kansas, Minnesota, Missouri, Nebraska, North Dakota, South Dakota |
| Southwestern States | Arizona, New Mexico, Oklahoma, Texas |
| Mountain States | Colorado, Idaho, Montana, Nevada, Utah, Wyoming |
| Pacific States | Alaska, California, Hawaii, Oregon, Washington |
| South-Central States | Arkansas, Louisiana |

### Business Rules
- **BR-S2.2.01:** Region tree is hierarchical: expanding a region shows sub-regions, expanding sub-regions shows countries.
- **BR-S2.2.02:** Selecting a region header selects/deselects all countries under it.
- **BR-S2.2.03:** United States expands into 9 state-region groups, each with select-all toggle.
- **BR-S2.2.04:** Location counter updates dynamically: total = selectedCountries.length + selectedStates.length.
