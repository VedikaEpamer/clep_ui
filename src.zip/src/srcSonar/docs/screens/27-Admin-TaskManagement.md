# S5.4 - Administration: Task Management

**Screen:** Administration - Task Management
**File:** `/components/admin/TaskManagement.tsx`
**Route:** `/admin/tasks`
**Description:** Admin view of all system tasks across all users. Filterable by status with search, showing task details, assignments, and priorities.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.4.1 | 1.0 | Header | Task Management | Page Title | — | — | — | — | No | — | Always | — | "Task Management" | Static header. | R1 |
| S5.4.2 | 1.0 | Summary Cards | Open Tasks | Display | Number | — | — | — | No | — | Always | — | 12 | Count of pending + in-progress tasks. | R1 |
| S5.4.3 | 1.0 | Summary Cards | Overdue Tasks | Display | Number | — | — | — | No | — | Always | — | 3 | Count of overdue tasks. | R1 |
| S5.4.4 | 1.0 | Summary Cards | Completed Tasks | Display | Number | — | — | — | No | — | Always | — | 8 | Count of completed tasks. | R1 |
| S5.4.5 | 1.0 | Tabs | Active Tab | Tab Bar | Enum | — | activeTab | Tab Typelist | Yes | — | Always | "open" | "reallocation" | Open Tasks / Task Reallocation tabs. | R1 |
| S5.4.6 | 1.0 | Filters | Search | Text Input | String | 100 | searchQuery | — | Yes | No | Always | "" | "Hurricane" | Filters by title, event name, or assigned user. | R1 |
| S5.4.7 | 1.0 | Filters | Status Filter | Dropdown | String | — | filterStatus | Status Typelist | Yes | No | Always | "all" | "pending" | Filters by task status. | R1 |
| S5.4.8 | 1.0 | Task Table | Title | Column | String | 200 | title | — | No | — | Always | — | "Review UW estimates" | Task description. | R1 |
| S5.4.9 | 1.0 | Task Table | Event Name | Column | String | 100 | eventName | — | No | — | Always | — | "Hurricane Milton" | Associated event. | R1 |
| S5.4.10 | 1.0 | Task Table | Assigned To | Column | String | 50 | assignedTo | — | No | — | Always | — | "Sarah Mitchell" | Assigned user. | R1 |
| S5.4.11 | 1.0 | Task Table | Priority | Badge | Enum | — | priority | Priority Typelist | No | — | Always | — | "High" | Color-coded priority. | R1 |
| S5.4.12 | 1.0 | Task Table | Status | Badge | Enum | — | status | Status Typelist | No | — | Always | — | "In Progress" | Color-coded status. | R1 |

### Status Typelist
| Value | Style |
|---|---|
| completed | bg-emerald-100 text-emerald-700 |
| in-progress | bg-amber-100 text-amber-700 |
| overdue | bg-red-100 text-red-700 |
| pending | bg-slate-100 text-slate-700 |

### Business Rules
- **BR-S5.4.01:** Search filters across title, event name, and assigned user (case-insensitive).
- **BR-S5.4.02:** Status filter is AND with search.
- **BR-S5.4.03:** Summary cards auto-compute from task context.
