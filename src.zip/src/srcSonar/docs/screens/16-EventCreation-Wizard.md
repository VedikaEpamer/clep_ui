# S2 - Event Creation Wizard (Container)

**Screen:** Event Creation Wizard
**File:** `/components/EventCreation.tsx`
**Route:** `/events/new`
**Description:** Multi-step wizard for creating new events. Vertical sidebar navigation with 5 steps, scrollable content area, and Save Draft / Publish actions.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.0.1 | 1.0 | Header Bar | SONAR Logo & Title | Display | — | — | — | — | No | — | Always | — | "SONAR" | Matches MainLayout header. Dark navy (#001f3f) background. Logo and text vertically centered. | R1 |
| S2.0.2 | 1.0 | Header Bar | Close (X) | Button | — | — | — | — | Yes | — | Always | — | — | Navigates back to `/events`. | R1 |
| S2.0.3 | 1.0 | Sidebar | Draft Event Indicator | Display | — | — | — | — | No | — | Always | — | — | Amber pulsing dot + "Draft Event" label. Shows event name + auto-generated ID. | R1 |
| S2.0.4 | 1.0 | Sidebar | Step Navigation | Button List | — | — | — | Step Typelist | Yes | — | Always | Step 1 | — | 5 steps with number badges. Current = white bg, completed = green check, future = dimmed. Clicking scrolls content to section. | R1 |
| S2.0.5 | 1.0 | Sidebar | Event ID | Display | String | 20 | eventId | — | No | — | Always | Auto-generated | "EVT-2025-042" | Format: EVT-{YYYY}-{NNN}. Generated on component mount. | R1 |
| S2.0.6 | 1.0 | Footer | Save Draft | Button | — | — | — | — | Yes | — | Always | — | — | Saves partial event as Draft status. Toast: "Draft saved successfully!" Navigates to `/events`. | R1 |
| S2.0.7 | 1.0 | Footer | Publish Event | Button | — | — | — | — | Yes | — | Always | — | — | Creates active event. Toast: "Event published successfully!" Navigates to event overview. Adds event to mockEvents. | R1 |
| S2.0.8 | 1.0 | Content Area | Scroll Tracking | Behavior | — | — | — | — | — | — | Always | — | — | As user scrolls, sidebar step indicator updates to match visible section via IntersectionObserver-like logic. | R1 |

### Step Typelist
| Step | Name | Component |
|---|---|---|
| 1 | Event Identity | EventIdentity |
| 2 | Impact Regions & Perils | ImpactRegionsPerils |
| 3 | Other IDs | OtherIds |
| 4 | Industry Market Loss | MarketLoss |
| 5 | Deadlines & Tracking | DeadlinesTracking |

### Business Rules
- **BR-S2.0.01:** Event ID auto-generates on mount: `EVT-{year}-{random 3-digit}`.
- **BR-S2.0.02:** Save Draft creates event with `status: 'Draft'`, progress based on current step.
- **BR-S2.0.03:** Publish creates event with `status: 'Active'`, random contract count, progress = 5%.
- **BR-S2.0.04:** Scroll tracking updates sidebar step indicator based on which section is in viewport center.
- **BR-S2.0.05:** Sidebar background is #0052FF (Everest blue).