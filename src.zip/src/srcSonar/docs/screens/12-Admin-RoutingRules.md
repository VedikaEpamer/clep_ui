# S5.3 - Administration: Routing Rules

**Screen:** Administration - Routing Rules
**File:** `/components/admin/RoutingRules.tsx`
**Route:** `/admin/routing`
**Description:** Configure assignment logic and notification workflows. Rules define who gets notified/tasked when specific triggers fire based on event matching criteria.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.3.1 | 1.0 | Header | Routing Rules | Page Title | — | — | — | — | No | — | Always | — | "Routing Rules" | Static header with subtitle. | R1 |
| S5.3.2 | 1.0 | Header | Search | Text Input | String | 100 | — | — | Yes | No | Always | "" | "Phase 1" | Filters rules by name substring match. | R1 |
| S5.3.3 | 1.0 | Header | Add Routing Rule | Button | — | — | — | — | Yes | — | Always | — | — | Opens side drawer for new rule creation. | R1 |
| S5.3.4 | 1.0 | Filters | Region Filter | Dropdown | String | — | — | Region Typelist | Yes | No | Always | "" (All) | "North America" | Filter rules by region. | R1 |
| S5.3.5 | 1.0 | Filters | LOB Filter | Dropdown | String | — | — | LOB Typelist | Yes | No | Always | "" (All) | "Property" | Filter by Line of Business. | R1 |
| S5.3.6 | 1.0 | Filters | Event Type Filter | Dropdown | String | — | — | Event Type Typelist | Yes | No | Always | "" (All) | "CAT" | Filter by event type. | R1 |
| S5.3.7 | 1.0 | Filters | Target Role Filter | Dropdown | String | — | — | Target Role Typelist | Yes | No | Always | "" (All) | "UW Lead" | Filter by target role. | R1 |
| S5.3.8 | 1.0 | Rules Table | Rule Name | Column | String | 100 | name | — | No | — | Always | — | "Phase 1: UW Estimation Window Opened" | Clickable row opens edit drawer. | R1 |
| S5.3.9 | 1.0 | Rules Table | Region | Column | String | 20 | region | Region Typelist | No | — | Always | — | "Global" | Geographic scope. | R1 |
| S5.3.10 | 1.0 | Rules Table | LOB / Portfolio | Column | String | 20 | lob | LOB Typelist | No | — | Always | — | "All LOBs" | Line of business scope. | R1 |
| S5.3.11 | 1.0 | Rules Table | Event Type | Column | String | 20 | eventType | Event Type Typelist | No | — | Always | — | "CAT" | Event type scope. | R1 |
| S5.3.12 | 1.0 | Rules Table | Trigger | Column / Badge | String | 30 | trigger | Trigger Typelist | No | — | Always | — | "Event Created" | Blue badge. Trigger condition. | R1 |
| S5.3.13 | 1.0 | Rules Table | Target Role | Column | String | 25 | targetRole | Target Role Typelist | No | — | Always | — | "UW Lead" | Role that receives the assignment. | R1 |
| S5.3.14 | 1.0 | Rules Table | Assignees | Column | String | — | defaultAssignees | — | No | — | Always | — | "4 assigned" | Users icon + count of assigned users. | R1 |
| S5.3.15 | 1.0 | Rules Table | Notification | Column | String | 20 | notificationType | Notification Typelist | No | — | Always | — | "Task + Email" | Notification delivery method. | R1 |
| S5.3.16 | 1.0 | Rules Table | Status | Column / Badge | Enum | — | status | Active/Inactive | No | — | Always | — | "Active" | Green or gray badge. | R1 |
| S5.3.17 | 1.0 | Rules Table | Actions | Column | Button | — | — | — | Yes | — | Always | — | — | Edit icon button. | R1 |
| S5.3.18 | 1.0 | Edit Drawer | Rule Name | Text Input | String | 100 | formName | — | Yes | Yes | In drawer | "" | "CAT Event Auto-Assignment" | Required field in edit/create drawer. | R1 |
| S5.3.19 | 1.0 | Edit Drawer | Region | Dropdown | String | — | formRegion | Region Typelist | Yes | Yes | In drawer | "Global" | "North America" | Matching criteria. | R1 |
| S5.3.20 | 1.0 | Edit Drawer | LOB / Portfolio | Dropdown | String | — | formLOB | LOB Typelist | Yes | Yes | In drawer | "All LOBs" | "Property" | Matching criteria. | R1 |
| S5.3.21 | 1.0 | Edit Drawer | Event Type | Dropdown | String | — | formEventType | Event Type Typelist | Yes | Yes | In drawer | "All Types" | "CAT" | Matching criteria. | R1 |
| S5.3.22 | 1.0 | Edit Drawer | Trigger | Dropdown | String | — | formTrigger | Trigger Typelist | Yes | Yes | In drawer | "Event Created" | "Threshold Breach" | What fires the rule. | R1 |
| S5.3.23 | 1.0 | Edit Drawer | Target Role | Dropdown | String | — | formTargetRole | Target Role Typelist | Yes | Yes | In drawer | "" | "UW Lead" | Who receives the assignment. | R1 |
| S5.3.24 | 1.0 | Edit Drawer | Notification Type | Dropdown | String | — | formNotificationType | Notification Typelist | Yes | Yes | In drawer | "Task + Email" | "Email only" | Delivery method. | R1 |
| S5.3.25 | 1.0 | Edit Drawer | Default Assignees | Checkbox List | Array[String] | — | formAssignees | User List | Yes | No | In drawer | [] | ["U004", "U005"] | Multi-select user checkboxes. Shows name, email, role per user. | R1 |
| S5.3.26 | 1.0 | Edit Drawer | Active | Toggle Checkbox | Boolean | — | formStatus | — | Yes | No | In drawer | true | false | Active/Inactive toggle with helper text. | R1 |
| S5.3.27 | 1.0 | Edit Drawer | Preview Recipients | Info Panel | — | — | — | — | No | — | When targetRole set | — | — | Blue panel showing computed recipient list with avatars. Combines selected assignees + role-based users. | R1 |

### Region Typelist
Global, North America, EMEA, APAC, Latin America

### LOB Typelist
All LOBs, Property, Casualty, Professional Lines, Specialty, Marine

### Event Type Typelist (Routing)
All Types, CAT, Man-Made, Aggregated Non-CAT

### Trigger Typelist
Event Created, Estimation Window Opened, Estimation Window Closed, Threshold Breach, Recalc Required, Approval Requested, Deadline Approaching

### Target Role Typelist
Finance Owner, Event Coordinator, UW Lead, UW Contributor, Modeler, Claims Reviewer, Reserving Reviewer, Retro Analyst, Executive Viewer

### Notification Typelist
Task + Email, Task only, Email only

### Business Rules
- **BR-S5.3.01:** Filters use AND logic across all filter dropdowns.
- **BR-S5.3.02:** Clicking any table row opens the edit drawer for that rule.
- **BR-S5.3.03:** Preview Recipients combines explicitly selected assignees + users matching the target role.
- **BR-S5.3.04:** Inactive rules do not trigger task assignments or notifications.
