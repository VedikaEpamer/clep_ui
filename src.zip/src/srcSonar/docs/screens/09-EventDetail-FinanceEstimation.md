# S3.4 - Event Detail: Finance Estimation

**Screen:** Event Detail - Finance Estimation Tab
**File:** `/components/event-detail/FinanceEstimation.tsx`
**Route:** `/events/:eventId/finance-estimation`
**Description:** Finance team estimation screen with contract-level IBNR tagging, UW/Modeling estimates, and net calculations. Includes lock/unlock, export, and submit workflows.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.4.1 | 1.0 | Header | Finance Estimation | Page Title | — | — | — | — | No | — | Always | — | "Finance Estimation" | Blue header with event name. | R1 |
| S3.4.2 | 1.0 | Header Actions | Lock All Estimates | Toggle Button | Boolean | — | — | — | Conditional | — | Role-based | Unlocked | — | Locks all editable fields. Only Finance Contributor, Event Coordinator, Administrator can toggle. | R1 |
| S3.4.3 | 1.0 | Header Actions | Export to Excel | Button | — | — | — | — | Yes | — | Always | — | — | Exports contract data to XLSX format via `xlsx` library. | R1 |
| S3.4.4 | 1.0 | Header Actions | Submit to Finance | Button | — | — | — | — | Yes | — | Always | — | — | Submits estimates. Triggers toast notification. | R1 |
| S3.4.5 | 1.0 | Contract Table | Contract Number | Column | String | 20 | contractNumber | — | No | — | Always | — | "PROP-2024-001" | Read-only. | R1 |
| S3.4.6 | 1.0 | Contract Table | Contract Name | Column | String | 100 | contractName | — | No | — | Always | — | "California Wildfire Coverage" | Read-only. | R1 |
| S3.4.7 | 1.0 | Contract Table | Cedant | Column | String | 50 | cedant | — | No | — | Always | — | "ABC Insurance" | Read-only. | R1 |
| S3.4.8 | 1.0 | Contract Table | CAT Model Status | Column / Badge | Enum | — | catModelStatus | CAT Status Typelist | No | — | Always | "Pending" | "Listed" | Color-coded badge. | R1 |
| S3.4.9 | 1.0 | Contract Table | Impact Status | Column / Badge | Enum | — | impactStatus | Impact Status Typelist | Conditional | — | Always | — | "Impacted" | Dropdown or badge. | R1 |
| S3.4.10 | 1.0 | Contract Table | Team | Column | String | 30 | team | — | No | — | Always | — | "Intl Treaty" | Executive area / team assignment. | R1 |
| S3.4.11 | 1.0 | Contract Table | Signed Share | Column | String | 10 | signedShare | — | No | — | Always | — | "15.5%" | Everest's signed share. | R1 |
| S3.4.12 | 1.0 | Contract Table | DREAM Limit | Column | Currency | 15 | dreamLimit | — | No | — | Always | — | "$7,750,000" | From DREAM system. | R1 |
| S3.4.13 | 1.0 | Contract Table | Limit 100% | Column | Currency | 15 | limit100Pct | — | No | — | Always | — | "$50,000,000" | Full contract limit. | R1 |
| S3.4.14 | 1.0 | Contract Table | Attach Point | Column | Currency | 15 | attachPoint | — | No | — | Always | — | "$10,000,000" | Attachment point / deductible. | R1 |
| S3.4.15 | 1.0 | Contract Table | UW Est Low | Column | Currency | 15 | uwEstimateLow | Conditional | No | Always | "" | "$1,200,000" | Editable when unlocked. | R1 |
| S3.4.16 | 1.0 | Contract Table | UW Est High | Column | Currency | 15 | uwEstimateHigh | Conditional | No | Always | "" | "$2,500,000" | Editable when unlocked. | R1 |
| S3.4.17 | 1.0 | Contract Table | Modeling Low | Column | Currency | 15 | modelingLow | No | — | Always | "" | "$1,100,000" | Read-only. From CAT modeling. | R1 |
| S3.4.18 | 1.0 | Contract Table | Modeling High | Column | Currency | 15 | modelingHigh | No | — | Always | "" | "$2,800,000" | Read-only. From CAT modeling. | R1 |
| S3.4.19 | 1.0 | Contract Table | Net of RI | Column | Currency | 15 | netOfRI | — | No | — | Always | — | "$900,000" | Computed: gross - reinsurance recoveries. | R1 |
| S3.4.20 | 1.0 | Contract Table | Net of Mount Logan | Column | Currency | 15 | netOfMountLogan | — | No | — | Always | — | "$750,000" | Net after Logan sidecar. | R1 |
| S3.4.21 | 1.0 | Contract Table | Final Net Net | Column | Currency | 15 | finalNetNet | — | No | — | Always | — | "$600,000" | Final net of all cessions. | R1 |
| S3.4.22 | 1.0 | Mapping | Reporting Level -> IBNR Tag | Internal Mapping | — | — | — | RL_MAP | No | — | Always | — | "NC_FPROPPR" | Maps Reporting Level to Executive Area, Business Unit, and IBNR Tag. Used for finance aggregation. | R1 |

### CAT Status Typelist
| Value | Label |
|---|---|
| Listed | Listed |
| Not Listed | Not Listed |
| Pending | Pending |

### Impact Status Typelist
| Value | Label |
|---|---|
| Impacted | Impacted |
| Not Impacted | Not Impacted |
| Excluded | Excluded |
| Manual | Manual |
| Not in RDM | Not in RDM |

### Business Rules
- **BR-S3.4.01:** Lock toggle disables all editable estimate fields.
- **BR-S3.4.02:** Export generates XLSX file with all visible columns.
- **BR-S3.4.03:** Reporting Level to IBNR mapping (RL_MAP) drives finance aggregation groupings.
- **BR-S3.4.04:** Uses Chile Earthquake historical contract data for EVT-2024-012.
