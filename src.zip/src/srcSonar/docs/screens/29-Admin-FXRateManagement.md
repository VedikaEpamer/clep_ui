# S5.6 - Administration: FX Rate Management

**Screen:** FX Rate Management
**File:** `/components/administration/FXRateManagement.tsx`
**Sub-Components:** `FXHistoricalChart.tsx`, `CurrencyGainLoss.tsx`, `FXRateAlerts.tsx`
**Route:** `/admin/fx-rates`
**Description:** Foreign exchange rate management dashboard. View, edit, and refresh currency pair rates. Includes historical chart, gain/loss analysis, and rate alert configuration.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.6.1 | 1.0 | Header | FX Rate Management | Page Title | — | — | — | — | No | — | Always | — | "FX Rate Management" | Static header. | R1 |
| S5.6.2 | 1.0 | Header | Effective Date | Display | Date | 10 | effectiveDate | — | No | — | Always | Today | "2026-03-07" | Current date. | R1 |
| S5.6.3 | 1.0 | Header | Last Updated | Display | DateTime | 20 | lastUpdated | — | No | — | Always | Now | "3/7/2026, 2:30:00 PM" | Last refresh timestamp. | R1 |
| S5.6.4 | 1.0 | Header Actions | Refresh Rates | Button | — | — | — | — | Yes | — | Always | — | — | Simulates API call. Updates rates with random micro-changes. Toast: "FX rates updated successfully". 1.5s delay. | R1 |
| S5.6.5 | 1.0 | Header Actions | Export | Button | — | — | — | — | Yes | — | Always | — | — | Export rates to file. | R1 |
| S5.6.6 | 1.0 | Header Actions | Import | Button | — | — | — | — | Yes | — | Always | — | — | Import rates from file. | R1 |
| S5.6.7 | 1.0 | Filters | Search | Text Input | String | 20 | searchQuery | — | Yes | No | Always | "" | "USD" | Filters currency pairs by from/to currency. | R1 |
| S5.6.8 | 1.0 | Filters | Source Filter | Dropdown | String | — | selectedSource | Source Typelist | Yes | No | Always | "All Sources" | "Bloomberg" | Filter by rate source. | R1 |
| S5.6.9 | 1.0 | Rate Table | From Currency | Column | String | 3 | from | — | No | — | Always | — | "USD" | Base currency. | R1 |
| S5.6.10 | 1.0 | Rate Table | To Currency | Column | String | 3 | to | — | No | — | Always | — | "EUR" | Quote currency. | R1 |
| S5.6.11 | 1.0 | Rate Table | Rate | Column | Decimal | 10 | rate | — | Conditional | No | Always | — | "0.92" | Mid-market rate. Editable via inline edit (pencil icon). | R1 |
| S5.6.12 | 1.0 | Rate Table | Bid | Column | Decimal | 10 | bid | — | No | — | Always | — | "0.9195" | Bid rate. | R1 |
| S5.6.13 | 1.0 | Rate Table | Ask | Column | Decimal | 10 | ask | — | No | — | Always | — | "0.9205" | Ask rate. | R1 |
| S5.6.14 | 1.0 | Rate Table | Mid | Column | Decimal | 10 | mid | — | No | — | Always | — | "0.92" | Mid rate. | R1 |
| S5.6.15 | 1.0 | Rate Table | 24h Change | Column | Percentage | 8 | change | — | No | — | Always | — | "-0.15%" | 24-hour change. Green = positive, red = negative. TrendingUp/Down icon. | R1 |
| S5.6.16 | 1.0 | Rate Table | Source | Column | String | 15 | source | — | No | — | Always | — | "Bloomberg" | Data source. | R1 |
| S5.6.17 | 1.0 | Rate Table | Actions | Column | Button | — | — | — | Yes | — | Always | — | — | Edit (pencil), Save, Cancel. | R1 |
| S5.6.18 | 1.0 | Sub-Components | Historical Chart | Embedded | — | — | — | — | No | — | Always | — | — | FXHistoricalChart component. | R1 |
| S5.6.19 | 1.0 | Sub-Components | Currency Gain/Loss | Embedded | — | — | — | — | No | — | Always | — | — | CurrencyGainLoss component. | R1 |
| S5.6.20 | 1.0 | Sub-Components | Rate Alerts | Embedded | — | — | — | — | Yes | — | Always | — | — | FXRateAlerts component. | R1 |

### Currency Pairs (Default)
USD/EUR, USD/GBP, USD/JPY, USD/BRL, USD/CLP, USD/MXN, USD/CAD, EUR/GBP, EUR/JPY, GBP/JPY

### Business Rules
- **BR-S5.6.01:** Refresh simulates Bloomberg API call with 1.5s delay, applies small random rate changes.
- **BR-S5.6.02:** Inline edit mode triggered by pencil icon; Save/Cancel buttons appear.
- **BR-S5.6.03:** 24h change color: positive = green with TrendingUp, negative = red with TrendingDown.
