# S2.6 - Event Creation: Event Notification Recipients (Participants)

**Screen:** Event Creation - Step 6
**File:** `/components/event-creation/EventParticipantsSection.tsx`
**Route:** `/create-event` (section 6)
**Description:** Read-only summary view of all event notification recipients organized by team, showing assignments, regions, tasks, and completion status.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.6.1 | 1.0 | Header | Event Notification Recipients | Label + Count | — | — | — | — | No | — | Always | — | "42 people" | Section header with step number badge (6) and total recipient count. | R1 |
| S2.6.2 | 1.0 | Column Headers | Name | Column Header | — | — | — | — | No | — | Always | — | — | 28% width. | R1 |
| S2.6.3 | 1.0 | Column Headers | Region | Column Header | — | — | — | — | No | — | Always | — | — | 15% width. | R1 |
| S2.6.4 | 1.0 | Column Headers | Task | Column Header | — | — | — | — | No | — | Always | — | — | Flex-1 width. Clipboard icon. | R1 |
| S2.6.5 | 1.0 | Column Headers | Status | Column Header | — | — | — | — | No | — | Always | — | — | 130px width. | R1 |
| S2.6.6 | 1.0 | Team Sections | Section Header | Collapsible Row | String | — | section | — | No | — | Always | Collapsed | — | Expandable section per team with member count badge. Teams: Group Underwriting, Finance, Claims, Risk Management, Cat Modeling, Underwriting Leadership. | R1 |
| S2.6.7 | 1.0 | Member Rows | Name | Display | String | 50 | name | — | No | — | When expanded | — | "Artur Klinger" | Indented members shown with "└" prefix. Bold for leads, regular for sub-members. | R1 |
| S2.6.8 | 1.0 | Member Rows | Region | Badge | String | 30 | region | — | No | — | Conditional | — | "International Treaty" | Shown as styled badge. Slate-200 for leads, gray-100 for indented members. Shows "—" if no region. | R1 |
| S2.6.9 | 1.0 | Member Rows | Task | Badge | String | 100 | task | — | No | — | Conditional | — | "Regional loss estimation" | Blue badge. Shows "Notification only" in gray if no task assigned. | R1 |
| S2.6.10 | 1.0 | Member Rows | Status | Status Badge | Enum | — | status | Status Typelist | No | — | When expanded | — | "In Progress" | Color-coded status badge. | R1 |

### Status Typelist
| Value | Style |
|---|---|
| Not Started | bg-gray-100 text-gray-500 |
| In Progress | bg-amber-50 text-amber-700 |
| Pending Review | bg-purple-50 text-purple-700 |
| Completed | bg-green-100 text-green-700 |

### Business Rules
- **BR-S2.6.01:** This section is read-only; participant assignments are configured in the Deadlines & Tracking step.
- **BR-S2.6.02:** All sections are collapsed by default.
- **BR-S2.6.03:** Member count badge appears next to each section header.
