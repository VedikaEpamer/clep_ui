# S3.8 - Event Detail: Documents

**Screen:** Documents Repository
**File:** `/components/event-detail/Documents.tsx`
**Route:** `/events/:eventId/documents`
**Description:** Document management for event-related files. Upload, download, preview, and delete documents with category filtering and search.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.8.1 | 1.0 | Header | Documents | Page Title | — | — | — | — | No | — | Always | — | "Documents" | Page header. | R1 |
| S3.8.2 | 1.0 | Header Actions | Upload Document | Button | — | — | — | — | Yes | — | Always | — | — | Opens file upload dialog. | R1 |
| S3.8.3 | 1.0 | Filters | Search | Text Input | String | 100 | — | — | Yes | No | Always | "" | "Model Output" | Filters documents by name. | R1 |
| S3.8.4 | 1.0 | Filters | Category Filter | Dropdown | String | — | — | Category Typelist | Yes | No | Always | "All Categories" | "Model Output" | Filters by document category. | R1 |
| S3.8.5 | 1.0 | Document Table | Name | Column | String | 200 | name | — | No | — | Always | — | "Hurricane_Milton_UW_Estimates_v3.xlsx" | File name with type icon. | R1 |
| S3.8.6 | 1.0 | Document Table | Category | Column / Badge | String | 30 | category | Category Typelist | No | — | Always | — | "Underwriting Estimate" | Colored category badge. | R1 |
| S3.8.7 | 1.0 | Document Table | Uploaded By | Column | String | 50 | uploadedBy | — | No | — | Always | — | "Sarah Johnson" | User who uploaded. | R1 |
| S3.8.8 | 1.0 | Document Table | Upload Date | Column | DateTime | 20 | uploadedAt | — | No | — | Always | — | "2024-11-28 14:32" | Upload timestamp. | R1 |
| S3.8.9 | 1.0 | Document Table | Size | Column | String | 10 | size | — | No | — | Always | — | "2.4 MB" | File size. | R1 |
| S3.8.10 | 1.0 | Document Table | Actions | Column | Button Group | — | — | — | Yes | — | Always | — | — | Preview (Eye), Download, Delete (Trash). | R1 |

### Category Typelist
All Categories, Model Output, Underwriting Estimate, Contract Set, Supporting Document, Regulatory Filing, Audit Trail

### Business Rules
- **BR-S3.8.01:** Search filters by document name (case-insensitive).
- **BR-S3.8.02:** Category filter is additive with search.
- **BR-S3.8.03:** Delete shows confirmation before removing.
- **BR-S3.8.04:** File type icon based on extension (excel, pdf, etc.).
