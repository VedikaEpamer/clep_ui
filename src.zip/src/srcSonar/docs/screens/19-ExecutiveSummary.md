# S3.5 - Event Detail: Executive Summary

**Screen:** Executive Summary
**File:** `/components/event-detail/ExecutiveSummary.tsx`
**Route:** Embedded in Event Overview (Executive tab)
**Description:** High-level executive dashboard with waterfall chart, BU breakdown charts, top cedents/contracts tables, BU completion status, and key financial ratios. All data derived from props.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.5.1 | 1.0 | KPI Cards | Total Gross Loss | Display | Currency | — | totalGross | — | No | — | Always | Computed | "$85.2M" | Sum of all BU grossEst. Formatted: K/M/B. | R1 |
| S3.5.2 | 1.0 | KPI Cards | Net Loss | Display | Currency | — | totalNet | — | No | — | Always | Computed | "$42.1M" | Sum of all BU netEst. | R1 |
| S3.5.3 | 1.0 | KPI Cards | Net of Logan | Display | Currency | — | netOfLogan | — | No | — | Always | Computed | "$72.4M" | totalGross x LOGAN_RETENTION (0.85). | R1 |
| S3.5.4 | 1.0 | KPI Cards | Logan Cession | Display | Currency | — | loganCession | — | No | — | Always | Computed | "$12.8M" | totalGross - netOfLogan. | R1 |
| S3.5.5 | 1.0 | KPI Cards | Recovery Rate | Display | Percentage | — | recoveryRate | — | No | — | Always | Computed | "50.6%" | (totalGross - totalNet) / totalGross x 100. | R1 |
| S3.5.6 | 1.0 | KPI Cards | Loss Ratio | Display | Percentage | — | lossRatio | — | No | — | Always | Computed | "8.4%" | totalGross / totalExposure x 100. | R1 |
| S3.5.7 | 1.0 | KPI Cards | Total Contracts | Display | Number | — | totalContracts | — | No | — | Always | Computed | 24 | Sum of all BU uwCount. | R1 |
| S3.5.8 | 1.0 | KPI Cards | BU Completion | Display | Fraction | — | completedBUs | — | No | — | Always | Computed | "4/8" | Count of BUs with status = 'Complete'. | R1 |
| S3.5.9 | 1.0 | Charts | Waterfall Chart | Recharts Bar | — | — | — | — | No | — | Always | — | — | 4 bars: Gross Loss (red), Logan Cession (orange, negative), Net of Logan (blue), Net Loss (navy). | R1 |
| S3.5.10 | 1.0 | Charts | BU Breakdown | Recharts Bar | — | — | — | — | No | — | Always | — | — | Horizontal bar chart by business unit. | R1 |
| S3.5.11 | 1.0 | Tables | Top Cedents | Table | — | — | top10Companies | — | No | — | Conditional | — | — | Shows top cedents by exposure. Requires hasContracts=true. | R1 |
| S3.5.12 | 1.0 | Tables | Top Contracts | Table | — | — | top10Deals | — | No | — | Conditional | — | — | Shows top contracts by exposure. Requires hasContracts=true. | R1 |
| S3.5.13 | 1.0 | Status | BU Status Grid | Card Grid | — | — | marketEstimates | — | No | — | Always | — | — | Per-BU card showing completion status and estimate totals. | R1 |
| S3.5.14 | 1.0 | Ratios | Key Ratios Panel | Display Grid | — | — | — | — | No | — | Always | — | — | Derived financial ratios and metrics. | R1 |

### Collapsible Sections
waterfall, buPie, buBar, cedents, contracts, buStatus, ratios — all expanded by default.

### Business Rules
- **BR-S3.5.01:** All values are derived (computed) from props — no editable fields.
- **BR-S3.5.02:** LOGAN_RETENTION = 0.85 applied globally.
- **BR-S3.5.03:** Currency formatting: >= 1000M shows "B", >= 1M shows "M", >= 1K shows "K".
- **BR-S3.5.04:** Top Cedents/Contracts tables only render if hasContracts = true.
