# S4.1 - Comment Thread

**Screen:** Comment Thread (Reusable Component)
**File:** `/components/CommentThread.tsx`
**Context:** `/lib/commentContext.tsx`
**Description:** Displays a threaded comment list with team badges, timestamps, attachments, and visibility indicators. Used across Event Overview, CAT Estimation Summary, and other screens.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S4.1.1 | 1.0 | Comment | Author Name | Display | String | 50 | author | — | No | — | Always | — | "Sarah Mitchell" | Comment author. | R1 |
| S4.1.2 | 1.0 | Comment | Team Badge | Badge | String | 30 | team | Team Slug Typelist | No | — | When showTeamBadge=true | — | "Latin America / Brazil Treaty" | Color-coded team badge. Slug mapped to display name. | R1 |
| S4.1.3 | 1.0 | Comment | Timestamp | Display | String | 20 | createdAt | — | No | — | Always | — | "2h ago" | Relative time: "Just now", "Xm ago", "Xh ago", "Xd ago", or formatted date. | R1 |
| S4.1.4 | 1.0 | Comment | Content | Display | String | 5000 | content | — | No | — | Always | — | "Updated loss estimate..." | Comment text content. | R1 |
| S4.1.5 | 1.0 | Comment | Attachments | Display | Array[String] | — | attachments | — | No | — | Conditional | — | "model_output.xlsx" | File attachment badges with paperclip icon. | R1 |
| S4.1.6 | 1.0 | Comment | Visibility | Badge | Enum | — | visibility | Visibility Typelist | No | — | Conditional | — | "Team Only" | Lock icon for restricted visibility. | R1 |
| S4.1.7 | 1.0 | Empty State | No Comments | Display | — | — | — | — | No | — | When 0 comments | — | — | MessageSquare icon + "No comments yet" + helper text. | R1 |

### Team Slug -> Display Name Map
(Same as EventOverview-NEW teamDisplayNames — see S3.0 doc)

### Known Issues (Stale References)
- Team slug map still contains `engineering`, `cyber`, `renewable-energy` — pending cleanup.

### Business Rules
- **BR-S4.1.01:** Timestamps use relative formatting (< 1m = "Just now", < 60m = "Xm ago", < 24h = "Xh ago", < 7d = "Xd ago", else formatted date).
- **BR-S4.1.02:** Team badge colors are mapped per team slug.
