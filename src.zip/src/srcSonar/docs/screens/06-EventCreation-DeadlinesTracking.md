# S2.5 - Event Creation: Deadlines & Operational Tracking

**Screen:** Event Creation - Step 5
**File:** `/components/event-creation/DeadlinesTracking.tsx`
**Route:** `/create-event` (section 5)
**Description:** Define the operational timeline for the event and determine when the workflow officially begins. Configure notification recipients.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.5.1 | 1.0 | Workflow Kickoff | Track Immediately - Kick Off Workflow | Checkbox | Boolean | — | trackImmediately | — | Yes | No | Always | false | true | Blue highlight panel. Activates event immediately after publishing, starts countdown for deadlines, triggers notifications. | R1 |
| S2.5.2 | 1.0 | Operational Summary | Operational Summary | Textarea | String | 5000 | operationalSummary | — | Yes | No | Always | "" | "Urgent - Board reporting required within 48 hours" | 3 rows. Placeholder: "Describe urgency, special instructions, and sensitivity considerations..." | R1 |
| S2.5.3 | 1.0 | Workflow Deadlines | High-Level Exposure Estimates Deadline | DateTime Picker | DateTime (ISO) | 20 | deadline1 | — | Yes | No | Always | "" | "2024-10-12T18:00" | HTML datetime-local input. | R1 |
| S2.5.4 | 1.0 | Workflow Deadlines | Contract-Level Estimates Deadline | DateTime Picker | DateTime (ISO) | 20 | deadline2 | — | Yes | No | Always | "" | "2024-10-15T18:00" | HTML datetime-local input. | R1 |
| S2.5.5 | 1.0 | Workflow Deadlines | Reserving Extract Deadline | DateTime Picker | DateTime (ISO) | 20 | deadline3 | — | Yes | No | Always | "" | "2024-10-18T18:00" | HTML datetime-local input. | R1 |
| S2.5.6 | 1.0 | Workflow Deadlines | CAT Model Run Updates Deadline | DateTime Picker | DateTime (ISO) | 20 | deadline4 | — | Yes | No | Always | "" | "2024-10-20T18:00" | HTML datetime-local input. | R1 |
| S2.5.7 | 1.0 | Notification Recipients | Select Recipients to Notify | Grouped Checkbox List | Array[String] | — | selectedRecipients | Org Hierarchy | Yes | No | Always | All names selected | — | Collapsible sections by team. Section headers have select-all checkbox with indeterminate state. Counter: "N of M selected". "Select All" / "Deselect All" buttons. | R1 |

### Notification Groups
| Section | Members |
|---|---|
| Group Underwriting | Reena Boltax, Chris Downey |
| Finance | Clem Demetz, Nigel Smith, Tim Ritter |
| Claims | Andrew McBride, Lope Garcia, Tim Carter (indent), James Parker (indent), Barbara Toro (indent), Patricia McMahon (indent) |
| Risk Management | Atilla Kerenyi, Nick Dimuzio, Kathy Garrigan |
| Cat Modeling | Neil Schwarzenberger, Huy Hong |
| Underwriting Leadership | Jill Beggs (CUO), Mike Cellura (Facultative), Juan Delgado (Fac, indent), Nicholas Pozzebon (Fac, indent), Artur Klinger (Intl Treaty), Harad Jacobsen (Zurich/Dublin, indent), Rui Marliere (Latam, indent), Mark Wallace (London, indent), Melissa Ford (Middle East, indent), Kevin Bogardus (Singapore, indent), Jiten Voralia (NA Treaty), Peter Bell (Bermuda, indent), Scott Paddington (Canada, indent), Mayur Doshi (Treaty Casualty, indent), Chuck Volker (Treaty Property, indent), Emily Davis (Specialty), Tim Hewer (Aviation, indent), Wesley Zeliff (Marine, indent), Jonathan Mesagaes (Renewable Energy, indent), Catherine Rudow (Cyber, indent), Alex Haines (Engineering, indent), Erick Davidson (Parametric, indent), Levi Mayer (Financial Lines), Marco Schiattone (Mortgage, indent) |

### Business Rules
- **BR-S2.5.01:** All recipients are selected by default on initial load.
- **BR-S2.5.02:** Section header checkbox shows indeterminate state when some (not all) members are selected.
- **BR-S2.5.03:** Sections are collapsed by default, expandable via chevron toggle.
- **BR-S2.5.04:** "Track Immediately" determines if workflow starts on publish or remains in draft.
