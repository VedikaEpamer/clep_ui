# S2.1 - Event Creation: Event Identity & Core Metadata

**Screen:** Event Creation - Step 1
**File:** `/components/event-creation/EventIdentity.tsx`
**Route:** `/create-event` (section 1)
**Description:** Captures foundational information that uniquely identifies the event and enables validation logic, notifications, and workflow routing.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S2.1.1 | 1.0 | Event Identity | Event Status | Text (Disabled) | String | 20 | status | Status Typelist | No | No | Always | "Draft" | "Draft" | Auto-populated. Updates automatically as workflow progresses. Disabled input. | R1 |
| S2.1.2 | 1.0 | Event Identity | Event ID (Auto-Generated) | Text (Disabled) | String | 20 | eventId | — | No | No | Always | Auto-generated | "EVT-2024-013" | System-generated unique identifier. Format: EVT-YYYY-NNN. Disabled input. | R1 |
| S2.1.3 | 1.0 | Event Identity | CAT code-Headline Loss code | Text Input | String | 30 | catCode | — | Yes | No | Always | "" | "CAT-2024-US-001" | Optional. Free-text. Placeholder: "e.g., CAT-2024-US-001" | R1 |
| S2.1.4 | 1.0 | Event Identity | Type of Everest Event | Custom Dropdown | String | 20 | everestEventType | Everest Event Type Typelist | Yes | Yes | Always | "" | "NAT CAT" | Required. When changed: auto-sets eventType and premiumAllocation. If "NAT CAT" selected, eventType auto-sets to "Natural Catastrophe" and premiumAllocation to "Premium Allocated". If "Man Made CAT", eventType clears and premiumAllocation sets to "Premium Not Allocated". Also clears eventSubType. | R1 |
| S2.1.5 | 1.0 | Event Identity | Event Name | Text Input | String | 200 | eventName | — | Yes | Yes | Always | "" | "Hurricane Milton" | Required. Full-width (col-span-2). Placeholder: "e.g., Hurricane Milton" | R1 |
| S2.1.6 | 1.0 | Event Identity | Event Type | Custom Dropdown | String | 50 | eventType | Event Type Typelist | Yes | Yes | Always | "" | "Natural Catastrophe" | Required. When changed: clears eventSubType. Auto-sets premiumAllocation ("Natural Catastrophe" -> "Premium Allocated", others -> "Premium Not Allocated"). | R1 |
| S2.1.7 | 1.0 | Event Identity | Event Sub-Type | Custom Dropdown | String | 50 | eventSubType | Event Sub-Type Typelist | Yes | Yes | Always | "" | "Hurricane" | Required. Options are dynamically filtered based on selected Event Type. If Event Type changes, this resets to empty. Should auto-default to first available sub-type (pending fix). | R1 |
| S2.1.8 | 1.0 | Event Identity | Product | Multi-Select Dropdown | Array[String] | — | businessGroups | Product Typelist | Yes | Yes | Always | [] | ["International Treaty", "NA Treaty"] | Required. Multi-checkbox dropdown with Select All / Deselect All. Shows badge count: "+N more" when >2 selected. | R1 |
| S2.1.9 | 1.0 | Event Identity | Loss Start Date | Date Picker | Date (ISO) | 10 | lossStartDate | — | Yes | Yes | Always | "" | "2024-10-09" | Required. HTML date input. | R1 |
| S2.1.10 | 1.0 | Event Identity | Loss End Date | Date Picker | Date (ISO) | 10 | lossEndDate | — | Yes | Yes | Always | "" | "2024-10-12" | Required. HTML date input. Validation: must be >= Loss Start Date. | R1 |
| S2.1.11 | 1.0 | Event Identity | Short Description | Text Input | String | 500 | shortDescription | — | Yes | No | Always | "" | "Category 5 hurricane making landfall in Florida" | Optional. Full-width. Placeholder: "Brief description of the event" | R1 |
| S2.1.12 | 1.0 | Event Identity | Long Description | Textarea | String | 5000 | longDescription | — | Yes | No | Always | "" | "Hurricane Milton formed in the Gulf of Mexico..." | Optional. 4 rows. Full-width. Placeholder: "Detailed description including scope, impact areas, and key details" | R1 |

### Everest Event Type Typelist
| Value | Label |
|---|---|
| NAT CAT | NAT CAT |
| Man Made CAT | Man Made CAT |

### Event Type Typelist
| Value | Label |
|---|---|
| Natural Catastrophe | Natural Catastrophe |
| Large Loss (Single Risk) | Large Loss (Single Risk) |
| Casualty Event | Casualty Event |
| Cyber | Cyber |
| Financial / Credit | Financial / Credit |
| Pandemic / Biological | Pandemic / Biological |
| War & Terror | War & Terror |

### Event Sub-Type Typelist (by Event Type)

**Natural Catastrophe:** Hurricane, Earthquake, Flood, Wildfire, Wind - Non Hurricane, Hail, Tornado, Tsunami, Drought, Volcano

**Large Loss (Single Risk):** Major Fire, Factory / Plant Explosion, Energy / Offshore Loss, Large Construction Loss, Mining Loss, Power Generation Loss, Airplane Crash, Dam Collapse, Train Derailment, Ship Collision, Ship Sinking, Ship Grounding, Airplane Grounding

**Casualty Event:** Product Liability, Product Recall, Architect / Design, Motor Liability, Mal Practice Liability

**Cyber:** Ransomware, Malware, Virus, Terrorist Attack

**Financial / Credit:** Bank Bankruptcy, Other Financial Institution Bankruptcy, Non Financial Bankruptcy, Economic Downturn, D&O / E&O, Reps & Warranties, Credit/Surety Default, Expropriation, Governmental Actions, Fraud

**Pandemic / Biological:** Epidemic (One Country), Pandemic (Several Countries)

**War & Terror:** SRCC, Political Violence, Terrorist Attack, War

### Product Typelist
International Treaty, NA Treaty, Facultative, Specialty, Financial Lines

### Business Rules
- **BR-S2.1.01:** When `everestEventType` = "NAT CAT", auto-set `eventType` = "Natural Catastrophe" and `premiumAllocation` = "Premium Allocated".
- **BR-S2.1.02:** When `everestEventType` = "Man Made CAT", clear `eventType` and set `premiumAllocation` = "Premium Not Allocated".
- **BR-S2.1.03:** Changing `eventType` always clears `eventSubType`.
- **BR-S2.1.04:** `eventSubType` options are dynamically filtered by the current `eventType`.
- **BR-S2.1.05:** `premiumAllocation` is auto-set: "Natural Catastrophe" -> "Premium Allocated", all others -> "Premium Not Allocated".
- **BR-S2.1.06 (Pending):** `eventSubType` should auto-default to the first available sub-type instead of clearing to empty.