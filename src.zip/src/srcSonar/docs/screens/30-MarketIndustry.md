# S3.10 - Event Detail: Market & Industry Loss

**Screen:** Market & Industry Loss (Event Detail Tab)
**File:** `/components/event-detail/MarketIndustry.tsx`
**Route:** `/events/:eventId/market`
**Description:** Market-facing view of industry loss estimates from external sources with Everest consensus. Extends the MarketLoss component from event creation with pre-populated sample data for active events.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.10.1 | 1.0 | External Sources | Source Table | Editable Table | — | — | marketSources | Market Source Typelist | Yes | No | Always | Sample data | — | Pre-populated with sample sources (Swiss Re, Munich Re, PCS, AIR, etc.) for demo. Same structure as MarketLoss (S2.3). | R1 |
| S3.10.2 | 1.0 | External Sources | Source | Dropdown | String | 30 | source | Market Source Typelist | Yes | No | Per row | — | "Swiss Re" | Same as S2.3.1. | R1 |
| S3.10.3 | 1.0 | External Sources | Low/Best/High ($M) | Currency Input | Decimal | 15 | lowEstimate/medEstimate/highEstimate | — | Yes | No | Per row | — | "6,000 / 8,000 / 10,000" | Same as S2.3.3-5. | R1 |
| S3.10.4 | 1.0 | External Sources | As-of Date | Date Picker | Date | 10 | asOfDate | — | Yes | No | Per row | — | "2024-12-01" | Same as S2.3.6. | R1 |
| S3.10.5 | 1.0 | External Sources | Notes | Text Input | String | 500 | notes | — | Yes | No | Per row | — | "Preliminary estimate" | Same as S2.3.7. | R1 |

### Business Rules
- **BR-S3.10.01:** Same field structure and validation as MarketLoss (S2.3).
- **BR-S3.10.02:** Pre-populated with sample external source data for demo purposes.
- **BR-S3.10.03:** Includes consensus section with lock/unlock (same as S2.3.11-16).
