# S3.9 - Event Detail: Audit Log

**Screen:** Audit Log
**File:** `/components/event-detail/AuditLog.tsx`
**Route:** `/events/:eventId/audit`
**Description:** Comprehensive audit trail of all actions performed on the event. Filterable and searchable timeline with action type icons, user details, and change details.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.9.1 | 1.0 | Header | Audit Log | Page Title | — | — | — | — | No | — | Always | — | "Audit Log" | Page header. | R1 |
| S3.9.2 | 1.0 | Filters | Search | Text Input | String | 100 | — | — | Yes | No | Always | "" | "upload" | Filters by description or user. | R1 |
| S3.9.3 | 1.0 | Filters | Action Type Filter | Dropdown | String | — | — | Action Type Typelist | Yes | No | Always | "All" | "upload" | Filters by action type. | R1 |
| S3.9.4 | 1.0 | Log Entry | Timestamp | Display | DateTime | 20 | timestamp | — | No | — | Always | — | "2024-12-01 14:32:00" | ISO timestamp formatted. | R1 |
| S3.9.5 | 1.0 | Log Entry | User | Display | String | 50 | user | — | No | — | Always | — | "Sarah Johnson" | User who performed action. | R1 |
| S3.9.6 | 1.0 | Log Entry | User Role | Display | String | 30 | userRole | — | No | — | Always | — | "UW Lead" | Role at time of action. | R1 |
| S3.9.7 | 1.0 | Log Entry | Action | Icon + Badge | Enum | — | action | Action Type Typelist | No | — | Always | — | "Upload" | Color-coded icon + label. | R1 |
| S3.9.8 | 1.0 | Log Entry | Description | Display | String | 500 | description | — | No | — | Always | — | "Uploaded UW estimate file" | Human-readable description. | R1 |
| S3.9.9 | 1.0 | Log Entry | Details | Expandable | Object | — | details | — | No | — | Conditional | — | — | Shows field, oldValue, newValue, fileName, affectedContracts, assignedTo, reason. | R1 |
| S3.9.10 | 1.0 | Log Entry | IP Address | Display | String | 15 | ipAddress | — | No | — | Conditional | — | "192.168.1.100" | Client IP (when available). | R1 |

### Action Type Typelist
| Value | Icon | Color | Label |
|---|---|---|---|
| upload | Upload | text-blue-600 bg-blue-50 | Upload |
| delete | Trash2 | text-red-600 bg-red-50 | Delete |
| validation | CheckCircle | text-green-600 bg-green-50 | Validation |
| approval | CheckCircle | text-green-600 bg-green-50 | Approval |
| rejection | XCircle | text-red-600 bg-red-50 | Rejection |
| assignment | UserPlus | text-purple-600 bg-purple-50 | Assignment |
| status_change | Edit | text-amber-600 bg-amber-50 | Status Change |
| report_generation | FileText | text-indigo-600 bg-indigo-50 | Report |
| data_change | Edit | — | Data Change |

### Business Rules
- **BR-S3.9.01:** Entries sorted newest first.
- **BR-S3.9.02:** Details panel shows field-level diff when available (old value -> new value).
- **BR-S3.9.03:** All actions are immutable audit records.
