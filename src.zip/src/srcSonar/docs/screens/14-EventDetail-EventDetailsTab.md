# S3.1 - Event Detail: Event Details Tab

**Screen:** Event Detail - Details Tab (Edit Mode)
**File:** `/components/event-detail/EventDetailsTab.tsx`
**Route:** `/events/:eventId` (default tab)
**Description:** Read/Edit view of all event creation data. Reuses EventIdentity, ImpactRegionsPerils, OtherIds, MarketLoss, DeadlinesTracking, and EventParticipantsSection components in view or edit mode.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.1.1 | 1.0 | Controls | Edit / Save / Cancel | Button Group | — | — | — | — | Conditional | — | Role-based | View mode | — | Edit button visible when canEdit=true and not currently editing. Save/Cancel appear in edit mode. | R1 |
| S3.1.2 | 1.0 | Event Data | eventId | State | String | 20 | eventId | — | — | — | — | From event | "EVT-2024-001" | Loaded from event prop. | R1 |
| S3.1.3 | 1.0 | Event Data | catCode | State | String | 30 | catCode | — | Conditional | No | Always | From event | "CAT-2024-US-001" | Editable in edit mode. | R1 |
| S3.1.4 | 1.0 | Event Data | eventName | State | String | 200 | eventName | — | Conditional | Yes | Always | From event | "Hurricane Milton" | Editable in edit mode. Required. | R1 |
| S3.1.5 | 1.0 | Event Data | eventType | State | String | 50 | eventType | Event Type Typelist | Conditional | Yes | Always | From event | "Natural Catastrophe" | Editable in edit mode. | R1 |
| S3.1.6 | 1.0 | Event Data | peril | State | String | 50 | peril | — | — | — | Always | From event | — | Legacy field reference (pending cleanup). | R1 |
| S3.1.7 | 1.0 | Event Data | lossStartDate | State | Date | 10 | lossStartDate | — | Conditional | Yes | Always | From event | "2024-10-09" | Editable in edit mode. | R1 |
| S3.1.8 | 1.0 | Event Data | lossEndDate | State | Date | 10 | lossEndDate | — | Conditional | Yes | Always | From event | "2024-10-12" | Editable in edit mode. | R1 |
| S3.1.9 | 1.0 | Event Data | premiumAllocation | State | String | 30 | premiumAllocation | — | — | — | Always | From event | "Premium Allocated" | May still have references (pending cleanup). Auto-set based on eventType. | R1 |
| S3.1.10 | 1.0 | Event Data | businessGroups | State | Array[String] | — | businessGroups | Product Typelist | Conditional | Yes | Always | From event | ["Intl Treaty", "NA Treaty"] | Multi-select. | R1 |
| S3.1.11 | 1.0 | Event Data | impactedCountries | State | Array[String] | — | impactedCountries | RDM Hierarchy | Conditional | Yes | Always | From event | ["United States"] | Hierarchical tree selector. | R1 |
| S3.1.12 | 1.0 | Event Data | impactedStates | State | Array[String] | — | impactedStates | US States | Conditional | No | Always | From event | ["Florida"] | US state-level selections. | R1 |
| S3.1.13 | 1.0 | Event Data | marketLossLow | State | Decimal | 15 | marketLossLow | — | Conditional | No | Always | From event | "30,000" | Consensus low estimate. | R1 |
| S3.1.14 | 1.0 | Event Data | marketLossMed | State | Decimal | 15 | marketLossMed | — | Conditional | No | Always | From event | "40,000" | Consensus best estimate. | R1 |
| S3.1.15 | 1.0 | Event Data | marketLossHigh | State | Decimal | 15 | marketLossHigh | — | Conditional | No | Always | From event | "55,000" | Consensus high estimate. | R1 |
| S3.1.16 | 1.0 | Event Data | severityLevel | State | Enum | — | severityLevel | Severity Typelist | Conditional | No | Always | From event | "major" | Severity selection. | R1 |
| S3.1.17 | 1.0 | Event Data | externalIds | State | Array[Object] | — | externalIds | — | Conditional | No | Always | From event | [{name: "PCS", value: "1234"}] | External identifier entries. | R1 |
| S3.1.18 | 1.0 | Event Data | marketSources | State | Array[Object] | — | marketSources | — | Conditional | No | Always | From event | [{source: "Swiss Re", ...}] | Market source entries. | R1 |
| S3.1.19 | 1.0 | Event Data | deadline1-4 | State | DateTime | 20 | deadline1..4 | — | Conditional | No | Always | From event | "2024-10-12T18:00" | Workflow deadline timestamps. | R1 |
| S3.1.20 | 1.0 | Event Data | trackImmediately | State | Boolean | — | trackImmediately | — | Conditional | No | Always | From event | true | Workflow kickoff flag. | R1 |
| S3.1.21 | 1.0 | Event Data | operationalSummary | State | String | 5000 | operationalSummary | — | Conditional | No | Always | From event | "Urgent tracking" | Operational notes. | R1 |

### Sections Rendered (reused components)
1. EventIdentity (S2.1)
2. ImpactRegionsPerils (S2.2)
3. OtherIds (S2.4)
4. MarketLoss (S2.3)
5. DeadlinesTracking (S2.5)
6. EventParticipantsSection (S2.6)

### Business Rules
- **BR-S3.1.01:** Edit mode is controlled by `canEdit` prop (role-based) and `isEditing` state.
- **BR-S3.1.02:** Save triggers toast notification "Event details updated successfully".
- **BR-S3.1.03:** Cancel exits edit mode without saving changes.
- **BR-S3.1.04:** Supports both internal and external edit state management (via props or internal useState).
- **BR-S3.1.05 (Pending):** `premiumAllocation` references may still exist and need cleanup.
- **BR-S3.1.06 (Pending):** `peril` field is a legacy reference that may need cleanup.