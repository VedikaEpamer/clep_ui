# S4.2 - Task Inbox

**Screen:** Task Inbox (Header Popover)
**File:** `/components/TaskInbox.tsx`
**Context:** `/lib/taskContext.tsx`
**Description:** Slide-out task panel accessible from the header. Shows pending and completed tasks for the current user, with click-through navigation to relevant event screens.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S4.2.1 | 1.0 | Header | Task Inbox Toggle | Icon Button | — | — | — | — | Yes | — | Always | — | — | Inbox icon with unread count badge. Toggles slide-out panel. | R1 |
| S4.2.2 | 1.0 | Panel | Pending Tasks | Task List | — | — | pendingTasks | — | No | — | Always | — | — | Tasks with status = 'pending' or 'in-progress'. | R1 |
| S4.2.3 | 1.0 | Panel | Completed Tasks | Task List | — | — | completedTasks | — | No | — | Always | — | — | Tasks with status = 'completed'. | R1 |
| S4.2.4 | 1.0 | Task Card | Title | Display | String | 200 | title | — | No | — | Always | — | "Review UW estimates for Hurricane Milton" | Task description. | R1 |
| S4.2.5 | 1.0 | Task Card | Event Name | Display | String | 100 | eventName | — | No | — | Always | — | "Hurricane Milton" | Associated event. | R1 |
| S4.2.6 | 1.0 | Task Card | Priority | Badge | Enum | — | priority | Priority Typelist | No | — | Always | — | "High" | Color-coded priority badge. | R1 |
| S4.2.7 | 1.0 | Task Card | Status | Badge | Enum | — | status | Status Typelist | No | — | Always | — | "In Progress" | Task completion status. | R1 |

### Priority Typelist
| Value | Style |
|---|---|
| high | text-red-600 bg-red-50 border-red-200 |
| medium | text-amber-600 bg-amber-50 border-amber-200 |
| low | text-slate-600 bg-slate-50 border-slate-200 |

### Task Type -> Navigation
| Task Type | Target Route |
|---|---|
| assignment | /events/{eventId}/overview |
| estimation | /events/{eventId}/uw-estimation |
| approval | /events/{eventId}/uw-estimation |
| modeling | /events/{eventId}/cat-modeling |
| (default) | /events/{eventId}/overview |

### Role -> User Mapping
| Role | User Name |
|---|---|
| Administrator | David Chen |
| Event Coordinator | Andrew McBride |
| Finance Contributor | Clem Demetz |
| CAT Contributor | Neil Schwarzenberger |
| UW Contributor | Thomas Brennan |
| Sub Unit Lead | Juan Delgado |
| Unit Lead | Mike Cellura |
| Reader | Reena Boltax |

### Business Rules
- **BR-S4.2.01:** Clicking a task sets its status to 'in-progress' and navigates to the appropriate screen.
- **BR-S4.2.02:** Tasks are filtered by current user (based on active role).
- **BR-S4.2.03:** Panel closes after task click navigation.
