# S5.1 - Administration: Users Directory

**Screen:** Administration - Users Directory
**File:** `/components/admin/UsersDirectory.tsx`
**Route:** `/admin/users`
**Description:** Searchable directory of all SONAR platform users showing executive area, business unit, team, role, access level, and status. 50 user entries across 8 roles.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.1.1 | 1.0 | Header | Users Directory | Page Title | — | — | — | — | No | — | Always | — | "Users Directory" | Static header. | R1 |
| S5.1.2 | 1.0 | Search | Search Users | Text Input | String | 100 | — | — | Yes | No | Always | "" | "Artur" | Filters user list by name (case-insensitive substring match). | R1 |
| S5.1.3 | 1.0 | User Table | Executive Area | Column | String | 30 | executiveArea | Exec Area Typelist | No | — | Always | — | "International Treaty" | Executive area assignment. | R1 |
| S5.1.4 | 1.0 | User Table | Business Unit | Column | String | 30 | businessUnit | — | No | — | Always | — | "London" | Business unit within executive area. | R1 |
| S5.1.5 | 1.0 | User Table | Name | Column | String | 50 | name | — | No | — | Always | — | "Artur Klinger" | User full name. | R1 |
| S5.1.6 | 1.0 | User Table | Team | Column / Badge | String | 20 | team | Team Typelist | No | — | Always | — | "Underwriting" | Color-coded badge. | R1 |
| S5.1.7 | 1.0 | User Table | Role | Column | String | 30 | role | Role Typelist | No | — | Always | — | "Unit Lead" | SONAR role assignment. | R1 |
| S5.1.8 | 1.0 | User Table | Access | Column / Badge | String | 15 | access | Access Level Typelist | No | — | Always | — | "Contributor" | Color-coded access level badge. | R1 |
| S5.1.9 | 1.0 | User Table | Status | Column / Badge | Enum | — | status | Status Typelist | No | — | Always | — | "Active" | Green or gray badge. | R1 |

### Executive Area Typelist
Administration, Cat Modeling, Claims, Finance, Group Underwriting, Facultative, International Treaty, North America Treaty, Specialty, Financial Lines, Risk Management

### Team Typelist
| Value | Badge Color |
|---|---|
| Admin | bg-red-100 text-red-700 |
| CAT | bg-purple-100 text-purple-700 |
| Claim | bg-orange-100 text-orange-700 |
| Finance | bg-green-100 text-green-700 |
| Management | bg-slate-200 text-slate-700 |
| Underwriting | bg-blue-100 text-blue-700 |

### Role Typelist
Administrator, Event Coordinator, Finance Contributor, CAT Contributor, UW Contributor, Business Unit Lead, Unit Lead, Reader

### Access Level Typelist
| Value | Badge Color |
|---|---|
| Admin | bg-red-100 text-red-700 |
| Coordinator | bg-orange-50 text-orange-700 |
| Contributor | bg-blue-50 text-blue-700 |
| Reader | bg-gray-100 text-gray-600 |

### Status Typelist
| Value | Badge Color |
|---|---|
| Active | bg-green-100 text-green-700 |
| Inactive | bg-gray-100 text-gray-500 |

### User Count Summary (50 total)
| Executive Area | Count |
|---|---|
| Administration | 1 |
| Cat Modeling | 2 |
| Claims | 6 |
| Finance | 3 |
| Group Underwriting | 3 |
| Facultative | 5 |
| International Treaty | 7 |
| North America Treaty | 6 |
| Specialty | 7 |
| Financial Lines | 4 |
| Risk Management | 4 |

### Known Issues
- **Stale entries (pending removal):** Jonathan Mesagaes/Renewable Energy (U033), Catherine Rudow/Cyber (U034), Alex Haines/Engineering (U035) — these business units were removed from the platform.

### Business Rules
- **BR-S5.1.01:** Risk Management users have team = "Management" (not "Underwriting").
- **BR-S5.1.02:** Search is case-insensitive on user name field.
