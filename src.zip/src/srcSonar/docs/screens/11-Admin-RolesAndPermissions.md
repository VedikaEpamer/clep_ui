# S5.2 - Administration: Roles & Permissions

**Screen:** Administration - Roles & Permissions
**File:** `/components/admin/RolesAndPermissions.tsx`
**Route:** `/admin/roles`
**Description:** Defines the 8 SONAR platform roles with their team assignments, access levels, descriptions, executive area scoping, and 9 permission columns.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S5.2.1 | 1.0 | Role Cards | Role Name | Display | String | 30 | name | — | No | — | Always | — | "Unit Lead" | Role display name. | R1 |
| S5.2.2 | 1.0 | Role Cards | Team | Badge | String | 20 | team | Team Typelist | No | — | Always | — | "Underwriting" | Team assignment badge. | R1 |
| S5.2.3 | 1.0 | Role Cards | Access Level | Badge | String | 15 | accessLevel | Access Level Typelist | No | — | Always | — | "Contributor" | Access level badge. | R1 |
| S5.2.4 | 1.0 | Role Cards | Description | Display | String | 500 | description | — | No | — | Always | — | "Scoped to Executive Area..." | Detailed role description with permissions summary. | R1 |
| S5.2.5 | 1.0 | Role Cards | Executive Areas | Display | Array[String] | — | executiveAreas | — | No | — | Always | — | ["Facultative", "International Treaty"] | Executive areas where this role applies. | R1 |
| S5.2.6 | 1.0 | Role Cards | User Count | Badge | Number | — | userCount | — | No | — | Always | — | 6 | Number of users assigned this role. | R1 |
| S5.2.7 | 1.0 | Role Cards | Is Lead | Display | Boolean | — | isLead | — | No | — | Conditional | — | true | Indicates if role is a lead/manager role. | R1 |
| S5.2.8 | 1.0 | Permissions Matrix | Permission Columns | Checkbox Grid | Boolean[] | — | permissions | Permission Typelist | No | — | Always | — | — | 9 permission columns displayed as check/x icons per role. | R1 |

### Role Definitions (8 Roles)
| Role | Team | Access Level | Exec Areas | User Count |
|---|---|---|---|---|
| Administrator | Admin | Admin | Administration | 1 |
| Event Coordinator | Claim | Coordinator | Claims | 6 |
| Finance Contributor | Finance | Coordinator | Finance | 3 |
| CAT Contributor | CAT | Contributor | Cat Modeling | 2 |
| Unit Lead | Underwriting | Contributor | Facultative, Intl Treaty, NA Treaty, Specialty, Financial Lines | 5 |
| Business Unit Lead | Underwriting / Management | Contributor | All UW exec areas + Risk Management | 20+ |
| UW Contributor | Underwriting | Contributor | All UW exec areas | 8 |
| Reader | Management | Reader | Group Underwriting | 3 |

### Permission Typelist (9 columns)
| Permission Key | Display Label | Description |
|---|---|---|
| read_all_priorities | Read All Priorities | Can view all priority events |
| read_all_units | Read All Units | Can view all business units |
| edit_finance | Edit Finance | Can edit Finance estimation tab |
| edit_cat | Edit CAT | Can edit CAT modeling tab |
| edit_uw | Edit UW | Can edit UW estimation tab |
| lock_estimates | Lock Estimates | Can lock/unlock estimate fields |
| reopen_estimate | Reopen Estimate | Can reopen closed/locked estimates |
| approve | Approve | Can approve estimates for sign-off |
| admin_override | Admin Override | Full system override capability |

### Access Level Typelist (4 Levels)
| Level | Scope |
|---|---|
| Admin | Full system access, all modules, all BUs |
| Coordinator | All BUs (read), edit Overview/Finance, create events, lock/reopen |
| Contributor | Scoped to executive area, edit assigned module |
| Reader | Read-only across all modules |

### Business Rules
- **BR-S5.2.01:** Administrator is the only role with `admin_override` permission.
- **BR-S5.2.02:** Only Administrator and Event Coordinator have `approve` permission.
- **BR-S5.2.03:** Reader role has no edit permissions — read-only across all modules.
- **BR-S5.2.04:** Risk Management team is "Management" (not "Underwriting").
