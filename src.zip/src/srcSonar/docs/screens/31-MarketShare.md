# S3.11 - Event Detail: Market Share Analysis

**Screen:** Market Share Analysis
**File:** `/components/event-detail/MarketShare.tsx`
**Route:** Embedded in Event Overview (Market tab)
**Description:** Placeholder screen for competitive positioning and market share breakdown. Displays summary KPIs and top competitor cards.

| UI Mock up ID | Version History | Section | Field Label | Field Type | Data Type | Field Length | Column1 | Typelist | Editable | Mandatory | Visible | Default Value | Sample Value | Notes, Conditions, Rules | Release |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S3.11.1 | 1.0 | Header | Market Share Analysis | Page Title | — | — | — | — | No | — | Always | — | "Market Share Analysis" | Header with event name subtitle. | R1 |
| S3.11.2 | 1.0 | Coming Soon | Placeholder | Display Panel | — | — | — | — | No | — | Always | — | — | Building2 icon + description text. | R1 |
| S3.11.3 | 1.0 | KPI Summary | Dream Re Market Share | Display | Percentage | 5 | — | — | No | — | Always | "15.3%" | "15.3%" | Static placeholder value. | R1 |
| S3.11.4 | 1.0 | KPI Summary | Industry Total | Display | Currency | 10 | — | — | No | — | Always | "$2.4B" | "$2.4B" | Static placeholder value. | R1 |
| S3.11.5 | 1.0 | KPI Summary | Rank | Display | Number | 3 | — | — | No | — | Always | "#4" | "#4" | Static placeholder value. | R1 |
| S3.11.6 | 1.0 | Competitors | Top Competitors | Card Grid | — | — | — | — | No | — | Always | — | — | 3 cards: Munich Re (18.7%), Swiss Re (16.9%), Hannover Re (15.8%). With up/down trend indicators. | R1 |

### Business Rules
- **BR-S3.11.01:** This is a placeholder/coming-soon screen. Data is static.
- **BR-S3.11.02:** Future release will include dynamic market share calculations.
