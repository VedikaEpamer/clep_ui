# SONAR Platform - RDM Impact Regions & Perils Codelist

**Module:** Impact Regions & Perils (ImpactRegionsPerils.tsx)
**Source:** Everest Re RDM Country Code Hierarchy
**Last Updated:** 2026-03-07
**Component Location:** `/components/event-creation/ImpactRegionsPerils.tsx`

---

## Dropdown Hierarchy

| Dropdown Name | Level | Code Pattern | Description |
|---|---|---|---|
| Broader Risk Zone | 1 | `X00` (e.g. A00, E00) | Top-level geographic area (continent/macro-region) |
| Risk Zone | 2 | `X_0` not `X00` (e.g. A10, E30) | Sub-region within a broader area |
| Main Risk Area | 3 | All other codes (e.g. A11, E57) | Country, state, or territory |
| Worldwide | 0 | `W__` codes (W00-W03) | Global scope qualifiers |

---

## Business Rules Summary

| Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|
| BR-IRP.001 | User selects a Main Risk Area (country) | Auto-selects parent Risk Zone + Broader Risk Zone + W00 Worldwide | Upward cascade on selection |
| BR-IRP.002 | User selects a Risk Zone | Auto-selects parent Broader Risk Zone | Upward cascade on selection |
| BR-IRP.003 | User clicks "Select All" in Broader Risk Zone dropdown | Selects all area codes AND cascades to select all child zones and countries | Full downward cascade |
| BR-IRP.004 | User clicks "Select All" in Risk Zone dropdown | Selects all zone codes AND cascades to select all child countries | Downward cascade |
| BR-IRP.005 | User clicks "Clear All" in Broader Risk Zone dropdown | Clears all areas AND cascades to clear child zones and countries | Full downward cascade |
| BR-IRP.006 | User clicks "Clear All" in Risk Zone dropdown | Clears all zones AND cascades to clear child countries | Downward cascade |
| BR-IRP.007 | User clicks master "Clear All" button | Clears all four dropdown states (countries, zones, areas, worldwide) | Master reset |
| BR-IRP.008 | User selects Broader Risk Zone(s) | Risk Zone dropdown filters to show only zones under selected areas; Main Risk Area filters to countries under selected areas | Cascading filter |
| BR-IRP.009 | User selects Risk Zone(s) | Main Risk Area dropdown filters to show only countries under selected zones | Cascading filter |
| BR-IRP.010 | No areas or zones selected | All zones and all countries are shown in their respective dropdowns | Default unfiltered |

---

## Full Codelist

### ASIA (A00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A00 | Broader Risk Zone | Geographic Classification | ASIA | 1 | All | All | Broader risk zone covering all Asian territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to A10/A20/A30/A40; filters Main Risk Area to all A-prefix countries | Parent area for all A-prefix codes |
| A10 | Risk Zone | Geographic Classification | NORTHEAST ASIA | 2 | All | All | Sub-region of Asia covering NE Asian nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects A00; filters Main Risk Area to A11-A18 | Parent zone for A11-A18 |
| A11 | Main Risk Area | Geographic Classification | CHINA | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 (zone) + A00 (area) + W00 (worldwide) | |
| A12 | Main Risk Area | Geographic Classification | HONG KONG | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A13 | Main Risk Area | Geographic Classification | JAPAN | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | High CAT exposure (earthquake, typhoon) |
| A14 | Main Risk Area | Geographic Classification | MACAU | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A15 | Main Risk Area | Geographic Classification | MONGOLIA | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A16 | Main Risk Area | Geographic Classification | NORTH KOREA | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A17 | Main Risk Area | Geographic Classification | SOUTH KOREA | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A18 | Main Risk Area | Geographic Classification | TAIWAN | 3 | All | All | Country-level entry under Northeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A10 + A00 + W00 | |
| A20 | Risk Zone | Geographic Classification | SOUTHEAST ASIA | 2 | All | All | Sub-region of Asia covering SE Asian nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects A00; filters Main Risk Area to A21-A2B | Parent zone for A21-A2B |
| A21 | Main Risk Area | Geographic Classification | BRUNEI | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A22 | Main Risk Area | Geographic Classification | MYANMAR | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A23 | Main Risk Area | Geographic Classification | CAMBODIA | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A24 | Main Risk Area | Geographic Classification | INDONESIA | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | High CAT exposure (earthquake, volcanic) |
| A25 | Main Risk Area | Geographic Classification | KAMPUCHEA, DEMOCRATIC RE | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | Legacy name |
| A26 | Main Risk Area | Geographic Classification | LAOS | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A27 | Main Risk Area | Geographic Classification | MALAYSIA | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A28 | Main Risk Area | Geographic Classification | PHILIPPINES | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | High CAT exposure (typhoon) |
| A29 | Main Risk Area | Geographic Classification | SINGAPORE | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A2A | Main Risk Area | Geographic Classification | THAILAND | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A2B | Main Risk Area | Geographic Classification | VIETNAM | 3 | All | All | Country-level entry under Southeast Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A20 + A00 + W00 | |
| A30 | Risk Zone | Geographic Classification | WEST ASIA | 2 | All | All | Sub-region of Asia covering West/South Asian nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects A00; filters Main Risk Area to A31-A3F | Parent zone for A31-A3F |
| A31 | Main Risk Area | Geographic Classification | AFGHANISTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A32 | Main Risk Area | Geographic Classification | ARMENIA | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A33 | Main Risk Area | Geographic Classification | AZERBAIJAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A34 | Main Risk Area | Geographic Classification | BANGLADESH | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A35 | Main Risk Area | Geographic Classification | GEORGIA (ASIA) | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | Disambiguated from US state |
| A36 | Main Risk Area | Geographic Classification | INDIA | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A37 | Main Risk Area | Geographic Classification | KAZAKSTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A38 | Main Risk Area | Geographic Classification | KYRGYZSTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A39 | Main Risk Area | Geographic Classification | MALDIVES | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3A | Main Risk Area | Geographic Classification | NEPAL | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3B | Main Risk Area | Geographic Classification | PAKISTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3C | Main Risk Area | Geographic Classification | SRI LANKA | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3D | Main Risk Area | Geographic Classification | TURKMENISTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3E | Main Risk Area | Geographic Classification | UZBEKISTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A3F | Main Risk Area | Geographic Classification | TAJIKISTAN | 3 | All | All | Country-level entry under West Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A30 + A00 + W00 | |
| A40 | Risk Zone | Geographic Classification | PACIFIC ASIA | 2 | All | All | Sub-region of Asia covering Pacific Asian territories | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects A00; filters Main Risk Area to A41-A44 | Parent zone for A41-A44 |
| A41 | Main Risk Area | Geographic Classification | FIJI | 3 | All | All | Country-level entry under Pacific Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A40 + A00 + W00 | |
| A42 | Main Risk Area | Geographic Classification | GUAM | 3 | All | All | Country-level entry under Pacific Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A40 + A00 + W00 | |
| A43 | Main Risk Area | Geographic Classification | MICRONESIA | 3 | All | All | Country-level entry under Pacific Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A40 + A00 + W00 | |
| A44 | Main Risk Area | Geographic Classification | PAPUA NEW GUINEA | 3 | All | All | Country-level entry under Pacific Asia | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects A40 + A00 + W00 | |

### CANADA (C00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| C00 | Broader Risk Zone | Geographic Classification | CANADA | 1 | All | All | Broader risk zone covering all Canadian territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to C10/C20/C30; filters Main Risk Area to all C-prefix provinces | Parent area for all C-prefix codes |
| C10 | Risk Zone | Geographic Classification | MARITIME PROVINCES | 2 | All | All | Sub-region of Canada covering Maritime provinces | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects C00; filters Main Risk Area to C11-C14 | Parent zone for C11-C14 |
| C11 | Main Risk Area | Geographic Classification | NEW BRUNSWICK | 3 | All | All | Province-level entry under Maritime Provinces | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C10 + C00 + W00 | |
| C12 | Main Risk Area | Geographic Classification | NEWFOUNDLAND | 3 | All | All | Province-level entry under Maritime Provinces | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C10 + C00 + W00 | |
| C13 | Main Risk Area | Geographic Classification | NOVA SCOTIA | 3 | All | All | Province-level entry under Maritime Provinces | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C10 + C00 + W00 | |
| C14 | Main Risk Area | Geographic Classification | PRINCE EDWARD ISLAND | 3 | All | All | Province-level entry under Maritime Provinces | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C10 + C00 + W00 | |
| C20 | Risk Zone | Geographic Classification | WESTERN CANADIAN PROVS | 2 | All | All | Sub-region of Canada covering Western provinces | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects C00; filters Main Risk Area to C21-C27 | Parent zone for C21-C27 |
| C21 | Main Risk Area | Geographic Classification | ALBERTA | 3 | All | All | Province-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C22 | Main Risk Area | Geographic Classification | BRITISH COLUMBIA | 3 | All | All | Province-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C23 | Main Risk Area | Geographic Classification | MANITOBA | 3 | All | All | Province-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C24 | Main Risk Area | Geographic Classification | NORTHWEST TERRITORY | 3 | All | All | Territory-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C25 | Main Risk Area | Geographic Classification | SASKATCHEWAN | 3 | All | All | Province-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C26 | Main Risk Area | Geographic Classification | YUKON TERRITORY | 3 | All | All | Territory-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C27 | Main Risk Area | Geographic Classification | NUNAVUT | 3 | All | All | Territory-level entry under Western Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C20 + C00 + W00 | |
| C30 | Risk Zone | Geographic Classification | CENTRAL CANADIAN PROVS | 2 | All | All | Sub-region of Canada covering Central provinces | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects C00; filters Main Risk Area to C31-C32 | Parent zone for C31-C32 |
| C31 | Main Risk Area | Geographic Classification | ONTARIO | 3 | All | All | Province-level entry under Central Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C30 + C00 + W00 | |
| C32 | Main Risk Area | Geographic Classification | QUEBEC | 3 | All | All | Province-level entry under Central Canadian Provs | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects C30 + C00 + W00 | |

### NORTH AMERICA (D00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| D00 | Broader Risk Zone | Geographic Classification | NORTH AMERICA | 1 | All | All | Broader risk zone for North America as a macro-region | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to D10; filters Main Risk Area to D-prefix entries | Parent area for D-prefix codes |
| D10 | Risk Zone | Geographic Classification | NORTH AMERICA EXC MEXICO | 2 | All | All | Sub-region: North America excluding Mexico | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects D00 | No child countries defined; used as scope qualifier |

### EUROPE (E00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| E00 | Broader Risk Zone | Geographic Classification | EUROPE | 1 | All | All | Broader risk zone covering all European territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to E10/E20/E30/E40/E50; filters Main Risk Area to all E-prefix countries | Parent area for all E-prefix codes |
| E10 | Risk Zone | Geographic Classification | CENTRAL EUROPE | 2 | All | All | Sub-region covering Central European nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects E00; filters Main Risk Area to E11-E16 | Parent zone for E11-E16 |
| E11 | Main Risk Area | Geographic Classification | AUSTRIA | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | |
| E12 | Main Risk Area | Geographic Classification | CZECH REPUBLIC | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | |
| E13 | Main Risk Area | Geographic Classification | GERMANY | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | Key reinsurance market |
| E14 | Main Risk Area | Geographic Classification | HUNGARY | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | |
| E15 | Main Risk Area | Geographic Classification | POLAND | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | |
| E16 | Main Risk Area | Geographic Classification | SLOVAKIA | 3 | All | All | Country-level entry under Central Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E10 + E00 + W00 | |
| E20 | Risk Zone | Geographic Classification | EASTERN EUROPE | 2 | All | All | Sub-region covering Eastern European nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects E00; filters Main Risk Area to E21-E26 | Parent zone for E21-E26 |
| E21 | Main Risk Area | Geographic Classification | BELARUS | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E22 | Main Risk Area | Geographic Classification | ESTONIA | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E23 | Main Risk Area | Geographic Classification | LATVIA | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E24 | Main Risk Area | Geographic Classification | LITHUANIA | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E25 | Main Risk Area | Geographic Classification | RUSSIA | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E26 | Main Risk Area | Geographic Classification | UKRAINE | 3 | All | All | Country-level entry under Eastern Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E20 + E00 + W00 | |
| E30 | Risk Zone | Geographic Classification | NORTH EUROPE | 2 | All | All | Sub-region covering Northern European nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects E00; filters Main Risk Area to E31-E36 | Parent zone for E31-E36 |
| E31 | Main Risk Area | Geographic Classification | DENMARK | 3 | All | All | Country-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E32 | Main Risk Area | Geographic Classification | FAEROE ISLANDS | 3 | All | All | Territory-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E33 | Main Risk Area | Geographic Classification | FINLAND | 3 | All | All | Country-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E34 | Main Risk Area | Geographic Classification | NETHERLANDS | 3 | All | All | Country-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E35 | Main Risk Area | Geographic Classification | NORWAY | 3 | All | All | Country-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E36 | Main Risk Area | Geographic Classification | SWEDEN | 3 | All | All | Country-level entry under North Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E30 + E00 + W00 | |
| E40 | Risk Zone | Geographic Classification | SOUTH EUROPE | 2 | All | All | Sub-region covering Southern European nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects E00; filters Main Risk Area to E41-E4M | Parent zone for E41-E4M |
| E41 | Main Risk Area | Geographic Classification | ALBANIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E42 | Main Risk Area | Geographic Classification | ANDORRA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E43 | Main Risk Area | Geographic Classification | BOSNIA-HERZEGOVINA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E44 | Main Risk Area | Geographic Classification | BULGARIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E45 | Main Risk Area | Geographic Classification | CROATIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E46 | Main Risk Area | Geographic Classification | CYPRUS | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E47 | Main Risk Area | Geographic Classification | GIBRALTAR | 3 | All | All | Territory-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E48 | Main Risk Area | Geographic Classification | GREECE | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E49 | Main Risk Area | Geographic Classification | ITALY | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4A | Main Risk Area | Geographic Classification | MACEDONIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4B | Main Risk Area | Geographic Classification | MALTA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4C | Main Risk Area | Geographic Classification | MOLDOVA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4D | Main Risk Area | Geographic Classification | MONACO | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4E | Main Risk Area | Geographic Classification | PORTUGAL | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4F | Main Risk Area | Geographic Classification | ROMANIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4G | Main Risk Area | Geographic Classification | SAN MARINO | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4H | Main Risk Area | Geographic Classification | SLOVENIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4I | Main Risk Area | Geographic Classification | SPAIN | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4J | Main Risk Area | Geographic Classification | VATICAN CITY | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4K | Main Risk Area | Geographic Classification | MONTENEGRO | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4L | Main Risk Area | Geographic Classification | SERBIA | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E4M | Main Risk Area | Geographic Classification | KOSOVO | 3 | All | All | Country-level entry under South Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E40 + E00 + W00 | |
| E50 | Risk Zone | Geographic Classification | WEST EUROPE | 2 | All | All | Sub-region covering Western European nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects E00; filters Main Risk Area to E51-E59 | Parent zone for E51-E59 |
| E51 | Main Risk Area | Geographic Classification | BELGIUM | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E52 | Main Risk Area | Geographic Classification | FRANCE | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E53 | Main Risk Area | Geographic Classification | IRELAND | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E54 | Main Risk Area | Geographic Classification | LIECHTENSTEIN | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E55 | Main Risk Area | Geographic Classification | LUXEMBOURG | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E56 | Main Risk Area | Geographic Classification | SWITZERLAND | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | Key reinsurance market |
| E57 | Main Risk Area | Geographic Classification | UNITED KINGDOM | 3 | All | All | Country-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | Key reinsurance market (Lloyd's) |
| E58 | Main Risk Area | Geographic Classification | BAILIWICK OF GUERNSEY | 3 | All | All | Territory-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |
| E59 | Main Risk Area | Geographic Classification | ISLE OF MAN | 3 | All | All | Territory-level entry under West Europe | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects E50 + E00 + W00 | |

### AFRICA (F00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F00 | Broader Risk Zone | Geographic Classification | AFRICA | 1 | All | All | Broader risk zone covering all African territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to F10/F20/F30/F40/F50/F60; filters Main Risk Area to all F-prefix countries | Parent area for all F-prefix codes |
| F10 | Risk Zone | Geographic Classification | CENTRAL AFRICAN CONTINENT | 2 | All | All | Sub-region covering Central African nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F11-F1A | Parent zone for F11-F1A |
| F11 | Main Risk Area | Geographic Classification | ANGOLA | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F12 | Main Risk Area | Geographic Classification | CAMEROON | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F13 | Main Risk Area | Geographic Classification | CENTRAL AFRICAN REPUBLIC | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F14 | Main Risk Area | Geographic Classification | CONGO | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F15 | Main Risk Area | Geographic Classification | EQUATORIAL GUINEA | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F16 | Main Risk Area | Geographic Classification | GABON | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F17 | Main Risk Area | Geographic Classification | MALAWI | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F18 | Main Risk Area | Geographic Classification | SAO TOME & PRINCIPE | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F19 | Main Risk Area | Geographic Classification | DEMOCRATIC REPUBLIC OF CONGO | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F1A | Main Risk Area | Geographic Classification | ZAMBIA | 3 | All | All | Country-level entry under Central Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F10 + F00 + W00 | |
| F20 | Risk Zone | Geographic Classification | EAST AFRICAN CONTINENT | 2 | All | All | Sub-region covering East African nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F21-F2B | Parent zone for F21-F2B |
| F21 | Main Risk Area | Geographic Classification | BURUNDI | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F22 | Main Risk Area | Geographic Classification | DJIBOUTI | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F23 | Main Risk Area | Geographic Classification | ERITREA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F24 | Main Risk Area | Geographic Classification | ETHIOPIA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F25 | Main Risk Area | Geographic Classification | KENYA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F26 | Main Risk Area | Geographic Classification | RWANDA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F27 | Main Risk Area | Geographic Classification | SOMALIA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F28 | Main Risk Area | Geographic Classification | SUDAN | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F29 | Main Risk Area | Geographic Classification | TANZANIA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F2A | Main Risk Area | Geographic Classification | UGANDA | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F2B | Main Risk Area | Geographic Classification | SOUTH SUDAN | 3 | All | All | Country-level entry under East Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F20 + F00 + W00 | |
| F30 | Risk Zone | Geographic Classification | NORTH AFRICAN CONTINENT | 2 | All | All | Sub-region covering North African nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F31-F39 | Parent zone for F31-F39 |
| F31 | Main Risk Area | Geographic Classification | ALGERIA | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F32 | Main Risk Area | Geographic Classification | CHAD | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F33 | Main Risk Area | Geographic Classification | LIBYA | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F34 | Main Risk Area | Geographic Classification | MALI | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F35 | Main Risk Area | Geographic Classification | MAURITANIA | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F36 | Main Risk Area | Geographic Classification | MOROCCO | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F37 | Main Risk Area | Geographic Classification | NIGER | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F38 | Main Risk Area | Geographic Classification | TUNISIA | 3 | All | All | Country-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F39 | Main Risk Area | Geographic Classification | WESTERN SAHARA | 3 | All | All | Territory-level entry under North Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F30 + F00 + W00 | |
| F40 | Risk Zone | Geographic Classification | SOUTH AFRICAN CONTINENT | 2 | All | All | Sub-region covering Southern African nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F41-F47 | Parent zone for F41-F47 |
| F41 | Main Risk Area | Geographic Classification | BOTSWANA | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F42 | Main Risk Area | Geographic Classification | LESOTHO | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F43 | Main Risk Area | Geographic Classification | MOZAMBIQUE | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F44 | Main Risk Area | Geographic Classification | NAMIBIA | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F45 | Main Risk Area | Geographic Classification | SOUTH AFRICA - REPUBLIC | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F46 | Main Risk Area | Geographic Classification | SWAZILAND | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F47 | Main Risk Area | Geographic Classification | ZIMBABWE | 3 | All | All | Country-level entry under South Africa region | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F40 + F00 + W00 | |
| F50 | Risk Zone | Geographic Classification | WEST AFRICAN CONTINENT | 2 | All | All | Sub-region covering West African nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F51-F5C | Parent zone for F51-F5C |
| F51 | Main Risk Area | Geographic Classification | BENIN | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F52 | Main Risk Area | Geographic Classification | BURKINA FASO | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F53 | Main Risk Area | Geographic Classification | GAMBIA | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F54 | Main Risk Area | Geographic Classification | GHANA | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F55 | Main Risk Area | Geographic Classification | GUINEA | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F56 | Main Risk Area | Geographic Classification | GUINEA-BISSAU | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F57 | Main Risk Area | Geographic Classification | IVORY COAST | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F58 | Main Risk Area | Geographic Classification | LIBERIA | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F59 | Main Risk Area | Geographic Classification | NIGERIA | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F5A | Main Risk Area | Geographic Classification | SENEGAL | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F5B | Main Risk Area | Geographic Classification | SIERRA LEONE | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F5C | Main Risk Area | Geographic Classification | TOGO | 3 | All | All | Country-level entry under West Africa | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F50 + F00 + W00 | |
| F60 | Risk Zone | Geographic Classification | MISC AFRICAN ISLANDS | 2 | All | All | Sub-region covering African island territories | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects F00; filters Main Risk Area to F61-F69 | Parent zone for F61-F69 |
| F61 | Main Risk Area | Geographic Classification | CANARY ISLANDS | 3 | All | All | Territory-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F62 | Main Risk Area | Geographic Classification | CAPE VERDE | 3 | All | All | Country-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F63 | Main Risk Area | Geographic Classification | COMOROS ISLANDS | 3 | All | All | Country-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F64 | Main Risk Area | Geographic Classification | MADAGASCAR | 3 | All | All | Country-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F65 | Main Risk Area | Geographic Classification | MADEIRA ISLANDS | 3 | All | All | Territory-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F66 | Main Risk Area | Geographic Classification | MAURITIUS | 3 | All | All | Country-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F67 | Main Risk Area | Geographic Classification | REUNION | 3 | All | All | Territory-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F68 | Main Risk Area | Geographic Classification | SEYCHELLES | 3 | All | All | Country-level entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | |
| F69 | Main Risk Area | Geographic Classification | SUB-SAHARAN AFRICA | 3 | All | All | Aggregate entry under Misc African Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects F60 + F00 + W00 | Aggregate scope qualifier |

### ISLANDS (I00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| I00 | Broader Risk Zone | Geographic Classification | ISLANDS | 1 | All | All | Broader risk zone covering oceanic island territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to I10/I20/I30/I40; filters Main Risk Area to all I-prefix territories | Parent area for all I-prefix codes |
| I10 | Risk Zone | Geographic Classification | ATLANTIC OCEAN ISLANDS | 2 | All | All | Sub-region covering Atlantic Ocean islands | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects I00; filters Main Risk Area to I11-I17 | Parent zone for I11-I17 |
| I11 | Main Risk Area | Geographic Classification | BERMUDA | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | Key reinsurance domicile |
| I12 | Main Risk Area | Geographic Classification | BOUVET ISLAND | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I13 | Main Risk Area | Geographic Classification | FALKLAND ISLANDS | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I14 | Main Risk Area | Geographic Classification | GREENLAND | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I15 | Main Risk Area | Geographic Classification | ICELAND | 3 | All | All | Country-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I16 | Main Risk Area | Geographic Classification | ST PIERRE & MIQUEON | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I17 | Main Risk Area | Geographic Classification | ST HELENA | 3 | All | All | Territory-level entry under Atlantic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I10 + I00 + W00 | |
| I20 | Risk Zone | Geographic Classification | INDIAN OCEAN ISLANDS | 2 | All | All | Sub-region covering Indian Ocean islands | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects I00; filters Main Risk Area to I21-I24 | Parent zone for I21-I24 |
| I21 | Main Risk Area | Geographic Classification | BRITISH INDIAN OCEAN TER | 3 | All | All | Territory-level entry under Indian Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I20 + I00 + W00 | |
| I22 | Main Risk Area | Geographic Classification | CHRISTMAS ISLAND | 3 | All | All | Territory-level entry under Indian Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I20 + I00 + W00 | |
| I23 | Main Risk Area | Geographic Classification | COCOS ISLANDS | 3 | All | All | Territory-level entry under Indian Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I20 + I00 + W00 | |
| I24 | Main Risk Area | Geographic Classification | HEARD & MCDONALD ISLANDS | 3 | All | All | Territory-level entry under Indian Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I20 + I00 + W00 | |
| I30 | Risk Zone | Geographic Classification | PACIFIC OCEAN ISLANDS | 2 | All | All | Sub-region covering Pacific Ocean islands | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects I00; filters Main Risk Area to I31-I3P | Parent zone for I31-I3P |
| I31 | Main Risk Area | Geographic Classification | AMERICAN SAMOA | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I32 | Main Risk Area | Geographic Classification | BHUTAN | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | RDM placement note: geographically South Asia |
| I33 | Main Risk Area | Geographic Classification | CANTON & ENDERBURY ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I34 | Main Risk Area | Geographic Classification | COOK ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I35 | Main Risk Area | Geographic Classification | EAST TIMOR / TIMOR-LESTE | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I36 | Main Risk Area | Geographic Classification | FRENCH POLYNESIA | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I37 | Main Risk Area | Geographic Classification | JOHNSTON ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I38 | Main Risk Area | Geographic Classification | MARSHALL ISLANDS | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I39 | Main Risk Area | Geographic Classification | NAURU | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3A | Main Risk Area | Geographic Classification | NEW CALEDONIA | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3B | Main Risk Area | Geographic Classification | NIUE | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3C | Main Risk Area | Geographic Classification | NORFOLK ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3D | Main Risk Area | Geographic Classification | NORTHERN MARIANA ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3E | Main Risk Area | Geographic Classification | PALAU | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3F | Main Risk Area | Geographic Classification | PITCAIRN ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3G | Main Risk Area | Geographic Classification | SOLOMON ISLANDS | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3H | Main Risk Area | Geographic Classification | TOKELAU | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3I | Main Risk Area | Geographic Classification | TONGA | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3J | Main Risk Area | Geographic Classification | TRUST TERRITORY | 3 | All | All | Legacy territory entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | Legacy code |
| I3K | Main Risk Area | Geographic Classification | TUVALU | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3L | Main Risk Area | Geographic Classification | US MINOR OUTLYING ISLAND | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3M | Main Risk Area | Geographic Classification | VANUATU | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3N | Main Risk Area | Geographic Classification | WALLIS & FUTUNA ISLANDS | 3 | All | All | Territory-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3O | Main Risk Area | Geographic Classification | SAMOA | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I3P | Main Risk Area | Geographic Classification | KIRIBATI | 3 | All | All | Country-level entry under Pacific Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I30 + I00 + W00 | |
| I40 | Risk Zone | Geographic Classification | ARCTIC OCEAN ISLANDS | 2 | All | All | Sub-region covering Arctic Ocean islands | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects I00; filters Main Risk Area to I41 | Parent zone for I41 |
| I41 | Main Risk Area | Geographic Classification | SVALBARD & JAN MAYEN | 3 | All | All | Territory-level entry under Arctic Ocean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects I40 + I00 + W00 | |

### LATIN AMERICA (L00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| L00 | Broader Risk Zone | Geographic Classification | LATIN AMERICA | 1 | All | All | Broader risk zone covering Latin American territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to L10/L20/L30/L40; filters Main Risk Area to all L-prefix countries | Parent area for all L-prefix codes |
| L10 | Risk Zone | Geographic Classification | SOUTH AMERICA | 2 | All | All | Sub-region covering South American nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects L00; filters Main Risk Area to L11-L1D | Parent zone for L11-L1D |
| L11 | Main Risk Area | Geographic Classification | ARGENTINA | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L12 | Main Risk Area | Geographic Classification | BOLIVIA | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L13 | Main Risk Area | Geographic Classification | BRAZIL | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L14 | Main Risk Area | Geographic Classification | CHILE | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | High CAT exposure (earthquake) |
| L15 | Main Risk Area | Geographic Classification | COLOMBIA | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L16 | Main Risk Area | Geographic Classification | ECUADOR | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L17 | Main Risk Area | Geographic Classification | FRENCH GUIANA | 3 | All | All | Territory-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L18 | Main Risk Area | Geographic Classification | GUYANA | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L19 | Main Risk Area | Geographic Classification | PARAGUAY | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L1A | Main Risk Area | Geographic Classification | PERU | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L1B | Main Risk Area | Geographic Classification | SURINAME | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L1C | Main Risk Area | Geographic Classification | URUGUAY | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L1D | Main Risk Area | Geographic Classification | VENEZUELA | 3 | All | All | Country-level entry under South America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L10 + L00 + W00 | |
| L20 | Risk Zone | Geographic Classification | CENTRAL AMERICA | 2 | All | All | Sub-region covering Central American nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects L00; filters Main Risk Area to L21-L27 | Parent zone for L21-L27 |
| L21 | Main Risk Area | Geographic Classification | BELIZE | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L22 | Main Risk Area | Geographic Classification | COSTA RICA | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L23 | Main Risk Area | Geographic Classification | EL SALVADOR | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L24 | Main Risk Area | Geographic Classification | GUATEMALA | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L25 | Main Risk Area | Geographic Classification | HONDURAS | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L26 | Main Risk Area | Geographic Classification | NICARAGUA | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L27 | Main Risk Area | Geographic Classification | PANAMA | 3 | All | All | Country-level entry under Central America | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L20 + L00 + W00 | |
| L30 | Risk Zone | Geographic Classification | MEXICO | 2 | All | All | Mexico as a risk zone under Latin America | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects L00 | No child countries; Mexico is both zone and country-level |
| L40 | Risk Zone | Geographic Classification | CARIBBEAN ISLANDS | 2 | All | All | Sub-region covering Caribbean island nations | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects L00; filters Main Risk Area to L41-L4P | Parent zone for L41-L4P |
| L41 | Main Risk Area | Geographic Classification | ANTIGUA & BARBUDA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | Hurricane exposure |
| L42 | Main Risk Area | Geographic Classification | ARUBA | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L43 | Main Risk Area | Geographic Classification | BAHAMAS | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | Hurricane exposure |
| L44 | Main Risk Area | Geographic Classification | BARBADOS | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L45 | Main Risk Area | Geographic Classification | BRITISH VIRGIN ISLANDS | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L46 | Main Risk Area | Geographic Classification | CAYMAN ISLANDS | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L47 | Main Risk Area | Geographic Classification | CUBA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L48 | Main Risk Area | Geographic Classification | DOMINICA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L49 | Main Risk Area | Geographic Classification | DOMINICAN REPUBLIC | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4A | Main Risk Area | Geographic Classification | GRENADA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4B | Main Risk Area | Geographic Classification | GUADELOUPE | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4C | Main Risk Area | Geographic Classification | HAITI | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4D | Main Risk Area | Geographic Classification | JAMAICA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4E | Main Risk Area | Geographic Classification | MARTINIQUE | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4F | Main Risk Area | Geographic Classification | MONTSERRAT | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4G | Main Risk Area | Geographic Classification | NETHERLANDS ANTILLES | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | Legacy; partially dissolved |
| L4H | Main Risk Area | Geographic Classification | PUERTO RICO | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | US territory; hurricane exposure |
| L4I | Main Risk Area | Geographic Classification | ST KITTS-NEVIS-ANGUI | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4J | Main Risk Area | Geographic Classification | ST LUCIA | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4K | Main Risk Area | Geographic Classification | ST VINCENT & GRENADINE | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4L | Main Risk Area | Geographic Classification | TRINIDAD & TOBAGO | 3 | All | All | Country-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4M | Main Risk Area | Geographic Classification | TURKS & CAICOS ISLANDS | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4N | Main Risk Area | Geographic Classification | US VIRGIN ISLANDS | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | US territory |
| L4O | Main Risk Area | Geographic Classification | CURACAO | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |
| L4P | Main Risk Area | Geographic Classification | ST MAARTEN | 3 | All | All | Territory-level entry under Caribbean Islands | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects L40 + L00 + W00 | |

### MIDDLE EAST (M00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| M00 | Broader Risk Zone | Geographic Classification | MIDDLE EAST | 1 | All | All | Broader risk zone covering Middle Eastern territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Main Risk Area to all M-prefix countries | Parent area for all M-prefix codes; no sub-zones defined |
| M11 | Main Risk Area | Geographic Classification | BAHRAIN | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone; direct child of M00 |
| M12 | Main Risk Area | Geographic Classification | EGYPT | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M13 | Main Risk Area | Geographic Classification | IRAN | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone; earthquake exposure |
| M14 | Main Risk Area | Geographic Classification | IRAQ | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M15 | Main Risk Area | Geographic Classification | ISRAEL | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M16 | Main Risk Area | Geographic Classification | JORDAN | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M17 | Main Risk Area | Geographic Classification | KUWAIT | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M18 | Main Risk Area | Geographic Classification | LEBANON | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M19 | Main Risk Area | Geographic Classification | OMAN | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1A | Main Risk Area | Geographic Classification | QATAR | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1B | Main Risk Area | Geographic Classification | SAUDI ARABIA | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1C | Main Risk Area | Geographic Classification | SYRIA | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1D | Main Risk Area | Geographic Classification | TURKEY | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone; high earthquake exposure |
| M1E | Main Risk Area | Geographic Classification | UNITED ARAB EMIRATES | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1F | Main Risk Area | Geographic Classification | YEMEN | 3 | All | All | Country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | No parent zone |
| M1G | Main Risk Area | Geographic Classification | YEMEN - PEOPLES DEM REP | 3 | All | All | Legacy country-level entry under Middle East | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects M00 + W00 | Legacy code |

### OUTERSPACE (R00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| R00 | Broader Risk Zone | Geographic Classification | OUTERSPACE | 1 | All | All | Broader risk zone for outer space / satellite events | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | No child zones or countries | Standalone area; satellite/space risk |

### OCEANS & SEAS (S00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S00 | Broader Risk Zone | Geographic Classification | OCEANS & SEAS | 1 | All | All | Broader risk zone covering maritime/oceanic areas | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters to S-prefix zones | Parent area for all S-prefix codes |
| S01 | Main Risk Area | Geographic Classification | MIDDLE EAST & CASPIAN SEA | 3 | All | All | Maritime area entry under Oceans & Seas | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects S00 + W00 | No parent zone; direct child |
| S10 | Risk Zone | Geographic Classification | ANTARCTIC OCEAN | 2 | All | All | Ocean zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S20 | Risk Zone | Geographic Classification | ARCTIC OCEAN | 2 | All | All | Ocean zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S30 | Risk Zone | Geographic Classification | ATLANTIC OCEAN | 2 | All | All | Ocean zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S40 | Risk Zone | Geographic Classification | BALTIC SEA | 2 | All | All | Sea zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S50 | Risk Zone | Geographic Classification | INDIAN OCEAN | 2 | All | All | Ocean zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S60 | Risk Zone | Geographic Classification | GULF OF MEXICO | 2 | All | All | Sea zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | Offshore energy exposure |
| S70 | Risk Zone | Geographic Classification | MEDITERRANEAN SEA | 2 | All | All | Sea zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| S80 | Risk Zone | Geographic Classification | NORTH SEA | 2 | All | All | Sea zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | Offshore energy exposure |
| S90 | Risk Zone | Geographic Classification | PACIFIC OCEAN | 2 | All | All | Ocean zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |
| SA0 | Risk Zone | Geographic Classification | OTHER SEAS & OCEANS | 2 | All | All | Catch-all sea zone under Oceans & Seas | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects S00 | No child countries |

### ANTARCTIC CONTINENT (T00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| T00 | Broader Risk Zone | Geographic Classification | ANTARCTIC CONTINENT | 1 | All | All | Broader risk zone covering Antarctic territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Main Risk Area to T01-T02 | Parent area for T-prefix codes |
| T01 | Main Risk Area | Geographic Classification | ANTARCTICA | 3 | All | All | Territory-level entry under Antarctic Continent | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects T00 + W00 | No parent zone; direct child |
| T02 | Main Risk Area | Geographic Classification | DRONNING MAUD ISLAND | 3 | All | All | Territory-level entry under Antarctic Continent | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects T00 + W00 | No parent zone; direct child |

### UNITED STATES (U00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| U00 | Broader Risk Zone | Geographic Classification | UNITED STATES | 1 | All | All | Broader risk zone covering all US territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to U10/U20/U30/U50/U60/U70/U90; filters Main Risk Area to all U-prefix states | Parent area for all U-prefix codes |
| U10 | Risk Zone | Geographic Classification | NEW ENGLAND STATES | 2 | All | All | Sub-region covering New England US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U11-U17 | Parent zone for U11-U17 |
| U11 | Main Risk Area | Geographic Classification | CONNECTICUT | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U12 | Main Risk Area | Geographic Classification | MAINE | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U13 | Main Risk Area | Geographic Classification | MASSACHUSETTS | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U14 | Main Risk Area | Geographic Classification | NEW HAMPSHIRE | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U15 | Main Risk Area | Geographic Classification | NEW YORK | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | Key exposure state |
| U16 | Main Risk Area | Geographic Classification | RHODE ISLAND | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U17 | Main Risk Area | Geographic Classification | VERMONT | 3 | All | All | State-level entry under New England | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U10 + U00 + W00 | |
| U20 | Risk Zone | Geographic Classification | MIDATLANTIC STATES | 2 | All | All | Sub-region covering Mid-Atlantic US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U21-U27 | Parent zone for U21-U27 |
| U21 | Main Risk Area | Geographic Classification | DISTRICT OF COLUMBIA | 3 | All | All | Territory-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U22 | Main Risk Area | Geographic Classification | DELAWARE | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U23 | Main Risk Area | Geographic Classification | MARYLAND | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U24 | Main Risk Area | Geographic Classification | NEW JERSEY | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U25 | Main Risk Area | Geographic Classification | PENNSYLVANIA | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U26 | Main Risk Area | Geographic Classification | VIRGINIA | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U27 | Main Risk Area | Geographic Classification | WEST VIRGINIA | 3 | All | All | State-level entry under Midatlantic | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U20 + U00 + W00 | |
| U30 | Risk Zone | Geographic Classification | SOUTHEASTERN STATES | 2 | All | All | Sub-region covering Southeastern US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U31-U37 | Parent zone for U31-U37 |
| U31 | Main Risk Area | Geographic Classification | ALABAMA | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | |
| U32 | Main Risk Area | Geographic Classification | FLORIDA | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | Key hurricane exposure state |
| U33 | Main Risk Area | Geographic Classification | GEORGIA (US) | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | Disambiguated from Asian country |
| U34 | Main Risk Area | Geographic Classification | LOUISIANA | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | Hurricane exposure |
| U35 | Main Risk Area | Geographic Classification | MISSISSIPPI | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | |
| U36 | Main Risk Area | Geographic Classification | NORTH CAROLINA | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | |
| U37 | Main Risk Area | Geographic Classification | SOUTH CAROLINA | 3 | All | All | State-level entry under Southeastern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U30 + U00 + W00 | |
| U41 | Main Risk Area | Geographic Classification | TEXAS | 3 | All | All | State-level entry (no zone parent in RDM) | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U00 + W00 | No parent zone defined; hurricane + severe convective storm exposure |
| U50 | Risk Zone | Geographic Classification | MIDAMERICAN STATES | 2 | All | All | Sub-region covering Mid-American US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U51-U57 | Parent zone for U51-U57 |
| U51 | Main Risk Area | Geographic Classification | ILLINOIS | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U52 | Main Risk Area | Geographic Classification | INDIANA | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U53 | Main Risk Area | Geographic Classification | KENTUCKY | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U54 | Main Risk Area | Geographic Classification | MICHIGAN | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U55 | Main Risk Area | Geographic Classification | OHIO | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U56 | Main Risk Area | Geographic Classification | TENNESSEE | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U57 | Main Risk Area | Geographic Classification | WISCONSIN | 3 | All | All | State-level entry under Midamerican | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U50 + U00 + W00 | |
| U60 | Risk Zone | Geographic Classification | MIDWESTERN STATES | 2 | All | All | Sub-region covering Midwestern US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U61-U69 | Parent zone for U61-U69 |
| U61 | Main Risk Area | Geographic Classification | ARKANSAS | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U62 | Main Risk Area | Geographic Classification | IOWA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U63 | Main Risk Area | Geographic Classification | KANSAS | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | Tornado alley |
| U64 | Main Risk Area | Geographic Classification | MINNESOTA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U65 | Main Risk Area | Geographic Classification | MISSOURI | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U66 | Main Risk Area | Geographic Classification | NEBRASKA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U67 | Main Risk Area | Geographic Classification | NORTH DAKOTA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U68 | Main Risk Area | Geographic Classification | OKLAHOMA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | Tornado alley |
| U69 | Main Risk Area | Geographic Classification | SOUTH DAKOTA | 3 | All | All | State-level entry under Midwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U60 + U00 + W00 | |
| U70 | Risk Zone | Geographic Classification | WESTERN STATES | 2 | All | All | Sub-region covering Western US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U71-U78 | Parent zone for U71-U78 |
| U71 | Main Risk Area | Geographic Classification | ARIZONA | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U72 | Main Risk Area | Geographic Classification | COLORADO | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U73 | Main Risk Area | Geographic Classification | IDAHO | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U74 | Main Risk Area | Geographic Classification | MONTANA | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U75 | Main Risk Area | Geographic Classification | NEVADA | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U76 | Main Risk Area | Geographic Classification | NEW MEXICO | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U77 | Main Risk Area | Geographic Classification | UTAH | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U78 | Main Risk Area | Geographic Classification | WYOMING | 3 | All | All | State-level entry under Western | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U70 + U00 + W00 | |
| U81 | Main Risk Area | Geographic Classification | CALIFORNIA | 3 | All | All | State-level entry (no zone parent in RDM) | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U00 + W00 | No parent zone defined; key earthquake + wildfire exposure state |
| U90 | Risk Zone | Geographic Classification | NORTHWESTERN STATES | 2 | All | All | Sub-region covering Northwestern US states | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects U00; filters Main Risk Area to U91-U93 | Parent zone for U91-U93 |
| U91 | Main Risk Area | Geographic Classification | ALASKA | 3 | All | All | State-level entry under Northwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U90 + U00 + W00 | Earthquake exposure |
| U92 | Main Risk Area | Geographic Classification | OREGON | 3 | All | All | State-level entry under Northwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U90 + U00 + W00 | |
| U93 | Main Risk Area | Geographic Classification | WASHINGTON | 3 | All | All | State-level entry under Northwestern | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U90 + U00 + W00 | |
| UA1 | Main Risk Area | Geographic Classification | HAWAII | 3 | All | All | State-level entry (no zone parent in RDM) | BR-IRP.001 | Selected in Main Risk Area dropdown | Auto-selects U00 + W00 | No parent zone defined; hurricane + volcanic exposure |

### WORLDWIDE (W00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| W00 | Worldwide | Scope Qualifier | WORLDWIDE | 0 | All | All | Global scope - all territories worldwide | BR-IRP.001 | Auto-added when any country is selected; can be manually deselected | Indicates global event scope | Can be freely toggled on/off |
| W01 | Worldwide | Scope Qualifier | WORLDWIDE EX NORTH AMER | 0 | All | All | Global scope excluding North American territories | - | Manually selected in Worldwide dropdown | Indicates worldwide scope excluding NA | Scope qualifier for treaty/program classification |
| W02 | Worldwide | Scope Qualifier | WORLDWIDE EX US & CANADA | 0 | All | All | Global scope excluding US and Canadian territories | - | Manually selected in Worldwide dropdown | Indicates worldwide scope excluding US+CA | Scope qualifier for treaty/program classification |
| W03 | Worldwide | Scope Qualifier | WORLDWIDE EX US | 0 | All | All | Global scope excluding US territories | - | Manually selected in Worldwide dropdown | Indicates worldwide scope excluding US | Scope qualifier for treaty/program classification |

### CONVERSION ONLY GROUP (X00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| X00 | Broader Risk Zone | System / Legacy | CONVERSION ONLY GROUP | 1 | All | All | Legacy conversion codes from prior system migration | - | Selected in Broader Risk Zone dropdown | No cascade behavior | Legacy; not for new event creation |
| X01 | Main Risk Area | System / Legacy | CONV ONLY - NORTH AMER | 3 | All | All | Legacy conversion code | - | Selected in Main Risk Area dropdown | Auto-selects X00 | Legacy; not for new event creation |
| X02 | Main Risk Area | System / Legacy | CONV ONLY - NEUTRAL ZONE | 3 | All | All | Legacy conversion code | - | Selected in Main Risk Area dropdown | Auto-selects X00 | Legacy; not for new event creation |
| X03 | Main Risk Area | System / Legacy | CONV ONLY - ADDITIONAL CODE | 3 | All | All | Legacy conversion code | - | Selected in Main Risk Area dropdown | Auto-selects X00 | Legacy; not for new event creation |
| X04 | Main Risk Area | System / Legacy | CONV ONLY - TBA | 3 | All | All | Legacy conversion code | - | Selected in Main Risk Area dropdown | Auto-selects X00 | Legacy; not for new event creation |

### AUSTRALIA / NEW ZEALAND (Z00)

| Code | Typelist | Purpose | Value | Level | Related Everest Event Type | Related Event Type | Description | Business Rule ID | Trigger / Condition | System Action | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Z00 | Broader Risk Zone | Geographic Classification | AUSTRALIA / NEW ZEALAND | 1 | All | All | Broader risk zone covering Oceania territories | BR-IRP.003, BR-IRP.005 | Selected in Broader Risk Zone dropdown | Filters Risk Zone to Z10/Z20/Z30; filters Main Risk Area to Z-prefix entries | Parent area for all Z-prefix codes |
| Z10 | Risk Zone | Geographic Classification | AUSTRALIA | 2 | All | All | Australia as risk zone under ANZ | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects Z00 | No child countries; Australia is both zone and country-level |
| Z20 | Risk Zone | Geographic Classification | NEW ZEALAND | 2 | All | All | New Zealand as risk zone under ANZ | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects Z00 | No child countries; NZ is both zone and country-level; earthquake exposure |
| Z30 | Risk Zone | Geographic Classification | WESTERN AUSTRALIA | 2 | All | All | Western Australia as sub-zone under ANZ | BR-IRP.004, BR-IRP.006 | Selected in Risk Zone dropdown | Auto-selects Z00 | No child countries |

---

## Code Structure Summary

| Prefix | Area | Level 1 (Broader) | Level 2 (Zones) | Level 3 (Countries/States) | Total Codes |
|---|---|---|---|---|---|
| A | Asia | 1 (A00) | 4 (A10, A20, A30, A40) | 38 | 43 |
| C | Canada | 1 (C00) | 3 (C10, C20, C30) | 12 | 16 |
| D | North America | 1 (D00) | 1 (D10) | 0 | 2 |
| E | Europe | 1 (E00) | 5 (E10-E50) | 33 | 39 |
| F | Africa | 1 (F00) | 6 (F10-F60) | 47 | 54 |
| I | Islands | 1 (I00) | 4 (I10-I40) | 28 | 33 |
| L | Latin America | 1 (L00) | 4 (L10-L40) | 34 | 39 |
| M | Middle East | 1 (M00) | 0 | 17 | 18 |
| R | Outerspace | 1 (R00) | 0 | 0 | 1 |
| S | Oceans & Seas | 1 (S00) | 10 (S10-SA0) | 1 (S01) | 12 |
| T | Antarctic | 1 (T00) | 0 | 2 | 3 |
| U | United States | 1 (U00) | 7 (U10-U90) | 40 | 48 |
| W | Worldwide | - | - | 4 (W00-W03) | 4 |
| X | Conversion | 1 (X00) | 0 | 4 | 5 |
| Z | Australia/NZ | 1 (Z00) | 3 (Z10-Z30) | 0 | 4 |
| **Total** | | **14** | **47** | **260** | **321** |

---

## Structural Anomalies & Notes

| Code | Issue | Notes |
|---|---|---|
| U41 (Texas) | No parent zone | Texas sits directly under U00 without a zone group; code falls between U30 (Southeastern) and U50 (Midamerican) |
| U81 (California) | No parent zone | California sits directly under U00 without a zone group; code falls between U70 (Western) and U90 (Northwestern) |
| UA1 (Hawaii) | No parent zone | Hawaii sits directly under U00; alphanumeric code pattern differs from others |
| M11-M1G | No zones under M00 | All Middle East countries are direct children of M00 with no intermediate zone layer |
| L30 (Mexico) | Zone with no children | Mexico is a zone-level code under L00 but has no child country codes |
| Z10/Z20/Z30 | Zones with no children | Australia, New Zealand, and Western Australia are zone-level only |
| S01 | Country-level under S00 | Middle East & Caspian Sea is a direct child of S00 (not under any zone) |
| I32 (Bhutan) | Geographic mismatch | Bhutan is listed under Pacific Ocean Islands (I30) but is geographically in South Asia |
| X00-X04 | Legacy codes | Conversion-only codes from prior system migration; should not be used for new events |
| A25 (Kampuchea) | Legacy name | Historical name for Cambodia; duplicate coverage with A23 |
| M1G (Yemen PDR) | Legacy country | Former country (merged into Yemen/M1F in 1990) |
