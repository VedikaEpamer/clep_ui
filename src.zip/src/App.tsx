import { RouterProvider } from 'react-router';
import { router } from './routes';
import { Component, type ReactNode, type ErrorInfo } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { theme } from './components/design-system';

// Global error boundary to catch and display runtime errors
class AppErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: Error | null; errorInfo: ErrorInfo | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('App Error Boundary caught:', error, errorInfo);
    this.setState({ errorInfo });
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: 32, maxWidth: 800, margin: '40px auto', fontFamily: 'system-ui, sans-serif' }}>
          <div style={{ background: '#fef2f2', border: '2px solid #fca5a5', borderRadius: 12, padding: 24 }}>
            <h1 style={{ color: '#991b1b', fontSize: 20, fontWeight: 700, marginBottom: 12 }}>
              Application Error
            </h1>
            <p style={{ color: '#b91c1c', fontSize: 14, marginBottom: 16 }}>
              The application encountered an error. This information can help diagnose the issue:
            </p>
            <div style={{ background: '#fff', border: '1px solid #fecaca', borderRadius: 8, padding: 16, marginBottom: 16 }}>
              <p style={{ color: '#dc2626', fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Error Message:</p>
              <pre style={{ color: '#7f1d1d', fontSize: 13, whiteSpace: 'pre-wrap', wordBreak: 'break-word', margin: 0 }}>
                {this.state.error?.message}
              </pre>
            </div>
            <details style={{ marginBottom: 16 }}>
              <summary style={{ color: '#991b1b', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>Stack Trace</summary>
              <pre style={{ color: '#991b1b', fontSize: 11, whiteSpace: 'pre-wrap', wordBreak: 'break-word', marginTop: 8, background: '#fff', padding: 12, borderRadius: 6, border: '1px solid #fecaca', maxHeight: 300, overflow: 'auto' }}>
                {this.state.error?.stack}
              </pre>
            </details>
            {this.state.errorInfo && (
              <details style={{ marginBottom: 16 }}>
                <summary style={{ color: '#991b1b', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>Component Stack</summary>
                <pre style={{ color: '#991b1b', fontSize: 11, whiteSpace: 'pre-wrap', wordBreak: 'break-word', marginTop: 8, background: '#fff', padding: 12, borderRadius: 6, border: '1px solid #fecaca', maxHeight: 300, overflow: 'auto' }}>
                  {this.state.errorInfo.componentStack}
                </pre>
              </details>
            )}
            <div style={{ display: 'flex', gap: 12 }}>
              <button
                onClick={() => this.setState({ hasError: false, error: null, errorInfo: null })}
                style={{ padding: '8px 20px', background: '#dc2626', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 14 }}
              >
                Try Again
              </button>
              <button
                onClick={() => { sessionStorage.clear(); window.location.reload(); }}
                style={{ padding: '8px 20px', background: '#f59e0b', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 14 }}
              >
                Clear Cache & Reload
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  return (
    <AppErrorBoundary>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <RouterProvider router={router} />
      </ThemeProvider>
    </AppErrorBoundary>
  );
}

export default App;
