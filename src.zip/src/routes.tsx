import { createBrowserRouter, Navigate } from "react-router";
import { RootProviders } from "./components/layouts/RootProviders";
import { DesignCatalog } from "./components/design-system/pages/DesignCatalog";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootProviders,
    children: [
      {
        index: true,
        element: <Navigate to="design-system" replace />,
      },
      {
        path: "design-system",
        Component: DesignCatalog,
      },
    ],
  },
]);
