/**
 * Asset Index - All extracted SVG icons and images
 *
 * Images:
 *   everest-logo.png              - Everest company logo
 *
 * Custom Icons (extracted from Figma/inline SVGs):
 *   icon-alert-circle.svg         - Warning/alert circle (20x20)
 *   icon-arrow-left.svg           - Left arrow for back nav (16x16)
 *   icon-bar-chart.svg            - Bar chart with axis (20x20)
 *   icon-bell.svg                 - Notification bell (20x20)
 *   icon-brand-logo.svg           - Brand logomark (28x28)
 *   icon-chart-bar.svg            - Chart bar columns, small (16x16)
 *   icon-checkmark.svg            - Checkmark, selection (16x16)
 *   icon-chevron-down.svg         - Chevron down, small (16x16)
 *   icon-chevron-down-lg.svg      - Chevron down, dropdown (24x24)
 *   icon-chevron-left.svg         - Chevron left, sidebar collapse (16x16)
 *   icon-clock-history.svg        - Clock with history arrow (16x16)
 *   icon-close.svg                - X/close button (24x24)
 *   icon-currency.svg             - Dollar sign S-curve (20x20)
 *   icon-document-text.svg        - Document with text lines (16x16)
 *   icon-download.svg             - Download arrow with tray (16x16)
 *   icon-eye.svg                  - Eye/view (16x16)
 *   icon-filter.svg               - Funnel/filter (20x20)
 *   icon-folder.svg               - Folder with document (16x16)
 *   icon-fullscreen.svg           - Expand fullscreen corners (16x16)
 *   icon-image-placeholder.svg    - Broken image placeholder (88x88)
 *   icon-info-circle.svg          - Info circle filled (20x20)
 *   icon-save.svg                 - Floppy disk save (16x16)
 *   icon-search.svg               - Magnifying glass, small (16x16)
 *   icon-search-lg.svg            - Magnifying glass, large (24x24)
 *   icon-send.svg                 - Paper plane/send (16x16)
 *   icon-settings-gear.svg        - Settings gear/cog (16x16)
 *   icon-shield-check.svg         - Shield with checkmark (24x24)
 *   icon-sort-arrow-down.svg      - Sort triangle down (10x5)
 *   icon-sort-arrow-up.svg        - Sort triangle up (10x5)
 *   icon-upload.svg               - Upload arrow with tray (16x16)
 *
 * Standard Icons (from Lucide icon library, 24x24):
 *   icon-activity.svg             - Activity/trend line
 *   icon-activity-line.svg        - Activity pulse line
 *   icon-alert-triangle.svg       - Warning triangle
 *   icon-archive.svg              - Archive box
 *   icon-arrow-down.svg           - Arrow down
 *   icon-arrow-right.svg          - Arrow right
 *   icon-arrow-up.svg             - Arrow up
 *   icon-arrow-up-down.svg        - Sort arrows up/down
 *   icon-bar-chart-2.svg          - Bar chart variant 2
 *   icon-bar-chart-3.svg          - Bar chart variant 3
 *   icon-building-2.svg           - Building/company
 *   icon-calendar.svg             - Calendar
 *   icon-check.svg                - Checkmark
 *   icon-check-circle.svg         - Check in circle
 *   icon-check-circle-2.svg       - Check in circle variant
 *   icon-check-square.svg         - Check in square
 *   icon-chevron-left-nav.svg     - Chevron left navigation
 *   icon-chevron-right.svg        - Chevron right
 *   icon-chevron-up.svg           - Chevron up
 *   icon-chevrons-down-up.svg     - Double chevrons collapse
 *   icon-chevrons-up-down.svg     - Double chevrons expand
 *   icon-circle.svg               - Circle outline
 *   icon-clipboard-list.svg       - Clipboard with list
 *   icon-clock.svg                - Clock
 *   icon-cpu.svg                  - CPU/processor
 *   icon-crosshair.svg            - Crosshair/target
 *   icon-dollar-sign.svg          - Dollar sign
 *   icon-edit.svg                 - Edit/pencil basic
 *   icon-edit-2.svg               - Edit/pencil with line
 *   icon-external-link.svg        - External link arrow
 *   icon-eye-off.svg              - Eye hidden/off
 *   icon-file.svg                 - File/document
 *   icon-file-text.svg            - File with text
 *   icon-folder-open.svg          - Open folder
 *   icon-globe.svg                - Globe
 *   icon-globe-full.svg           - Globe with meridians
 *   icon-history.svg              - History/undo
 *   icon-inbox.svg                - Inbox
 *   icon-info.svg                 - Info circle
 *   icon-key-round.svg            - Key/access
 *   icon-layers.svg               - Layers stacked
 *   icon-loader-2.svg             - Loading spinner
 *   icon-lock.svg                 - Lock/locked
 *   icon-mail.svg                 - Mail/email
 *   icon-map-pin.svg              - Map pin/location
 *   icon-maximize-2.svg           - Maximize/expand
 *   icon-message-square.svg       - Chat message
 *   icon-message-square-plus.svg  - New message
 *   icon-minimize-2.svg           - Minimize/collapse
 *   icon-paperclip.svg            - Paperclip/attachment
 *   icon-pencil.svg               - Pencil/edit
 *   icon-percent.svg              - Percentage
 *   icon-plus.svg                 - Plus/add
 *   icon-printer.svg              - Printer
 *   icon-receipt.svg              - Receipt
 *   icon-refresh-cw.svg           - Refresh/sync
 *   icon-rotate-ccw.svg           - Rotate counter-clockwise
 *   icon-settings.svg             - Settings sliders
 *   icon-shield.svg               - Shield
 *   icon-square.svg               - Square
 *   icon-tag.svg                  - Tag/label
 *   icon-target.svg               - Target/bullseye
 *   icon-trash-2.svg              - Trash/delete
 *   icon-trending-down.svg        - Trending down
 *   icon-trending-up.svg          - Trending up
 *   icon-unlock.svg               - Unlock/unlocked
 *   icon-user.svg                 - User/person
 *   icon-user-check.svg           - User verified
 *   icon-user-plus.svg            - Add user
 *   icon-users.svg                - Multiple users
 *   icon-x.svg                    - X/close
 *   icon-x-circle.svg             - X in circle
 *   icon-x-square.svg             - X in square
 */

// PNG Images
export { default as everestLogo } from './everest-logo.png';

// SVG Icons (alphabetical)
export { default as iconActivity } from './icon-activity.svg';
export { default as iconActivityLine } from './icon-activity-line.svg';
export { default as iconAlertCircle } from './icon-alert-circle.svg';
export { default as iconAlertTriangle } from './icon-alert-triangle.svg';
export { default as iconArchive } from './icon-archive.svg';
export { default as iconArrowDown } from './icon-arrow-down.svg';
export { default as iconArrowLeft } from './icon-arrow-left.svg';
export { default as iconArrowRight } from './icon-arrow-right.svg';
export { default as iconArrowUp } from './icon-arrow-up.svg';
export { default as iconArrowUpDown } from './icon-arrow-up-down.svg';
export { default as iconBarChart } from './icon-bar-chart.svg';
export { default as iconBarChart2 } from './icon-bar-chart-2.svg';
export { default as iconBarChart3 } from './icon-bar-chart-3.svg';
export { default as iconBell } from './icon-bell.svg';
export { default as iconBrandLogo } from './icon-brand-logo.svg';
export { default as iconBuilding2 } from './icon-building-2.svg';
export { default as iconCalendar } from './icon-calendar.svg';
export { default as iconChartBar } from './icon-chart-bar.svg';
export { default as iconCheck } from './icon-check.svg';
export { default as iconCheckCircle } from './icon-check-circle.svg';
export { default as iconCheckCircle2 } from './icon-check-circle-2.svg';
export { default as iconCheckSquare } from './icon-check-square.svg';
export { default as iconCheckmark } from './icon-checkmark.svg';
export { default as iconChevronDown } from './icon-chevron-down.svg';
export { default as iconChevronDownLg } from './icon-chevron-down-lg.svg';
export { default as iconChevronLeft } from './icon-chevron-left.svg';
export { default as iconChevronLeftNav } from './icon-chevron-left-nav.svg';
export { default as iconChevronRight } from './icon-chevron-right.svg';
export { default as iconChevronUp } from './icon-chevron-up.svg';
export { default as iconChevronsDownUp } from './icon-chevrons-down-up.svg';
export { default as iconChevronsUpDown } from './icon-chevrons-up-down.svg';
export { default as iconCircle } from './icon-circle.svg';
export { default as iconClipboardList } from './icon-clipboard-list.svg';
export { default as iconClock } from './icon-clock.svg';
export { default as iconClockHistory } from './icon-clock-history.svg';
export { default as iconClose } from './icon-close.svg';
export { default as iconCpu } from './icon-cpu.svg';
export { default as iconCrosshair } from './icon-crosshair.svg';
export { default as iconCurrency } from './icon-currency.svg';
export { default as iconDocumentText } from './icon-document-text.svg';
export { default as iconDollarSign } from './icon-dollar-sign.svg';
export { default as iconDownload } from './icon-download.svg';
export { default as iconEdit } from './icon-edit.svg';
export { default as iconEdit2 } from './icon-edit-2.svg';
export { default as iconExternalLink } from './icon-external-link.svg';
export { default as iconEye } from './icon-eye.svg';
export { default as iconEyeOff } from './icon-eye-off.svg';
export { default as iconFile } from './icon-file.svg';
export { default as iconFileText } from './icon-file-text.svg';
export { default as iconFilter } from './icon-filter.svg';
export { default as iconFolder } from './icon-folder.svg';
export { default as iconFolderOpen } from './icon-folder-open.svg';
export { default as iconFullscreen } from './icon-fullscreen.svg';
export { default as iconGlobe } from './icon-globe.svg';
export { default as iconGlobeFull } from './icon-globe-full.svg';
export { default as iconHistory } from './icon-history.svg';
export { default as iconImagePlaceholder } from './icon-image-placeholder.svg';
export { default as iconInbox } from './icon-inbox.svg';
export { default as iconInfo } from './icon-info.svg';
export { default as iconInfoCircle } from './icon-info-circle.svg';
export { default as iconKeyRound } from './icon-key-round.svg';
export { default as iconLayers } from './icon-layers.svg';
export { default as iconLoader2 } from './icon-loader-2.svg';
export { default as iconLock } from './icon-lock.svg';
export { default as iconMail } from './icon-mail.svg';
export { default as iconMapPin } from './icon-map-pin.svg';
export { default as iconMaximize2 } from './icon-maximize-2.svg';
export { default as iconMessageSquare } from './icon-message-square.svg';
export { default as iconMessageSquarePlus } from './icon-message-square-plus.svg';
export { default as iconMinimize2 } from './icon-minimize-2.svg';
export { default as iconPaperclip } from './icon-paperclip.svg';
export { default as iconPencil } from './icon-pencil.svg';
export { default as iconPercent } from './icon-percent.svg';
export { default as iconPlus } from './icon-plus.svg';
export { default as iconPrinter } from './icon-printer.svg';
export { default as iconReceipt } from './icon-receipt.svg';
export { default as iconRefreshCw } from './icon-refresh-cw.svg';
export { default as iconRotateCcw } from './icon-rotate-ccw.svg';
export { default as iconSave } from './icon-save.svg';
export { default as iconSearch } from './icon-search.svg';
export { default as iconSearchLg } from './icon-search-lg.svg';
export { default as iconSend } from './icon-send.svg';
export { default as iconSettings } from './icon-settings.svg';
export { default as iconSettingsGear } from './icon-settings-gear.svg';
export { default as iconShield } from './icon-shield.svg';
export { default as iconShieldCheck } from './icon-shield-check.svg';
export { default as iconSortArrowDown } from './icon-sort-arrow-down.svg';
export { default as iconSortArrowUp } from './icon-sort-arrow-up.svg';
export { default as iconSquare } from './icon-square.svg';
export { default as iconTag } from './icon-tag.svg';
export { default as iconTarget } from './icon-target.svg';
export { default as iconTrash2 } from './icon-trash-2.svg';
export { default as iconTrendingDown } from './icon-trending-down.svg';
export { default as iconTrendingUp } from './icon-trending-up.svg';
export { default as iconUnlock } from './icon-unlock.svg';
export { default as iconUpload } from './icon-upload.svg';
export { default as iconUser } from './icon-user.svg';
export { default as iconUserCheck } from './icon-user-check.svg';
export { default as iconUserPlus } from './icon-user-plus.svg';
export { default as iconUsers } from './icon-users.svg';
export { default as iconX } from './icon-x.svg';
export { default as iconXCircle } from './icon-x-circle.svg';
export { default as iconXSquare } from './icon-x-square.svg';
